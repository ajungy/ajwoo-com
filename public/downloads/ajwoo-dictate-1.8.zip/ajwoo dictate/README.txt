ajwoo dictate
=============

Talk instead of type, on your Mac. Double-tap a key, speak, double-tap again,
and your words appear wherever your cursor is.

By GG Creative Studios, LLC.


WHAT YOU NEED
-------------

• A Mac with Apple Silicon (M1 or newer), macOS 13 or later
• About 3 GB of free space
• An internet connection for the one-time setup

Nothing else. You don't need to install anything else first.


GETTING STARTED
---------------

1. Double-click "ajwoo dictate.zip" to unzip it, then drag
   "ajwoo dictate" into your Applications folder.

2. Double-click "ajwoo dictate" in Applications to open it. If your Mac
   asks whether you want to open an app downloaded from the internet,
   click "Open".
   Updating from an older version? First quit the old one (click the
   ajwoo dictate icon in the menu bar → Quit), then replace it.
   If you see "can't be opened (-47)", do that, wait a few seconds for
   unzipping or copying to finish, and open it again.

3. A welcome window appears. Click "Download".
   The app sets itself up and downloads its speech models (a few minutes
   on a good connection). You can close the window; it keeps going.

4. When your Mac asks, click "Allow" for the Microphone, and turn on
   ajwoo dictate under Accessibility. This lets it hear you and type
   for you.

That's it.


USING IT
--------

• Double-tap Control (⌃) to start talking. Double-tap again to stop.
  Your words are typed where your cursor is.
• Change the key, language, and more by clicking the menu bar icon →
  Settings.
• Dictate Log (menu bar icon) shows what you've dictated recently.


PRIVACY
-------

Your speech is turned into text on your Mac. The app has no accounts, no
ads, and no tracking. Full details: menu bar icon → Legal → Privacy Policy.


LEGAL
-----

Use of ajwoo dictate is subject to the License Agreement and Privacy Policy
(menu bar icon → Legal). Third-party components and their licenses are
listed in THIRD-PARTY-NOTICES.txt. Parakeet TDT 0.6B v3 by NVIDIA is used
under CC BY 4.0.

© 2026 GG Creative Studios, LLC. All rights reserved.
