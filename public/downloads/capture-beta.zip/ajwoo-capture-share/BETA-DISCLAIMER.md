# ⚠️ Beta / testing build — please read before using

**ajwoo capture is still in active development.** What you have here is a
beta build, shared for **testing and educational purposes only** — it is
not a finished product, and it has not gone through the kind of testing a
released app would.

## No warranty, no liability

This software is provided **"as is," without warranty of any kind**, express
or implied — including, without limitation, any warranty that it will work
correctly, record what you expect, or not lose, corrupt, or damage any
recording, file, or data on your Mac.

**You use it entirely at your own risk.** To the fullest extent permitted by
law, the developer accepts **no responsibility and no liability** for any
damage, loss, or harm arising from installing or using this build —
including but not limited to lost recordings, corrupted files, data loss,
system issues, or any other direct, indirect, incidental, or consequential
damage.

If that's not an acceptable level of risk for how you plan to use it —
recording something you can't redo, for instance — please don't use this
build for it.

## What this build is for

- Trying out features before they're finished.
- Giving feedback that shapes what ships later.
- Learning how the app is built, if you're looking at the source.

It is **not** a commercial release, is **not** sold, and carries none of the
guarantees a finished, purchased product would.

## Bugs and missing pieces are expected

A beta means things can and will break — a crash, a feature that doesn't
work yet, a recording that doesn't come out right. Please don't rely on this
build for anything you can't afford to lose or redo.

---

*Drafted as a plain-language beta notice for informal testing among friends —
this is not a substitute for reviewed legal terms, and isn't intended as
legal advice. `EULA.md` and `PRIVACY.md` in the `source` folder are separate,
more detailed drafts (also unreviewed) written for an eventual public
release, if you want the longer version.*
