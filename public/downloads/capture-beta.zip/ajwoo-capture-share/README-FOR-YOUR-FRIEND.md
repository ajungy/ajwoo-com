# ajwoo capture — trying it out without an Apple Developer account

**Please read [BETA-DISCLAIMER.md](BETA-DISCLAIMER.md) first** — this is a
beta build, shared for testing and educational purposes only.

This app isn't notarized (that needs a paid $99/year Apple Developer account),
so macOS Gatekeeper will refuse to open it the normal way — you'll need to
tell your Mac you trust it, once. That's the only thing "no developer
account" changes; everything else about the app works normally.

## Option A — just try the app (fastest)

The `ajwoo capture.app` sitting next to this file is already built and ready
to run. It only works on **Apple Silicon Macs** (M1/M2/M3/M4 — anything from
late 2020 onward). If you have an Intel Mac, skip to Option B instead.

1. **Move `ajwoo capture.app`** out of this folder into your `Applications`
   folder (or anywhere you like — it doesn't need to stay here).
2. **Right-click (or Control-click) the app → Open.** A dialog will warn you
   it's from an unidentified developer — click **Open** on that dialog. (Do
   this once; after that, opening it normally works.)
   - If instead of that dialog macOS says the app **"is damaged and can't be
     opened,"** that's Gatekeeper's quarantine flag, not actual damage. Open
     Terminal (Applications → Utilities → Terminal), type the line below,
     press Return, then try opening the app again:
     ```
     xattr -cr "/Applications/ajwoo capture.app"
     ```
     (adjust the path if you put the app somewhere other than Applications)
   - If neither works, go to **System Settings → Privacy & Security**, scroll
     down, and look for a note about `ajwoo capture` being blocked, with an
     **"Open Anyway"** button.
3. **Grant permissions when asked.** The app needs Screen Recording (and
   Camera/Microphone if you want to record those too) — macOS will prompt you
   the first time you pick a camera or microphone, or hit Record. If you miss
   a prompt, go to **System Settings → Privacy & Security → Screen
   Recording** (and Camera / Microphone) and enable it there, then relaunch
   the app.

That's it — no account, no payment, no App Store.

## Option B — build it yourself from source

Use this if Option A's app won't open on your Mac (wrong chip architecture),
or if you just want to build it yourself.

1. **Install the free Xcode Command Line Tools** (not full Xcode — this is a
   much smaller download). Open Terminal and run:
   ```
   xcode-select --install
   ```
   Follow the prompts. This alone gives you everything needed to build a
   Swift app — no Xcode, no App Store, no Apple Developer account.
2. **Open Terminal in the `source` folder** next to this file (drag the
   `source` folder onto the Terminal icon, or `cd` into it manually).
3. **Build it**, signing it "ad hoc" (a placeholder signature that only needs
   your own Mac to trust, not Apple):
   ```
   AJWOO_SIGN_IDENTITY="-" ./scripts/make_app.sh
   ```
   This takes about a minute or two. When it finishes, you'll have a fresh
   `ajwoo capture.app` right there in the `source` folder — open it the same
   way as Option A (right-click → Open, and the `xattr -cr` fallback above if
   needed).

## Why any of this is necessary

Apple ties "can this app be opened without a warning" to a paid Developer ID
certificate and a notarization step, which costs the developer $99/year and
some extra tooling. None of that affects what the app actually does on your
Mac once you've told Gatekeeper you trust it — the ad-hoc or unsigned build
is the exact same code, it just doesn't carry Apple's stamp of "we scanned
this and know who published it."

## What this app does with your data

Worth knowing up front: **ajwoo capture makes no network connections at
all** — no analytics, no telemetry, no account, nothing sent anywhere.
Everything it records stays in files on your own Mac, in a folder you
choose. (You can verify this yourself: there's no `URLSession` or networking
code anywhere in `source/Sources/`.)

## If something goes wrong

Screen recording and camera/mic access are controlled per-app by macOS. If
the app never gets to the permission prompt, or a permission you granted
seems to have been "forgotten," it's usually because the app was rebuilt (a
new build gets a new identity in Gatekeeper's eyes) — just re-grant it in
**System Settings → Privacy & Security**.

This is a beta build — see [BETA-DISCLAIMER.md](BETA-DISCLAIMER.md) for what
that means and what it doesn't come with.
