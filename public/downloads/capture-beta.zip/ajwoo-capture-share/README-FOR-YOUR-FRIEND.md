# ajwoo capture — trying it out

**Please read [BETA-DISCLAIMER.md](BETA-DISCLAIMER.md) first** — this is a
beta build, shared for testing and educational purposes only.

## Good news: this build is properly signed

Unlike an earlier version of this package, `ajwoo capture.app` is now signed
with a real **Apple Developer ID** certificate (GG Creative Studios, LLC) —
not a self-signed or "ad hoc" placeholder. That means macOS can verify who
actually built it.

**One thing is still missing: notarization.** That's a separate step where
Apple scans the app and vouches for it specifically (not just the identity
behind it), and it hasn't been done for this build yet. In practice this
means you'll still see **one** Gatekeeper prompt the first time you open it —
a calmer one than an unsigned app gets ("Apple could not verify this app is
free of malware," with an **Open Anyway** option), rather than the more
alarming unidentified-developer warning. After that one-time click, it opens
normally.

## Opening it

1. **Move `ajwoo capture.app`** into your `Applications` folder (or anywhere
   you like).
2. **Try double-clicking it first.** If it just opens, you're done.
3. If macOS blocks it, go to **System Settings → Privacy & Security**, scroll
   down, and click **Open Anyway** next to the note about `ajwoo capture`.
   Then open it again from Applications/Launchpad and confirm.
4. It only works on **Apple Silicon Macs** (M1/M2/M3/M4, late 2020 onward).
   If you're on an Intel Mac, see "Building from source" below.
5. **Grant permissions when asked** — Screen Recording (and Camera/Microphone
   if you want those too). If you miss a prompt, enable it manually in
   **System Settings → Privacy & Security**, then relaunch the app.

## Building from source

If Option above doesn't work for your Mac's chip, or you just want to build
it yourself:

1. Install the free Xcode Command Line Tools (not full Xcode): open Terminal
   and run `xcode-select --install`.
2. Open Terminal in the `source` folder next to this file.
3. Run:
   ```
   AJWOO_SIGN_IDENTITY="-" ./scripts/make_app.sh
   ```
   This signs it "ad hoc" instead — you'll get the stronger "unidentified
   developer" prompt in that case (right-click → Open to get past it), since
   an ad-hoc build carries no real identity at all.

## What this app does with your data

**ajwoo capture makes no network connections at all** — no analytics, no
telemetry, no account, nothing sent anywhere. Everything it records stays in
files on your own Mac, in a folder you choose. You can verify this yourself:
there's no `URLSession` or networking code anywhere in `source/Sources/`.

## If something goes wrong

If a permission you granted seems to have been "forgotten," it's usually
because the app was rebuilt (a new build can get a new identity in
Gatekeeper's eyes, especially an ad-hoc one) — just re-grant it in
**System Settings → Privacy & Security**.

This is a beta build — see [BETA-DISCLAIMER.md](BETA-DISCLAIMER.md) for what
that means and what it doesn't come with.
