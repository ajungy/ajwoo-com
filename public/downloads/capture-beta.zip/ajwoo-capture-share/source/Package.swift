// swift-tools-version:5.9
import PackageDescription

// "ajwoo capture" builds as a plain SwiftPM executable; `scripts/make_app.sh`
// wraps the binary in a proper .app bundle (Info.plist + codesign) so TCC will
// grant it Screen Recording / Camera / Microphone access.
//
// The target is `AjwooCapture` (a valid Swift identifier); every user-visible
// surface says "ajwoo capture" and comes from `AppInfo.name` / Info.plist.
//
// No external dependencies. Everything comes from Apple's SDK.
let package = Package(
    name: "AjwooCapture",
    platforms: [.macOS(.v14)],
    targets: [
        .executableTarget(
            name: "AjwooCapture",
            path: "Sources/AjwooCapture"
        )
    ]
)
