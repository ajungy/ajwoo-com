# End User License Agreement — ajwoo capture

**⚠️ DRAFT — not reviewed by an attorney. Fill in every `[DECISION: ...]` and get
`[COUNSEL: ...]` items reviewed before this governs a real sale. See
`GTM-STATUS.md`.**

**Version 0.1 — draft, not yet published**
**Last updated:** [DECISION: set the date you actually publish this]

This End User License Agreement ("Agreement") is between you ("Licensee") and
[DECISION: your LLC's exact legal name], a [DECISION: state] limited liability
company ("Licensor," "we," "us"), and governs your use of the software
application "ajwoo capture" (the "Software").

BY DOWNLOADING, INSTALLING, OR USING THE SOFTWARE, YOU AGREE TO THIS AGREEMENT.
IF YOU DO NOT AGREE, DO NOT INSTALL OR USE THE SOFTWARE.

## 1. License Grant

Subject to your compliance with this Agreement and payment of the applicable
fee, Licensor grants you a limited, non-exclusive, non-transferable,
non-sublicensable, revocable license to install and use one copy of the
Software on Macintosh computers that you own or control, for your personal or
internal business use.

[DECISION: license scope — per-user, per-device, or per-purchase with no
device limit? Most one-time-purchase indie Mac apps allow install on
multiple personal devices owned by the same buyer. Pick one and state it here.]

The Software is **licensed, not sold**. Licensor retains all right, title, and
interest in and to the Software, including all intellectual property rights.

## 2. Restrictions

You may not:
- Reverse engineer, decompile, or disassemble the Software, except to the
  extent applicable law expressly permits despite this restriction
- Redistribute, resell, rent, lease, or sublicense the Software
- Remove or alter any proprietary notices
- Use the Software to build a competing product
- Use the Software in connection with any life-support, weapons, nuclear, or
  aviation-safety system

## 3. Updates

Licensor may, but is not obligated to, provide updates to the Software.
[DECISION: are updates included free with the purchase, or a separate
purchase? State plainly — buyers will ask.] The Software makes **no network
calls of any kind** and therefore does not check for or install updates
automatically; you will need to download any new version yourself from
[DECISION: your distribution URL].

## 4. Your Data

The Software runs entirely on your device. It records screen video, and
optionally camera and microphone, to files stored locally on your Mac. **The
Software does not transmit any of your data — recordings, transcripts,
settings, or anything else — to Licensor or to any third party, at any time.**
See the Privacy Policy for the full explanation of what the Software does and
does not do with your data.

## 5. Disclaimer of Warranties

THE SOFTWARE IS PROVIDED "AS IS" AND "AS AVAILABLE," WITHOUT WARRANTY OF ANY
KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES
OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, TITLE, AND
NON-INFRINGEMENT. LICENSOR DOES NOT WARRANT THAT THE SOFTWARE WILL BE
UNINTERRUPTED, ERROR-FREE, OR THAT ANY RECORDING WILL BE SUCCESSFULLY CAPTURED
OR SAVED.

*[Note: some jurisdictions do not allow the exclusion of certain implied
warranties for consumer transactions — see §9.]*

## 6. Limitation of Liability

TO THE MAXIMUM EXTENT PERMITTED BY LAW, LICENSOR WILL NOT BE LIABLE FOR ANY
INDIRECT, INCIDENTAL, SPECIAL, CONSEQUENTIAL, EXEMPLARY, OR PUNITIVE DAMAGES,
OR ANY LOSS OF PROFITS, REVENUE, DATA, OR GOODWILL, ARISING FROM YOUR USE OF
THE SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.

LICENSOR'S TOTAL AGGREGATE LIABILITY UNDER THIS AGREEMENT WILL NOT EXCEED THE
AMOUNT YOU PAID FOR THE SOFTWARE IN THE 12 MONTHS PRECEDING THE CLAIM, OR
[DECISION: a fixed floor, e.g. $50], WHICHEVER IS GREATER.

`[DECISION: cap amount — the template above uses a common floor; confirm it fits.]`

## 7. Termination

This license terminates automatically if you breach this Agreement. Upon
termination, you must delete all copies of the Software. Recordings you have
already made remain yours; this Agreement does not affect ownership of your
own content.

## 8. Governing Law

This Agreement is governed by the laws of [DECISION: your state], without
regard to conflict-of-laws principles, and any dispute will be resolved
exclusively in the state or federal courts located in [DECISION: your county/state].

`[COUNSEL: if you want binding arbitration with a class-action waiver — the
strongest protection against mass consumer claims — that clause needs a
lawyer's drafting. It is not included in this draft.]`

## 9. Consumer Rights Notice

If you are a consumer located in the European Union, the United Kingdom, or
Australia, certain rights under local consumer protection law cannot be
excluded or limited by this Agreement regardless of what it says, including
statutory withdrawal rights and non-excludable quality guarantees. Nothing in
this Agreement limits those rights.

## 10. Export Compliance

The Software may be subject to US export control laws. You represent that you
are not located in a country subject to a US embargo, and are not on any US
government restricted-party list.

## 11. Changes to This Agreement

Licensor may update this Agreement for future versions of the Software.
Continued use of a version after a material change requires your acceptance
of the updated Agreement before that version is installed.

## 12. Contact

[DECISION: a real support email address]

---

*Third-party notices: the Software has zero third-party dependencies — it is
built entirely on Apple's own frameworks (AVFoundation, ScreenCaptureKit,
Core Image, Speech, SwiftUI). There is nothing to disclose in a
`THIRD-PARTY-NOTICES.txt`.*
