# End User License Agreement — ajwoo capture

**⚠️ DRAFT — not reviewed by an attorney. Fill in every `[DECISION: ...]` and get
`[COUNSEL: ...]` items reviewed before this governs real commercial sales at
scale. See `GTM-STATUS.md`.** This version was strengthened for commercial
distribution — it adds indemnification and a draft arbitration/class-action
waiver, the two clauses that do the most to cap mass-consumer-claim exposure —
but "maximum protection" is a spectrum, not a switch, and the items still
marked below are the ones that actually need a licensed attorney before this
should be relied on at real revenue.

**Version 0.2 — draft, not yet published**
**Last updated:** [DECISION: set the date you actually publish this]

This End User License Agreement ("Agreement") is between you ("Licensee") and
**GG Creative Studios, LLC**, a [DECISION: state of formation — e.g. "Delaware"
or "California"] limited liability company ("Licensor," "we," "us"), and
governs your use of the software application "ajwoo capture" (the "Software").

BY DOWNLOADING, INSTALLING, OR USING THE SOFTWARE, YOU AGREE TO THIS AGREEMENT.
IF YOU DO NOT AGREE, DO NOT INSTALL OR USE THE SOFTWARE.

## 1. License Grant

Subject to your compliance with this Agreement and payment of the applicable
fee, Licensor grants you a limited, non-exclusive, non-transferable,
non-sublicensable, revocable license to install and use the Software on any
Macintosh computer you personally own or control, for your personal or
internal business use.

`[DECISION: this draft assumes "unlimited personal devices, one buyer" — the
common choice for a one-time-purchase indie Mac app. If you'd rather license
per-device or per-seat, replace this paragraph.]`

The Software is **licensed, not sold**. Licensor retains all right, title, and
interest in and to the Software, including all intellectual property rights.

## 2. Restrictions

You may not:
- Reverse engineer, decompile, or disassemble the Software, except to the
  extent applicable law expressly permits despite this restriction
- Redistribute, resell, rent, lease, or sublicense the Software
- Remove or alter any proprietary notices
- Use the Software to build a competing product
- Use the Software in connection with any life-support, weapons, nuclear, or
  aviation-safety system
- Use the Software to record any person without the consent required by the
  laws that apply to you — screen and audio recording laws vary by
  jurisdiction (some US states require all-party consent to record audio),
  and compliance with those laws is your responsibility, not the Software's

## 3. Updates

Licensor may, but is not obligated to, provide updates to the Software.
Updates within the same major version (e.g. 1.1, 1.2) are included free with
your purchase; Licensor may offer a future major version as a separate paid
upgrade, and will say so clearly before charging for one. The Software makes
**no network calls of any kind** and therefore does not check for or install
updates automatically; you will need to download any new version yourself
from `[DECISION: your distribution URL, e.g. https://ajwoo.com/capture]`.

## 4. Your Data

The Software runs entirely on your device. It records screen video, and
optionally camera and microphone, to files stored locally on your Mac. **The
Software does not transmit any of your data — recordings, transcripts,
settings, or anything else — to Licensor or to any third party, at any time.**
See the Privacy Policy for the full explanation of what the Software does and
does not do with your data.

## 5. Disclaimer of Warranties

THE SOFTWARE IS PROVIDED "AS IS" AND "AS AVAILABLE," WITHOUT WARRANTY OF ANY
KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES
OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, TITLE, AND
NON-INFRINGEMENT. LICENSOR DOES NOT WARRANT THAT THE SOFTWARE WILL BE
UNINTERRUPTED, ERROR-FREE, OR THAT ANY RECORDING WILL BE SUCCESSFULLY CAPTURED
OR SAVED.

*[Note: some jurisdictions do not allow the exclusion of certain implied
warranties for consumer transactions — see §10.]*

## 6. Limitation of Liability

TO THE MAXIMUM EXTENT PERMITTED BY LAW, LICENSOR WILL NOT BE LIABLE FOR ANY
INDIRECT, INCIDENTAL, SPECIAL, CONSEQUENTIAL, EXEMPLARY, OR PUNITIVE DAMAGES,
OR ANY LOSS OF PROFITS, REVENUE, DATA, OR GOODWILL, ARISING FROM YOUR USE OF
THE SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.

LICENSOR'S TOTAL AGGREGATE LIABILITY UNDER THIS AGREEMENT WILL NOT EXCEED THE
GREATER OF (A) THE AMOUNT YOU PAID FOR THE SOFTWARE IN THE 12 MONTHS PRECEDING
THE CLAIM, OR (B) FIFTY US DOLLARS ($50).

`[DECISION: $50 is a common indie-software floor. Raise it if you'd rather;
this is one of the few numbers in this document that's purely your call, not
a legal requirement.]`

This limitation does not apply to liability that cannot be limited under
applicable law, including liability for death, personal injury, fraud, or
gross negligence.

## 7. Indemnification

You agree to indemnify, defend, and hold harmless Licensor and its officers,
members, and employees from any claim, demand, loss, or expense (including
reasonable attorneys' fees) arising from: (a) your use of the Software in
violation of this Agreement or applicable law; (b) any recording you make,
including any claim that a recording violated a third party's privacy,
publicity, or other rights; or (c) your violation of any third party's
rights.

`[COUNSEL: this is a standard-form indemnification clause. It's the paired
half of §6's liability cap — you're capping what you owe a customer while
having them cover what your customer's own misuse (recording someone without
consent, say) could cost you. Have it reviewed alongside the arbitration
clause below.]`

## 8. Termination

This license terminates automatically if you breach this Agreement. Upon
termination, you must delete all copies of the Software. Recordings you have
already made remain yours; this Agreement does not affect ownership of your
own content.

## 9. Governing Law and Dispute Resolution

This Agreement is governed by the laws of [DECISION: your state], without
regard to conflict-of-laws principles.

**Agreement to Arbitrate.** Any dispute, claim, or controversy arising out of
or relating to this Agreement or the Software will be resolved by **binding
individual arbitration**, not in court, except that either party may bring an
individual claim in small claims court. **YOU AND LICENSOR EACH WAIVE THE
RIGHT TO A JURY TRIAL AND THE RIGHT TO PARTICIPATE IN A CLASS ACTION,
CLASS ARBITRATION, OR REPRESENTATIVE PROCEEDING.** Arbitration will be
administered by [COUNSEL: name an arbitration provider — AAA and JAMS are the
two most commonly used] under its rules then in effect, seated in
[DECISION: your county/state].

`[COUNSEL: this is the single highest-value clause for protecting a solo
developer against mass consumer claims, and it is also the one most likely to
be thrown out if drafted wrong — enforceability turns on clear notice, an
opt-out window (many enforceable clauses give users 30 days to opt out in
writing), and not being unconscionably one-sided. Do not rely on the
paragraph above as final; have an attorney confirm or rewrite it before this
governs a real dispute. It is included here as a placeholder marking where
that protection goes, not as ready-to-use language.]`

## 10. Consumer Rights Notice

If you are a consumer located in the European Union, the United Kingdom, or
Australia, certain rights under local consumer protection law cannot be
excluded or limited by this Agreement regardless of what it says, including
statutory withdrawal rights, non-excludable quality guarantees, and (in some
cases) the right to bring a claim despite the arbitration clause above.
Nothing in this Agreement limits those rights.

## 11. Export Compliance

The Software may be subject to US export control laws. You represent that you
are not located in a country subject to a US embargo, and are not on any US
government restricted-party list.

## 12. Changes to This Agreement

Licensor may update this Agreement for future versions of the Software.
Continued use of a version after a material change requires your acceptance
of the updated Agreement before that version is installed.

## 13. Contact

[DECISION: a real support email address — e.g. support@ajwoo.com or
alex@ajwoo.com]

---

*Third-party notices: the Software has zero third-party dependencies — it is
built entirely on Apple's own frameworks (AVFoundation, ScreenCaptureKit,
Core Image, Speech, SwiftUI). There is nothing to disclose in a
`THIRD-PARTY-NOTICES.txt`.*
