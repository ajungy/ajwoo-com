import AppKit
import AVFoundation

/// One small poster frame per recording, for the list.
///
/// Cached in memory *and* on disk inside the package as `poster.jpg`, so the
/// list is instant on every launch after the first. Generation is capped to a
/// couple at a time — a folder of thirty recordings shouldn't spawn thirty
/// concurrent `AVAssetImageGenerator`s and stall the UI on first open.
actor RecordingThumbnails {
    static let shared = RecordingThumbnails()

    private var cache: [URL: NSImage] = [:]
    private var inFlight: [URL: Task<NSImage?, Never>] = [:]
    private let gate = AsyncGate(limit: 2)

    /// Small: it draws at 64×36, so anything larger is wasted decode time.
    private static let pixelWidth: CGFloat = 160

    func thumbnail(for session: RecordingSession) async -> NSImage? {
        if let cached = cache[session.url] { return cached }
        if let existing = inFlight[session.url] { return await existing.value }

        let task = Task<NSImage?, Never> { [gate] in
            // Disk cache first — decoding a small JPEG is far cheaper than
            // seeking into an HEVC master.
            let posterURL = session.url.appendingPathComponent("poster.jpg")
            if let data = try? Data(contentsOf: posterURL), let image = NSImage(data: data) {
                return image
            }

            await gate.wait()
            defer { Task { await gate.signal() } }

            guard FileManager.default.fileExists(atPath: session.screenVideoURL.path) else { return nil }
            let asset = AVURLAsset(url: session.screenVideoURL)
            let generator = AVAssetImageGenerator(asset: asset)
            generator.appliesPreferredTrackTransform = true
            generator.maximumSize = CGSize(width: Self.pixelWidth, height: Self.pixelWidth)
            // Generous tolerance: any nearby frame will do, and an exact seek
            // costs a full GOP decode.
            generator.requestedTimeToleranceBefore = CMTime(seconds: 2, preferredTimescale: 600)
            generator.requestedTimeToleranceAfter = CMTime(seconds: 2, preferredTimescale: 600)

            guard let cgImage = try? await generator.image(at: CMTime(seconds: 1, preferredTimescale: 600)).image
            else { return nil }

            let image = NSImage(cgImage: cgImage, size: .zero)
            if let tiff = image.tiffRepresentation,
               let bitmap = NSBitmapImageRep(data: tiff),
               let jpeg = bitmap.representation(using: .jpeg, properties: [.compressionFactor: 0.7]) {
                try? jpeg.write(to: posterURL, options: .atomic)
            }
            return image
        }

        inFlight[session.url] = task
        let image = await task.value
        inFlight[session.url] = nil
        if let image { cache[session.url] = image }
        return image
    }

    func forget(_ session: RecordingSession) {
        cache[session.url] = nil
        inFlight[session.url]?.cancel()
        inFlight[session.url] = nil
    }
}

/// Minimal counting semaphore for async callers.
private actor AsyncGate {
    private var available: Int
    private var waiters: [CheckedContinuation<Void, Never>] = []

    init(limit: Int) { available = limit }

    func wait() async {
        if available > 0 { available -= 1; return }
        await withCheckedContinuation { waiters.append($0) }
    }

    func signal() {
        if waiters.isEmpty { available += 1 } else { waiters.removeFirst().resume() }
    }
}
