import AppKit
import SwiftUI

/// The menu bar mark, in its three states.
///
/// # Why this draws an NSImage instead of composing SwiftUI shapes
/// The first version was a `ZStack` of `Circle`s wrapped in `TimelineView`, and
/// it rendered as *nothing at all* — the status item was invisible, so there was
/// no way into the app from the menu bar. A `MenuBarExtra` label isn't a normal
/// SwiftUI view: it's flattened into a status item's image, and arbitrary
/// vector content with a continuously-updating timeline doesn't survive the
/// trip. An `NSImage` marked as a template does, and it also gets the menu bar's
/// automatic light/dark and highlight handling for free.
///
/// The states:
/// - **Idle** — the mark, quiet.
/// - **Recording** — the dot breathes, small to large, on a 1.6 s cycle. The menu
///   bar is monochrome, so motion is the only signal available.
/// - **Processing** — the take has stopped and the editor is being prepared; an
///   arc sweeps round the mark, which reads as "working" rather than "armed".
enum MenuBarIcon {

    enum Phase: Equatable {
        case idle
        case recording
        case processing
    }

    static let side: CGFloat = 18

    /// `progress` runs 0...1 and drives whichever animation the phase implies.
    static func image(phase: Phase, progress: Double) -> NSImage {
        let size = NSSize(width: side, height: side)
        let image = NSImage(size: size, flipped: false) { _ in
            guard let ctx = NSGraphicsContext.current?.cgContext else { return true }
            ctx.setAllowsAntialiasing(true)

            let unit = side
            let inset = unit * 0.07
            let box = CGRect(x: inset, y: inset, width: unit - inset * 2, height: unit - inset * 2)

            switch phase {
            case .idle, .recording:
                // Rounded square outline plus centre dot — the same mark as the
                // app icon, at the Figma proportions (500 pt square, 46 stroke,
                // 200 dot inside an 840 tile).
                // The icon's own proportion, 46/500 of the square's width. It
                // was being drawn at 2.2x that "for legibility", which made the
                // menu bar mark a thick blob next to a thin-lined app icon —
                // recognisably not the same logo. The floor keeps it from
                // vanishing on a 1x display; at 2x the true weight is crisp.
                let stroke = max(1, box.width * (46.0 / 500.0))
                let radius = box.width * (100.0 / 500.0)
                ctx.addPath(CGPath(roundedRect: box.insetBy(dx: stroke / 2, dy: stroke / 2),
                                   cornerWidth: radius, cornerHeight: radius, transform: nil))
                ctx.setStrokeColor(NSColor.black.cgColor)
                ctx.setLineWidth(stroke)
                ctx.strokePath()

                // Only the dot scales, so the outline stays put and the movement
                // reads as one thing changing rather than the icon jumping.
                let scale: CGFloat = phase == .recording
                    ? 0.60 + 0.40 * CGFloat((sin(progress * 2 * .pi) + 1) / 2)
                    : 1
                let dot = box.width * (200.0 / 500.0) * scale
                ctx.setFillColor(NSColor.black.cgColor)
                ctx.fillEllipse(in: CGRect(x: box.midX - dot / 2, y: box.midY - dot / 2,
                                           width: dot, height: dot))

            case .processing:
                let stroke = unit * 0.13
                let radius = (box.width - stroke) / 2
                let centre = CGPoint(x: box.midX, y: box.midY)

                ctx.setStrokeColor(NSColor.black.withAlphaComponent(0.3).cgColor)
                ctx.setLineWidth(stroke)
                ctx.addArc(center: centre, radius: radius, startAngle: 0,
                           endAngle: .pi * 2, clockwise: false)
                ctx.strokePath()

                let start = -progress * .pi * 2
                ctx.setStrokeColor(NSColor.black.cgColor)
                ctx.setLineWidth(stroke)
                ctx.setLineCap(.round)
                ctx.addArc(center: centre, radius: radius, startAngle: start,
                           endAngle: start - .pi * 0.6, clockwise: true)
                ctx.strokePath()
            }
            return true
        }
        // Template: the menu bar inverts it for dark mode and for the highlighted
        // state, which hand-picked colours would get wrong.
        image.isTemplate = true
        return image
    }
}
