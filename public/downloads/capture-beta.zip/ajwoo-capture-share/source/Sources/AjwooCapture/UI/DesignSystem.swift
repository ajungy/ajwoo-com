import SwiftUI
import AppKit

/// The Minimal design system, expressed for SwiftUI/AppKit.
///
/// A direct port of `minimal/tokens/tokens.json` — the same semantic names, the
/// same values. Nothing here is invented; if a colour is needed that isn't in
/// this file, the design is wrong rather than the token set being incomplete.
///
/// Colours are built as dynamic `NSColor`s so a single token resolves correctly
/// in both appearances. That's the AppKit equivalent of `data-theme` on `<html>`:
/// one name, two values, resolved at draw time.
enum DS {

    // MARK: - Colour

    /// Page, cards, wells, menus.
    enum Surface {
        static let page     = dynamic(light: "#FFFFFF", dark: "#0E0E10")
        static let raised   = dynamic(light: "#FFFFFF", dark: "#18181B")
        static let sunken   = dynamic(light: "#F7F7F8", dark: "#09090B")
        static let overlay  = dynamic(light: "#FFFFFF", dark: "#1C1C20")
        static let inverse  = dynamic(light: "#0E0E10", dark: "#FFFFFF")
        static let hover    = dynamic(light: "#F7F7F8", dark: "#FFFFFF0F")
        static let active   = dynamic(light: "#F1F1F3", dark: "#FFFFFF1A")
        static let selected = dynamic(light: "#F1F1F3", dark: "#FFFFFF14")
    }

    enum Text {
        static let primary   = dynamic(light: "#0E0E10", dark: "#F2F2F3")
        static let secondary = dynamic(light: "#56565C", dark: "#A1A1A8")
        static let tertiary  = dynamic(light: "#71717A", dark: "#8A8A92")
        static let disabled  = dynamic(light: "#A5A5AE", dark: "#5A5A62")
        static let inverse   = dynamic(light: "#FFFFFF", dark: "#0E0E10")
    }

    /// One line weight, four strengths. `control` is deliberately darker: it's
    /// the resting outline of anything identified only by its boundary, and it
    /// has to clear 3:1 on its own.
    enum Border {
        static let subtle  = dynamic(light: "#E4E4E7", dark: "#232327")
        static let `default` = dynamic(light: "#D2D2D8", dark: "#2E2E33")
        static let control = dynamic(light: "#8E8E97", dark: "#6A6A74")
        static let strong  = dynamic(light: "#71717A", dark: "#8A8A95")
        static let focus   = dynamic(light: "#0E0E10", dark: "#F2F2F3")
    }

    enum Action {
        static let primaryBG        = dynamic(light: "#0E0E10", dark: "#FFFFFF")
        static let primaryBGHover   = dynamic(light: "#26262A", dark: "#DEDEE2")
        static let primaryFG        = dynamic(light: "#FFFFFF", dark: "#0E0E10")
        static let primaryBGOff     = dynamic(light: "#F1F1F3", dark: "#232327")
        static let primaryFGOff     = dynamic(light: "#A5A5AE", dark: "#5A5A62")

        static let secondaryHover   = dynamic(light: "#F7F7F8", dark: "#FFFFFF0F")
        static let secondaryActive  = dynamic(light: "#F1F1F3", dark: "#FFFFFF1A")
        static let secondaryBorder  = dynamic(light: "#D2D2D8", dark: "#3A3A41")
        static let secondaryBorderHover = dynamic(light: "#A5A5AE", dark: "#55555E")

        static let tertiaryHover    = dynamic(light: "#F1F1F3", dark: "#FFFFFF14")
        static let tertiaryActive   = dynamic(light: "#E4E4E7", dark: "#FFFFFF24")

        static let dangerBG         = dynamic(light: "#B42318", dark: "#D93A3F")
        static let dangerBGHover    = dynamic(light: "#9A1E14", dark: "#C42F33")
        static let dangerFG         = dynamic(light: "#FFFFFF", dark: "#FFFFFF")
    }

    /// The only colours in the product. Green succeeded, amber needs attention,
    /// red failed or destroys. Anything else is monochrome.
    enum Status {
        static let success = dynamic(light: "#0F7A34", dark: "#4ADE80")
        static let warning = dynamic(light: "#8A5A00", dark: "#FBBF24")
        static let danger  = dynamic(light: "#B42318", dark: "#F87171")
        static let dangerSolid = dynamic(light: "#DC2626", dark: "#F87171")
    }

    // MARK: - Scale

    /// 4px base, 8px grid for layout.
    enum Space {
        static let xxs: CGFloat = 2
        static let xs: CGFloat = 4
        static let s: CGFloat = 8
        static let m: CGFloat = 12
        static let l: CGFloat = 16
        static let xl: CGFloat = 24
        static let xxl: CGFloat = 32
        static let huge: CGFloat = 64
        /// Page padding for a `medium` canvas (600–839pt), which is this app's shell.
        static let page: CGFloat = 24
    }

    enum Radius {
        static let chip: CGFloat = 6
        static let small: CGFloat = 8
        static let control: CGFloat = 10
        static let card: CGFloat = 14
        static let modal: CGFloat = 20
    }

    /// One line weight, everywhere, in every project.
    static let line: CGFloat = 1

    enum ControlHeight {
        static let sm: CGFloat = 32
        static let md: CGFloat = 40
        static let lg: CGFloat = 48
    }

    // MARK: - Type
    //
    // Weights 400/500/600 only — there is no bold in the UI. Tracking tightens
    // as size grows; that negative letter-spacing is most of what reads as craft.

    enum Font {
        static let h1      = SwiftUI.Font.system(size: 32, weight: .semibold)
        static let h2      = SwiftUI.Font.system(size: 24, weight: .semibold)
        static let h3      = SwiftUI.Font.system(size: 20, weight: .semibold)
        static let title   = SwiftUI.Font.system(size: 17, weight: .semibold)
        static let bodyLg  = SwiftUI.Font.system(size: 17, weight: .regular)
        static let body    = SwiftUI.Font.system(size: 15, weight: .regular)
        static let label   = SwiftUI.Font.system(size: 14, weight: .medium)
        static let caption = SwiftUI.Font.system(size: 13, weight: .regular)
        static let micro   = SwiftUI.Font.system(size: 11, weight: .medium)

        static func mono(_ size: CGFloat, weight: SwiftUI.Font.Weight = .regular) -> SwiftUI.Font {
            .system(size: size, weight: weight, design: .monospaced)
        }
    }

    /// Tracking, applied with `.tracking()`. Larger type, tighter letters.
    enum Tracking {
        static let h1: CGFloat = -0.6
        static let title: CGFloat = -0.3
        static let body: CGFloat = -0.1
    }

    // MARK: - Motion
    //
    // Things leave faster than they arrive. Only opacity, transform and colour
    // are ever animated — never a size or a position that moves a neighbour.

    enum Motion {
        static let fast = Animation.timingCurve(0.2, 0, 0, 1, duration: 0.12)
        static let base = Animation.timingCurve(0.2, 0, 0, 1, duration: 0.18)
        static let entrance = Animation.timingCurve(0.16, 1, 0.3, 1, duration: 0.26)
        static let exit = Animation.timingCurve(0.4, 0, 1, 1, duration: 0.12)
        /// The one permitted transform.
        static let press = Animation.timingCurve(0.2, 0, 0, 1, duration: 0.09)
        static let pressScale: CGFloat = 0.98
    }

    // MARK: - Colour plumbing

    /// One token, both appearances, resolved when it's drawn.
    static func dynamic(light: String, dark: String) -> Color {
        Color(nsColor: NSColor(name: nil) { appearance in
            let isDark = appearance.bestMatch(from: [.aqua, .darkAqua]) == .darkAqua
            return NSColor(hex: isDark ? dark : light)
        })
    }
}

extension NSColor {
    /// `#RRGGBB` or `#RRGGBBAA`.
    convenience init(hex: String) {
        var value = hex.hasPrefix("#") ? String(hex.dropFirst()) : hex
        if value.count == 6 { value += "FF" }
        let number = UInt64(value, radix: 16) ?? 0xFFFFFFFF
        self.init(
            srgbRed: CGFloat((number & 0xFF00_0000) >> 24) / 255,
            green:   CGFloat((number & 0x00FF_0000) >> 16) / 255,
            blue:    CGFloat((number & 0x0000_FF00) >> 8) / 255,
            alpha:   CGFloat( number & 0x0000_00FF) / 255
        )
    }
}

// MARK: - Buttons

/// The load-bearing component.
///
/// Hover moves the fill one step toward mid-grey — black lightens, white dims —
/// which reads as lifting toward you. Press returns the fill to its default and
/// applies `scale(0.98)`, which reads as pushing down. Same physical metaphor in
/// both appearances, so muscle memory transfers.
///
/// **The box never resizes.** No state changes the frame; only fill, border and
/// the one permitted transform.
struct MinimalButton: ButtonStyle {
    enum Variant { case primary, secondary, tertiary, danger }
    enum Size { case sm, md, lg }

    var variant: Variant = .secondary
    var size: Size = .md
    /// Locks the width so a label swap (e.g. Record → Stop) can't move neighbours.
    var minWidth: CGFloat?
    /// Icon-only: drop the horizontal padding so the box is a square of the
    /// control height, rather than a wide capsule around a single glyph.
    var square: Bool = false
    /// Overrides the label colour for the quiet variants.
    ///
    /// The style sets `foregroundStyle` on the label itself, so a
    /// `.foregroundStyle` applied to the `Button` from outside never reaches it —
    /// the destructive actions here looked exactly like the ordinary ones. The
    /// tint has to be handed in.
    var tint: Color?

    func makeBody(configuration: Configuration) -> some View {
        ButtonBody(configuration: configuration, variant: variant, size: size,
                   minWidth: minWidth, square: square, tint: tint)
    }

    struct ButtonBody: View {
        let configuration: ButtonStyle.Configuration
        let variant: Variant
        let size: Size
        let minWidth: CGFloat?
        let square: Bool
        var tint: Color?

        @State private var hovering = false
        @Environment(\.isEnabled) private var isEnabled

        private var height: CGFloat {
            switch size {
            case .sm: return DS.ControlHeight.sm
            case .md: return DS.ControlHeight.md
            case .lg: return DS.ControlHeight.lg
            }
        }

        private var horizontalPadding: CGFloat {
            guard !square else { return 0 }
            switch size {
            case .sm: return DS.Space.m
            case .md: return DS.Space.l
            case .lg: return DS.Space.xl
            }
        }

        var body: some View {
            configuration.label
                .font(size == .sm ? DS.Font.caption : DS.Font.label)
                .foregroundStyle(foreground)
                .padding(.horizontal, horizontalPadding)
                .frame(minWidth: minWidth)
                .frame(width: square ? height : nil, height: height)
                .background(RoundedRectangle(cornerRadius: DS.Radius.control).fill(background))
                .overlay(
                    RoundedRectangle(cornerRadius: DS.Radius.control)
                        .strokeBorder(border, lineWidth: DS.line)
                )
                .contentShape(RoundedRectangle(cornerRadius: DS.Radius.control))
                .scaleEffect(configuration.isPressed ? DS.Motion.pressScale : 1)
                .onHover { hovering = $0 && isEnabled }
                .animation(DS.Motion.fast, value: hovering)
                .animation(DS.Motion.press, value: configuration.isPressed)
        }

        private var background: Color {
            guard isEnabled else {
                return variant == .primary || variant == .danger ? DS.Action.primaryBGOff : .clear
            }
            switch variant {
            case .primary:
                // Press returns to the default fill; hover lifts toward mid-grey.
                if configuration.isPressed { return DS.Action.primaryBG }
                return hovering ? DS.Action.primaryBGHover : DS.Action.primaryBG
            case .danger:
                if configuration.isPressed { return DS.Action.dangerBG }
                return hovering ? DS.Action.dangerBGHover : DS.Action.dangerBG
            case .secondary:
                if configuration.isPressed { return DS.Action.secondaryActive }
                return hovering ? DS.Action.secondaryHover : .clear
            case .tertiary:
                if configuration.isPressed { return DS.Action.tertiaryActive }
                return hovering ? DS.Action.tertiaryHover : .clear
            }
        }

        private var foreground: Color {
            guard isEnabled else {
                return variant == .primary || variant == .danger ? DS.Action.primaryFGOff : DS.Text.disabled
            }
            if let tint { return tint }
            switch variant {
            case .primary: return DS.Action.primaryFG
            case .danger:  return DS.Action.dangerFG
            default:       return DS.Text.primary
            }
        }

        private var border: Color {
            guard variant == .secondary else { return .clear }
            guard isEnabled else { return DS.Border.subtle }
            return hovering ? DS.Action.secondaryBorderHover : DS.Action.secondaryBorder
        }
    }
}

/// A `Menu` dressed as `MinimalButton`'s secondary variant — same border, same
/// hover law, same height — with a trailing chevron marking it as a dropdown.
///
/// A plain SwiftUI `Picker` renders as a native macOS pop-up button, which has
/// its own bezel and its own idea of hover/press. Sitting in a row next to
/// `MinimalButton`s, it reads as a different *kind* of control rather than a
/// dropdown among buttons — this makes it the same object as the buttons
/// either side of it, the way `deviceMenu`'s icon buttons already are.
struct MinimalDropdown<MenuContent: View>: View {
    var size: MinimalButton.Size = .md
    let label: String
    @ViewBuilder var content: () -> MenuContent

    @State private var hovering = false
    @Environment(\.isEnabled) private var isEnabled

    private var height: CGFloat {
        switch size {
        case .sm: return DS.ControlHeight.sm
        case .md: return DS.ControlHeight.md
        case .lg: return DS.ControlHeight.lg
        }
    }

    var body: some View {
        Menu {
            content()
        } label: {
            HStack(spacing: DS.Space.xs) {
                Text(label)
                    .font(size == .sm ? DS.Font.caption : DS.Font.label)
                    .foregroundStyle(isEnabled ? DS.Text.primary : DS.Text.disabled)
                    .lineLimit(1)
                Spacer(minLength: 0)
                Image(systemName: "chevron.down")
                    .font(.system(size: 10, weight: .semibold))
                    .foregroundStyle(isEnabled ? DS.Text.secondary : DS.Text.disabled)
            }
            .padding(.horizontal, DS.Space.m)
            .frame(height: height)
            .background(
                RoundedRectangle(cornerRadius: DS.Radius.control)
                    .fill(hovering && isEnabled ? DS.Action.secondaryHover : Color.clear)
            )
            .overlay(
                RoundedRectangle(cornerRadius: DS.Radius.control)
                    .strokeBorder(isEnabled
                                  ? (hovering ? DS.Action.secondaryBorderHover : DS.Action.secondaryBorder)
                                  : DS.Border.subtle,
                                  lineWidth: DS.line)
            )
            .contentShape(RoundedRectangle(cornerRadius: DS.Radius.control))
        }
        .menuStyle(.borderlessButton)
        .menuIndicator(.hidden)
        .onHover { hovering = $0 && isEnabled }
        .animation(DS.Motion.fast, value: hovering)
    }
}

extension View {
    /// Square icon-only control at a given control height.
    ///
    /// Icon buttons are the same height as text buttons so a toolbar row is one
    /// line, and the hit area is padded to 44pt rather than the box being grown.
    func minimalIconFrame(_ height: CGFloat = DS.ControlHeight.md) -> some View {
        frame(width: height, height: height)
            .contentShape(Rectangle())
    }
}

/// A soft border that brightens on hover — the same language `MinimalButton`
/// uses for its `.secondary` variant, applied to controls that aren't buttons.
///
/// The inspector is a column of toggles, sliders and colour wells with no
/// affordance at all between "resting" and "being dragged" — nothing said a row
/// was interactive until you were already interacting with it. This wraps a row
/// in the same border+background pair a secondary button rests on, so hovering
/// a checkbox's label reads the same way hovering any other control in the app
/// does.
///
/// A view modifier rather than a `ToggleStyle`/custom slider: `Toggle` and
/// `Slider` render their own system chrome (the checkbox glyph, the thumb), and
/// this only wraps that chrome in a highlight rather than replacing it — the
/// controls still look and behave exactly as native AppKit ones.
private struct HoverHighlight: ViewModifier {
    @State private var hovering = false
    @Environment(\.isEnabled) private var isEnabled

    func body(content: Content) -> some View {
        let active = hovering && isEnabled
        content
            // Inflated, painted, hover-tracked, *then* shrunk back with equal
            // negative padding — the border and its hover region extend a
            // little past the content, but the row reports its original size
            // to whatever's laying it out, so wrapping a control in this never
            // nudges its neighbours or breaks column alignment.
            .padding(.horizontal, DS.Space.s)
            .padding(.vertical, DS.Space.xs)
            .background(
                RoundedRectangle(cornerRadius: DS.Radius.chip)
                    .fill(active ? DS.Action.secondaryHover : .clear)
            )
            .overlay(
                RoundedRectangle(cornerRadius: DS.Radius.chip)
                    .strokeBorder(active ? DS.Action.secondaryBorderHover : .clear, lineWidth: DS.line)
            )
            .contentShape(RoundedRectangle(cornerRadius: DS.Radius.chip))
            .onHover { hovering = $0 }
            .padding(.horizontal, -DS.Space.s)
            .padding(.vertical, -DS.Space.xs)
            .animation(DS.Motion.fast, value: hovering)
    }
}

extension View {
    /// Border brightens on hover, matching `MinimalButton`'s secondary variant.
    /// For anything clickable that isn't already a `MinimalButton` — toggles,
    /// the labelled sliders, colour wells.
    func hoverHighlight() -> some View {
        modifier(HoverHighlight())
    }
}

// MARK: - Tri-state checkbox

/// A checkbox with a third state: on, off, and **mixed** — a dash instead of a
/// checkmark, in a box that's still filled. Native `Toggle` can only bind to a
/// `Bool`, so this exists purely for the case a `Bool` can't represent: a
/// setting that's "on" but no longer describes everything on the timeline,
/// because the user deleted a few of the things it generated by hand. Tapping
/// it always flips the same underlying `Bool` a plain checkbox would — mixed
/// is a read-only report of drift, not a third click target.
struct MixedCheckbox: View {
    enum State { case off, on, mixed }

    let label: String
    let state: State
    let action: () -> Void

    @Environment(\.isEnabled) private var isEnabled

    var body: some View {
        NativeCheckboxButton(label: label, state: state, isEnabled: isEnabled, action: action)
            .fixedSize()
            .hoverHighlight()
    }
}

/// The actual `NSButton` checkbox, hand-drawn shapes replaced entirely.
///
/// The first version of this control drew its own box — a rounded rectangle,
/// a checkmark glyph, a dash for mixed — and it never quite matched: every
/// other checkbox in the app (`Toggle`, which AppKit backs with the same
/// `NSButton` checkbox type) came out a hair thicker and a different shade.
/// `NSButton` already has a real mixed state (`NSControl.StateValue.mixed`,
/// gated by `allowsMixedState`), so wrapping it directly is both less code
/// and a guaranteed pixel match — it's not an imitation of the system
/// checkbox, it *is* the system checkbox.
private struct NativeCheckboxButton: NSViewRepresentable {
    let label: String
    let state: MixedCheckbox.State
    let isEnabled: Bool
    let action: () -> Void

    func makeCoordinator() -> Coordinator { Coordinator(action: action) }

    func makeNSView(context: Context) -> NSButton {
        let button = NSButton(checkboxWithTitle: label,
                              target: context.coordinator,
                              action: #selector(Coordinator.fire))
        button.allowsMixedState = true
        button.setContentHuggingPriority(.required, for: .horizontal)
        return button
    }

    func updateNSView(_ button: NSButton, context: Context) {
        context.coordinator.action = action
        if button.title != label { button.title = label }
        button.isEnabled = isEnabled
        let target = nsState
        if button.state != target { button.state = target }
    }

    private var nsState: NSControl.StateValue {
        switch state {
        case .off:   return .off
        case .on:    return .on
        case .mixed: return .mixed
        }
    }

    final class Coordinator: NSObject {
        var action: () -> Void
        init(action: @escaping () -> Void) { self.action = action }
        @objc func fire() { action() }
    }
}


// MARK: - Tooltips

/// `.help()` is unreliable once a view sits inside a custom `ButtonStyle`, an
/// overlay, or a `Menu` label — which is most of this app, and why several
/// controls had no tooltip at all despite carrying `.help()`.
///
/// AppKit's own `NSView.toolTip` always works, so this parks an invisible,
/// non-hit-testing `NSView` over the control and lets AppKit handle it. The view
/// returns `nil` from `hitTest`, so clicks pass straight through to the real
/// control while the tooltip tracking rect stays live.
private struct TooltipHost: NSViewRepresentable {
    let text: String

    final class PassthroughView: NSView {
        override func hitTest(_ point: NSPoint) -> NSView? { nil }
    }

    func makeNSView(context: Context) -> PassthroughView {
        let view = PassthroughView()
        view.toolTip = text
        return view
    }

    func updateNSView(_ nsView: PassthroughView, context: Context) {
        if nsView.toolTip != text { nsView.toolTip = text }
    }
}

extension View {
    /// Tooltip plus accessibility hint in one call. Include the keyboard
    /// shortcut in `text` — the tooltip is where people look for it.
    func tooltip(_ text: String) -> some View {
        overlay(TooltipHost(text: text))
            .accessibilityHint(text)
    }
}


extension Color {
    /// Builds a colour from the plain component tuples the model stores, so
    /// `ProjectState` never has to import SwiftUI.
    init(_ rgb: (r: Double, g: Double, b: Double)) {
        self.init(red: rgb.r, green: rgb.g, blue: rgb.b)
    }
}
