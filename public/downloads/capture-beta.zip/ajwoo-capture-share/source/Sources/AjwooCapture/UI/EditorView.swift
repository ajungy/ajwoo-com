import SwiftUI
import AVFoundation
import AppKit

/// Wraps the model's lifetime so the window owns it.
struct EditorWindowView: View {
    let recordingURL: URL
    @StateObject private var model: EditorModel

    init(recordingURL: URL) {
        self.recordingURL = recordingURL
        _model = StateObject(wrappedValue: EditorModel(session: RecordingSession(url: recordingURL)))
    }

    var body: some View {
        EditorView(model: model)
            .task { if model.loadState == .loading { await model.load() } }
            .onDisappear { model.pause(); model.saveNow() }
            .navigationTitle(model.session.name)
    }
}

struct EditorView: View {
    @ObservedObject var model: EditorModel
    @State private var showExport = false
    @State private var showSuggestions = false
    @AppStorage("AjwooCapture.scrubOnHover") private var scrubOnHover = true

    var body: some View {
        switch model.loadState {
        case .loading:
            ProgressView("Opening recording…")
                .font(DS.Font.body)
                .frame(maxWidth: .infinity, maxHeight: .infinity)
                .background(DS.Surface.page)
        case .failed(let message):
            VStack(spacing: DS.Space.m) {
                Text("Couldn't open this recording.")
                    .font(DS.Font.h3)
                    .foregroundStyle(DS.Text.primary)
                Text(message)
                    .font(DS.Font.body)
                    .foregroundStyle(DS.Text.secondary)
                    .multilineTextAlignment(.center)
                    .frame(maxWidth: 460)
            }
            .frame(maxWidth: .infinity, maxHeight: .infinity)
            .background(DS.Surface.page)
        case .ready:
            content
        }
    }

    private var content: some View {
        HSplitView {
            VStack(spacing: 0) {
                preview
                Divider()
                transport
                TimelineView(model: model)
                    .padding(.horizontal, DS.Space.l)
                    .padding(.bottom, DS.Space.l)
            }
            .frame(minWidth: 520)

            InspectorView(model: model)
                .frame(minWidth: 280, idealWidth: 300, maxWidth: 360)
                .background(DS.Surface.raised)
        }
        .background(DS.Surface.page)
        .background(shortcuts)
        .sheet(isPresented: $showExport) {
            ExportSheet(model: model)
        }
    }

    // MARK: - Preview

    private var preview: some View {
        GeometryReader { geometry in
            ZStack {
                Color.black
                PlayerView(player: model.player)

                if model.isCropping {
                    CropOverlay(model: model, videoRect: model.videoRect(in: geometry.size))
                } else {
                    // One layer owns every pointer interaction on the preview:
                    // the camera bubble, its corner handles, and zoom-focus
                    // panning everywhere else. Splitting these across stacked
                    // views over an NSViewRepresentable is what broke it before.
                    PreviewInteractionLayer(model: model,
                                            videoRect: model.videoRect(in: geometry.size))

                    if let hint = previewHint {
                        Text(hint)
                            .font(DS.Font.micro)
                            .padding(.horizontal, DS.Space.m).padding(.vertical, DS.Space.xs)
                            .background(.black.opacity(0.6), in: Capsule())
                            .foregroundStyle(.white)
                            .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .bottom)
                            .padding(.bottom, DS.Space.l)
                            .allowsHitTesting(false)
                            .transition(.opacity)
                    }
                }
            }
        }
        .frame(minHeight: 260)
    }

    private var previewHint: String? {
        guard let zoom = model.selectedZoom else { return nil }
        return zoom.followsCursor
            ? "This zoom follows the cursor — focus is automatic"
            : "Drag the preview to move the zoom focus"
    }

    // MARK: - Transport

    private var transport: some View {
        model.isCropping ? AnyView(cropTransport) : AnyView(normalTransport)
    }

    /// The crop tool takes over the transport bar rather than opening a sheet —
    /// you need to see the frame while you're choosing the region.
    private var cropTransport: some View {
        HStack(spacing: DS.Space.m) {
            Text("Drag to choose the area to keep")
                .font(DS.Font.caption)
                .foregroundStyle(DS.Text.secondary)
            Spacer()
            Button("Reset") { model.resetCrop() }
                .buttonStyle(MinimalButton(variant: .tertiary, size: .sm))
                .tooltip("Use the whole screen again")
            Button("Cancel") { model.cancelCropping() }
                .buttonStyle(MinimalButton(variant: .secondary, size: .sm, minWidth: 72))
                .keyboardShortcut(.escape, modifiers: [])
                .tooltip("Cancel  Esc")
            Button("Use this crop") { model.applyCrop() }
                .buttonStyle(MinimalButton(variant: .primary, size: .sm, minWidth: 104))
                .keyboardShortcut(.return, modifiers: [])
                .tooltip("Apply  Return")
        }
        .padding(.horizontal, DS.Space.l)
        .padding(.vertical, DS.Space.m)
    }

    /// The transport.
    ///
    /// Export is deliberately secondary rather than the row's one primary
    /// emphasis — its own sheet has the actual commit action (Save/Copy), so
    /// this button only opens a dialog rather than finishing anything itself.
    ///
    /// **Nothing moves.** Buttons that only apply to a selection stay in place
    /// and disable rather than appearing and shifting their neighbours, and the
    /// timecode is a fixed-width monospaced slot so counting digits can't nudge
    /// the row.
    /// Position over total, with the exported length underneath.
    ///
    /// The second line only says something when cuts exist, but its space is
    /// always reserved — an earlier version appeared and disappeared, which
    /// shifted every button in the row. Red because it's the one number that
    /// differs from what you're looking at: the preview plays the whole take,
    /// the export won't.
    private var timecodeReadout: some View {
        let exported = model.exportedTimecode
        // With no cuts there's one line and it sits on the row's centre line,
        // level with the buttons either side. The two-line form only appears
        // when there's a second number worth reading, and its slot is reserved
        // either way so nothing shifts when cuts arrive.
        return VStack(alignment: .leading, spacing: 0) {
            Text(Timecode.format(model.currentTime) + " / " + Timecode.format(model.duration))
                .font(DS.Font.mono(12))
                .foregroundStyle(DS.Text.primary)

            if exported != nil {
                Text(exported ?? "")
                    .font(DS.Font.mono(10))
                    .foregroundStyle(DS.Status.danger)
            }
        }
        .monospacedDigit()
        .frame(width: 148, height: DS.ControlHeight.sm, alignment: .leading)
        .tooltip(model.exportedTimecode == nil
                 ? "Where you are, and how long it is"
                 : "Where you are and how long it is in the exported video, after your cuts")
    }

    /// Percent readout / zoom-in / zoom-out — the timeline's own scale, not
    /// the video's Ken Burns zoom that the "Zoom" button next to this adds.
    /// The percent itself is a button: click it to reset to 100%, the same
    /// job a separate "fit" icon used to do. Both it and zoom-out disable at
    /// 100%, since that's the floor: the whole recording already fills the
    /// timeline's width there.
    private var timelineZoomControls: some View {
        HStack(spacing: DS.Space.xxs) {
            Button { model.fitTimeline() } label: {
                Text("\(Int((model.timelineZoom * 100).rounded()))%")
                    .font(DS.Font.mono(11))
                    .monospacedDigit()
                    .frame(minWidth: 38, alignment: .trailing)
            }
            .buttonStyle(MinimalButton(variant: .tertiary, size: .sm))
            .disabled(model.timelineZoom <= 1.001)
            .tooltip("Fit the timeline to 100%")
            .accessibilityLabel("Fit the timeline to 100%")

            Button { model.zoomTimelineIn() } label: {
                Image(systemName: "plus.magnifyingglass").minimalIconFrame(DS.ControlHeight.sm)
            }
            .buttonStyle(MinimalButton(variant: .tertiary, size: .sm, square: true))
            .tooltip("Zoom in on the timeline")
            .accessibilityLabel("Zoom in on the timeline")

            Button { model.zoomTimelineOut() } label: {
                Image(systemName: "minus.magnifyingglass").minimalIconFrame(DS.ControlHeight.sm)
            }
            .buttonStyle(MinimalButton(variant: .tertiary, size: .sm, square: true))
            .disabled(model.timelineZoom <= 1.001)
            .tooltip("Zoom out on the timeline")
            .accessibilityLabel("Zoom out on the timeline")
        }
    }

    private var normalTransport: some View {
        HStack(spacing: DS.Space.xs) {
            Button(action: model.togglePlayback) {
                Image(systemName: model.isPlaying ? "pause.fill" : "play.fill")
                    .minimalIconFrame(DS.ControlHeight.sm)
            }
            .buttonStyle(MinimalButton(variant: .tertiary, size: .sm, square: true))
            .tooltip("Play or pause  Space")
            .accessibilityLabel(model.isPlaying ? "Pause" : "Play")

            timecodeReadout
                .padding(.leading, DS.Space.xs)

            Divider().frame(height: 16).overlay(DS.Border.subtle)
                .padding(.horizontal, DS.Space.xs)

            timelineZoomControls

            Divider().frame(height: 16).overlay(DS.Border.subtle)
                .padding(.horizontal, DS.Space.xs)

            Button { model.addZoom() } label: { Text("Zoom") }
                .buttonStyle(MinimalButton(variant: .tertiary, size: .sm))
                .tooltip("Add a zoom here")

            Button { model.addCut() } label: { Text("Cut") }
                .buttonStyle(MinimalButton(variant: .tertiary, size: .sm))
                .tooltip("Cut out a section  ⌘X")

            Button { model.beginCropping() } label: { Text("Crop") }
                .buttonStyle(MinimalButton(variant: .tertiary, size: .sm))
                .overlay(alignment: .topTrailing) {
                    // A dot rather than a "✓" appended to the label, so the
                    // button's width is the same whether a crop is set or not.
                    Circle()
                        .fill(DS.Text.primary)
                        .frame(width: 5, height: 5)
                        .padding(4)
                        .opacity(model.project.crop.enabled ? 1 : 0)
                }
                .tooltip(model.project.crop.enabled
                         ? "Crop — a crop is applied. Click to adjust it."
                         : "Crop — choose the area of the recording to keep")

            Button {
                if let id = model.selectedZoomID {
                    model.deleteZoom(id)
                } else if let cut = model.selectedCut {
                    model.deleteCut(cut.id)
                }
            } label: {
                Text(model.selectedCut != nil ? "Restore" : "Remove")
            }
            .buttonStyle(MinimalButton(variant: .tertiary, size: .sm, minWidth: 72))
            .disabled(model.selectedZoomID == nil && model.selectedCut == nil)
            .tooltip(model.selectedCut != nil
                     ? "Restore the selected cut footage  Delete"
                     : "Remove the selected zoom  Delete")

            Divider().frame(height: 16).overlay(DS.Border.subtle)
                .padding(.horizontal, DS.Space.xs)

            Button { model.undo() } label: {
                Image(systemName: "arrow.uturn.backward").minimalIconFrame(DS.ControlHeight.sm)
            }
            .buttonStyle(MinimalButton(variant: .tertiary, size: .sm, square: true))
            .disabled(!model.canUndo)
            .tooltip("Undo  ⌘Z")
            .accessibilityLabel("Undo")

            Button { model.redo() } label: {
                Image(systemName: "arrow.uturn.forward").minimalIconFrame(DS.ControlHeight.sm)
            }
            .buttonStyle(MinimalButton(variant: .tertiary, size: .sm, square: true))
            .disabled(!model.canRedo)
            .tooltip("Redo  ⇧⌘Z")
            .accessibilityLabel("Redo")

            Button {
                showSuggestions.toggle()
            } label: {
                Image(systemName: "wand.and.stars").minimalIconFrame(DS.ControlHeight.sm)
            }
            .buttonStyle(MinimalButton(variant: .tertiary, size: .sm, square: true))
            .overlay(alignment: .topTrailing) {
                // A dot when the generated zooms have been changed, so the panel
                // is worth opening. A count badge would move the button.
                Circle()
                    .fill(DS.Status.warning)
                    .frame(width: 5, height: 5)
                    .padding(3)
                    .opacity(model.autoZoomsAreModified ? 1 : 0)
            }
            .popover(isPresented: $showSuggestions, arrowEdge: .bottom) {
                AutoZoomPopover(model: model)
            }
            .tooltip("Automatic zooms — the ones added for you from your clicks")
            .accessibilityLabel("Automatic zooms")

            Toggle(isOn: $scrubOnHover) {
                Image(systemName: "hand.point.up.left").minimalIconFrame(DS.ControlHeight.sm)
            }
            .toggleStyle(.button)
            .buttonStyle(MinimalButton(variant: scrubOnHover ? .secondary : .tertiary, size: .sm, square: true))
            .tooltip("Preview by hovering, no clicking")
            .accessibilityLabel("Scrub on hover")

            Spacer(minLength: DS.Space.l)

            Button("Export") {
                model.pause()
                showExport = true
            }
            .buttonStyle(MinimalButton(variant: .secondary, size: .sm, minWidth: 88))
            .keyboardShortcut("e", modifiers: .command)
            .tooltip("Save a video or GIF  ⌘E")
        }
        .padding(.horizontal, DS.Space.l)
        .padding(.vertical, DS.Space.m)
    }

    /// Hidden buttons carrying the keyboard shortcuts.
    private var shortcuts: some View {
        ZStack {
            Button("") { model.togglePlayback() }
                .keyboardShortcut(.space, modifiers: [])
            Button("") { model.step(by: -1.0 / 60.0) }
                .keyboardShortcut(.leftArrow, modifiers: [])
            Button("") { model.step(by: 1.0 / 60.0) }
                .keyboardShortcut(.rightArrow, modifiers: [])
            Button("") { model.step(by: -1) }
                .keyboardShortcut(.leftArrow, modifiers: .shift)
            Button("") { model.step(by: 1) }
                .keyboardShortcut(.rightArrow, modifiers: .shift)
            Button("") {
                if let id = model.selectedZoomID { model.deleteZoom(id) }
                else if let id = model.selectedCutID { model.deleteCut(id) }
            }
            .keyboardShortcut(.delete, modifiers: [])
            Button("") { model.undo() }
                .keyboardShortcut("z", modifiers: .command)
            Button("") { model.redo() }
                .keyboardShortcut("z", modifiers: [.command, .shift])
            Button("") { model.addCut() }
                .keyboardShortcut("x", modifiers: .command)
        }
        .opacity(0)
        .frame(width: 0, height: 0)
    }
}

// MARK: - Automatic zooms

/// What the wand added, and what's happened to it since.
///
/// This used to be a list of *suggestions* — zooms proposed but not applied,
/// which you then had to add one by one. That was a duplicate of the auto-zoom
/// feature that already puts them on the timeline for you, and it meant the wand
/// showed things that weren't in your video while the things that were had no
/// home anywhere.
///
/// So it now reflects the timeline: every zoom auto-zoom generated, whether it's
/// still as generated, whether you moved it, or whether you deleted it — with a
/// way back in each case.
struct AutoZoomPopover: View {
    @ObservedObject var model: EditorModel

    var body: some View {
        let statuses = model.autoZoomStatuses

        return VStack(alignment: .leading, spacing: DS.Space.s) {
            HStack {
                Text("Automatic zooms")
                    .font(DS.Font.label)
                    .foregroundStyle(DS.Text.primary)
                Spacer()
                Text("\(statuses.count)")
                    .font(DS.Font.mono(11))
                    .foregroundStyle(DS.Text.tertiary)
            }
            .tooltip("Zooms added for you, one around each burst of clicks")

            Divider().overlay(DS.Border.subtle)

            if statuses.isEmpty {
                Text(model.hasClicks
                     ? "Auto-zoom is off. Switch it on under Auto-zoom."
                     : "No clicks were recorded, so there's nothing to zoom to.")
                    .font(DS.Font.caption)
                    .foregroundStyle(DS.Text.secondary)
                    .fixedSize(horizontal: false, vertical: true)
                    .padding(.vertical, DS.Space.xs)
            } else {
                ScrollView {
                    VStack(spacing: DS.Space.xs) {
                        ForEach(statuses) { status in
                            row(status)
                        }
                    }
                }
                .frame(maxHeight: 240)

                Divider().overlay(DS.Border.subtle)

                HStack(spacing: DS.Space.xs) {
                    Button("Reset all") { model.restoreAllAutoZooms() }
                        .buttonStyle(MinimalButton(variant: .secondary, size: .sm))
                        .disabled(!model.autoZoomsAreModified)
                        .tooltip("Put every automatic zoom back the way it was made")

                    Spacer()

                    Button("Remove all") { model.removeAllAutoZooms() }
                        .buttonStyle(MinimalButton(variant: .tertiary, size: .sm,
                                                   tint: DS.Status.danger))
                        .tooltip("Take the automatic zooms off the timeline. Your own zooms stay.")
                }
            }
        }
        .padding(DS.Space.l)
        .frame(width: 320)
    }

    private func row(_ status: EditorModel.AutoZoomStatus) -> some View {
        let segment = status.live ?? status.blueprint
        return HStack(spacing: DS.Space.s) {
            Text("\(Timecode.format(segment.start)) – \(Timecode.format(segment.end))")
                .font(DS.Font.mono(12))
                .foregroundStyle(status.state == .removed ? DS.Text.tertiary : DS.Text.primary)

            // "removed" is a statement of fact, not a warning, and this panel
            // already carries enough amber. Plain text reads as information.
            Text(label(for: status.state))
                .font(DS.Font.caption)
                .foregroundStyle(status.state == .unchanged ? DS.Text.tertiary : DS.Text.primary)

            Spacer()

            // One button, whose meaning depends on the state. Two buttons that
            // both meant "undo" on a removed row was the same action twice.
            Button {
                switch status.state {
                case .unchanged: model.removeAutoZoom(status)
                case .edited, .removed: model.restoreAutoZoom(status)
                }
            } label: {
                Image(systemName: status.state == .unchanged ? "xmark" : "arrow.uturn.backward")
            }
            .buttonStyle(MinimalButton(variant: .tertiary, size: .sm, square: true))
            .tooltip(status.state == .unchanged ? "Remove this zoom" : "Put this zoom back")
        }
        .contentShape(Rectangle())
        .onTapGesture {
            guard let live = status.live else { return }
            model.selectedZoomID = live.id
            model.seek(to: live.start)
        }
    }

    private func label(for state: EditorModel.AutoZoomStatus.State) -> String {
        switch state {
        case .unchanged: return "as added"
        case .edited:    return "edited"
        case .removed:   return "removed"
        }
    }
}

enum Timecode {
    static func format(_ seconds: Double) -> String {
        guard seconds.isFinite, seconds >= 0 else { return "0:00.0" }
        let minutes = Int(seconds) / 60
        let remainder = seconds - Double(minutes * 60)
        return String(format: "%d:%04.1f", minutes, remainder)
    }
}
