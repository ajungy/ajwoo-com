import AppKit
import SwiftUI

/// Keeps one editor window per recording.
///
/// `WindowGroup(for:)` will happily open a second window for a value that's
/// already on screen, which means two editors over the same recording, both
/// writing `project.json`, with no indication that the other exists. Rather than
/// try to talk SwiftUI out of it, each editor stamps its `NSWindow` with the
/// recording's path as an identifier on appear; opening one checks for that
/// stamp first and raises the existing window instead.
@MainActor
enum EditorWindows {

    private static func identifier(for url: URL) -> NSUserInterfaceItemIdentifier {
        NSUserInterfaceItemIdentifier("ajwoo.editor.\(url.standardizedFileURL.path)")
    }

    /// The already-open editor for this recording, if there is one.
    static func existing(for url: URL) -> NSWindow? {
        let id = identifier(for: url)
        return NSApp.windows.first { $0.identifier == id && $0.isVisible }
    }

    /// Raises the existing editor, or opens a new one.
    ///
    /// The previous version ran a `CABasicAnimation` on the window to draw
    /// attention to it, which took the app down. Raising a window is not worth
    /// any risk of losing the editor you were working in, so the flourish is
    /// gone: this now does the one thing it needs to and nothing else.
    static func open(_ url: URL, using openWindow: OpenWindowAction) {
        if let window = existing(for: url) {
            NSApp.activate(ignoringOtherApps: true)
            window.makeKeyAndOrderFront(nil)
            return
        }
        openWindow(id: "editor", value: url)
    }

    static func claim(_ window: NSWindow, for url: URL) {
        window.identifier = identifier(for: url)
    }

}

/// Stamps the hosting window so `EditorWindows` can find it again.
struct EditorWindowClaim: NSViewRepresentable {
    let url: URL

    func makeNSView(context: Context) -> NSView {
        let view = ClaimView()
        view.url = url
        return view
    }

    func updateNSView(_ nsView: NSView, context: Context) {
        (nsView as? ClaimView)?.url = url
    }

    private final class ClaimView: NSView {
        var url: URL?

        override func viewDidMoveToWindow() {
            super.viewDidMoveToWindow()
            guard let window, let url else { return }
            EditorWindows.claim(window, for: url)
        }

        // Purely a hook onto the window; it must never take the mouse.
        override func hitTest(_ point: NSPoint) -> NSView? { nil }
    }
}
