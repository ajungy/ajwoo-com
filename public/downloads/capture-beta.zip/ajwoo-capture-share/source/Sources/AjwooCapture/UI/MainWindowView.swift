import SwiftUI
import AppKit

/// The record screen.
///
/// **Job to be done:** start a recording of the right thing, with the right
/// inputs, without thinking about it.
///
/// So there is exactly one emphasised control — Record — and everything else is
/// a quiet adjustment to what Record will capture. Identity sits top-left,
/// settings top-right, per the house layout.
struct MainWindowView: View {

    /// Narrowest the window may be before the action bar starts clipping.
    ///
    /// The row is a fixed set of controls with no flexible member except the
    /// spacer, so below this width the last items are simply cut off — the
    /// settings button disappears first, and it's the only way into the
    /// settings. A guessed minimum drifts the moment a label or a control size
    /// changes, so the pieces are *measured*: the three variable-width labels
    /// against the font they're actually drawn in, and everything else from the
    /// same design tokens the views use.
    static var minimumContentWidth: CGFloat {
        func labelWidth(_ text: String, size: CGFloat, weight: NSFont.Weight) -> CGFloat {
            let font = NSFont.systemFont(ofSize: size, weight: weight)
            return ceil((text as NSString).size(withAttributes: [.font: font]).width)
        }

        // DS.Font.label — what the mode toggle and the Record button use.
        let modeLabel = DS.Space.m * 2  // horizontal padding inside each segment
        let fullDisplay = max(92, labelWidth("Full display", size: 14, weight: .medium) + modeLabel)
        let region = max(92, labelWidth("Region", size: 14, weight: .medium) + modeLabel)

        // DS.Font.mono(13) — the elapsed readout, whose slot is reserved even
        // while idle so the row doesn't jump when recording starts.
        let elapsed = labelWidth("00:00", size: 13, weight: .medium) + 8 + DS.Space.s

        let gaps = DS.Space.s * 8
        let controls =
            96                        // Record
            + DS.ControlHeight.md     // microphone
            + DS.ControlHeight.md     // camera
            + fullDisplay + DS.line + region
            + 200                     // display picker
            + DS.Space.l              // the spacer's minimum
            + elapsed
            + DS.ControlHeight.md     // settings

        return ceil(controls + gaps + DS.Space.l * 2)
    }

    @EnvironmentObject private var controller: RecordingController
    @Environment(\.openWindow) private var openWindow
    @State private var showSettings = false
    @State private var confirmDeleteAll = false
    /// Captured so the window can grow itself when the first recording lands —
    /// see `growWindowToShowRecordingsIfNeeded`.
    @State private var window: NSWindow?
    /// Fires the growth at most once per window. Without this, reopening the
    /// app with recordings already on disk risks a race — the window can
    /// resolve before `refreshRecordings()` finishes, or the reverse — and a
    /// plain "did the count just go from zero" check can miss whichever side
    /// arrives second. Checking both places against one guard instead means it
    /// doesn't matter which arrives first, and it still only ever happens once.
    @State private var hasGrownToShowRecordings = false

    var body: some View {
        // One rhythm: 16 pt between every section and 16 pt to every edge.
        // Sections carry no padding of their own, so the spacing can't be the
        // sum of two different opinions.
        VStack(alignment: .leading, spacing: DS.Space.l) {
            if controller.permission.isGranted {
                actionBar
                summaryRow
                RecordingsListView()
            } else {
                PermissionGateView()
            }
        }
        // 16 pt on three sides, nothing at the bottom: the recordings list runs
        // to the window's edge, so a scrolling list reads as continuing past the
        // frame rather than stopping short of it behind a band of background.
        .padding(.horizontal, DS.Space.l)
        .padding(.top, DS.Space.l)
        // The recordings list carries an `idealHeight`, so the window still
        // opens at content size, and a `maxHeight` of infinity, so it absorbs
        // any extra height rather than leaving a band below it. The page colour
        // is painted across the whole window regardless — the system's default
        // window background is a different shade, and it showed wherever the
        // content stopped.
        .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .topLeading)
        .background(DS.Surface.page.ignoresSafeArea())
        .background(WindowAccessor { resolved in
            window = resolved
            growWindowToShowRecordingsIfNeeded()
        })
        .task { await controller.refreshContent() }
        // A finished take opens straight in the editor.
        .onChange(of: controller.pendingEditorURL) { _, url in
            guard let url else { return }
            EditorWindows.open(url, using: openWindow)
            controller.pendingEditorURL = nil
        }
        .onChange(of: controller.recordings.count) { _, _ in
            growWindowToShowRecordingsIfNeeded()
        }
    }

    /// Grows the window by one row's height the first time there's a recording
    /// to show, so it's visible without a manual resize.
    ///
    /// SwiftUI's own window-sizing APIs (`.defaultSize`, `.windowResizability`)
    /// size the window once, at open — they don't track a later change in the
    /// content's own ideal size, so this is done by hand. Guarded by
    /// `hasGrownToShowRecordings` rather than "did the count just go from zero":
    /// growing an already-populated window every time one more recording is
    /// added would be presumptuous about space the user may have deliberately
    /// reclaimed by shrinking the window back down, so this only ever fires
    /// once per window, whether that's triggered by a recording finishing or by
    /// opening the app onto recordings that were already there.
    private func growWindowToShowRecordingsIfNeeded() {
        guard !hasGrownToShowRecordings, !controller.recordings.isEmpty, let window else { return }
        hasGrownToShowRecordings = true

        var frame = window.frame
        let delta = RecordingsListView.rowHeight
        // Grow downward: the top edge — where the controls the user is looking
        // at already are — stays exactly where it was.
        frame.origin.y -= delta
        frame.size.height += delta
        window.setFrame(frame, display: true, animate: true)
    }

    // MARK: - Action bar

    /// One row, left-aligned: everything that decides what the next recording
    /// captures, then the live indicator and settings on the right.
    ///
    /// The window title is gone. It was one line of chrome repeating what the
    /// title bar already says, pushing the only controls that matter down the
    /// screen.
    private var actionBar: some View {
        HStack(spacing: DS.Space.s) {
            // The one action this screen exists for.
            Button(action: controller.toggleRecording) {
                Text(controller.isRecording ? "Stop" : "Record")
            }
            .buttonStyle(MinimalButton(variant: .primary, size: .md, minWidth: 96))
            .keyboardShortcut("r", modifiers: [.command, .shift])
            .disabled(controller.state == .starting || controller.state == .stopping)
            .tooltip(controller.isRecording
                     ? "Stop recording and open the result in the editor  ⇧⌘R"
                     : "Start recording  ⇧⌘R")

            // Mic before camera: narration is the more common addition, and
            // the row reads in the order people usually switch things on.
            DeviceMenuButton(
                devices: controller.microphones,
                selection: $controller.settings.microphoneDeviceID,
                onSymbol: "mic.fill",
                offSymbol: "mic.slash",
                name: "Microphone",
                offHelp: "Microphone — off. Click to record narration.",
                isRecording: controller.isRecording,
                onSelectionChanged: handleDeviceSelectionChange
            )
            DeviceMenuButton(
                devices: controller.cameras,
                selection: $controller.settings.cameraDeviceID,
                onSymbol: "video.fill",
                offSymbol: "video.slash",
                name: "Camera",
                offHelp: "Camera — off. Click to record your camera alongside the screen.",
                isRecording: controller.isRecording,
                onSelectionChanged: handleDeviceSelectionChange
            )

            captureModeToggle

            sourcePicker

            Spacer(minLength: DS.Space.l)

            // Reserved, so starting a recording never changes the row's height
            // or shifts the settings button.
            //
            // Finishing a take is not instant — the writers flush, the movie is
            // finalised, the event log is written — and on a long recording
            // that's several seconds where the app looked idle and people
            // pressed Record again. So the same slot reports it.
            HStack(spacing: DS.Space.s) {
                if let message = controller.processingMessage {
                    ProgressView()
                        .controlSize(.small)
                        .scaleEffect(0.7)
                        .frame(width: 12, height: 12)
                    Text(message)
                        .font(DS.Font.caption)
                        .foregroundStyle(DS.Text.secondary)
                } else {
                    Circle()
                        .fill(DS.Status.dangerSolid)
                        .frame(width: 8, height: 8)
                    Text(timecode(controller.elapsed))
                        .font(DS.Font.mono(13, weight: .medium))
                        .monospacedDigit()
                        .foregroundStyle(DS.Text.primary)
                }
            }
            .opacity(controller.isRecording ? 1 : 0)
            .accessibilityHidden(!controller.isRecording)
            .animation(DS.Motion.base, value: controller.isRecording)
            .animation(DS.Motion.base, value: controller.processingMessage)

            Button {
                showSettings.toggle()
            } label: {
                Image(systemName: "slider.horizontal.3")
            }
            .buttonStyle(MinimalButton(variant: .tertiary, size: .md, square: true))
            .popover(isPresented: $showSettings, arrowEdge: .bottom) { settingsPopover }
            .disabled(controller.isRecording)
            .tooltip("Settings")
            .accessibilityLabel("Settings")
        }
    }

    // MARK: - Capture controls

    /// Both states visible at once, so the current mode is readable without
    /// interpreting which button is showing. Full display is the default;
    /// choosing Region opens the selector, and the chosen rectangle stays on
    /// screen and adjustable until recording starts or it's cleared.
    private var captureModeToggle: some View {
        HStack(spacing: 0) {
            ModeButton(title: "Full display",
                       selected: controller.region == nil,
                       help: "Record the whole screen") {
                controller.clearRegion()
            }
            Rectangle()
                .fill(DS.Action.secondaryBorder)
                .frame(width: DS.line, height: DS.ControlHeight.md - 2)
            ModeButton(title: "Region",
                       selected: controller.region != nil,
                       help: controller.region != nil
                             ? "Drag the corners on screen to adjust, or click here to draw a new one"
                             : "Record part of the screen. Drag out a box, or click a window.") {
                controller.chooseRegion()
            }
        }
        .background(
            RoundedRectangle(cornerRadius: DS.Radius.control)
                .strokeBorder(DS.Action.secondaryBorder, lineWidth: DS.line)
        )
        .clipShape(RoundedRectangle(cornerRadius: DS.Radius.control))
        .disabled(controller.isRecording)
    }

    /// The display picker, dressed as a `MinimalButton` (border, hover,
    /// height) with a trailing chevron rather than a native pop-up — the same
    /// object as the buttons either side of it, per the house style.
    private var sourcePicker: some View {
        let currentName = controller.displays.first { $0.id == controller.selectedDisplayID }?.localizedName
            ?? "Choose a display"

        return MinimalDropdown(size: .md, label: currentName) {
            ForEach(controller.displays) { display in
                Button {
                    controller.selectedDisplayID = display.id
                } label: {
                    if display.id == controller.selectedDisplayID {
                        Label(display.localizedName, systemImage: "checkmark")
                    } else {
                        Text(display.localizedName)
                    }
                }
            }
        }
        .frame(width: 200)
        .disabled(controller.isRecording || controller.region != nil)
        .tooltip(controller.region != nil
                 ? "Recording a region. Choose Full display to pick a screen."
                 : "Which screen to record")
    }

    /// Runs whenever a mic or camera selection changes. A first pick — going
    /// from Off to an actual device — is the one moment a permission prompt
    /// is earned: it's a direct response to something the person just clicked,
    /// not a surprise from opening the app. Both media types are requested
    /// together regardless of which control was touched, so a "successful
    /// capture experience" — screen plus narration plus a camera bubble —
    /// only ever costs one round of system dialogs instead of one now and
    /// another mid-recording later.
    private func handleDeviceSelectionChange(_ newValue: String?) {
        guard newValue != nil else {
            controller.syncMicMonitor()
            return
        }
        Task {
            await controller.requestCaptureAccessIfNeeded()
            controller.syncMicMonitor()
        }
    }

    /// What the next recording will capture. Grouped by space, not by separators.
    private var summaryRow: some View {
        HStack(alignment: .center, spacing: DS.Space.m) {
            cameraPreview

            // The text column sits beside the preview, not under it: a status
            // line under a 95 pt picture is a long way from the controls it's
            // reporting on.
            VStack(alignment: .leading, spacing: DS.Space.s) {
                HStack(spacing: DS.Space.m) {
                    Text(controller.captureDescription)
                        .tooltip("What will be recorded")

                    HStack(spacing: DS.Space.xs) {
                        Text("\(controller.settings.frameRate) fps")
                            .tooltip("Frames recorded each second")
                        skippedFramesMarker
                    }
                }
                .font(DS.Font.caption)
                .foregroundStyle(DS.Text.secondary)

                // Its own line. Sharing a row with the resolution meant the meter
                // moved sideways whenever the capture description changed length,
                // which is exactly when you're looking at it.
                if controller.settings.microphoneDeviceID != nil {
                    micMeter
                }

                messageSlot
            }

            Spacer()
        }
    }

    /// A quiet marker beside the frame rate when frames were skipped.
    ///
    /// Skipped frames are the normal result of a screen that didn't change, so
    /// this says so on hover and says nothing otherwise. It used to be a warning
    /// in the message slot, where it sat beside real failures like "couldn't
    /// save the video" — and on a slide-based demo, where almost nothing moves,
    /// it was both the loudest message on screen and the least important.
    @ViewBuilder
    private var skippedFramesMarker: some View {
        if controller.skippedFrames > 0 {
            Image(systemName: "info.circle")
                .font(.system(size: 11))
                .foregroundStyle(DS.Text.tertiary)
                .tooltip("\(controller.skippedFrames) frames were skipped because the screen didn't change. That's normal and doesn't affect your video.")
                .accessibilityLabel("\(controller.skippedFrames) frames skipped")
        }
    }

    /// Live camera, so you can check you're in frame before pressing Record
    /// rather than after.
    ///
    /// Only present when a camera is selected — an empty well the rest of the
    /// time would be a permanent reminder of a feature you aren't using. It
    /// leads the summary row: it's the one thing here you have to *look* at
    /// rather than read, so it shouldn't be at the end of the reading path.
    @ViewBuilder
    private var cameraPreview: some View {
        if controller.settings.cameraDeviceID != nil {
            ZStack {
                RoundedRectangle(cornerRadius: DS.Radius.chip)
                    .fill(DS.Surface.sunken)

                if controller.cameraMonitor.isRunning {
                    CameraPreviewView(session: controller.cameraMonitor.captureSession,
                                      cornerRadius: DS.Radius.chip)
                } else {
                    // Permission hasn't been granted yet, or the device is busy.
                    // The monitor deliberately never prompts, so this explains
                    // the blank rather than leaving it unexplained.
                    Image(systemName: "video.slash")
                        .font(.system(size: 18))
                        .foregroundStyle(DS.Text.tertiary)
                }
            }
            .frame(width: 168, height: 95)
            .overlay(
                RoundedRectangle(cornerRadius: DS.Radius.chip)
                    .strokeBorder(DS.Border.subtle, lineWidth: DS.line)
            )
            .tooltip(controller.cameraMonitor.isRunning
                     ? "Your camera, mirrored — the recording matches this"
                     : "Camera preview appears once camera access is granted")
            .transition(.opacity)
            .animation(DS.Motion.fast, value: controller.settings.cameraDeviceID)
        }
    }

    /// A fixed slot. Messages appear and disappear without moving the list below —
    /// an appearing status must never shove the rest of the screen.
    private var messageSlot: some View {
        Group {
            if let error = controller.errorMessage {
                message(error, symbol: "exclamationmark.triangle", tint: DS.Status.danger)
            } else if let warning = controller.warnings.first {
                message(warning, symbol: "exclamationmark.circle", tint: DS.Status.warning)
            } else if let status = controller.statusMessage {
                message(status, symbol: "checkmark.circle", tint: DS.Status.success)
            } else {
                Color.clear
            }
        }
        .frame(height: 18, alignment: .leading)
        .frame(maxWidth: .infinity, alignment: .leading)
    }

    private func message(_ text: String, symbol: String, tint: Color) -> some View {
        // Colour never carries the meaning alone — every status has an icon too.
        HStack(spacing: DS.Space.s) {
            Image(systemName: symbol)
            Text(text).lineLimit(1)
        }
        .font(DS.Font.caption)
        .foregroundStyle(tint)
    }

    /// Input meter. Neutral until it approaches clipping, which is the only part
    /// that is actually a warning.
    private var micMeter: some View {
        let level = AudioLevel.meter(controller.micLevel)
        let segments = 12

        return HStack(spacing: 2) {
            ForEach(0..<segments, id: \.self) { index in
                let threshold = Double(index + 1) / Double(segments)
                RoundedRectangle(cornerRadius: 1)
                    .fill(level >= threshold ? segmentColor(threshold) : DS.Border.default)
                    .frame(width: 4, height: 12)
            }
        }
        .animation(DS.Motion.fast, value: level)
        .tooltip(controller.micLevel > 0.001 ? "Microphone level" : "Say something to test it")
        .accessibilityLabel("Microphone level")
    }

    private func segmentColor(_ threshold: Double) -> Color {
        if threshold > 0.92 { return DS.Status.danger }
        if threshold > 0.8 { return DS.Status.warning }
        return DS.Text.primary
    }

    // MARK: - Settings

    /// Reset, three saved configurations, and where to save the current one.
    ///
    /// The same row as the editor's, for the same reason: if you always want
    /// 30 fps H.264 with the system audio off, that shouldn't be four clicks
    /// every time. Device choices are excluded — a set that pinned a particular
    /// webcam would silently do nothing on a Mac without it.
    private var captureSetRow: some View {
        HStack(spacing: DS.Space.xs) {
            Button("Reset") { controller.resetCaptureSettings() }
                .buttonStyle(MinimalButton(variant: .tertiary, size: .sm))
                .disabled(controller.captureSettingsAreDefault)
                .tooltip(controller.captureSettingsAreDefault
                         ? "Already at the standard settings"
                         : "Back to the standard settings")

            Spacer(minLength: DS.Space.xs)

            ForEach(CaptureSet.Slot.allCases) { slot in
                let exists = controller.captureSetExists(slot)
                let inUse = controller.captureSettingsMatch(slot)
                Button("\(slot.rawValue)") { controller.applyCaptureSet(slot) }
                    .buttonStyle(MinimalButton(variant: inUse ? .secondary : .tertiary,
                                               size: .sm, square: true))
                    .disabled(!exists || inUse)
                    .tooltip(!exists ? "\(slot.label) is empty"
                             : inUse ? "\(slot.label) is already in use"
                             : "Use \(slot.label)")
            }

            Spacer(minLength: DS.Space.xs)

            Menu {
                ForEach(CaptureSet.Slot.allCases) { slot in
                    Button(controller.captureSetExists(slot) ? "\(slot.label) (replace)" : slot.label) {
                        controller.saveCaptureSet(slot)
                    }
                }
            } label: {
                Text("Save set")
            }
            .menuStyle(.borderlessButton)
            .fixedSize()
            .tooltip("Save these settings so you can use them again")
        }
    }

    private var settingsPopover: some View {
        // No dividers: the row spacing alone is enough separation between
        // these groups, and a rule between every couple of controls turned six
        // short groups into a ladder.
        VStack(alignment: .leading, spacing: DS.Space.m) {
            captureSetRow

            Picker("Frame rate", selection: $controller.settings.frameRate) {
                ForEach(CaptureSettings.frameRateOptions, id: \.self) { rate in
                    Text("\(rate) fps")
                        .tag(rate)
                        .disabled(!controller.frameRateIsAvailable(rate))
                }
            }
            .tooltip("Higher is smoother. Lower makes much smaller files. This screen tops out at \(controller.displayMaxFrameRate) fps.")

            Picker("Quality", selection: $controller.settings.quality) {
                ForEach(CaptureSettings.Quality.allCases) { quality in
                    Text(quality.label).tag(quality)
                }
            }
            .tooltip(controller.settings.quality.detail)

            Picker("Codec", selection: $controller.settings.codec) {
                ForEach(CaptureSettings.MasterCodec.allCases) { codec in
                    Text(codec.displayName).tag(codec)
                }
            }
            .tooltip("HEVC: smaller file. H.264: plays everywhere.")

            Picker("Appearance", selection: Binding(
                get: { controller.theme },
                set: { controller.setTheme($0) }
            )) {
                ForEach(AppTheme.allCases) { theme in
                    Text(theme.label).tag(theme)
                }
            }
            .tooltip("Light, dark, or match your Mac")

            if controller.settings.cameraDeviceID != nil {
                Picker("Camera preview", selection: $controller.settings.cameraPreviewCorner) {
                    ForEach(CaptureSettings.PreviewCorner.allCases) { corner in
                        Text(corner.label).tag(corner)
                    }
                }
                .tooltip("Where the preview sits while you record")
            }

            Toggle("System audio", isOn: $controller.settings.capturesSystemAudio)
                .tooltip("Record your Mac’s sound")

            // Off by default — `SCContentFilter` keeps the recorder out of its
            // own output. This is the one way around that: it excludes the
            // whole application by bundle identifier, not one specific window,
            // so switching it on covers the home window *and* any editor window
            // that's open — everything needed to make a video about the app
            // itself, not a video of one screen of it.
            Toggle("Record Capture's own windows", isOn: $controller.settings.includeAppWindows)
                .tooltip("Show ajwoo capture itself in the recording — the home window and any editor windows that are open")

            Button("Rescan devices") { controller.refreshDevices() }
                .buttonStyle(MinimalButton(variant: .tertiary, size: .sm))
                .tooltip("Look for newly plugged-in devices")

            Button("Delete unfavorited videos") { confirmDeleteAll = true }
                .buttonStyle(MinimalButton(variant: .tertiary, size: .sm, tint: DS.Status.danger))
                .disabled(deletableRecordingsCount == 0)
                .tooltip(controller.recordings.isEmpty
                         ? "No recordings to delete"
                         : deletableRecordingsCount == 0
                         ? "Every recording is favorited — nothing to delete"
                         : "Delete every recording that isn't favorited. Can’t be undone.")
        }
        .font(DS.Font.body)
        .padding(DS.Space.m)
        // Wide enough for Reset, the two slots and Save set to share one line.
        .frame(width: 300)
        .confirmationDialog("Delete \(deletableRecordingsCount) \(deletableRecordingsCount == 1 ? "recording" : "recordings")?",
                            isPresented: $confirmDeleteAll,
                            titleVisibility: .visible) {
            Button("Delete", role: .destructive) { controller.deleteAllRecordings() }
            Button("Cancel", role: .cancel) { }
        } message: {
            Text("Every video, its audio and its edits are erased. Favorited recordings are kept. This can't be undone.")
        }
    }

    /// How many recordings "Delete unfavorited videos" would actually touch —
    /// favorited ones are left alone, so the button, its tooltip and the
    /// confirmation count all need to agree on that, not on
    /// `recordings.count`.
    private var deletableRecordingsCount: Int {
        controller.recordings.filter { !$0.isFavorite }.count
    }

    private func timecode(_ seconds: TimeInterval) -> String {
        let total = Int(seconds)
        return String(format: "%02d:%02d", total / 60, total % 60)
    }
}

/// No dead ends: names what's missing and offers the one action that fixes it.
struct PermissionGateView: View {
    @EnvironmentObject private var controller: RecordingController

    var body: some View {
        VStack(alignment: .leading, spacing: DS.Space.l) {
            Text("Let ajwoo capture see your screen")
                .font(DS.Font.h3)
                .tracking(DS.Tracking.title)
                .foregroundStyle(DS.Text.primary)

            switch controller.permission {
            case .notDetermined:
                Text("Your Mac has to allow this before you can record anything.")
                    .font(DS.Font.body)
                    .foregroundStyle(DS.Text.secondary)
                Button("Grant permission") { controller.requestPermission() }
                    .buttonStyle(MinimalButton(variant: .primary, size: .md))
                    .tooltip("Ask macOS for permission")
            case .denied:
                Text("Open System Settings, switch on ajwoo capture under Screen & System Audio Recording, then reopen the app.")
                    .font(DS.Font.body)
                    .foregroundStyle(DS.Text.secondary)
                    .fixedSize(horizontal: false, vertical: true)
                    .frame(maxWidth: 460, alignment: .leading)
                HStack(spacing: DS.Space.s) {
                    Button("Open settings") { controller.openSettings() }
                        .buttonStyle(MinimalButton(variant: .primary, size: .md))
                        .tooltip("Open the setting in System Settings")
                    Button("Check again") { Task { await controller.refreshContent() } }
                        .buttonStyle(MinimalButton(variant: .secondary, size: .md))
                        .tooltip("Check whether permission has been granted")
                }
            case .granted:
                EmptyView()
            }
            Spacer()
        }
        .padding(DS.Space.l)
        .frame(maxWidth: .infinity, alignment: .leading)
    }
}

/// One segment of `captureModeToggle` — "Full display" or "Region".
///
/// A plain `Button(action:)` here carried the selected-state fill but nothing
/// for hover, so the segment you weren't on gave no feedback at all until the
/// exact pixel of the click. Own view struct rather than a helper function
/// because hover needs `@State`, and a function can't hold that.
private struct ModeButton: View {
    let title: String
    let selected: Bool
    let help: String
    let action: () -> Void

    @State private var hovering = false
    @Environment(\.isEnabled) private var isEnabled

    var body: some View {
        Button(action: action) {
            Text(title)
                .font(DS.Font.label)
                .lineLimit(1)
                .fixedSize(horizontal: true, vertical: false)
                .foregroundStyle(selected ? DS.Text.primary : DS.Text.secondary)
                .padding(.horizontal, DS.Space.m)
                .frame(height: DS.ControlHeight.md)
                .frame(minWidth: 92)
                // A filled black segment reads as a pressed button rather than
                // a selection. This matches the way a macOS pop-up marks its
                // current item: a light fill, text unchanged. Hover gets the
                // same quieter fill `MinimalButton`'s tertiary variant uses,
                // so the unselected segment isn't dead until you click it.
                .background(selected ? DS.Surface.selected
                            : (hovering && isEnabled ? DS.Action.tertiaryHover : Color.clear))
                .contentShape(Rectangle())
        }
        .buttonStyle(.plain)
        .onHover { hovering = $0 && isEnabled }
        .animation(DS.Motion.fast, value: hovering)
        .tooltip(help)
        .accessibilityAddTraits(selected ? [.isSelected] : [])
    }
}

/// The mic/camera on-off-and-pick control — one icon, the same height as the
/// row, that opens a menu of devices.
///
/// Own view struct for the same reason as `ModeButton`: hover needs `@State`.
/// `isRecording`/`devices.isEmpty` are passed in and used for a local
/// `isDisabled` rather than read back through `@Environment(\.isEnabled)`,
/// because that environment value reflects what an *ancestor* set before this
/// view — a `.disabled()` this view applies to itself, later in its own body,
/// isn't visible to a `@Environment` read earlier in the same chain.
private struct DeviceMenuButton: View {
    let devices: [RecordingController.DeviceOption]
    let selection: Binding<String?>
    let onSymbol: String
    let offSymbol: String
    let name: String
    let offHelp: String
    let isRecording: Bool
    /// Called with the new selection right after it changes, so the caller
    /// can decide whether a first pick needs to ask for permission.
    let onSelectionChanged: (String?) -> Void

    @State private var hovering = false

    private var isOn: Bool { selection.wrappedValue != nil }
    private var device: String? { devices.first { $0.id == selection.wrappedValue }?.name }
    private var isDisabled: Bool { isRecording || devices.isEmpty }

    var body: some View {
        Menu {
            Button("Off") { selection.wrappedValue = nil }
            if !devices.isEmpty {
                Divider()
                ForEach(devices) { option in
                    Button(option.name) { selection.wrappedValue = option.id }
                }
            }
        } label: {
            Image(systemName: isOn ? onSymbol : offSymbol)
                .foregroundStyle(isOn ? DS.Text.primary : DS.Text.tertiary)
        }
        .menuStyle(.borderlessButton)
        .menuIndicator(.hidden)
        .frame(width: DS.ControlHeight.md, height: DS.ControlHeight.md)
        .background(
            RoundedRectangle(cornerRadius: DS.Radius.control)
                .fill(hovering && !isDisabled ? DS.Action.secondaryHover : Color.clear)
        )
        .overlay(
            RoundedRectangle(cornerRadius: DS.Radius.control)
                .strokeBorder(isOn ? DS.Border.strong : DS.Action.secondaryBorder, lineWidth: DS.line)
        )
        .onHover { hovering = $0 && !isDisabled }
        .animation(DS.Motion.fast, value: hovering)
        .disabled(isDisabled)
        .tooltip(devices.isEmpty ? "No \(name.lowercased()) available"
                                 : (isOn ? "\(name) — \(device ?? "on"). Click to change or switch off."
                                         : offHelp))
        .accessibilityLabel(name)
        .accessibilityValue(isOn ? (device ?? "on") : "off")
        .onChange(of: selection.wrappedValue) { _, newValue in onSelectionChanged(newValue) }
    }
}

/// Hands back the `NSWindow` a SwiftUI view is hosted in.
///
/// SwiftUI has no direct way to read or resize the window a view sits inside —
/// `.defaultSize`/`.windowResizability` only ever set it once, at open. This is
/// the standard bridge: an invisible `NSView` parked in the background that
/// reports its window the moment it's attached to one. It returns `nil` from
/// `hitTest` so it never intercepts a click meant for the real content.
private struct WindowAccessor: NSViewRepresentable {
    let onResolve: (NSWindow) -> Void

    func makeNSView(context: Context) -> NSView {
        let view = ProbeView()
        view.onResolve = onResolve
        return view
    }

    func updateNSView(_ nsView: NSView, context: Context) {}

    private final class ProbeView: NSView {
        var onResolve: ((NSWindow) -> Void)?

        override func viewDidMoveToWindow() {
            super.viewDidMoveToWindow()
            if let window { onResolve?(window) }
        }

        override func hitTest(_ point: NSPoint) -> NSView? { nil }
    }
}
