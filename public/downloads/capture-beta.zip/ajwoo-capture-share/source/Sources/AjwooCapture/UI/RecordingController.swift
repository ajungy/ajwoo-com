import Foundation
import SwiftUI
import AppKit
import AVFoundation
import CoreGraphics

/// The one object the recording UI talks to. Owns the capture engine, the
/// camera/mic recorder and the recordings list.
@MainActor
final class RecordingController: ObservableObject {

    enum State: Equatable {
        case idle
        case starting
        case recording
        case stopping
    }

    struct DeviceOption: Identifiable, Hashable {
        let id: String
        let name: String
    }

    @Published private(set) var state: State = .idle {
        didSet {
            guard oldValue != state else { return }
            updateMenuBarAnimation()
        }
    }
    @Published private(set) var menuBarImage: NSImage = MenuBarIcon.image(phase: .idle, progress: 0)
    @Published private(set) var permission: ScreenRecordingPermission = .notDetermined
    @Published private(set) var displays: [DisplayOption] = []
    @Published private(set) var windowCount: Int = 0
    @Published var selectedDisplayID: CGDirectDisplayID? {
        didSet {
            guard oldValue != selectedDisplayID else { return }
            clampFrameRateToDisplay()
        }
    }
    @Published var settings = CaptureSettings()
    @Published private(set) var region: CaptureRegion?

    @Published private(set) var cameras: [DeviceOption] = []
    @Published private(set) var microphones: [DeviceOption] = []
    @Published private(set) var micLevel: Float = 0

    @Published private(set) var recordings: [RecordingSession] = []
    @Published private(set) var elapsed: TimeInterval = 0
    /// Whole seconds, published separately.
    ///
    /// `elapsed` ticks ten times a second, and anything bound to it redraws that
    /// often — which, for an open menu, means it redraws under the pointer and
    /// loses its highlight. Displays that only need seconds bind to this.
    @Published private(set) var elapsedSeconds: Int = 0
    @Published var statusMessage: String?
    @Published var errorMessage: String?
    @Published private(set) var warnings: [String] = []
    /// Frames the last recording skipped because the screen hadn't changed.
    /// Shown as a quiet marker beside the frame rate, not as a warning.
    @Published private(set) var skippedFrames: Int = 0
    @Published private(set) var lastRecordingURL: URL?
    /// Set when a take finishes, so the UI can open it in the editor. Cleared by
    /// whoever handles it.
    @Published var pendingEditorURL: URL?
    @Published private(set) var theme: AppTheme = .current

    var isRecording: Bool { state == .recording || state == .stopping }

    /// What the menu bar should be showing.
    ///
    /// `.stopping` covers everything between releasing the button and the editor
    /// opening — flushing the writers, finalising the movie, reading the event
    /// log. On a long take that's several seconds of apparently nothing
    /// happening, which is exactly when people press Record again.
    var menuBarPhase: MenuBarIcon.Phase {
        switch state {
        case .idle:      return .idle
        case .starting:  return .idle
        case .recording: return .recording
        case .stopping:  return .processing
        }
    }

    /// Ticked while recording or processing so the menu bar mark animates.
    ///
    /// A timer rather than a SwiftUI animation: the status item takes an image,
    /// so something has to hand it a new one. 20 Hz is plenty for a 1.6 s breath
    /// and costs nothing next to the capture itself, and the timer only exists
    /// while there's something to show.
    private var menuBarTimer: Timer?

    private func updateMenuBarAnimation() {
        let phase = menuBarPhase
        guard phase != .idle else {
            menuBarTimer?.invalidate()
            menuBarTimer = nil
            menuBarImage = MenuBarIcon.image(phase: .idle, progress: 0)
            return
        }
        guard menuBarTimer == nil else { return }
        let timer = Timer(timeInterval: 1.0 / 20, repeats: true) { [weak self] _ in
            MainActor.assumeIsolated {
                guard let self else { return }
                let period = self.menuBarPhase == .processing ? 1.1 : 1.6
                let progress = CaptureClock.now().truncatingRemainder(dividingBy: period) / period
                self.menuBarImage = MenuBarIcon.image(phase: self.menuBarPhase, progress: progress)
            }
        }
        RunLoop.main.add(timer, forMode: .common)
        menuBarTimer = timer
    }

    /// Human-readable version of the same thing, for the window and the menu.
    var processingMessage: String? {
        state == .stopping ? "Finishing your recording…" : nil
    }

    private let engine = ScreenCaptureEngine()
    private let cameraPreview = CameraPreviewWindow()
    private let regionSelector = RegionSelector()
    private let regionOverlay = RegionOverlayWindow()
    private let regionDim = RegionDimWindow()
    private var cameraRecorder: CameraMicRecorder?
    private let micMonitor = MicMonitor()
    /// Live camera preview for the home window. Only runs while a camera is
    /// selected and nothing is being recorded — during a take the recorder owns
    /// the device and provides its own preview session.
    let cameraMonitor = CameraMonitor()
    private var activeSession: RecordingSession?
    private var elapsedTimer: Timer?
    private var meterTimer: Timer?
    private var startInstant: Double = 0

    init() {
        permission = CapturePermissions.screenRecordingStatus()
        recordings = RecordingSession.all()
        region = CaptureRegion.remembered
        theme = .current
        refreshDevices()
        Task { await refreshContent() }
        startMeterTimer()
        syncMicMonitor()
    }

    // MARK: - Idle mic monitoring

    /// Keeps the level meter live whenever a mic is selected and we're not
    /// recording, so you can check the input before starting rather than after.
    /// The monitor is torn down for the take itself — the recorder needs the
    /// device.
    func syncMicMonitor() {
        Task {
            if let deviceID = settings.microphoneDeviceID, !isRecording {
                await micMonitor.start(deviceID: deviceID)
            } else {
                micMonitor.stop()
                cameraMonitor.stop()
            }
        }
        syncCameraMonitor()
    }

    /// Same idea for the camera: you should be able to see that you're in frame
    /// and lit before pressing Record, not after.
    func syncCameraMonitor() {
        if let deviceID = settings.cameraDeviceID, !isRecording {
            cameraMonitor.start(deviceID: deviceID)
        } else {
            cameraMonitor.stop()
        }
    }

    /// Asks for whatever camera/microphone access hasn't been decided yet.
    ///
    /// `MicMonitor`/`CameraMonitor` deliberately never prompt on their own —
    /// see their own comments — because a dialog appearing just from opening
    /// the app would be rude. But that meant the *first* prompt a person ever
    /// saw was buried inside starting an actual recording, by which point
    /// they'd already been looking at a blank preview and a silent meter with
    /// no explanation. This is the one place a prompt is earned: the person
    /// just clicked the mic or camera control themselves, so it's a direct
    /// response to something they did, not a surprise.
    ///
    /// Both media types are requested together, regardless of which control
    /// was clicked — the goal is a *successful capture experience*, and a
    /// screen recording with narration needs both. Asking for both up front
    /// means one round of system dialogs instead of the mic prompt now and a
    /// camera prompt minutes later, mid-recording, when switching it on.
    func requestCaptureAccessIfNeeded() async {
        if AVCaptureDevice.authorizationStatus(for: .audio) == .notDetermined {
            _ = await AVCaptureDevice.requestAccess(for: .audio)
        }
        if AVCaptureDevice.authorizationStatus(for: .video) == .notDetermined {
            _ = await AVCaptureDevice.requestAccess(for: .video)
        }
    }

    // MARK: - Capture sets

    /// Frame rate, codec and what's recorded alongside the screen, back to the
    /// shipped defaults. Device choices are left alone — they're about what's
    /// plugged in right now, not about a saved preference.
    func resetCaptureSettings() {
        CaptureSet(from: CaptureSettings()).apply(to: &settings)
    }

    func applyCaptureSet(_ slot: CaptureSet.Slot) {
        guard let set = CaptureSet.load(slot) else { return }
        set.apply(to: &settings)
        statusMessage = "Applied \(slot.label)"
    }

    func saveCaptureSet(_ slot: CaptureSet.Slot) {
        CaptureSet.save(CaptureSet(from: settings), to: slot)
        objectWillChange.send()
        statusMessage = "Saved \(slot.label)"
    }

    func captureSetExists(_ slot: CaptureSet.Slot) -> Bool { CaptureSet.exists(slot) }

    /// The refresh rate of the display being recorded.
    ///
    /// Asking ScreenCaptureKit for more frames than the panel produces doesn't
    /// get them — it just repeats what's there — so those options are offered
    /// and then quietly ignored. `maximumFramesPerSecond` reports 0 on displays
    /// that don't answer, and 60 is the safe reading of "we don't know".
    var displayMaxFrameRate: Int {
        let target = region?.displayID ?? selectedDisplayID
        guard let screen = NSScreen.screens.first(where: { $0.displayID == target })
                ?? NSScreen.main else { return 60 }
        let reported = screen.maximumFramesPerSecond
        return reported > 0 ? reported : 60
    }

    /// A frame rate the current display can actually deliver.
    ///
    /// The next step down is always allowed — 120 Hz panels can do 60, and every
    /// panel can do 15 — so this only ever rules out asking for *more* than the
    /// hardware has.
    func frameRateIsAvailable(_ rate: Int) -> Bool {
        rate <= displayMaxFrameRate
    }

    /// Drops the chosen rate to something this display can deliver.
    ///
    /// Needed when the display changes under a setting that was fine for the
    /// last one — otherwise the picker shows a greyed-out option as selected,
    /// which is a state the user can't get out of by clicking.
    private func clampFrameRateToDisplay() {
        guard !frameRateIsAvailable(settings.frameRate) else { return }
        let max = displayMaxFrameRate
        settings.frameRate = CaptureSettings.frameRateOptions
            .filter { $0 <= max }
            .last ?? CaptureSettings.frameRateOptions.first ?? 30
    }

    var captureSettingsAreDefault: Bool {
        CaptureSet(from: settings) == CaptureSet(from: CaptureSettings())
    }

    func captureSettingsMatch(_ slot: CaptureSet.Slot) -> Bool {
        guard let stored = CaptureSet.load(slot) else { return false }
        return stored == CaptureSet(from: settings)
    }

    func setTheme(_ theme: AppTheme) {
        self.theme = theme
        theme.apply()
    }

    // MARK: - Permission

    func requestPermission() {
        permission = CapturePermissions.requestScreenRecording()
        if permission == .granted {
            Task { await refreshContent() }
        }
    }

    func openSettings() {
        CapturePermissions.openScreenRecordingSettings()
    }

    // MARK: - Content and devices

    func refreshContent() async {
        permission = CapturePermissions.screenRecordingStatus()
        guard permission == .granted else {
            displays = []
            return
        }
        do {
            let content = try await ShareableContent.fetch()
            displays = content.displays
            windowCount = content.windows.count
            if selectedDisplayID == nil || !content.displays.contains(where: { $0.id == selectedDisplayID }) {
                selectedDisplayID = content.displays.first(where: { $0.id == CGMainDisplayID() })?.id
                    ?? content.displays.first?.id
            }
            // A remembered region is useless if that display is gone.
            if let region, !content.displays.contains(where: { $0.id == region.displayID }) {
                self.region = nil
            }
        } catch {
            errorMessage = "Couldn't find your screens."
        }
    }

    func refreshDevices() {
        cameras = CameraMicRecorder.cameras().map { DeviceOption(id: $0.uniqueID, name: $0.localizedName) }
        microphones = CameraMicRecorder.microphones().map { DeviceOption(id: $0.uniqueID, name: $0.localizedName) }

        if let id = settings.cameraDeviceID, !cameras.contains(where: { $0.id == id }) {
            settings.cameraDeviceID = nil
        }
        if let id = settings.microphoneDeviceID, !microphones.contains(where: { $0.id == id }) {
            settings.microphoneDeviceID = nil
        }
        syncMicMonitor()
    }

    func refreshRecordings() {
        recordings = RecordingSession.all()
    }

    // MARK: - Region

    func chooseRegion() {
        guard !isRecording else { return }
        regionOverlay.hide()
        regionSelector.present { [weak self] region in
            guard let self else { return }
            guard let region else {
                // Cancelled: restore the previous region's overlay if there was one.
                self.showRegionOverlay()
                return
            }
            self.region = region
            self.selectedDisplayID = region.displayID
            self.showRegionOverlay()
        }
    }

    func clearRegion() {
        region = nil
        regionOverlay.hide()
        regionDim.hide()
    }

    /// Keeps the chosen rectangle on screen and adjustable until recording
    /// starts or the mode is switched back to the full display.
    private func showRegionOverlay() {
        guard let region, !isRecording else { return }
        regionOverlay.show(region: region) { [weak self] updated in
            self?.region = updated
        }
    }

    var captureDescription: String {
        if let region {
            let scale = displays.first { $0.id == region.displayID }?.scale ?? 2
            return "\(Int(region.rectPoints.width * scale))×\(Int(region.rectPoints.height * scale)) px region"
        }
        guard let display = displays.first(where: { $0.id == selectedDisplayID }) else { return "—" }
        return "\(Int(display.pixelSize.width))×\(Int(display.pixelSize.height)) px full display"
    }

    var estimatedBitrateMbps: Int {
        let size: CGSize
        if let region {
            let scale = displays.first { $0.id == region.displayID }?.scale ?? 2
            size = CGSize(width: region.rectPoints.width * scale, height: region.rectPoints.height * scale)
        } else if let display = displays.first(where: { $0.id == selectedDisplayID }) {
            size = display.pixelSize
        } else {
            return 0
        }
        return settings.masterBitrate(pixelWidth: Int(size.width), pixelHeight: Int(size.height)) / 1_000_000
    }

    // MARK: - Record

    func toggleRecording() {
        switch state {
        case .idle:      startRecording()
        case .recording: stopRecording()
        case .starting, .stopping: break
        }
    }

    func startRecording() {
        guard state == .idle else { return }
        guard let displayID = region?.displayID ?? selectedDisplayID else {
            errorMessage = "Pick a display first."
            return
        }
        errorMessage = nil
        statusMessage = nil
        warnings = []
        state = .starting

        let settings = self.settings
        let region = self.region

        Task {
            do {
                // The controller owns the package so the camera and mic writers
                // land in the same directory as the screen capture.
                let session = try RecordingSession.create()
                activeSession = session

                // Camera and mic go first: their buffers queue up until the
                // screen engine's first frame fixes t0, so nothing at the head
                // of the take is lost.
                // The adjustable overlay goes; the dim surround replaces it, so
                // you can still see what's in shot without corner handles
                // sitting over the thing you're demonstrating.
                regionOverlay.hide()
                if let region { regionDim.show(region: region) }

                // Hand the device over to the recorder.
                micMonitor.stop()

                let recorder = CameraMicRecorder()
                cameraRecorder = recorder
                engine.onOriginEstablished = { [weak recorder] t0 in
                    recorder?.setOrigin(t0)
                }
                if settings.cameraDeviceID != nil || settings.microphoneDeviceID != nil {
                    await recorder.start(session: session,
                                         cameraID: settings.cameraDeviceID,
                                         microphoneID: settings.microphoneDeviceID)
                }

                do {
                    try await engine.start(session: session,
                                           displayID: displayID,
                                           region: region,
                                           settings: settings)
                } catch {
                    _ = await recorder.finish()
                    cameraRecorder = nil
                    try? session.delete()
                    activeSession = nil
                    throw error
                }

                state = .recording
                startInstant = CaptureClock.now()
                elapsed = 0
                startElapsedTimer()

                if let previewSession = recorder.previewSession {
                    cameraPreview.show(session: previewSession, corner: settings.cameraPreviewCorner)
                }
                if recorder.startedMic { startMeterTimer() }
                if !recorder.warnings.isEmpty { warnings = recorder.warnings }

            } catch {
                state = .idle
                errorMessage = error.localizedDescription
                if case CaptureError.permissionDenied = error {
                    permission = .denied
                }
            }
        }
    }

    func stopRecording() {
        guard state == .recording else { return }
        state = .stopping
        stopElapsedTimer()
        cameraPreview.hide()
        regionDim.hide()

        Task {
            // Finish the auxiliary files first so their entries can be folded
            // into events.json, which the engine writes on stop.
            let extraMedia = await cameraRecorder?.finish() ?? []
            let extraWarnings = cameraRecorder?.warnings ?? []
            cameraRecorder = nil
            engine.onOriginEstablished = nil

            do {
                let outcome = try await engine.stop(additionalMedia: extraMedia,
                                                    additionalWarnings: extraWarnings)
                state = .idle
                warnings = outcome.warnings
                skippedFrames = outcome.skippedFrames
                lastRecordingURL = outcome.session.url
                statusMessage = String(format: "Saved · %.0fs", outcome.duration)
                refreshRecordings()
                // Straight into the editor: after a take the next thing you want
                // is to watch it back, not hunt for it in a list.
                NSApp.activate(ignoringOtherApps: true)
                pendingEditorURL = outcome.session.url
            } catch {
                state = .idle
                errorMessage = error.localizedDescription
                refreshRecordings()
            }
            activeSession = nil
            syncMicMonitor()

            // Back to the full display. A region is a decision about one take,
            // and leaving its rectangle floating over the screen afterwards —
            // while you're trying to edit the very recording it produced — is
            // just in the way. Choosing Region again is one click.
            clearRegion()
        }
    }

    // MARK: - Recordings list

    func reveal(_ session: RecordingSession) {
        NSWorkspace.shared.activateFileViewerSelecting([session.url])
    }

    func delete(_ session: RecordingSession) {
        try? session.delete()
        refreshRecordings()
    }

    /// Favoriting is a visible promise — "this one stays" — so it has to
    /// actually block deletion, not just suggest it.
    func toggleFavorite(_ session: RecordingSession) {
        try? session.setFavorite(!session.isFavorite)
        refreshRecordings()
    }

    /// Removes every recording in the folder **except favorited ones**.
    ///
    /// Recordings are the only copy of the capture and this doesn't route them
    /// through the Trash, so the caller is responsible for confirming first.
    /// Deletion is best-effort per package: one unreadable take shouldn't stop
    /// the rest from going. `session.delete()` already refuses a favorite on
    /// its own — the filter here just avoids trying in the first place.
    func deleteAllRecordings() {
        for session in RecordingSession.all() where !session.isFavorite {
            try? session.delete()
        }
        refreshRecordings()
    }

    // MARK: - Timers

    private func startElapsedTimer() {
        stopElapsedTimer()
        let timer = Timer(timeInterval: 0.1, repeats: true) { [weak self] _ in
            MainActor.assumeIsolated {
                guard let self else { return }
                self.elapsed = CaptureClock.now() - self.startInstant
                let seconds = Int(self.elapsed)
                if seconds != self.elapsedSeconds { self.elapsedSeconds = seconds }
            }
        }
        RunLoop.main.add(timer, forMode: .common)
        elapsedTimer = timer
    }

    private func stopElapsedTimer() {
        elapsedTimer?.invalidate()
        elapsedTimer = nil
    }

    /// Runs for the whole app lifetime: the meter is fed by the idle monitor
    /// between takes and by the recorder during one.
    private func startMeterTimer() {
        stopMeterTimer()
        let timer = Timer(timeInterval: 1.0 / 20.0, repeats: true) { [weak self] _ in
            MainActor.assumeIsolated {
                guard let self else { return }
                self.micLevel = self.cameraRecorder?.micLevel ?? self.micMonitor.level
            }
        }
        RunLoop.main.add(timer, forMode: .common)
        meterTimer = timer
    }

    private func stopMeterTimer() {
        meterTimer?.invalidate()
        meterTimer = nil
        micLevel = 0
    }
}
