import SwiftUI
import AVFoundation
import AppKit

/// Thin wrapper around `AVPlayerLayer`.
///
/// Not AVKit's `VideoPlayer`: that brings its own transport controls, and the
/// whole point of the editor is that the timeline *is* the transport.
struct PlayerView: NSViewRepresentable {
    let player: AVPlayer

    func makeNSView(context: Context) -> PlayerHostView {
        let view = PlayerHostView()
        view.playerLayer.player = player
        return view
    }

    func updateNSView(_ nsView: PlayerHostView, context: Context) {
        if nsView.playerLayer.player !== player {
            nsView.playerLayer.player = player
        }
    }
}

final class PlayerHostView: NSView {
    let playerLayer = AVPlayerLayer()

    override init(frame frameRect: NSRect) {
        super.init(frame: frameRect)
        wantsLayer = true
        let root = CALayer()
        root.backgroundColor = NSColor.black.cgColor
        layer = root
        playerLayer.videoGravity = .resizeAspect
        playerLayer.backgroundColor = NSColor.black.cgColor
        root.addSublayer(playerLayer)
    }

    required init?(coder: NSCoder) { fatalError("not used") }

    /// Never take part in hit testing.
    ///
    /// This is a display surface, nothing more. As a normal `NSView` it becomes
    /// the hit view for every click inside its bounds, which sits it in front of
    /// the SwiftUI overlays layered above it — that's why the camera bubble
    /// couldn't be grabbed. Returning nil makes AppKit look straight through to
    /// the SwiftUI hosting view, so the overlays get their gestures and this view
    /// just draws.
    override func hitTest(_ point: NSPoint) -> NSView? { nil }

    override func layout() {
        super.layout()
        CATransaction.begin()
        CATransaction.setDisableActions(true)
        playerLayer.frame = bounds
        CATransaction.commit()
    }
}
