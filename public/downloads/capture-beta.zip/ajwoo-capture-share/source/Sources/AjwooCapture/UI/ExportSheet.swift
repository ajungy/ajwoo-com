import SwiftUI
import AppKit
import AVFoundation
import UniformTypeIdentifiers

@MainActor
final class ExportController: ObservableObject {
    enum Phase: Equatable {
        case idle
        case running(Double)
        case finished(URL, copiedToClipboard: Bool)
        case failed(String)
    }

    @Published private(set) var phase: Phase = .idle
    private var token: ExportCancellationToken?
    private var task: Task<Void, Never>?

    var isRunning: Bool { if case .running = phase { return true }; return false }

    func exportMovie(model: EditorModel,
                     settings: ExportSettings,
                     to url: URL,
                     copyToClipboard: Bool = false) {
        guard let (context, session) = model.makeExportContext() else { return }
        let token = ExportCancellationToken()
        self.token = token
        phase = .running(0)

        task = Task {
            do {
                let result = try await VideoExporter.export(
                    session: session, context: context, settings: settings, to: url, token: token
                ) { value in
                    Task { @MainActor in
                        if case .running = self.phase { self.phase = .running(value) }
                    }
                }
                if copyToClipboard { Self.copy(result.url) }
                phase = .finished(result.url, copiedToClipboard: copyToClipboard)
            } catch {
                phase = .failed(error.localizedDescription)
            }
        }
    }

    func exportGIF(model: EditorModel, to url: URL, copyToClipboard: Bool = false) {
        guard let (context, session) = model.makeExportContext() else { return }
        let token = ExportCancellationToken()
        self.token = token
        phase = .running(0)

        task = Task {
            do {
                try await GIFExporter.export(session: session, context: context, to: url, token: token) { value in
                    Task { @MainActor in
                        if case .running = self.phase { self.phase = .running(value) }
                    }
                }
                if copyToClipboard { Self.copy(url) }
                phase = .finished(url, copiedToClipboard: copyToClipboard)
            } catch {
                phase = .failed(error.localizedDescription)
            }
        }
    }

    /// Puts the file on the pasteboard as a **file reference**, which is what
    /// Slack, Mail, Messages and Finder all expect. Writing the raw bytes instead
    /// works in a few apps and silently fails in most.
    private static func copy(_ url: URL) {
        let pasteboard = NSPasteboard.general
        pasteboard.clearContents()
        pasteboard.writeObjects([url as NSURL])
    }

    func cancel() {
        token?.cancel()
        phase = .idle
    }

    func reset() { phase = .idle }
}

struct ExportSheet: View {
    @ObservedObject var model: EditorModel
    @Environment(\.dismiss) private var dismiss
    @StateObject private var controller = ExportController()
    @State private var settings = ExportSettings()
    @State private var format: Format = .video
    /// Where `Save…`'s panel starts. Defaults to Desktop — somewhere obvious
    /// for a first export, rather than a Movies subfolder nobody's opened
    /// yet. The small folder button below lets you change it once and have
    /// every export after that start there instead.
    @State private var exportDirectory: URL = FileManager.default.urls(for: .desktopDirectory, in: .userDomainMask).first
        ?? AppInfo.recordingsDirectory

    private enum Format: String, CaseIterable, Identifiable {
        case video, gif
        var id: String { rawValue }
        var label: String { self == .video ? "Video" : "GIF" }
    }

    private var output: (size: CGSize, upscaleClamped: Bool) {
        settings.outputSize(sourceSize: model.effectiveSourceSize)
    }

    private var trimmedDuration: Double { model.exportedDuration }
    private var frameRate: Int { settings.frameRate(sourceFrameRate: model.sourceFrameRate) }
    private var hasAudio: Bool { model.hasMicAudio || model.hasSystemAudio }
    private var gifTooLong: Bool { trimmedDuration > GIFExporter.maximumDuration }

    var body: some View {
        VStack(alignment: .leading, spacing: DS.Space.xl) {
            Text("Export")
                .font(DS.Font.h3)
                .tracking(DS.Tracking.title)
                .foregroundStyle(DS.Text.primary)

            switch controller.phase {
            case .idle, .failed:
                settingsForm
            case .running(let progress):
                runningView(progress)
            case .finished(let url, let copied):
                finishedView(url, copied: copied)
            }
        }
        .padding(DS.Space.xxl)
        .frame(width: 460)
        .background(DS.Surface.overlay)
    }

    // MARK: - Form

    private var settingsForm: some View {
        VStack(alignment: .leading, spacing: DS.Space.l) {
            Picker("Format", selection: $format) {
                ForEach(Format.allCases) { option in
                    Text(option.label).tag(option)
                }
            }
            .pickerStyle(.segmented)
            .tooltip("GIF is silent, 15 fps and capped at \(Int(GIFExporter.maximumDuration))s, but pastes anywhere")

            if format == .video {
                Picker("Resolution", selection: $settings.preset) {
                    ForEach(ExportSettings.Preset.allCases) { preset in
                        Text(preset.label).tag(preset)
                    }
                }
                .tooltip("Smaller size, smaller file")

                Picker("Quality", selection: $settings.quality) {
                    ForEach(ExportSettings.Quality.allCases) { quality in
                        Text(quality.label).tag(quality)
                    }
                }
                .tooltip("Balanced is right for most videos")

                Picker("Codec", selection: $settings.codec) {
                    ForEach(ExportSettings.Codec.allCases) { codec in
                        Text(codec.label).tag(codec)
                    }
                }
                .tooltip("HEVC: smaller file. H.264: plays everywhere.")

                Picker("Frame rate", selection: $settings.frameRateMode) {
                    ForEach(ExportSettings.FrameRateMode.allCases) { mode in
                        Text(mode.label).tag(mode)
                    }
                }
                .tooltip("Half the file size")
            }

            exportLocationRow

            Divider().overlay(DS.Border.subtle)
            summary
            Divider().overlay(DS.Border.subtle)

            HStack(spacing: DS.Space.s) {
                Button("Cancel") { dismiss() }
                    .buttonStyle(MinimalButton(variant: .tertiary, size: .md))
                Spacer()
                Button("Copy") { exportToClipboard() }
                    .buttonStyle(MinimalButton(variant: .secondary, size: .md, minWidth: 88))
                    .disabled(format == .gif && gifTooLong)
                    .tooltip("Copy, ready to paste")
                Button("Save…") { chooseAndExport() }
                    .buttonStyle(MinimalButton(variant: .primary, size: .md, minWidth: 96))
                    .disabled(format == .gif && gifTooLong)
                    .tooltip("Save to a file")
            }
        }
    }

    /// Where the file will land, plus a small button to change it — shown
    /// once, rather than making every export interrupt itself with a full
    /// save panel just to confirm a folder you already picked last time.
    private var exportLocationRow: some View {
        HStack(spacing: DS.Space.s) {
            Text("Save to")
                .font(DS.Font.label)
                .foregroundStyle(DS.Text.secondary)
            Text(displayPath(exportDirectory))
                .font(DS.Font.caption)
                .foregroundStyle(DS.Text.primary)
                .lineLimit(1)
                .truncationMode(.head)
            Spacer(minLength: DS.Space.s)
            Button {
                chooseExportDirectory()
            } label: {
                Image(systemName: "folder").minimalIconFrame(DS.ControlHeight.sm)
            }
            .buttonStyle(MinimalButton(variant: .tertiary, size: .sm, square: true))
            .tooltip("Choose where exports are saved")
            .accessibilityLabel("Choose export location")
        }
    }

    /// `~/...` rather than the full absolute path — shorter, and doesn't
    /// spell out the account name for no reason.
    private func displayPath(_ url: URL) -> String {
        let home = FileManager.default.homeDirectoryForCurrentUser.path
        let path = url.path
        return path.hasPrefix(home) ? "~" + path.dropFirst(home.count) : path
    }

    private func chooseExportDirectory() {
        let panel = NSOpenPanel()
        panel.canChooseDirectories = true
        panel.canChooseFiles = false
        panel.canCreateDirectories = true
        panel.allowsMultipleSelection = false
        panel.directoryURL = exportDirectory
        panel.prompt = "Choose"
        guard panel.runModal() == .OK, let url = panel.url else { return }
        exportDirectory = url
    }

    private var summary: some View {
        VStack(alignment: .leading, spacing: DS.Space.s) {
            if format == .video {
                HStack {
                    Text("\(Int(output.size.width))×\(Int(output.size.height)) · \(frameRate) fps · \(Timecode.format(trimmedDuration))")
                    Spacer()
                    Text("≈ " + estimatedSize)
                        .fontWeight(.semibold)
                        .tooltip("Rough guess at the file size")
                }
                .font(DS.Font.body)
                .foregroundStyle(DS.Text.primary)

                Text("\(settings.bitrate(outputSize: output.size, frameRate: frameRate) / 1_000_000) Mbps video"
                     + (hasAudio ? "  ·  \(settings.quality.audioBitrate / 1000) kbps audio" : "  ·  no audio"))
                    .font(DS.Font.caption).foregroundStyle(DS.Text.secondary)
            } else {
                HStack {
                    Text("\(Int(min(GIFExporter.maximumWidth, output.size.width))) px wide · 15 fps · \(Timecode.format(trimmedDuration)) · silent")
                    Spacer()
                }
                .font(DS.Font.body)
                .foregroundStyle(DS.Text.primary)
                if gifTooLong {
                    Label("Too long for GIF — trim or cut below \(Int(GIFExporter.maximumDuration))s",
                          systemImage: "exclamationmark.triangle")
                        .font(DS.Font.caption).foregroundStyle(DS.Status.warning)
                }
            }

            if model.totalCutDuration > 0.01 {
                Text(String(format: "%.1fs removed by cuts", model.totalCutDuration))
                    .font(DS.Font.caption).foregroundStyle(DS.Text.tertiary)
            }
            if output.upscaleClamped {
                Label("Clamped to source size", systemImage: "info.circle")
                    .font(DS.Font.caption).foregroundStyle(DS.Status.warning)
                    .tooltip("Your recording is smaller than this")
            }
            if case .failed(let message) = controller.phase {
                Label(message, systemImage: "exclamationmark.triangle")
                    .font(DS.Font.caption).foregroundStyle(DS.Status.danger)
                    .fixedSize(horizontal: false, vertical: true)
            }
        }
    }

    private var estimatedSize: String {
        let bytes = settings.estimatedBytes(outputSize: output.size,
                                            frameRate: frameRate,
                                            seconds: trimmedDuration,
                                            hasAudio: hasAudio)
        return ByteCountFormatter.string(fromByteCount: bytes, countStyle: .file)
    }

    private func runningView(_ progress: Double) -> some View {
        VStack(alignment: .leading, spacing: DS.Space.l) {
            ProgressView(value: progress) {
                Text("Rendering…").font(DS.Font.body)
            } currentValueLabel: {
                Text("\(Int(progress * 100))%").font(DS.Font.mono(12)).monospacedDigit()
            }
            .tint(DS.Text.primary)
            HStack {
                Spacer()
                Button("Cancel") { controller.cancel() }
                    .buttonStyle(MinimalButton(variant: .secondary, size: .md, minWidth: 88))
            }
        }
    }

    private func finishedView(_ url: URL, copied: Bool) -> some View {
        VStack(alignment: .leading, spacing: DS.Space.l) {
            Label(copied ? "Copied to clipboard" : "Export complete",
                  systemImage: copied ? "doc.on.clipboard.fill" : "checkmark.circle")
                .font(DS.Font.label).foregroundStyle(DS.Status.success)
            Text(url.lastPathComponent)
                .font(DS.Font.body).foregroundStyle(DS.Text.primary)
            Text(fileSize(url))
                .font(DS.Font.caption).foregroundStyle(DS.Text.secondary)
            HStack(spacing: DS.Space.s) {
                Button("Show in Finder") { NSWorkspace.shared.activateFileViewerSelecting([url]) }
                    .buttonStyle(MinimalButton(variant: .tertiary, size: .md))
                    .tooltip("Show the file in Finder")
                Spacer()
                Button("Done") { controller.reset(); dismiss() }
                    .buttonStyle(MinimalButton(variant: .primary, size: .md, minWidth: 88))
            }
        }
    }

    // MARK: - Actions

    private func chooseAndExport() {
        let panel = NSSavePanel()
        panel.nameFieldStringValue = model.session.name + (format == .gif ? ".gif" : ".mov")
        panel.canCreateDirectories = true
        panel.allowedContentTypes = format == .gif ? [.gif] : [.quickTimeMovie]
        panel.directoryURL = exportDirectory

        guard panel.runModal() == .OK, let url = panel.url else { return }
        // Wherever they actually saved it becomes the new default, so picking
        // a different folder once doesn't have to be repeated every export.
        exportDirectory = url.deletingLastPathComponent()
        run(to: url, copyToClipboard: false)
    }

    /// Clipboard exports go to a temp file first — the pasteboard holds a file
    /// reference, so the file has to exist somewhere, and the user shouldn't have
    /// to name and file something they only want to paste once.
    private func exportToClipboard() {
        let name = model.session.name + (format == .gif ? ".gif" : ".mov")
        let url = FileManager.default.temporaryDirectory
            .appendingPathComponent("ajwoo-\(UUID().uuidString.prefix(8))", isDirectory: true)
            .appendingPathComponent(name)
        try? FileManager.default.createDirectory(at: url.deletingLastPathComponent(),
                                                 withIntermediateDirectories: true)
        run(to: url, copyToClipboard: true)
    }

    private func run(to url: URL, copyToClipboard: Bool) {
        if format == .gif {
            controller.exportGIF(model: model, to: url, copyToClipboard: copyToClipboard)
        } else {
            controller.exportMovie(model: model, settings: settings, to: url,
                                   copyToClipboard: copyToClipboard)
        }
    }

    private func fileSize(_ url: URL) -> String {
        let bytes = (try? url.resourceValues(forKeys: [.fileSizeKey]).fileSize) ?? 0
        return ByteCountFormatter.string(fromByteCount: Int64(bytes), countStyle: .file)
    }
}
