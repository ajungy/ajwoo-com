import SwiftUI
import AppKit
import UniformTypeIdentifiers

/// The only settings surface in the editor. One column of collapsible sections —
/// collapse the ones you're not using and the column stops being a wall.
struct InspectorView: View {
    @ObservedObject var model: EditorModel

    /// Arrow tone belongs in the same row as the other cursor choices: from the
    /// user's side "dark arrow" and "light arrow" are two styles, not one style
    /// plus a modifier. The model keeps them separate because the renderer needs
    /// them separate; this flattens the four options for the picker.
    private enum CursorChoice: String, CaseIterable, Identifiable {
        case dark, light, dot, hidden
        var id: String { rawValue }
        var label: String {
            switch self {
            case .dark:   return "Dark"
            case .light:  return "Light"
            case .dot:    return "Dot"
            case .hidden: return "Off"
            }
        }
    }

    /// Which named section (Background, Cursor, Audio, ...) is currently
    /// open — exactly one at a time. Zoom/Cut aren't part of this: they only
    /// appear while something's selected on the timeline and stay open for
    /// as long as it is, the same as before this existed.
    @AppStorage("AjwooCapture.section.open") private var openSectionKey: String = "background"

    private func sectionBinding(_ key: String) -> Binding<Bool> {
        Binding(
            get: { openSectionKey == key },
            set: { isOpen in openSectionKey = isOpen ? key : "" }
        )
    }

    private var cursorChoice: Binding<CursorChoice> {
        Binding(
            get: {
                switch model.project.cursor.kind {
                case .hidden: return .hidden
                case .dot:    return .dot
                case .arrow:  return model.project.cursor.arrowTone == .dark ? .dark : .light
                }
            },
            set: { choice in
                switch choice {
                case .dark:
                    model.project.cursor.kind = .arrow
                    model.project.cursor.arrowTone = .dark
                case .light:
                    model.project.cursor.kind = .arrow
                    model.project.cursor.arrowTone = .light
                case .dot:
                    model.project.cursor.kind = .dot
                case .hidden:
                    model.project.cursor.kind = .hidden
                }
            }
        )
    }

    var body: some View {
        ScrollView {
            // Every section is laid out on every scroll frame unless it's told
            // not to be. The inspector is thirty-odd controls bound to one
            // `@Published` project, so SwiftUI re-evaluates the whole column each
            // time — which is what made scrolling stutter. `drawingGroup` on the
            // static chrome and a fixed row height on the sliders keep the layout
            // pass off the critical path.
            LazyVStack(alignment: .leading, spacing: DS.Space.l) {
                styleSetRow

                // Not part of the accordion below — these two only appear
                // while something's selected on the timeline, and stay open
                // for exactly as long as it is, independent of whichever
                // named section is currently open.
                if let zoom = model.selectedZoom {
                    CollapsibleSection(title: "Zoom", expanded: .constant(true)) { zoomSection(zoom) }
                }
                if let cut = model.selectedCut {
                    CollapsibleSection(title: "Cut", expanded: .constant(true)) { cutSection(cut) }
                }

                // Exactly one of these open at a time — opening one closes
                // whichever else was open, so the column never grows into a
                // wall of every section at once.
                CollapsibleSection(title: "Auto-zoom", expanded: sectionBinding("autozoom"),
                                   badge: model.project.autoZoom.enabled ? "\(model.autoZoomCount)" : nil,
                                   info: "Adds a zoom around each burst of clicks. Generated segments behave like any other and can be edited or deleted individually.") {
                    autoZoomSection
                }

                // Background first: it's the frame everything else sits inside,
                // and it's the one people reach for immediately after auto-zoom.
                // Open by default, the same reasoning.
                CollapsibleSection(title: "Background", expanded: sectionBinding("background")) { backgroundSection }

                CollapsibleSection(title: "Cursor", expanded: sectionBinding("cursor"),
                                   info: "The pointer is drawn at export time from the recorded path, so its size, style and timing remain adjustable.") { cursorSection }

                if model.hasCamera {
                    CollapsibleSection(
                        title: "Camera",
                        expanded: sectionBinding("camera"),
                        info: "Drag the bubble on the preview to reposition it. Drag any corner to resize."
                    ) { cameraSection }
                }

                CollapsibleSection(title: "Audio", expanded: sectionBinding("audio")) { audioSection }

                CollapsibleSection(
                    title: "Speech",
                    expanded: sectionBinding("speech"),
                    badge: model.autoCutCount > 0 ? "\(model.autoCutCount)" : nil,
                    info: "Transcribes the microphone track on this Mac using Apple's on-device speech recogniser. No audio is uploaded."
                ) { speechSection }

                CollapsibleSection(
                    title: "Subtitles",
                    expanded: sectionBinding("subtitles"),
                    info: "Drag the caption block on the preview to reposition it. Drag its left or right edge to change the wrap width."
                ) { subtitlesSection }
            }
            .padding(DS.Space.xl)
        }
        // AppKit's momentum scrolling is smoother than SwiftUI's default here,
        // and this is a plain vertical list with no horizontal component.
        .scrollBounceBehavior(.basedOnSize)
    }

    // MARK: - Zoom

    private func zoomSection(_ zoom: ProjectState.ZoomSegment) -> some View {
        VStack(alignment: .leading, spacing: DS.Space.m) {
            HStack {
                Slider(
                    value: Binding(
                        get: { zoom.level },
                        set: { value in model.updateZoom(zoom.id) { $0.level = value } }
                    ),
                    in: ZoomTrack.minLevel...ZoomTrack.maxLevel
                )
                TextField("", value: Binding(
                    get: { zoom.level },
                    set: { value in model.updateZoom(zoom.id) { $0.level = value } }
                ), format: .number.precision(.fractionLength(2)))
                .frame(width: 52)
                .textFieldStyle(.roundedBorder)
            }

            if model.exceedsNativeDensity(level: zoom.level, outputWidth: model.effectiveSourceSize.width) {
                Label(String(format: "Soft above %.1fx at full size", model.maxNativeLevelForSource),
                      systemImage: "exclamationmark.triangle")
                    .font(DS.Font.caption)
                    .foregroundStyle(DS.Status.warning)
                    .tooltip("Past here the picture starts to get soft")
            }

            Toggle("Follow cursor", isOn: Binding(
                get: { zoom.followsCursor },
                set: { value in model.updateZoom(zoom.id) { $0.followsCursor = value } }
            ))
            .tooltip("The zoom follows your pointer")
            .hoverHighlight()

            labelled("Ramp", value: Binding(
                get: { zoom.rampDuration },
                set: { value in model.updateZoom(zoom.id) { $0.rampDuration = value } }
            ), range: 0.1...2.0, format: "%.2fs")
                .tooltip("How long the zoom takes")

            if zoom.isAuto {
                Text("Auto")
                    .font(DS.Font.caption).foregroundStyle(DS.Text.tertiary)
                    .tooltip("Made automatically from your clicks")
            }

            HStack {
                Text(Timecode.format(zoom.start) + " – " + Timecode.format(zoom.end))
                    .font(DS.Font.mono(12))
                    .foregroundStyle(.secondary)
                Spacer()
                Button("Delete") { model.deleteZoom(zoom.id) }
                    .buttonStyle(MinimalButton(variant: .tertiary, size: .sm))
                    .foregroundStyle(DS.Status.danger)
            }
        }
        .font(DS.Font.body)
    }

    // MARK: - Cut

    private func cutSection(_ cut: ProjectState.CutRange) -> some View {
        VStack(alignment: .leading, spacing: DS.Space.m) {
            HStack {
                Text(Timecode.format(cut.start) + " – " + Timecode.format(cut.end))
                    .font(DS.Font.mono(12))
                Spacer()
                Text(String(format: "−%.2fs", cut.duration))
                    .font(DS.Font.mono(12))
                    .foregroundStyle(DS.Status.danger)
            }
            Button("Restore") { model.deleteCut(cut.id) }
                .buttonStyle(MinimalButton(variant: .secondary, size: .sm))
                .tooltip("Put this part back")
        }
        .font(DS.Font.body)
    }

    // MARK: - Auto-zoom

    private var autoZoomSection: some View {
        VStack(alignment: .leading, spacing: DS.Space.m) {
            pair {
                Toggle("Zoom all", isOn: Binding(
                    get: { model.project.autoZoom.enabled },
                    set: { value in
                        model.project.autoZoom.enabled = value
                        model.regenerateAutoZooms()
                    }
                ))
                .disabled(!model.hasClicks)
                .tooltip("Zoom in wherever you click")
                .hoverHighlight()
            } _: {
                Toggle("Follow cursor", isOn: Binding(
                    get: { model.project.autoZoom.followsCursor },
                    set: { value in
                        model.project.autoZoom.followsCursor = value
                        model.regenerateAutoZooms()
                    }
                ))
                .disabled(!model.hasClicks || !model.project.autoZoom.enabled)
                .tooltip("Zooms follow your pointer")
                .hoverHighlight()
            }

            if !model.hasClicks {
                Text("No clicks were recorded.")
                    .font(DS.Font.caption).foregroundStyle(DS.Text.secondary)
            } else if model.project.autoZoom.enabled {
                autoZoomSlider("Level", value: $model.project.autoZoom.level,
                               range: ZoomTrack.minLevel...ZoomTrack.maxLevel, format: "%.1fx")
                    .tooltip("How far in to zoom")
                autoZoomSlider("Lead time", value: $model.project.autoZoom.leadIn,
                               range: 0...2.5, format: "%.2fs")
                    .tooltip("How early the zoom starts")
                autoZoomSlider("Hold time", value: $model.project.autoZoom.holdAfter,
                               range: 0.3...5, format: "%.2fs")
                    .tooltip("How long the zoom stays")
            }
        }
        .font(DS.Font.body)
    }

    /// Auto-zoom parameters regenerate the segments rather than just redrawing,
    /// so they commit on mouse-up instead of on every tick.
    private func autoZoomSlider(_ title: String,
                                value: Binding<Double>,
                                range: ClosedRange<Double>,
                                format: String) -> some View {
        HStack {
            Text(title).frame(width: 72, alignment: .leading)
            Slider(value: value, in: range) { editing in
                if !editing { model.regenerateAutoZooms() }
            }
            Text(String(format: format, value.wrappedValue))
                .font(DS.Font.mono(12))
                .frame(width: 44, alignment: .trailing)
        }
        .hoverHighlight()
    }

    /// Reset, the three saved looks, and where to save the current one.
    ///
    /// Above every section because it acts on all of them. Reset sits at the far
    /// left, away from the slots — it's the one button here you can't undo by
    /// pressing another one, so it shouldn't be adjacent to the ones you'll be
    /// clicking repeatedly.
    private var styleSetRow: some View {
        HStack(spacing: DS.Space.xs) {
            // Disabled when it would change nothing. A button that's already
            // been pressed shouldn't invite pressing again.
            Button("Reset") { model.resetStyleToDefaults() }
                .buttonStyle(MinimalButton(variant: .tertiary, size: .sm))
                .disabled(model.styleIsDefault)
                .tooltip(model.styleIsDefault
                         ? "Everything is already at its default"
                         : "Put every setting back to its default. Your cuts and zooms stay.")

            Spacer(minLength: DS.Space.s)

            ForEach(StyleSet.Slot.allCases) { slot in
                let exists = model.styleSetExists(slot)
                let inUse = model.styleMatches(slot)
                Button("\(slot.rawValue)") { model.applyStyleSet(slot) }
                    .buttonStyle(MinimalButton(variant: inUse ? .secondary : .tertiary,
                                               size: .sm, square: true))
                    .disabled(!exists || inUse)
                    .tooltip(!exists ? "\(slot.label) is empty. Save one with the button on the right."
                             : inUse ? "\(slot.label) is already in use"
                             : "Use \(slot.label)")
            }

            Spacer(minLength: DS.Space.s)

            Menu {
                ForEach(StyleSet.Slot.allCases) { slot in
                    Button(model.styleSetExists(slot) ? "\(slot.label) (replace)" : slot.label) {
                        model.saveStyleSet(slot)
                    }
                }
            } label: {
                Text("Save set")
            }
            .menuStyle(.borderlessButton)
            .fixedSize()
            .tooltip("Save these settings so you can use them on another recording")
        }
        .frame(maxWidth: .infinity)
    }

    /// Two controls on one row.
    ///
    /// The inspector is a tall narrow column and toggles waste most of their
    /// width on empty space. Pairing the related ones halves how far you scroll
    /// to reach the sections underneath.
    private func pair<A: View, B: View>(@ViewBuilder _ a: () -> A,
                                        @ViewBuilder _ b: () -> B) -> some View {
        HStack(alignment: .firstTextBaseline, spacing: DS.Space.m) {
            a().frame(maxWidth: .infinity, alignment: .leading)
            b().frame(maxWidth: .infinity, alignment: .leading)
        }
    }

    // MARK: - Cursor

    private var cursorSection: some View {
        VStack(alignment: .leading, spacing: DS.Space.m) {
            Picker("Style", selection: cursorChoice) {
                ForEach(CursorChoice.allCases) { choice in
                    Text(choice.label).tag(choice)
                }
            }
            .pickerStyle(.segmented)
            .labelsHidden()
            .tooltip("Dark: black pointer. Light: white pointer.")

            if model.project.cursor.kind != .hidden {
                labelled("Size", value: $model.project.cursor.sizeMultiplier,
                         range: 1...4, format: "%.1fx")
                    .tooltip("How big the pointer looks")
                labelled("Smoothing", value: $model.project.cursor.smoothing,
                         range: 0...1, format: "%.2f")
                    .tooltip("Smooths out shaky pointer movement")
                labelled("Hide after", value: $model.project.cursor.hideAfterIdleSeconds,
                         range: 0...20,
                         format: model.project.cursor.hideAfterIdleSeconds < 0.05 ? "Off" : "%.0fs")
                    .tooltip("Fades the pointer out once it's sat still this long; off means it never hides")

                if model.project.cursor.kind == .arrow {
                    pair {
                        Toggle("Hand cursor", isOn: $model.project.cursor.matchSystemShape)
                            .tooltip("Show the pointer shape you actually saw — hand, text bar, and the rest")
                            .hoverHighlight()
                    } _: {
                        Toggle("Drop shadow", isOn: $model.project.cursor.shadow)
                            .tooltip("Helps the pointer stand out")
                            .hoverHighlight()
                    }
                } else {
                    Toggle("Drop shadow", isOn: $model.project.cursor.shadow)
                        .tooltip("Helps the pointer stand out")
                        .hoverHighlight()
                }

                if model.project.cursor.kind == .dot {
                    labelled("Opacity", value: $model.project.cursor.dotOpacity,
                             range: 0.1...1, format: "%.2f")
                    ColorPicker("Colour", selection: Binding(
                        get: {
                            Color(red: model.project.cursor.dotRed,
                                  green: model.project.cursor.dotGreen,
                                  blue: model.project.cursor.dotBlue)
                        },
                        set: { color in
                            let rgb = NSColor(color).usingColorSpace(.sRGB) ?? .white
                            model.project.cursor.dotRed = Double(rgb.redComponent)
                            model.project.cursor.dotGreen = Double(rgb.greenComponent)
                            model.project.cursor.dotBlue = Double(rgb.blueComponent)
                        }
                    ))
                    .font(.callout)
                    .hoverHighlight()
                }

                Divider().padding(.vertical, 2)

                Text("Click feedback").font(DS.Font.label).foregroundStyle(DS.Text.secondary)
                pair {
                    Toggle("Bounce", isOn: $model.project.cursor.clickPulse)
                        .tooltip("The pointer dips and springs back")
                        .hoverHighlight()
                } _: {
                    Toggle("Ripple", isOn: $model.project.cursor.clickRipple)
                        .tooltip("A ring spreads out from each click")
                        .hoverHighlight()
                }
                labelled("Strength", value: $model.project.cursor.clickEmphasis,
                         range: 0.5...2, format: "%.2f")
                    .disabled(!model.project.cursor.clickPulse && !model.project.cursor.clickRipple)
                    .tooltip("How strong the click effect is")
                labelled("Speed", value: $model.project.cursor.clickSpeed,
                         range: 0.4...3, format: "%.2fx")
                    .disabled(!model.project.cursor.clickPulse && !model.project.cursor.clickRipple)
                    .tooltip("How fast the click effect plays")
            }
        }
        .font(DS.Font.body)
    }

    // MARK: - Audio

    private var audioSection: some View {
        VStack(alignment: .leading, spacing: DS.Space.m) {
            if model.hasSystemAudio {
                Toggle("System audio", isOn: Binding(
                    get: { !model.project.audio.systemMuted },
                    set: { model.project.audio.systemMuted = !$0 }
                ))
                .hoverHighlight()
                // Up to 2x. 1.0 is the recording as captured; above that is
                // real gain, which is the only way to rescue a take recorded too
                // quietly without going back to the source.
                labelled("Level", value: $model.project.audio.systemVolume,
                         range: 0...2, format: "%.2fx")
                    .disabled(model.project.audio.systemMuted)
            }

            if model.hasMicAudio {
                Toggle("Microphone", isOn: Binding(
                    get: { !model.project.audio.micMuted },
                    set: { model.project.audio.micMuted = !$0 }
                ))
                .hoverHighlight()
                labelled("Level", value: $model.project.audio.micVolume,
                         range: 0...2, format: "%.2fx")
                    .disabled(model.project.audio.micMuted)
                labelled("Noise", value: $model.project.audio.noiseReduction,
                         range: 0...1, format: "%.0f%%", displayScale: 100)
                    .disabled(model.project.audio.micMuted)
                    .tooltip("Quiets background noise while you're not talking. All the way left is off.")
            }

            if !model.hasSystemAudio && !model.hasMicAudio {
                Text("This recording contains no audio.")
                    .font(DS.Font.caption).foregroundStyle(DS.Text.secondary)
            }
        }
        .font(DS.Font.body)
    }

    // MARK: - Speech

    private func mixedState(_ state: EditorModel.SpeechCutState) -> MixedCheckbox.State {
        switch state {
        case .off:   return .off
        case .on:    return .on
        case .mixed: return .mixed
        }
    }

    @ViewBuilder
    private var speechSection: some View {
        VStack(alignment: .leading, spacing: DS.Space.m) {
            if !model.canTranscribe {
                Text("This recording has no microphone track.")
                    .font(DS.Font.caption).foregroundStyle(DS.Text.secondary)
            } else {
                transcriptStatus

                MixedCheckbox(label: "Remove filler words",
                              state: mixedState(model.fillerCutState)) {
                    model.project.speech.removeFillers.toggle()
                }
                .disabled(!model.hasTranscript)
                .tooltip(model.fillerCutState == .mixed
                         ? "Cut out “um”, “uh” and “er” — you've restored some of these"
                         : "Cut out “um”, “uh” and “er”")

                MixedCheckbox(label: "Remove long silences",
                              state: mixedState(model.silenceCutState)) {
                    model.project.speech.removeSilences.toggle()
                }
                .disabled(!model.hasTranscript)
                .tooltip(model.silenceCutState == .mixed
                         ? "Cut out long pauses — you've restored some of these"
                         : "Cut out long pauses")

                if model.project.speech.removeSilences {
                    labelled("Length", value: $model.project.speech.silenceThreshold,
                             range: 0.4...4, format: "%.1fs")
                        .tooltip("Pauses longer than this get cut")
                }
            }
        }
        .font(DS.Font.body)
    }

    // MARK: - Subtitles

    @ViewBuilder
    private var subtitlesSection: some View {
        VStack(alignment: .leading, spacing: DS.Space.m) {
            // Switching this on used to do nothing at all when the transcript
            // wasn't ready — the toggle was simply disabled, with the reason
            // buried in a collapsed section further down. It now starts the
            // transcription itself and reports on it here.
            Toggle("Add subtitles", isOn: $model.project.subtitles.enabled)
                .disabled(!model.canTranscribe)
                .tooltip(model.canTranscribe
                         ? "Show captions in the video"
                         : "No microphone was recorded")
                .onChange(of: model.project.subtitles.enabled) { _, on in
                    if on { model.transcribeIfNeeded() }
                }
                .hoverHighlight()

            if !model.canTranscribe {
                Text("This recording has no microphone track.")
                    .font(DS.Font.caption).foregroundStyle(DS.Text.secondary)
            } else if !model.hasTranscript {
                transcriptStatus
            } else if model.project.subtitles.enabled {
                pair {
                    Picker("Font", selection: $model.project.subtitles.font) {
                        ForEach(ProjectState.Subtitles.FontChoice.allCases) { choice in
                            Text(choice.label).tag(choice)
                        }
                    }
                    // Capped rather than left to its longest label ("System
                    // Rounded"): the point of narrowing it is the room that
                    // buys for Uppercase alongside it.
                    .frame(maxWidth: 128, alignment: .leading)
                    .tooltip("Fonts that come with your Mac")
                } _: {
                    Toggle("Uppercase", isOn: $model.project.subtitles.uppercase)
                        .tooltip("ALL CAPS captions")
                        .hoverHighlight()
                }

                labelled("Size", value: $model.project.subtitles.fontSize,
                         range: 0.02...0.09, format: "%.3f")
                    .tooltip("How big the captions are")

                Stepper(value: $model.project.subtitles.wordsPerCue, in: 2...14) {
                    HStack {
                        Text("Words per caption")
                            .font(DS.Font.caption).foregroundStyle(DS.Text.secondary)
                        Spacer()
                        Text("\(model.project.subtitles.wordsPerCue)")
                            .font(DS.Font.mono(12)).monospacedDigit()
                            .foregroundStyle(DS.Text.tertiary)
                    }
                }
                .tooltip("How many words show at once")

                // "None" used to sit here too, but it and Shadow have painted
                // identically since the shadow slider stopped being tied to
                // which backdrop was picked — Shadow *is* the no-box option now.
                Picker("Backdrop", selection: $model.project.subtitles.backdrop) {
                    ForEach([ProjectState.Subtitles.Backdrop.shadow, .box]) { style in
                        Text(style.label).tag(style)
                    }
                }
                .pickerStyle(.segmented)
                .tooltip("Box is easiest to read on any video")

                labelled("Shadow", value: $model.project.subtitles.shadowStrength,
                         range: 0...1, format: "%.0f%%", displayScale: 100)
                    .tooltip("Darkness behind the text")

                labelled("Width", value: $model.project.subtitles.width,
                         range: 0.2...0.95, format: "%.2f")
                    .tooltip("How wide the captions are")

                // Last, and only shown for the one backdrop it applies to —
                // below everything else in the section rather than wedged
                // right after the Backdrop picker.
                if model.project.subtitles.backdrop == .box {
                    labelled("Box opacity", value: $model.project.subtitles.boxOpacity,
                             range: 0...1, format: "%.0f%%", displayScale: 100)
                        .tooltip("How solid the black box is")
                }
            }
        }
        .font(DS.Font.body)
    }

    /// Shared by Speech and Subtitles — both wait on the same transcript.
    @ViewBuilder
    private var transcriptStatus: some View {
        switch model.transcriptState {
        case .none:
            Button("Transcribe audio") { model.transcribeIfNeeded() }
                .buttonStyle(MinimalButton(variant: .secondary, size: .sm))
                .tooltip("Turn your narration into text, on this Mac")
        case .running(let progress):
            HStack(spacing: DS.Space.s) {
                ProgressView(value: progress).frame(width: 120)
                Text("\(Int(progress * 100))%")
                    .font(DS.Font.mono(12)).monospacedDigit()
                    .foregroundStyle(DS.Text.secondary)
            }
        case .ready(let count):
            Text("\(count) words transcribed")
                .font(DS.Font.caption).foregroundStyle(DS.Text.secondary)
        case .failed(let message):
            Text(message)
                .font(DS.Font.caption).foregroundStyle(DS.Status.warning)
                .fixedSize(horizontal: false, vertical: true)
            Button("Try again") { model.transcribeIfNeeded() }
                .buttonStyle(MinimalButton(variant: .secondary, size: .sm))
        }
    }

    // MARK: - Camera

    private var cameraSection: some View {
        VStack(alignment: .leading, spacing: DS.Space.m) {
            Toggle("Show bubble", isOn: $model.project.camera.enabled)
                .hoverHighlight()

            if model.project.camera.enabled {

                pair {
                    Picker("Shape", selection: Binding(
                    get: { model.project.camera.shape },
                    set: { shape in
                        model.project.camera.shape = shape
                        // Circles and stars are square by definition; give the
                        // rectangles a sensible default instead of a 1:1 box.
                        if !shape.forcesSquare, model.project.camera.aspect == 1.0 {
                            model.project.camera.aspect = 16.0 / 9.0
                        }
                    }
                )) {
                    ForEach(ProjectState.CameraOverlay.Shape.allCases) { shape in
                        Text(shape.label).tag(shape)
                    }
                    }
                    .labelsHidden()
                } _: {
                    Toggle("Shadow", isOn: $model.project.camera.shadow)
                        .hoverHighlight()
                }

                if !model.project.camera.shape.forcesSquare {
                    Picker("Aspect", selection: $model.project.camera.aspect) {
                        Text("16:9").tag(16.0 / 9.0)
                        Text("4:3").tag(4.0 / 3.0)
                        Text("1:1").tag(1.0)
                        Text("9:16").tag(9.0 / 16.0)
                    }
                    .pickerStyle(.segmented)
                }
                if model.project.camera.shape == .roundedRectangle {
                    labelled("Corners", value: $model.project.camera.cornerRadius,
                             range: 0...0.5, format: "%.2f")
                }

                Divider().padding(.vertical, 2)

                Text("Look").font(DS.Font.label).foregroundStyle(DS.Text.secondary)
                    .tooltip("Changes the camera only, not the screen")
                Picker("", selection: Binding(
                    get: { model.project.camera.filter.preset },
                    set: { model.applyCameraFilterPreset($0) }
                )) {
                    ForEach(ProjectState.CameraFilter.Preset.allCases) { preset in
                        Text(preset.label).tag(preset)
                    }
                }
                .labelsHidden()

                labelled("Brightness", value: $model.project.camera.filter.brightness,
                         range: -0.3...0.3, format: "%+.2f")
                labelled("Contrast", value: $model.project.camera.filter.contrast,
                         range: 0.6...1.6, format: "%.2f")
                labelled("Saturation", value: $model.project.camera.filter.saturation,
                         range: 0...2, format: "%.2f")
                labelled("Warmth", value: $model.project.camera.filter.warmth,
                         range: -1200...1200, format: "%.0f")
                labelled("Clarity", value: $model.project.camera.filter.clarity,
                         range: 0...1, format: "%.2f")
                    .tooltip("Sharpens a soft webcam picture")
            }
        }
        .font(DS.Font.body)
    }

    // MARK: - Background

    private var backgroundSection: some View {
        VStack(alignment: .leading, spacing: DS.Space.m) {
            Toggle("Padded background", isOn: $model.project.background.enabled)
                .disabled(model.isCropping)
                .tooltip(model.isCropping
                         ? "Hidden while you crop, so you can see the real edges of the picture"
                         : "Put the video on a coloured backdrop")
                .hoverHighlight()
            if model.project.background.enabled {
                labelled("Padding", value: $model.project.background.padding, range: 0...0.15, format: "%.2f")
                labelled("Corners", value: $model.project.background.cornerRadius, range: 0...0.06, format: "%.3f")
                Toggle("Drop shadow", isOn: $model.project.background.shadow)
                    .hoverHighlight()

                HStack(spacing: DS.Space.m) {
                    colorSwatch("Top", top: true)
                    colorSwatch("Bottom", top: false)
                    Spacer(minLength: 0)
                    uploadBackgroundButton
                }

                // On their own line below the wells. Nine swatches sharing a row
                // with two colour pickers left each one too small to read.
                presetGrid

                Divider().padding(.vertical, 2)

                // Six options (five ratios plus "Recording") is one too many for
                // a legible segmented control at this column width — a pull-down
                // is the same choice the font picker above makes for the same
                // reason.
                Picker("Aspect ratio", selection: $model.project.background.aspectRatio) {
                    ForEach(ProjectState.Background.CanvasAspect.allCases) { aspect in
                        Text(aspect.label).tag(aspect)
                    }
                }
                .tooltip("Exports at this shape instead of the recording's own. The recording stays the same size — the background fills the rest.")
            }
        }
        .font(DS.Font.body)
    }

    /// One row of nine squares.
    ///
    /// Three rows of wide rectangles took a third of the section's height for a
    /// control you touch once. Squares are the compact form, and one row keeps
    /// the gradient-then-solid ordering readable as a single sweep.
    private var presetGrid: some View {
        HStack(spacing: DS.Space.xxs) {
            ForEach(ProjectState.Background.presets) { preset in
                presetSwatch(preset)
            }
        }
    }

    private func presetSwatch(_ preset: ProjectState.Background.Preset) -> some View {
        let selected = model.backgroundMatches(preset)
        // A photo preset shows the actual photo; a bundled file missing under
        // `swift run` (see `BackgroundImageStore`) falls back to the same flat
        // tint a gradient preset uses, rather than an empty square.
        let image = preset.imageFilename.flatMap {
            BackgroundImageStore.nsImage(filename: $0, bundled: preset.isBundledImage)
        }

        return Button { model.applyBackgroundPreset(preset) } label: {
            ZStack {
                if let image {
                    Image(nsImage: image)
                        .resizable()
                        .aspectRatio(contentMode: .fill)
                } else {
                    LinearGradient(colors: [Color(preset.top), Color(preset.bottom)],
                                   startPoint: .top, endPoint: .bottom)
                }
            }
            .aspectRatio(1, contentMode: .fit)
            .frame(maxWidth: .infinity)
            .clipShape(RoundedRectangle(cornerRadius: DS.Radius.chip))
            .overlay(
                RoundedRectangle(cornerRadius: DS.Radius.chip)
                    .strokeBorder(selected ? DS.Text.primary : DS.Border.subtle,
                                  lineWidth: selected ? 2 : DS.line)
            )
        }
        .buttonStyle(.plain)
        .tooltip(preset.name)
    }

    /// Opens a photo and makes it the background — the thumbnail shows
    /// whichever custom photo is actually applied right now, so the button
    /// doubles as a reminder of what's active rather than a plain icon that
    /// never changes.
    private var uploadBackgroundButton: some View {
        Button(action: chooseCustomBackgroundImage) {
            HStack(spacing: DS.Space.xs) {
                if let thumbnail = model.customBackgroundThumbnail {
                    Image(nsImage: thumbnail)
                        .resizable()
                        .aspectRatio(contentMode: .fill)
                        .frame(width: 18, height: 18)
                        .clipShape(RoundedRectangle(cornerRadius: 4))
                } else {
                    Image(systemName: "photo")
                }
                Text("Upload")
            }
        }
        .buttonStyle(MinimalButton(variant: .secondary, size: .sm))
        .tooltip("Use your own photo as the background")
    }

    private func chooseCustomBackgroundImage() {
        let panel = NSOpenPanel()
        panel.title = "Choose a background photo"
        panel.canChooseFiles = true
        panel.canChooseDirectories = false
        panel.allowsMultipleSelection = false
        panel.allowedContentTypes = [.image]
        guard panel.runModal() == .OK, let url = panel.url else { return }
        model.applyCustomBackgroundImage(from: url)
    }

    /// A round well instead of `ColorPicker`'s own label-plus-pill — a circle
    /// reads as "a colour" on its own the way a swatch always has, so the
    /// caption can sit beside it at caption size instead of the picker
    /// spending a whole row's width on a repeated label.
    private func colorSwatch(_ title: String, top: Bool) -> some View {
        HStack(spacing: DS.Space.xs) {
            ColorPicker("", selection: gradientBinding(top: top))
                .labelsHidden()
                .frame(width: 22, height: 22)
                .clipShape(Circle())
                .overlay(Circle().strokeBorder(DS.Border.control, lineWidth: DS.line))
            Text(title)
                .font(DS.Font.caption)
                .foregroundStyle(DS.Text.secondary)
        }
        .hoverHighlight()
        .tooltip("\(title) colour")
        .accessibilityLabel("\(title) colour")
    }

    private func gradientBinding(top: Bool) -> Binding<Color> {
        Binding(
            get: {
                top
                    ? Color(red: model.project.background.topRed,
                            green: model.project.background.topGreen,
                            blue: model.project.background.topBlue)
                    : Color(red: model.project.background.bottomRed,
                            green: model.project.background.bottomGreen,
                            blue: model.project.background.bottomBlue)
            },
            set: { color in
                let rgb = NSColor(color).usingColorSpace(.sRGB) ?? .black
                if top {
                    model.project.background.topRed = Double(rgb.redComponent)
                    model.project.background.topGreen = Double(rgb.greenComponent)
                    model.project.background.topBlue = Double(rgb.blueComponent)
                } else {
                    model.project.background.bottomRed = Double(rgb.redComponent)
                    model.project.background.bottomGreen = Double(rgb.greenComponent)
                    model.project.background.bottomBlue = Double(rgb.blueComponent)
                }
            }
        )
    }

    // MARK: - Helper

    /// `displayScale` multiplies the value for the readout only — a 0...1
    /// setting that reads "72%" is easier to talk about than one that reads
    /// "0.72", and the model stays in its own units.
    private func labelled(_ title: String,
                          value: Binding<Double>,
                          range: ClosedRange<Double>,
                          format: String,
                          displayScale: Double = 1) -> some View {
        HStack {
            Text(title).frame(width: 78, alignment: .leading)
            Slider(value: value, in: range)
            Text(String(format: format, value.wrappedValue * displayScale))
                .font(DS.Font.mono(12))
                .monospacedDigit()
                .frame(width: 46, alignment: .trailing)
        }
        // Fixed height: without it the row grows and shrinks by a point as the
        // readout changes width, and every row below it relayouts.
        .frame(height: DS.ControlHeight.sm)
        .hoverHighlight()
    }
}
