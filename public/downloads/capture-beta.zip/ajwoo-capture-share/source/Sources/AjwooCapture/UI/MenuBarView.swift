import SwiftUI
import AppKit

/// The menu bar menu.
///
/// # Two bugs this layout fixes
/// **A bare `Text` is still a menu item.** The elapsed readout used to sit at the
/// top as a `Text`, which AppKit lays out as an item but SwiftUI doesn't treat as
/// one — so the highlight landed one row off. Hovering "Stop Recording" lit the
/// timer row instead. Everything here is now a `Button`; the readout is a
/// disabled one, which is a real item that simply can't be picked.
///
/// **A menu that redraws under the pointer loses its highlight.** `elapsed`
/// updates ten times a second, and every tick re-rendered the open menu. The
/// readout binds to `elapsedSeconds` instead, which changes once a second.
///
/// The timer also moved below Quit: it's the one row you can't act on, so it
/// doesn't belong among the ones you can.
struct MenuBarView: View {
    @EnvironmentObject private var controller: RecordingController
    @Environment(\.openWindow) private var openWindow

    var body: some View {
        if controller.isRecording {
            Button("Stop Recording") { controller.stopRecording() }
                .keyboardShortcut("r", modifiers: [.command, .shift])
        } else {
            Button("Start Recording") { controller.startRecording() }
                .keyboardShortcut("r", modifiers: [.command, .shift])
                .disabled(!controller.permission.isGranted)
        }

        Divider()

        Button("Open \(AppInfo.name)") {
            NSApp.activate(ignoringOtherApps: true)
            openWindow(id: "main")
        }
        Button("Show Recordings Folder") {
            NSWorkspace.shared.open(AppInfo.recordingsDirectory)
        }

        Divider()

        Button("Quit") { NSApp.terminate(nil) }
            .keyboardShortcut("q")

        if controller.isRecording {
            Divider()
            Button("Recording — \(controller.elapsedSeconds)s") { }
                .disabled(true)
        }
    }
}
