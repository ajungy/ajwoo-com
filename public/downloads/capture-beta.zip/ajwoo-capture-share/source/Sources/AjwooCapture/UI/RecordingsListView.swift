import SwiftUI

struct RecordingsListView: View {
    @EnvironmentObject private var controller: RecordingController
    @Environment(\.openWindow) private var openWindow

    /// Deleting a take removes the only copy of the capture — there's no undo
    /// and it doesn't go to the Trash, so the trash icon asks first.
    @State private var pendingDeletion: RecordingSession?
    @State private var hoveredID: URL?

    /// Thumbnail height plus the row's vertical padding and its divider.
    /// Hard-coded because the frame has to be known before the rows are laid
    /// out — measuring them would defeat the point.
    static let rowHeight: CGFloat = 36 + DS.Space.s * 2 + 1

    var body: some View {
        // No padding of its own: the shell owns the 16 pt margin, and a second
        // one here would read as 32. No section title either — the list sits
        // directly under the capture controls, and "Recordings" was the only
        // thing in the window naming what's already self-evident from the
        // thumbnails and filenames below it.
        VStack(alignment: .leading, spacing: DS.Space.l) {
            // Nothing at all when there are no recordings — not even a label
            // saying so. An empty window is already the message; a caption
            // repeating it back just held the window open at a height it no
            // longer needs.
            if !controller.recordings.isEmpty {
                // Ideal height is the rows it has, capped at five; maximum is
                // whatever the window offers.
                //
                // A fixed height meant dragging the window taller left an empty
                // band below the list rather than showing more recordings — the
                // list stayed five rows tall no matter how much room there was.
                // An `idealHeight` still lets the window open at content size,
                // and `maxHeight: .infinity` lets it take the slack afterwards.
                ScrollView {
                    LazyVStack(spacing: 0) {
                        ForEach(controller.recordings) { recording in
                            row(recording)
                            Divider().overlay(DS.Border.subtle)
                        }
                    }
                }
                .frame(minHeight: Self.rowHeight,
                       idealHeight: Self.rowHeight * CGFloat(min(controller.recordings.count, 5)),
                       maxHeight: .infinity)
            }
        }
        .onAppear { controller.refreshRecordings() }
        .confirmationDialog(
            pendingDeletion.map { "Delete “\($0.name)”?" } ?? "Delete recording?",
            isPresented: Binding(get: { pendingDeletion != nil },
                                 set: { if !$0 { pendingDeletion = nil } }),
            titleVisibility: .visible
        ) {
            Button("Delete", role: .destructive) {
                if let recording = pendingDeletion { controller.delete(recording) }
                pendingDeletion = nil
            }
            Button("Cancel", role: .cancel) { pendingDeletion = nil }
        } message: {
            Text("The video, audio and edits are removed for good. This can't be undone.")
        }
    }

    private func row(_ recording: RecordingSession) -> some View {
        let canEdit = recording.hasScreenVideo && recording.hasEvents
        let hovered = hoveredID == recording.url

        return HStack(spacing: DS.Space.m) {
            RecordingThumbnailView(session: recording)

            VStack(alignment: .leading, spacing: DS.Space.xxs) {
                Text(recording.name)
                    .font(DS.Font.body)
                    .foregroundStyle(DS.Text.primary)
                Text(subtitle(for: recording))
                    .font(DS.Font.caption)
                    .foregroundStyle(DS.Text.secondary)
            }

            Spacer()

            Button("Edit") { EditorWindows.open(recording.url, using: openWindow) }
                .buttonStyle(MinimalButton(variant: .secondary, size: .sm, minWidth: 64))
                .disabled(!canEdit)
                .tooltip(canEdit ? "Open in the editor"
                                 : "This recording is incomplete")

            Button { controller.reveal(recording) } label: {
                Image(systemName: "folder")
            }
            .buttonStyle(MinimalButton(variant: .tertiary, size: .sm, square: true))
            .tooltip("Show in Finder")
            .accessibilityLabel("Show \(recording.name) in the Finder")

            Button { pendingDeletion = recording } label: {
                Image(systemName: "trash")
            }
            .buttonStyle(MinimalButton(variant: .tertiary, size: .sm, square: true,
                                       tint: DS.Status.danger))
            .tooltip("Delete this recording")
            .accessibilityLabel("Delete \(recording.name)")
        }
        .padding(.vertical, DS.Space.s)
        .background(hovered ? DS.Surface.hover : .clear)
        .contentShape(Rectangle())
        .onHover { hoveredID = $0 ? recording.url : nil }
        .animation(DS.Motion.fast, value: hovered)
        .onTapGesture(count: 2) {
            guard canEdit else { return }
            EditorWindows.open(recording.url, using: openWindow)
        }
    }

    /// Size, length, clicks, then which tracks are present.
    private func subtitle(for recording: RecordingSession) -> String {
        var parts: [String] = []
        parts.append(ByteCountFormatter.string(fromByteCount: recording.sizeOnDisk, countStyle: .file))

        if recording.hasEvents, let log = try? EventLog.read(from: recording.eventsURL) {
            parts.append(String(format: "%.1fs", log.recording.durationSeconds))
            parts.append("\(log.clicks.filter { $0.phase == .down }.count) clicks")
        }

        if recording.hasScreenVideo { parts.append("screen") }
        if recording.hasCameraVideo { parts.append("camera") }
        if recording.hasSystemAudio { parts.append("system audio") }
        if recording.hasMicAudio { parts.append("microphone") }

        return parts.joined(separator: "  ·  ")
    }
}

/// Poster frame for one recording.
///
/// Loads asynchronously from `RecordingThumbnails`, which caches to disk inside
/// the package. Until it arrives the frame holds its exact size as a neutral
/// well, so rows never resize as thumbnails land.
struct RecordingThumbnailView: View {
    let session: RecordingSession
    @State private var image: NSImage?

    private let width: CGFloat = 64
    private let height: CGFloat = 36

    var body: some View {
        ZStack {
            RoundedRectangle(cornerRadius: DS.Radius.chip)
                .fill(DS.Surface.sunken)

            if let image {
                Image(nsImage: image)
                    .resizable()
                    .aspectRatio(contentMode: .fill)
                    .frame(width: width, height: height)
                    .clipShape(RoundedRectangle(cornerRadius: DS.Radius.chip))
                    .transition(.opacity)
            }
        }
        .frame(width: width, height: height)
        .overlay(
            RoundedRectangle(cornerRadius: DS.Radius.chip)
                .strokeBorder(DS.Border.subtle, lineWidth: DS.line)
        )
        .animation(DS.Motion.fast, value: image != nil)
        .task(id: session.url) {
            image = await RecordingThumbnails.shared.thumbnail(for: session)
        }
    }
}
