import SwiftUI

/// Drag-to-crop rectangle drawn over the preview.
///
/// While this is up the model feeds the renderer an uncropped, unzoomed frame —
/// you can't sensibly choose a crop region from a picture that's already cropped
/// and zoomed into.
struct CropOverlay: View {
    @ObservedObject var model: EditorModel
    /// Where the video actually sits inside the preview view. `AVPlayerLayer`
    /// uses `resizeAspect`, so this is the letterboxed rect, not the full view.
    let videoRect: CGRect

    private let handleSize: CGFloat = 12

    private enum Handle: Equatable {
        case move
        case topLeft, topRight, bottomLeft, bottomRight
    }

    @State private var active: Handle?
    @State private var startCrop: ProjectState.Crop?

    private var cropRect: CGRect {
        let crop = model.project.crop
        return CGRect(
            x: videoRect.minX + crop.x * videoRect.width,
            y: videoRect.minY + crop.y * videoRect.height,
            width: crop.width * videoRect.width,
            height: crop.height * videoRect.height
        )
    }

    var body: some View {
        ZStack(alignment: .topLeading) {
            // Dim everything outside the crop.
            Path { path in
                path.addRect(videoRect)
                path.addRect(cropRect)
            }
            .fill(Color.black.opacity(0.55), style: FillStyle(eoFill: true))
            .allowsHitTesting(false)

            Rectangle()
                .strokeBorder(Color.white, lineWidth: DS.line)
                .frame(width: cropRect.width, height: cropRect.height)
                .offset(x: cropRect.minX, y: cropRect.minY)
                .allowsHitTesting(false)

            // Rule-of-thirds guides.
            Path { path in
                for i in 1...2 {
                    let x = cropRect.minX + cropRect.width * CGFloat(i) / 3
                    path.move(to: CGPoint(x: x, y: cropRect.minY))
                    path.addLine(to: CGPoint(x: x, y: cropRect.maxY))
                    let y = cropRect.minY + cropRect.height * CGFloat(i) / 3
                    path.move(to: CGPoint(x: cropRect.minX, y: y))
                    path.addLine(to: CGPoint(x: cropRect.maxX, y: y))
                }
            }
            .stroke(Color.white.opacity(0.28), lineWidth: 0.5)
            .allowsHitTesting(false)

            corner(.topLeft, at: CGPoint(x: cropRect.minX, y: cropRect.minY))
            corner(.topRight, at: CGPoint(x: cropRect.maxX, y: cropRect.minY))
            corner(.bottomLeft, at: CGPoint(x: cropRect.minX, y: cropRect.maxY))
            corner(.bottomRight, at: CGPoint(x: cropRect.maxX, y: cropRect.maxY))

            Text(dimensionsLabel)
                .font(DS.Font.mono(11, weight: .medium))
                .foregroundStyle(.white)
                .padding(.horizontal, 7).padding(.vertical, 3)
                .background(.black.opacity(0.75), in: RoundedRectangle(cornerRadius: DS.Radius.chip))
                .offset(x: cropRect.minX + 6, y: cropRect.minY + 6)
                .allowsHitTesting(false)
        }
        .contentShape(Rectangle())
        .gesture(
            DragGesture(minimumDistance: 0)
                .onChanged { value in
                    if active == nil {
                        active = hitTest(value.startLocation)
                        startCrop = model.project.crop
                    }
                    apply(translation: value.translation)
                }
                .onEnded { _ in
                    active = nil
                    startCrop = nil
                }
        )
    }

    private var dimensionsLabel: String {
        let size = model.effectiveSourceSizeIfCropApplied
        return "\(Int(size.width)) × \(Int(size.height))"
    }

    private func corner(_ handle: Handle, at point: CGPoint) -> some View {
        RoundedRectangle(cornerRadius: 2)
            .fill(Color.white)
            .frame(width: handleSize, height: handleSize)
            .shadow(radius: 1)
            .offset(x: point.x - handleSize / 2, y: point.y - handleSize / 2)
            .allowsHitTesting(false)
    }

    private func hitTest(_ point: CGPoint) -> Handle {
        let slop = handleSize * 1.6
        let corners: [(Handle, CGPoint)] = [
            (.topLeft, CGPoint(x: cropRect.minX, y: cropRect.minY)),
            (.topRight, CGPoint(x: cropRect.maxX, y: cropRect.minY)),
            (.bottomLeft, CGPoint(x: cropRect.minX, y: cropRect.maxY)),
            (.bottomRight, CGPoint(x: cropRect.maxX, y: cropRect.maxY)),
        ]
        for (handle, position) in corners {
            if abs(point.x - position.x) <= slop && abs(point.y - position.y) <= slop {
                return handle
            }
        }
        return .move
    }

    private func apply(translation: CGSize) {
        guard let active, let start = startCrop, videoRect.width > 0, videoRect.height > 0 else { return }

        let dx = Double(translation.width / videoRect.width)
        let dy = Double(translation.height / videoRect.height)
        var crop = start

        switch active {
        case .move:
            crop.x = start.x + dx
            crop.y = start.y + dy
        case .topLeft:
            crop.x = start.x + dx
            crop.y = start.y + dy
            crop.width = start.width - dx
            crop.height = start.height - dy
        case .topRight:
            crop.y = start.y + dy
            crop.width = start.width + dx
            crop.height = start.height - dy
        case .bottomLeft:
            crop.x = start.x + dx
            crop.width = start.width - dx
            crop.height = start.height + dy
        case .bottomRight:
            crop.width = start.width + dx
            crop.height = start.height + dy
        }

        crop.clampToFrame()
        model.project.crop = crop
    }
}
