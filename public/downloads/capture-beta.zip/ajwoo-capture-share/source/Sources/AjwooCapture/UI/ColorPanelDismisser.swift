import AppKit

/// Closes the system colour panel when you click away from it.
///
/// `ColorPicker` opens `NSColorPanel`, a shared floating panel that stays up
/// until it's explicitly closed. In an inspector where a colour is one control
/// among thirty, that leaves a large panel hovering over the preview long after
/// you've picked the colour. Every other popover in the app dismisses on an
/// outside click, so this makes the colour panel behave the same way.
///
/// The colour has already been committed through the binding by the time the
/// panel closes, so dismissing it never discards a choice.
@MainActor
enum ColorPanelDismisser {

    private static var observer: NSObjectProtocol?

    static func install() {
        guard observer == nil else { return }
        observer = NotificationCenter.default.addObserver(
            forName: NSWindow.didResignKeyNotification,
            object: nil,
            queue: .main
        ) { note in
            guard let window = note.object as? NSWindow,
                  window === NSColorPanel.shared,
                  NSColorPanel.sharedColorPanelExists else { return }
            // Deferred by one hop: the panel resigns key *before* the click that
            // took focus is delivered, and closing it inside the notification
            // can swallow that click.
            DispatchQueue.main.async {
                guard !NSColorPanel.shared.isKeyWindow else { return }
                NSColorPanel.shared.orderOut(nil)
            }
        }
    }
}
