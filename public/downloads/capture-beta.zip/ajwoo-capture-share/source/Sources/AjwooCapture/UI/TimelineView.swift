import SwiftUI
import AppKit

/// Filmstrip, waveform, zoom track, cuts, playhead, trim handles. That's the
/// whole timeline — no multi-clip editing, no tracks to manage, no transitions.
///
/// Everything here works in **recording time**. Cuts shift where things land in
/// the finished video, but the timeline keeps showing the recording as captured,
/// with removed stretches struck through — otherwise clips would slide around
/// underneath you every time you trimmed something out.
/// Seconds along the top of the timeline.
///
/// A filmstrip tells you what's there but not when; scrubbing to find "about
/// forty seconds in" meant guessing at a proportion of the width. Ticks every
/// second, a taller one every five, and a label wherever there's room for it.
///
/// The tick interval grows on long recordings — one mark per second across a
/// twenty-minute take is a grey smear, so the step climbs to 2, 5, 10, 30 and
/// 60 seconds, whichever first gives the ticks about four points of breathing
/// room.
struct TimeRuler: View, Equatable {
    let duration: Double
    let width: CGFloat
    let height: CGFloat

    static func == (a: TimeRuler, b: TimeRuler) -> Bool {
        a.duration == b.duration && a.width == b.width && a.height == b.height
    }

    private static let steps: [Double] = [1, 2, 5, 10, 30, 60, 300]

    /// Seconds per tick, chosen so ticks never crowd.
    private var step: Double {
        guard duration > 0, width > 0 else { return 1 }
        let minimumSpacing: CGFloat = 6
        return Self.steps.first { CGFloat($0 / duration) * width >= minimumSpacing } ?? 600
    }

    var body: some View {
        Canvas { ctx, size in
            guard duration > 0, size.width > 0 else { return }
            let step = self.step
            let labelEvery = 5

            var index = 0
            var t = 0.0
            while t <= duration {
                let x = (t / duration) * size.width
                let labelled = index % labelEvery == 0

                if labelled {
                    // A number where the long tick used to be.
                    //
                    // The tall white tick and its number were competing for the
                    // same 14 pt of height, and the number lost — it was drawn
                    // above the tick, off the top of the row, and simply wasn't
                    // there. The number *is* the marker now, so the tick would be
                    // redundant even if it fitted.
                    let resolved = ctx.resolve(
                        Text(TimeRuler.label(t))
                            .font(.system(size: 9, weight: .medium))
                            .foregroundColor(Palette.rulerText)
                    )
                    let textSize = resolved.measure(in: size)

                    // Centred on the moment it marks, except at the ends, where
                    // it's pulled inside the row instead of being dropped. The
                    // first label especially: a ruler that doesn't start at 0 is
                    // missing the one number you can be sure of.
                    let half = textSize.width / 2
                    let centre = min(max(x, half), size.width - half)
                    ctx.draw(resolved, at: CGPoint(x: centre, y: size.height / 2))
                } else {
                    // Short grey ticks for the seconds in between.
                    var line = Path()
                    line.move(to: CGPoint(x: x, y: size.height))
                    line.addLine(to: CGPoint(x: x, y: size.height - size.height * 0.3))
                    ctx.stroke(line, with: .color(Palette.rulerMinor), lineWidth: 1)
                }

                index += 1
                t += step
            }
        }
        .frame(height: height)
    }

    /// `12` under a minute, `1:05` over it — a bare `65` reads as nothing.
    static func label(_ seconds: Double) -> String {
        let total = Int(seconds.rounded())
        guard total >= 60 else { return "\(total)" }
        return String(format: "%d:%02d", total / 60, total % 60)
    }
}

/// The waveform, isolated so playback doesn't redraw it.
///
/// Same reasoning as `Filmstrip`: it's a `Canvas` walking 1800 samples, sitting
/// inside a view that re-evaluates whenever anything on the model changes. The
/// only inputs that can alter the drawing are the samples and the two mix
/// levels, so `Equatable` skips it the rest of the time.
struct Waveform: View, Equatable {
    let mic: [Float]
    let system: [Float]
    let micGain: Double
    let systemGain: Double
    let height: CGFloat

    static func == (a: Waveform, b: Waveform) -> Bool {
        a.mic.count == b.mic.count && a.system.count == b.system.count
            && a.micGain == b.micGain && a.systemGain == b.systemGain
            && a.height == b.height
    }

    var body: some View {
        Canvas { ctx, size in
            let midY = size.height / 2

            if !system.isEmpty, systemGain > 0.001 {
                let path = Self.envelope(system, in: size, midY: midY, gain: systemGain)
                ctx.fill(path, with: .color(Palette.waveformSystem.opacity(0.55)))
                ctx.stroke(path, with: .color(Palette.waveformSystem), lineWidth: DS.line)
            }
            if !mic.isEmpty, micGain > 0.001 {
                let path = Self.envelope(mic, in: size, midY: midY, gain: micGain)
                ctx.fill(path, with: .color(Palette.waveform.opacity(0.65)))
                ctx.stroke(path, with: .color(Palette.waveform), lineWidth: DS.line)
            }
        }
        .frame(height: height)
        .background(Palette.trackWell)
        .clipShape(RoundedRectangle(cornerRadius: DS.Radius.chip))
    }

    /// Mirrored envelope with a silence gate, so room tone doesn't draw as a
    /// solid bar the full length of the recording.
    ///
    /// The height is a *perceptual* curve, not the raw peak. Speech peaks around
    /// 0.2–0.4 of full scale, so drawing amplitude linearly left ordinary talking
    /// as a barely-moving ripple near the centre line while the row's top and
    /// bottom went unused — you could see there was audio but not where it got
    /// louder. Raising the value to the power of 0.45 is roughly how loudness is
    /// heard: 0.3 becomes 0.58, 0.6 becomes 0.79, and anything genuinely loud
    /// reaches the edge of the row and clips there, which is what makes the
    /// shape readable at a glance.
    static func envelope(_ samples: [Float], in size: CGSize, midY: CGFloat,
                         gain: Double) -> Path {
        var path = Path()
        guard !samples.isEmpty, size.width > 0 else { return path }

        let step = size.width / CGFloat(samples.count)
        func y(_ index: Int, up: Bool) -> CGFloat {
            let raw = CGFloat(samples[index]) * CGFloat(gain)
            // Gate first, so the curve can't lift the noise floor into view —
            // pow() is steepest near zero, which is exactly where room tone is.
            guard raw >= 0.006 else { return midY }
            let shaped = pow(raw, 0.45)
            let amplitude = min(midY - 1, shaped * (midY - 1) * 1.15)
            return up ? midY - amplitude : midY + amplitude
        }

        path.move(to: CGPoint(x: 0, y: y(0, up: true)))
        for index in samples.indices {
            path.addLine(to: CGPoint(x: CGFloat(index) * step, y: y(index, up: true)))
        }
        for index in samples.indices.reversed() {
            path.addLine(to: CGPoint(x: CGFloat(index) * step, y: y(index, up: false)))
        }
        path.closeSubpath()
        return path
    }
}

/// The filmstrip, isolated so playback doesn't redraw it.
///
/// It's fourteen `NSImage`s, and it lives inside a view that re-evaluates
/// whenever anything on the model changes. `Equatable` lets SwiftUI skip it
/// entirely unless the frames or the width actually changed — which, once the
/// thumbnails have loaded, is never.
private struct Filmstrip: View, Equatable {
    let images: [NSImage]
    let slots: Int
    let width: CGFloat
    let height: CGFloat

    static func == (a: Filmstrip, b: Filmstrip) -> Bool {
        a.images.count == b.images.count && a.slots == b.slots && a.width == b.width
    }

    var body: some View {
        let count = max(images.count, slots)
        if count == 0 {
            Rectangle().fill(Palette.trackWell).frame(height: height)
        } else {
            let tile = width / CGFloat(count)
            HStack(spacing: 0) {
                // Drawn against the final tile count from the first paint, so
                // frames drop into place as they decode rather than the row
                // resizing under the pointer.
                ForEach(Array(0..<count), id: \.self) { index in
                    if index < images.count {
                        Image(nsImage: images[index])
                            .resizable()
                            .aspectRatio(contentMode: .fill)
                            .frame(width: tile, height: height)
                            .clipped()
                    } else {
                        Rectangle()
                            .fill(Palette.trackWell)
                            .frame(width: tile, height: height)
                            .overlay(Rectangle().fill(DS.Surface.page).frame(width: DS.line),
                                     alignment: .trailing)
                    }
                }
            }
            .frame(height: height)
            // Flattened into one layer: fourteen separate image layers is fourteen
            // things for the compositor to walk on every frame of playback.
            .drawingGroup()
        }
    }
}

struct TimelineView: View {
    @ObservedObject var model: EditorModel

    private let filmstripHeight: CGFloat = 48
    // Matched to the zoom row. Two thin rows read as a pair of tracks; one fat
    // one and one thin one read as a mistake.
    private let waveformHeight: CGFloat = 24
    private let zoomHeight: CGFloat = 24
    // Room for a 9 pt numeral plus the short ticks under it.
    private let rulerHeight: CGFloat = 15
    private let gap: CGFloat = DS.Space.xs
    /// How close a click has to be to count as grabbing a handle.
    private let grabSlop: CGFloat = 7
    /// How close a drag has to land to the playhead, in screen points, before
    /// it snaps to it exactly — trimming, or resizing a cut or a zoom, up
    /// against the moment you're already looking at.
    ///
    /// Spec'd at 2pt, which turned out to be a catch radius nobody could
    /// actually land in — a mouse drifts more than that between two
    /// `onChanged` callbacks, so the snap almost never fired even when you
    /// were clearly aiming for the playhead. `grabSlop` above is the
    /// established "close enough" tolerance this file already uses for
    /// grabbing a handle, so this borrows it rather than inventing a second
    /// number for the same kind of fuzziness.
    private let playheadSnapDistance: CGFloat = 7

    private var totalHeight: CGFloat {
        zoomRowTop + zoomHeight
    }

    // Row tops, derived rather than restated.
    //
    // Hit testing used to spell these sums out at each call site, so adding the
    // ruler above the filmstrip shifted every row on screen while every hit
    // region stayed where it was — an 18 pt offset between what you clicked and
    // what responded. One definition each, used everywhere.
    private var filmstripTop: CGFloat { rulerHeight + gap }
    private var waveformTop: CGFloat { filmstripTop + filmstripHeight + gap }
    private var zoomRowTop: CGFloat { waveformTop + waveformHeight + gap }

    private enum Drag: Equatable {
        case none
        case scrub
        case moveZoom(UUID, grabOffset: Double)
        case resizeZoomStart(UUID)
        case resizeZoomEnd(UUID)
        case moveCut(UUID, grabOffset: Double)
        case resizeCutStart(UUID)
        case resizeCutEnd(UUID)
        case trimStart
        case trimEnd
    }

    /// What the pointer is currently over, so it can be highlighted.
    private enum Hover: Equatable {
        case none
        case zoom(UUID)
        case zoomEdge(UUID)
        case cut(UUID)
        case cutEdge(UUID)
        case trimStart
        case trimEnd
    }

    @State private var drag: Drag = .none
    @State private var hover: Hover = .none
    /// The zoom level when a trackpad pinch started, so the gesture's running
    /// magnification (always relative to 1 at touch-down) multiplies from a
    /// fixed point rather than compounding against whatever it last set.
    @State private var pinchBaseline: CGFloat?

    @AppStorage("AjwooCapture.scrubOnHover") private var scrubOnHover = true

    /// Room below the content for the horizontal scrollbar, kept clear via
    /// `.contentMargins(_:_:for: .scrollIndicators)` rather than by leaving
    /// blank space in the content itself — that only *hoped* the indicator
    /// would land in the gap; this tells SwiftUI to put it there.
    private let scrollbarGutter: CGFloat = 16

    var body: some View {
        GeometryReader { geometry in
            let viewportWidth = geometry.size.width
            let duration = max(0.01, model.duration)
            let width = viewportWidth * model.timelineZoom

            ScrollView(.horizontal, showsIndicators: true) {
                ZStack(alignment: .topLeading) {
                    VStack(spacing: gap) {
                        TimeRuler(duration: duration, width: width, height: rulerHeight)
                            .equatable()
                            .tooltip("Seconds from the start of the recording")

                        filmstrip(width: width, duration: duration)
                        Waveform(mic: model.waveformMic,
                                 system: model.waveformSystem,
                                 micGain: model.project.audio.micMuted ? 0 : model.project.audio.micVolume,
                                 systemGain: model.project.audio.systemMuted ? 0 : model.project.audio.systemVolume,
                                 height: waveformHeight)
                            .equatable()
                            .tooltip(waveformHelp)
                        zoomTrack(width: width, duration: duration)
                    }

                    // Drawn over the filmstrip, so it has to start where the
                    // filmstrip does rather than at the top of the stack — which is
                    // now the ruler.
                    trimOverlay(width: width, duration: duration)
                        .offset(y: filmstripTop)

                    // Redrawn every display frame while playing, so the playhead
                    // slides pixel by pixel instead of stepping with the 60 Hz time
                    // observer. Only this one element repaints.
                    if model.isPlaying {
                        SwiftUI.TimelineView(.animation) { _ in
                            playhead(at: model.playheadTime(), width: width, duration: duration)
                        }
                    } else {
                        playhead(at: model.currentTime, width: width, duration: duration)
                    }
                }
                .frame(width: width, height: totalHeight)
                .contentShape(Rectangle())
                .onContinuousHover { phase in
                    switch phase {
                    case .active(let location):
                        guard drag == .none else { return }
                        let target = hoverTest(x: location.x, y: location.y, width: width, duration: duration)
                        if target != hover {
                            hover = target
                            // A resize cursor over every draggable edge, the same
                            // affordance the trim handles have always had.
                            switch target {
                            case .cutEdge, .zoomEdge, .trimStart, .trimEnd:
                                NSCursor.resizeLeftRight.set()
                            default:
                                NSCursor.arrow.set()
                            }
                        }
                        // Scrub as the pointer moves, so you can find the moment you
                        // want by sweeping rather than clicking and re-clicking.
                        // Suppressed during playback — hijacking the playhead while
                        // something is playing is just a fight.
                        if scrubOnHover, !model.isPlaying {
                            model.scrub(to: min(duration, max(0, Double(location.x / max(1, width)) * duration)))
                        }
                    case .ended:
                        hover = .none
                        NSCursor.arrow.set()
                    }
                }
                .gesture(
                    DragGesture(minimumDistance: 0)
                        .onChanged { value in
                            handleDrag(value, width: width, duration: duration)
                        }
                        .onEnded { _ in drag = .none }
                )
            }
            .scrollIndicators(.visible, axes: .horizontal)
            // Reserves the indicator's own strip at the bottom of the
            // timeline's frame instead of the content's — the content stays
            // exactly `totalHeight` tall, and the scrollbar never has to share
            // a row with the zoom track under it.
            .contentMargins(.bottom, scrollbarGutter, for: .scrollIndicators)
            // Trackpad pinch, independent of the two-finger pan the ScrollView
            // already handles — magnify is its own gesture type, so this never
            // fights the horizontal scroll.
            .gesture(
                MagnifyGesture()
                    .onChanged { value in
                        let baseline = pinchBaseline ?? model.timelineZoom
                        if pinchBaseline == nil { pinchBaseline = baseline }
                        model.setTimelineZoom(baseline * value.magnification)
                    }
                    .onEnded { _ in pinchBaseline = nil }
            )
        }
        .frame(height: totalHeight + scrollbarGutter)
    }

    // MARK: - Rows

    private func filmstrip(width: CGFloat, duration: Double) -> some View {
        ZStack(alignment: .topLeading) {
            // The strip is drawn against its final tile count from the first
            // paint, so frames drop into place as they decode instead of the row
            // resizing under the pointer. An empty well would look broken for the
            // second or so a long recording takes to seek.
            Filmstrip(images: model.thumbnails,
                      slots: model.thumbnailSlots,
                      width: width,
                      height: filmstripHeight)
                .equatable()
            .frame(height: filmstripHeight)

            // Cut bands sit on the filmstrip, which is where the footage they
            // remove is visible.
            ForEach(model.project.cuts) { cut in
                let x = CGFloat(cut.start / duration) * width
                let w = max(3, CGFloat(cut.duration / duration) * width)
                let selected = model.selectedCutID == cut.id
                let hovered = hover == .cut(cut.id) || hover == .cutEdge(cut.id)

                ZStack {
                    Rectangle().fill(Palette.cut.opacity(selected ? 0.5 : hovered ? 0.38 : 0.28))
                    Rectangle().strokeBorder(Palette.cut.opacity(selected ? 1 : hovered ? 0.85 : 0.6),
                                             lineWidth: DS.line)
                    if w > 26 {
                        Image(systemName: "scissors")
                            .font(.system(size: 10, weight: .medium))
                            .foregroundStyle(.white)
                    }
                }
                .frame(width: w, height: filmstripHeight)
                .offset(x: x)
                .animation(DS.Motion.fast, value: hovered)

                // Edge grips, drawn the same way as the trim handles so the
                // gesture reads identically: this edge is draggable.
                if hovered || selected {
                    cutGrip(at: x, active: hover == .cutEdge(cut.id) || drag == .resizeCutStart(cut.id))
                    cutGrip(at: x + w, active: hover == .cutEdge(cut.id) || drag == .resizeCutEnd(cut.id))
                }
            }
        }
        .frame(height: filmstripHeight)
        .clipShape(RoundedRectangle(cornerRadius: DS.Radius.chip))
    }

    /// A draggable edge on a cut band. Constant box; only the fill changes.
    private func cutGrip(at x: CGFloat, active: Bool) -> some View {
        RoundedRectangle(cornerRadius: 2)
            .fill(active ? Color.white : Palette.cut)
            .overlay(RoundedRectangle(cornerRadius: 2)
                .strokeBorder(Color.black.opacity(0.35), lineWidth: DS.line))
            .frame(width: 5, height: filmstripHeight)
            .offset(x: x - 2.5)
            .animation(DS.Motion.fast, value: active)
    }

    /// Audio envelope.
    ///
    /// Drawn as a **filled, mirrored envelope** rather than one hairline per
    /// sample. 900 hairlines across ~800 px alias into a flat band that reads the
    /// same whether there's sound or not, which is useless for editing. Resampling
    /// to roughly one column per 1.5 px and filling the shape gives silence and
    /// speech obviously different footprints.
    ///
    /// Both tracks are drawn: microphone in the accent colour, system audio in
    /// teal behind it. They overlap, but they're different colours and each is
    /// individually readable.

    private var waveformHelp: String {
        switch (model.hasMicAudio, model.hasSystemAudio) {
        case (true, true):   return "The brighter shape is your microphone; the dimmer one is system audio"
        case (true, false):  return "Microphone level"
        case (false, true):  return "System audio level"
        case (false, false): return "This recording has no sound."
        }
    }

    /// Silence gate, in raw amplitude. Below this a bucket draws as a hairline
    /// rather than being lifted by the decibel curve — otherwise a digitally
    /// silent track (nothing was playing) renders as a solid bar.
    private static let silenceFloor: Float = 0.002


    private func zoomTrack(width: CGFloat, duration: Double) -> some View {
        ZStack(alignment: .topLeading) {
            RoundedRectangle(cornerRadius: DS.Radius.chip).fill(Palette.trackWell)
            RoundedRectangle(cornerRadius: DS.Radius.chip)
                .strokeBorder(Palette.trackBorder, lineWidth: DS.line)

            ForEach(model.project.zoomSegments) { segment in
                let x = CGFloat(segment.start / duration) * width
                let w = max(6, CGFloat((segment.end - segment.start) / duration) * width)
                let selected = model.selectedZoomID == segment.id
                let hovered = hover == .zoom(segment.id) || hover == .zoomEdge(segment.id)
                let pressed = isDragging(segment.id)

                RoundedRectangle(cornerRadius: DS.Radius.chip)
                    .fill(Palette.zoomTile(selected: selected, hovered: hovered))
                    .overlay(
                        RoundedRectangle(cornerRadius: DS.Radius.chip)
                            .strokeBorder(DS.Text.primary.opacity(selected ? 0 : 0.25), lineWidth: DS.line)
                    )
                    .overlay(
                        HStack(spacing: DS.Space.xxs) {
                            if segment.followsCursor, w > 48 {
                                Image(systemName: "location.fill").font(.system(size: 8))
                            }
                            Text(String(format: "%.1f×", segment.level))
                                .font(DS.Font.micro)
                                .monospacedDigit()
                        }
                        .foregroundStyle(Palette.zoomTileLabel(selected: selected))
                        .padding(.horizontal, DS.Space.xs)
                        .opacity(w > 34 ? 1 : 0)
                    )
                    // The one permitted transform: a press settles the tile.
                    // Hover changes fill only, so nothing shifts under the pointer.
                    .scaleEffect(pressed ? DS.Motion.pressScale : 1, anchor: .center)
                    .frame(width: w, height: zoomHeight)
                    .offset(x: x)
                    .animation(DS.Motion.fast, value: hovered)
                    .animation(DS.Motion.press, value: pressed)

                if hovered || selected {
                    zoomGrip(at: x, active: hover == .zoomEdge(segment.id))
                    zoomGrip(at: x + w, active: hover == .zoomEdge(segment.id))
                }
            }
        }
        .frame(height: zoomHeight)
    }

    private func zoomGrip(at x: CGFloat, active: Bool) -> some View {
        RoundedRectangle(cornerRadius: 1.5)
            .fill(active ? DS.Text.inverse : DS.Text.primary)
            .overlay(RoundedRectangle(cornerRadius: 1.5)
                .strokeBorder(DS.Text.inverse.opacity(0.5), lineWidth: DS.line))
            .frame(width: 4, height: zoomHeight)
            .offset(x: x - 2)
            .animation(DS.Motion.fast, value: active)
    }

    private func isDragging(_ id: UUID) -> Bool {
        switch drag {
        case .moveZoom(let dragged, _), .resizeZoomStart(let dragged), .resizeZoomEnd(let dragged):
            return dragged == id
        default:
            return false
        }
    }

    private func trimOverlay(width: CGFloat, duration: Double) -> some View {
        let startX = CGFloat(model.trimStart / duration) * width
        let endX = CGFloat(model.trimEnd / duration) * width

        return ZStack(alignment: .topLeading) {
            Rectangle()
                .fill(Palette.excluded)
                .frame(width: max(0, startX), height: filmstripHeight)
            Rectangle()
                .fill(Palette.excluded)
                .frame(width: max(0, width - endX), height: filmstripHeight)
                .offset(x: endX)

            handle(at: startX, active: hover == .trimStart || drag == .trimStart)
            handle(at: endX, active: hover == .trimEnd || drag == .trimEnd)
        }
        .allowsHitTesting(false)
    }

    /// Trim handles keep a constant 4pt box — hover changes their fill, never
    /// their width, so the grab target can't move out from under the pointer.
    private func handle(at x: CGFloat, active: Bool) -> some View {
        RoundedRectangle(cornerRadius: 2)
            .fill(active ? DS.Text.primary : Palette.trimHandle)
            .frame(width: 4, height: filmstripHeight)
            .offset(x: x - 2)
            .animation(DS.Motion.fast, value: active)
    }

    private func playhead(at time: Double, width: CGFloat, duration: Double) -> some View {
        let x = CGFloat(time / duration) * width
        return ZStack(alignment: .top) {
            // A dark hairline behind the light one keeps the playhead legible
            // over both bright and dark thumbnails without resorting to colour.
            Rectangle()
                .fill(Color.black.opacity(0.55))
                .frame(width: 3, height: totalHeight)
            Rectangle()
                .fill(Palette.playhead)
                .frame(width: DS.line, height: totalHeight)
            // The knob gets the same treatment as the line: a dark ring behind
            // a light fill. Without it the circle vanished against a pale
            // thumbnail while the line beneath it stayed perfectly readable.
            Circle()
                .fill(Palette.playhead)
                .frame(width: 8, height: 8)
                .overlay(Circle().strokeBorder(Color.black.opacity(0.55), lineWidth: 1.5))
                .offset(y: -3)
        }
        .offset(x: x - 1.5)
        .allowsHitTesting(false)
    }

    // MARK: - Interaction

    private func handleDrag(_ value: DragGesture.Value, width: CGFloat, duration: Double) {
        // Every trim/resize case below reads its target instant through this
        // one closure, so snapping lives in exactly one place: get within
        // `playheadSnapDistance` screen points of the playhead and the edge
        // you're dragging locks to the exact instant it's showing, rather
        // than whatever pixel your pointer happens to be over.
        let playheadX = CGFloat(model.currentTime / duration) * width
        let time = { (x: CGFloat) -> Double in
            if abs(x - playheadX) <= self.playheadSnapDistance { return model.currentTime }
            return min(duration, max(0, Double(x / max(1, width)) * duration))
        }
        let x = value.location.x

        if drag == .none {
            drag = beginDrag(x: value.startLocation.x, y: value.startLocation.y,
                             width: width, duration: duration)
        }

        switch drag {
        case .none:
            break
        case .scrub:
            model.pause()
            model.seek(to: time(x))
        case .trimStart:
            model.setTrimStart(time(x))
        case .trimEnd:
            model.setTrimEnd(time(x))
        case .moveZoom(let id, let grabOffset):
            model.updateZoom(id) { segment in
                let length = segment.end - segment.start
                let newStart = min(max(0, time(x) - grabOffset), duration - length)
                segment.start = newStart
                segment.end = newStart + length
            }
        case .resizeZoomStart(let id):
            model.updateZoom(id) { $0.start = time(x) }
        case .resizeZoomEnd(let id):
            model.updateZoom(id) { $0.end = time(x) }
        case .moveCut(let id, let grabOffset):
            model.updateCut(id) { cut in
                let length = cut.duration
                let newStart = min(max(0, time(x) - grabOffset), duration - length)
                cut.start = newStart
                cut.end = newStart + length
            }
        case .resizeCutStart(let id):
            model.updateCut(id) { $0.start = time(x) }
        case .resizeCutEnd(let id):
            model.updateCut(id) { $0.end = time(x) }
        }
    }

    private func beginDrag(x: CGFloat, y: CGFloat, width: CGFloat, duration: Double) -> Drag {

        // Zoom row: edges resize, body moves.
        if y >= zoomRowTop {
            for segment in model.project.zoomSegments {
                let startX = CGFloat(segment.start / duration) * width
                let endX = CGFloat(segment.end / duration) * width
                if abs(x - startX) <= grabSlop {
                    model.selectedZoomID = segment.id
                    model.selectedCutID = nil
                    return .resizeZoomStart(segment.id)
                }
                if abs(x - endX) <= grabSlop {
                    model.selectedZoomID = segment.id
                    model.selectedCutID = nil
                    return .resizeZoomEnd(segment.id)
                }
                if x > startX, x < endX {
                    model.selectedZoomID = segment.id
                    model.selectedCutID = nil
                    return .moveZoom(segment.id, grabOffset: Double(x / max(1, width)) * duration - segment.start)
                }
            }
            model.selectedZoomID = nil
            return .scrub
        }

        // Filmstrip row: cuts, then trim handles, then scrub.
        if y >= filmstripTop, y <= filmstripTop + filmstripHeight {
            for cut in model.project.cuts {
                let startX = CGFloat(cut.start / duration) * width
                let endX = CGFloat(cut.end / duration) * width
                if abs(x - startX) <= grabSlop {
                    model.selectedCutID = cut.id
                    model.selectedZoomID = nil
                    return .resizeCutStart(cut.id)
                }
                if abs(x - endX) <= grabSlop {
                    model.selectedCutID = cut.id
                    model.selectedZoomID = nil
                    return .resizeCutEnd(cut.id)
                }
                if x > startX, x < endX {
                    model.selectedCutID = cut.id
                    model.selectedZoomID = nil
                    return .moveCut(cut.id, grabOffset: Double(x / max(1, width)) * duration - cut.start)
                }
            }

            let startX = CGFloat(model.trimStart / duration) * width
            let endX = CGFloat(model.trimEnd / duration) * width
            if abs(x - startX) <= grabSlop { return .trimStart }
            if abs(x - endX) <= grabSlop { return .trimEnd }
            model.selectedCutID = nil
        }

        return .scrub
    }

    /// Same hit test as `beginDrag`, without the side effects — drives the
    /// highlight so you can see what a click would grab before committing to it.
    private func hoverTest(x: CGFloat, y: CGFloat, width: CGFloat, duration: Double) -> Hover {

        if y >= zoomRowTop {
            for segment in model.project.zoomSegments {
                let startX = CGFloat(segment.start / duration) * width
                let endX = CGFloat(segment.end / duration) * width
                if abs(x - startX) <= grabSlop || abs(x - endX) <= grabSlop { return .zoomEdge(segment.id) }
                if x > startX, x < endX { return .zoom(segment.id) }
            }
            return .none
        }

        if y >= filmstripTop, y <= filmstripTop + filmstripHeight {
            for cut in model.project.cuts {
                let startX = CGFloat(cut.start / duration) * width
                let endX = CGFloat(cut.end / duration) * width
                if abs(x - startX) <= grabSlop || abs(x - endX) <= grabSlop { return .cutEdge(cut.id) }
                if x > startX, x < endX { return .cut(cut.id) }
            }
            let startX = CGFloat(model.trimStart / duration) * width
            let endX = CGFloat(model.trimEnd / duration) * width
            if abs(x - startX) <= grabSlop { return .trimStart }
            if abs(x - endX) <= grabSlop { return .trimEnd }
        }

        return .none
    }
}
