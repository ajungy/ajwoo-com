import SwiftUI
import AppKit

/// Light / dark appearance.
///
/// SwiftUI already follows the system setting; this exists so the app can be
/// pinned to one appearance regardless — useful when you're recording a demo and
/// don't want the OS flipping to dark halfway through.
enum AppTheme: String, CaseIterable, Identifiable {
    case system, light, dark

    var id: String { rawValue }

    var label: String {
        switch self {
        case .system: return "System"
        case .light:  return "Light"
        case .dark:   return "Dark"
        }
    }

    var symbol: String {
        switch self {
        case .system: return "circle.lefthalf.filled"
        case .light:  return "sun.max"
        case .dark:   return "moon"
        }
    }

    var appearance: NSAppearance? {
        switch self {
        case .system: return nil
        case .light:  return NSAppearance(named: .aqua)
        case .dark:   return NSAppearance(named: .darkAqua)
        }
    }

    static let storageKey = "AjwooCapture.appearance"

    /// Dark unless the user has chosen otherwise. An editor is mostly a video on
    /// a dark surround; a bright chrome around it skews how the footage reads.
    static var current: AppTheme {
        AppTheme(rawValue: UserDefaults.standard.string(forKey: storageKey) ?? "") ?? .dark
    }

    /// Applies to every window, including ones already on screen.
    func apply() {
        UserDefaults.standard.set(rawValue, forKey: Self.storageKey)
        NSApp.appearance = appearance
    }
}

/// Timeline colours, all drawn from the design system.
///
/// The timeline used to be blue for zooms, teal for system audio, yellow for
/// trim and red for the playhead — four hues carrying no meaning between them.
/// Under Minimal, colour means something: everything structural is monochrome
/// and separated by *lightness*, and red is reserved for the one thing on this
/// timeline that destroys footage.
enum Palette {
    /// Recessed background for timeline rows.
    static var trackWell: Color { DS.Surface.sunken }
    static var trackBorder: Color { DS.Border.subtle }
    /// Area of the timeline that won't be exported.
    static var excluded: Color { DS.Surface.page.opacity(0.72) }

    /// Microphone: the loudest thing in the row, so the strongest neutral.
    static var waveform: Color { DS.Text.primary }
    /// System audio: the same family, one step back, so the two read as one
    /// scale rather than two categories.
    static var waveformSystem: Color { DS.Text.tertiary }

    static var playhead: Color { DS.Text.primary }

    /// Ruler: grey ticks and a slightly stronger numeral, so it reads as one
    /// scale and never competes with the content it's measuring.
    static var rulerMinor: Color { DS.Border.default }
    static var rulerText: Color { DS.Text.secondary }
    static var trimHandle: Color { DS.Border.strong }
    /// Cuts remove footage. That is the one destructive thing here, so it is the
    /// one red thing here.
    static var cut: Color { DS.Status.dangerSolid }

    /// Zoom tile fill by interaction state — a lightness ramp, not a hue.
    static func zoomTile(selected: Bool, hovered: Bool) -> Color {
        if selected { return DS.Text.primary.opacity(0.85) }
        if hovered { return DS.Text.primary.opacity(0.5) }
        return DS.Text.primary.opacity(0.3)
    }

    /// Text drawn on top of a zoom tile.
    static func zoomTileLabel(selected: Bool) -> Color {
        selected ? DS.Text.inverse : DS.Text.primary
    }
}

/// Level metering.
///
/// Raw peak amplitude is the wrong scale for a meter: normal speech peaks around
/// 0.1–0.3, so a linear bar barely twitches and looks broken. Mapping to decibels
/// over a −54 dB floor puts speech in the top half of the bar, which is what
/// people expect a meter to do.
enum AudioLevel {
    static let floorDB: Double = -54

    static func meter(_ peak: Float) -> Double {
        let value = Double(peak)
        guard value > 0.0001 else { return 0 }
        let db = 20 * log10(value)
        return min(1, max(0, (db - floorDB) / -floorDB))
    }
}

// MARK: - Hover-aware controls

/// Kept as a thin alias so existing call sites read the same; the behaviour is
/// the system's tertiary button.
typealias HoverButtonStyleBase = MinimalButton

struct HoverButtonStyle: ButtonStyle {
    var prominent: Bool = false

    func makeBody(configuration: Configuration) -> some View {
        MinimalButton(variant: prominent ? .secondary : .tertiary, size: .sm)
            .makeBody(configuration: configuration)
    }
}

/// Reports a view's natural height upward through the view tree, so a
/// parent that constrains/clips that view for animation purposes still knows
/// what size it's animating toward.
private struct SectionHeightKey: PreferenceKey {
    static var defaultValue: CGFloat = 0
    static func reduce(value: inout CGFloat, nextValue: () -> CGFloat) { value = nextValue() }
}

/// Section with a chevron that collapses.
///
/// Doesn't own its own open/closed state — the caller hands in a binding.
/// That's what makes the inspector's "only one section open at a time"
/// behavior possible: every section's binding reads from and writes to the
/// same one value in `InspectorView`, so opening one automatically closes
/// whichever other was open. A section that tracked its own `@State`, the
/// way an earlier version of this did, has no way to know about its
/// siblings at all.
///
/// # Two phases, not one
/// A plain height/opacity animation opens and reveals content at the same
/// time, which for a column of labels and sliders means text reflowing and
/// controls fading in *while the row underneath is still resizing* — legible
/// as a glitch, not a transition. Opening instead runs as two visible steps,
/// each taking half of the 500ms total: the row grows into an **empty**
/// space first, then the content wipes in from the top once that space
/// already exists and nothing has to move again. Closing runs the same two
/// steps in reverse — the content wipes away from the bottom first, *then*
/// the now-empty row collapses — so the same rule ("space changes size, or
/// content changes visibility — never both moves at once") holds in both
/// directions.
struct CollapsibleSection<Content: View>: View {
    let title: String
    var badge: String?
    /// Shown behind an ⓘ beside the title. Guidance that would otherwise sit
    /// permanently under the controls, taking up room once it's been read.
    var info: String?
    @Binding var expanded: Bool
    @ViewBuilder var content: () -> Content

    @State private var hovering = false
    /// The content's real height, kept current at all times — `content()` is
    /// always mounted (never conditionally removed), specifically so this
    /// stays accurate even while collapsed and ready the instant an opening
    /// animation needs a target to animate toward.
    @State private var measuredHeight: CGFloat = 0
    /// The row's own height — phase 1 of opening, phase 2 of closing.
    @State private var shellHeight: CGFloat = 0
    /// How much of the content is actually revealed within the shell —
    /// phase 2 of opening, phase 1 of closing. Top-aligned and clipped, so
    /// growing this wipes content in top-to-bottom and shrinking it wipes
    /// content away bottom-to-top.
    @State private var revealHeight: CGFloat = 0
    /// Whenever the section is fully open and idle (no animation in
    /// flight), both heights above are dropped in favor of natural,
    /// unconstrained layout — so a section whose own content changes size
    /// while sitting open (a different item selected, say) just follows it,
    /// rather than staying clipped to whatever it last measured.
    @State private var constrained: Bool

    // Explicit rather than relying on the synthesized memberwise init: that
    // one requires arguments in declaration order regardless of label, which
    // would make call sites brittle against reordering the properties above.
    init(title: String,
         expanded: Binding<Bool>,
         badge: String? = nil,
         info: String? = nil,
         @ViewBuilder content: @escaping () -> Content) {
        self.title = title
        self._expanded = expanded
        self.badge = badge
        self.info = info
        self.content = content
        _constrained = State(initialValue: !expanded.wrappedValue)
    }

    /// Half of the requested 500ms total per phase, so the two-step sequence
    /// still finishes in the time asked for rather than 500ms per phase.
    private static var phaseDuration: Double { 0.25 }
    private static var phaseAnimation: Animation { .timingCurve(0.2, 0, 0, 1, duration: phaseDuration) }
    /// The chevron's own rotation isn't part of the two-phase sequence above
    /// — it just tracks `expanded` directly, smoothly, over the same total
    /// 500ms window.
    private static var chevronAnimation: Animation { .timingCurve(0.2, 0, 0, 1, duration: phaseDuration * 2) }

    var body: some View {
        VStack(alignment: .leading, spacing: 0) {
            Button {
                expanded.toggle()
            } label: {
                HStack(spacing: 6) {
                    Image(systemName: "chevron.right")
                        .font(.system(size: 10, weight: .semibold))
                        .rotationEffect(.degrees(expanded ? 90 : 0))
                        .foregroundStyle(.secondary)
                        .animation(Self.chevronAnimation, value: expanded)
                    Text(title)
                        .font(DS.Font.label)
                        .foregroundStyle(DS.Text.primary)
                    if let info {
                        Image(systemName: "info.circle")
                            .font(.system(size: 11))
                            .foregroundStyle(DS.Text.tertiary)
                            .tooltip(info)
                            .accessibilityLabel("\(title) help")
                            .accessibilityValue(info)
                    }
                    if let badge {
                        Text(badge)
                            .font(DS.Font.micro)
                            .padding(.horizontal, DS.Space.s).padding(.vertical, DS.Space.xxs)
                            .background(DS.Surface.selected, in: Capsule())
                            .foregroundStyle(DS.Text.secondary)
                    }
                    Spacer()
                }
                .padding(.horizontal, 4).padding(.vertical, 3)
                .background(
                    RoundedRectangle(cornerRadius: DS.Radius.small)
                        .fill(hovering ? DS.Action.tertiaryHover : .clear)
                )
                .contentShape(Rectangle())
            }
            .buttonStyle(.plain)
            .onHover { hovering = $0 }
            .animation(DS.Motion.fast, value: hovering)

            content()
                .padding(.top, DS.Space.m)
                .padding(.leading, 2)
                .background(
                    GeometryReader { proxy in
                        Color.clear.preference(key: SectionHeightKey.self, value: proxy.size.height)
                    }
                )
                .frame(height: constrained ? revealHeight : nil, alignment: .top)
                .clipped()
                .frame(height: constrained ? shellHeight : nil, alignment: .top)
        }
        .onPreferenceChange(SectionHeightKey.self) { measuredHeight = $0 }
        .onChange(of: expanded) { _, newValue in newValue ? open() : close() }
        .onChange(of: measuredHeight) { _, newHeight in
            // Only while open and settled — mid-animation this is already
            // being driven explicitly, and applying it while closed would
            // pop the row open on its own.
            guard !constrained else { return }
            shellHeight = newHeight
            revealHeight = newHeight
        }
    }

    /// Phase 1: the row grows to the content's full height, empty.
    /// Phase 2: the content wipes in, top to bottom, filling that space.
    private func open() {
        constrained = true
        shellHeight = 0
        revealHeight = 0
        withAnimation(Self.phaseAnimation) {
            shellHeight = measuredHeight
        } completion: {
            withAnimation(Self.phaseAnimation) {
                revealHeight = measuredHeight
            } completion: {
                // Back to natural, unconstrained layout now that it matches
                // — see `measuredHeight`'s `onChange` above for why.
                constrained = false
            }
        }
    }

    /// Phase 1: the content wipes away, bottom to top, leaving an empty row
    /// of the same height. Phase 2: that empty row collapses.
    private func close() {
        // Currently unconstrained (natural layout) — pin both heights to the
        // current measured size first so there's a concrete number to
        // animate down from, with no visible change at this instant.
        shellHeight = measuredHeight
        revealHeight = measuredHeight
        constrained = true
        withAnimation(Self.phaseAnimation) {
            revealHeight = 0
        } completion: {
            withAnimation(Self.phaseAnimation) {
                shellHeight = 0
            }
        }
    }
}
