import AppKit
import AVFoundation

/// Floating circular webcam preview shown while recording.
///
/// **Click-through, not draggable.** A window with `ignoresMouseEvents = false`
/// sits in front of whatever you're demonstrating and eats clicks, which is far
/// worse during a take than not being able to move it. So it's click-through and
/// parks in a corner you pick in the sources popover.
///
/// This is preview only. Where the bubble actually lands in the finished video
/// is decided later, by dragging it on the editor preview.
///
/// The recorded `camera.mov` is always full-frame; this circle is preview only.
/// It belongs to our app, so `SCContentFilter` keeps it out of the capture.
@MainActor
final class CameraPreviewWindow {

    private var panel: OverlayPanel?

    func show(session: AVCaptureSession,
              corner: CaptureSettings.PreviewCorner,
              diameter: CGFloat = 180) {
        hide()
        guard let screen = NSScreen.main else { return }

        let margin: CGFloat = 28
        let frame = frameFor(corner: corner, diameter: diameter, screen: screen, margin: margin)

        let panel = OverlayPanel(contentRect: frame,
                            styleMask: [.borderless, .nonactivatingPanel],
                            backing: .buffered,
                            defer: false)
        panel.level = .screenSaver
        panel.isOpaque = false
        panel.backgroundColor = .clear
        panel.hasShadow = true
        panel.ignoresMouseEvents = true
        panel.collectionBehavior = [.canJoinAllSpaces, .stationary, .fullScreenNone, .ignoresCycle]

        let host = NSView(frame: NSRect(origin: .zero, size: frame.size))
        host.wantsLayer = true

        let preview = AVCaptureVideoPreviewLayer(session: session)
        preview.videoGravity = .resizeAspectFill
        preview.frame = host.bounds
        preview.cornerRadius = diameter / 2
        preview.masksToBounds = true
        preview.borderWidth = 2
        preview.borderColor = NSColor.white.withAlphaComponent(0.85).cgColor
        CameraMirror.apply(to: preview.connection)

        host.layer?.addSublayer(preview)
        panel.contentView = host
        panel.orderFrontRegardless()

        self.panel = panel
    }

    func hide() {
        panel?.orderOut(nil)
        panel = nil
    }

    private func frameFor(corner: CaptureSettings.PreviewCorner,
                          diameter: CGFloat,
                          screen: NSScreen,
                          margin: CGFloat) -> NSRect {
        // NSScreen.visibleFrame is AppKit space: origin bottom-left.
        let area = screen.visibleFrame
        switch corner {
        case .bottomLeft:
            return NSRect(x: area.minX + margin, y: area.minY + margin, width: diameter, height: diameter)
        case .bottomRight:
            return NSRect(x: area.maxX - margin - diameter, y: area.minY + margin, width: diameter, height: diameter)
        case .topLeft:
            return NSRect(x: area.minX + margin, y: area.maxY - margin - diameter, width: diameter, height: diameter)
        case .topRight:
            return NSRect(x: area.maxX - margin - diameter, y: area.maxY - margin - diameter, width: diameter, height: diameter)
        }
    }
}
