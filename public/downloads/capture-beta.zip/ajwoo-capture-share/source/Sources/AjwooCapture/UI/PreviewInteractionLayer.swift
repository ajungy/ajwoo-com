import SwiftUI
import AppKit

/// All pointer input on the preview: dragging the camera bubble, resizing it from
/// its corners, and panning a zoom's focus everywhere else.
///
/// # Why one layer instead of a gesture per element
/// The previous version hung a `DragGesture` off each subview — the bubble body,
/// then each corner handle — stacked over the player and over a separate pan
/// layer. It never worked, and it took three attempts to see why: the more
/// SwiftUI views with gestures you stack over an `NSViewRepresentable`, the more
/// places routing can quietly go wrong, and the harder it is to tell which one
/// did.
///
/// So this is the timeline's pattern, which has worked from the start: **one view
/// that fills the area, one gesture, and hit-testing done in plain code** against
/// rectangles we compute ourselves. `hitTest` is a static pure function, so the
/// geometry is checked by the self-test rather than by clicking around.
struct PreviewInteractionLayer: View {
    @ObservedObject var model: EditorModel
    /// Where the video sits inside the preview view (aspect-fit letterboxed).
    let videoRect: CGRect

    enum Corner: CaseIterable, Equatable {
        case topLeft, topRight, bottomLeft, bottomRight
    }

    enum Target: Equatable {
        case none
        case bubble
        case corner(Corner)
        case subtitles
        /// Left or right edge of the caption block, which sets its wrap width.
        case subtitleEdge(leading: Bool)
    }

    /// Half-size of a corner's grab area.
    static let handleGrab: CGFloat = 14
    private let handleSize: CGFloat = 10

    /// The cue being edited, and the text as typed. Non-nil means the caption
    /// on the preview has been replaced by a live text field.
    @State private var editingCue: SubtitleCue?
    @State private var editingText: String = ""
    @FocusState private var editorFocused: Bool

    @State private var hoverTarget: Target = .none
    @State private var dragTarget: Target?
    @State private var dragStartRect: CGRect = .zero
    @State private var lastPanTranslation: CGSize = .zero

    private var cameraEnabled: Bool { model.hasCamera && model.project.camera.enabled }
    private var subtitlesEnabled: Bool { model.project.subtitles.enabled && model.hasTranscript }

    /// Same formula `FrameRenderer` uses for the baked-in caption — a fraction
    /// of the output height — applied to `videoRect`'s own height instead of
    /// the export's pixel height. Since the preview draws the video at 1
    /// point per rendered pixel, that gives an on-screen point size that
    /// matches what's actually burned into the frame, rather than the fixed
    /// 13pt the editor used to fall back to regardless of the Size slider.
    private var previewFontPointSize: CGFloat {
        max(1, videoRect.height * CGFloat(model.project.subtitles.fontSize))
    }

    /// Mirrors `ProjectState.Subtitles.nsFont(pixelSize:)` so the family
    /// matches too, not just the size.
    private var previewFont: Font {
        let size = previewFontPointSize
        switch model.project.subtitles.font {
        case .system:        return .system(size: size, weight: .semibold)
        case .systemRounded: return .system(size: size, weight: .semibold, design: .rounded)
        case .helvetica:     return .custom("HelveticaNeue-Medium", size: size)
        case .avenir:        return .custom("AvenirNext-DemiBold", size: size)
        case .georgia:       return .custom("Georgia", size: size)
        case .menlo:         return .custom("Menlo-Regular", size: size)
        }
    }

    private var subtitleRect: CGRect {
        let normalized = model.subtitleNormalizedRect
        return CGRect(
            x: videoRect.minX + normalized.minX * videoRect.width,
            y: videoRect.minY + normalized.minY * videoRect.height,
            width: normalized.width * videoRect.width,
            height: normalized.height * videoRect.height
        )
    }

    private var bubbleRect: CGRect {
        let normalized = model.cameraNormalizedRect
        return CGRect(
            x: videoRect.minX + normalized.minX * videoRect.width,
            y: videoRect.minY + normalized.minY * videoRect.height,
            width: normalized.width * videoRect.width,
            height: normalized.height * videoRect.height
        )
    }

    /// Chrome is shown only while the pointer is on the bubble, or during a drag.
    /// Nothing is drawn otherwise — a permanent dashed outline sits on top of
    /// every frame you're trying to judge.
    private var showChrome: Bool {
        if let dragTarget, dragTarget != .none { return true }
        return hoverTarget != .none
    }

    private func isCameraTarget(_ target: Target) -> Bool {
        switch target {
        case .bubble, .corner: return true
        default: return false
        }
    }

    private func isSubtitleTarget(_ target: Target) -> Bool {
        switch target {
        case .subtitles, .subtitleEdge: return true
        default: return false
        }
    }

    var body: some View {
        ZStack(alignment: .topLeading) {
            Color.clear
            if showChrome, editingCue == nil { chrome }
            if editingCue != nil {
                editorDismissCatcher
                subtitleEditor
            }
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .topLeading)
        .contentShape(Rectangle())
        .onContinuousHover { phase in
            switch phase {
            case .active(let location):
                guard dragTarget == nil else { return }
                let target = Self.hitTest(location,
                                          bubble: cameraEnabled ? bubbleRect : .zero,
                                          subtitles: subtitlesEnabled ? subtitleRect : .zero,
                                          grab: Self.handleGrab)
                if target != hoverTarget {
                    hoverTarget = target
                    apply(cursor: target)
                }
            case .ended:
                hoverTarget = .none
                NSCursor.arrow.set()
            }
        }
        // Before the drag gesture, so a double-click on the caption opens the
        // editor rather than starting a one-pixel drag of the block.
        .simultaneousGesture(
            TapGesture(count: 2).onEnded {
                beginEditingSubtitleIfPossible()
            }
        )
        .gesture(
            DragGesture(minimumDistance: 0)
                .onChanged { value in
                    guard editingCue == nil else { return }
                    if dragTarget == nil {
                        dragTarget = Self.hitTest(value.startLocation,
                                                  bubble: cameraEnabled ? bubbleRect : .zero,
                                                  subtitles: subtitlesEnabled ? subtitleRect : .zero,
                                                  grab: Self.handleGrab)
                        dragStartRect = isSubtitleTarget(dragTarget ?? .none) ? subtitleRect : bubbleRect
                        lastPanTranslation = .zero
                    }
                    handle(value)
                }
                .onEnded { _ in
                    dragTarget = nil
                    lastPanTranslation = .zero
                }
        )
    }

    // MARK: - Subtitle editing

    /// Opens the inline editor if the pointer is over the caption.
    ///
    /// Guarded on the hover target rather than re-hit-testing: `TapGesture`
    /// doesn't report a location, and the hover tracking above already knows
    /// what's under the pointer.
    private func beginEditingSubtitleIfPossible() {
        guard subtitlesEnabled, isSubtitleTarget(hoverTarget), let cue = model.currentCue else { return }
        model.pause()
        editingText = cue.text
        editingCue = cue
        editorFocused = true
    }

    private func commitSubtitleEdit() {
        guard let cue = editingCue else { return }
        model.setSubtitleText(editingText, forCueStart: cue.start)
        editingCue = nil
        editorFocused = false
    }

    private func cancelSubtitleEdit() {
        editingCue = nil
        editorFocused = false
    }

    /// A real text field over the caption's own position.
    ///
    /// It's a `TextField`, not a bespoke editor, so every habit already works —
    /// select a word, delete, paste, ⌘Z. Committing on blur is what makes
    /// "click out of it" save, and Escape abandons the change; without the
    /// escape hatch a mistyped correction would be as hard to undo as the typo.
    private var subtitleEditor: some View {
        let rect = subtitleRect
        return HStack(spacing: DS.Space.xs) {
            TextField("", text: $editingText, axis: .vertical)
                .textFieldStyle(.plain)
                .font(previewFont)
                .textCase(model.project.subtitles.uppercase ? .uppercase : nil)
                .multilineTextAlignment(.center)
                .foregroundStyle(.white)
                .focused($editorFocused)
                .lineLimit(1...4)
                .onSubmit { commitSubtitleEdit() }

            // Visible controls as well as the keyboard ones. Return-to-save and
            // Escape-to-cancel are invisible until someone tells you about them,
            // and clicking away to save is a leap of faith the first time.
            Button(action: commitSubtitleEdit) {
                Image(systemName: "checkmark")
                    .font(.system(size: 11, weight: .bold))
            }
            .buttonStyle(.plain)
            .foregroundStyle(.white)
            .tooltip("Save  ⏎")
            .accessibilityLabel("Save caption")

            Button(action: cancelSubtitleEdit) {
                Image(systemName: "xmark")
                    .font(.system(size: 11, weight: .bold))
            }
            .buttonStyle(.plain)
            .foregroundStyle(.white.opacity(0.75))
            .tooltip("Cancel  esc")
            .accessibilityLabel("Cancel editing")
        }
        .padding(.horizontal, DS.Space.s)
        .padding(.vertical, DS.Space.xs)
        .background(
            RoundedRectangle(cornerRadius: DS.Radius.chip)
                .fill(.black.opacity(0.85))
                .overlay(
                    RoundedRectangle(cornerRadius: DS.Radius.chip)
                        .strokeBorder(.white.opacity(0.9), lineWidth: 1.5)
                )
        )
        .frame(width: max(200, rect.width))
        .position(x: rect.midX, y: rect.midY)
        .onExitCommand { cancelSubtitleEdit() }
    }

    /// Clicking anywhere outside the editor saves, as asked.
    ///
    /// Deliberately *not* driven by focus loss: pressing Cancel moves focus away
    /// before its action runs, so a focus-loss save would commit the very change
    /// Cancel exists to discard.
    private var editorDismissCatcher: some View {
        Color.clear
            .contentShape(Rectangle())
            .onTapGesture { commitSubtitleEdit() }
    }

    // MARK: - Chrome

    @ViewBuilder
    private var chrome: some View {
        let active = dragTarget ?? hoverTarget
        if isSubtitleTarget(active) {
            subtitleChrome
        } else if isCameraTarget(active) {
            cameraChrome
        }
    }

    private var subtitleChrome: some View {
        let rect = subtitleRect
        return ZStack(alignment: .topLeading) {
            Rectangle()
                .fill(Color.white.opacity(0.06))
                .overlay(Rectangle().strokeBorder(Color.white, lineWidth: DS.line))
                .shadow(color: .black.opacity(0.5), radius: 2)
                .frame(width: rect.width, height: rect.height)
                .offset(x: rect.minX, y: rect.minY)

            ForEach([true, false], id: \.self) { leading in
                RoundedRectangle(cornerRadius: 2)
                    .fill(Color.white)
                    .overlay(RoundedRectangle(cornerRadius: 2)
                        .strokeBorder(Color.black.opacity(0.35), lineWidth: DS.line))
                    .frame(width: 6, height: min(rect.height, 34))
                    .shadow(color: .black.opacity(0.5), radius: 1.5)
                    .offset(x: (leading ? rect.minX : rect.maxX) - 3, y: rect.midY - min(rect.height, 34) / 2)
            }

            Text("Subtitles")
                .font(DS.Font.micro)
                .foregroundStyle(.white)
                .padding(.horizontal, 6).padding(.vertical, 2)
                .background(.black.opacity(0.75), in: Capsule())
                .offset(x: rect.minX, y: rect.minY - 20)
        }
        .allowsHitTesting(false)
        .animation(DS.Motion.fast, value: hoverTarget)
    }

    private var cameraChrome: some View {
        let rect = bubbleRect
        let dragging = dragTarget != nil && dragTarget != Target.none

        return ZStack(alignment: .topLeading) {
            // Chrome drawn over video is always white with a dark shadow, in
            // both appearances. The video is its own surface — it isn't page
            // background — so app text colours would vanish against half of it.
            Rectangle()
                .fill(Color.white.opacity(dragging ? 0.14 : 0.06))
                .overlay(
                    Rectangle().strokeBorder(Color.white, lineWidth: DS.line)
                )
                .shadow(color: .black.opacity(0.5), radius: 2)
                .frame(width: rect.width, height: rect.height)
                .offset(x: rect.minX, y: rect.minY)

            ForEach(Array(Corner.allCases.enumerated()), id: \.offset) { _, corner in
                let point = Self.position(of: corner, in: rect)
                let hot = hoverTarget == .corner(corner) || dragTarget == .corner(corner)
                // Constant box in every state — the handle darkens its ring when
                // it's the target rather than growing, so the thing you're
                // aiming at never moves as you approach it.
                RoundedRectangle(cornerRadius: 2)
                    .fill(Color.white)
                    .overlay(RoundedRectangle(cornerRadius: 2)
                        .strokeBorder(Color.black.opacity(hot ? 0.95 : 0.3),
                                      lineWidth: hot ? 2 : DS.line))
                    .frame(width: handleSize, height: handleSize)
                    .shadow(color: .black.opacity(0.5), radius: 1.5)
                    .offset(x: point.x - handleSize / 2, y: point.y - handleSize / 2)
            }

            Text("Camera")
                .font(DS.Font.micro)
                .foregroundStyle(.white)
                .padding(.horizontal, 6).padding(.vertical, 2)
                .background(.black.opacity(0.75), in: Capsule())
                .offset(x: rect.minX, y: rect.minY - 20)
        }
        .allowsHitTesting(false)
        .animation(DS.Motion.fast, value: hoverTarget)
    }

    private func apply(cursor target: Target) {
        switch target {
        case .none:          NSCursor.arrow.set()
        case .bubble:        NSCursor.openHand.set()
        case .corner:        NSCursor.crosshair.set()
        case .subtitles:     NSCursor.openHand.set()
        case .subtitleEdge:  NSCursor.resizeLeftRight.set()
        }
    }

    // MARK: - Hit testing (pure, so the self-test can check it)

    static func position(of corner: Corner, in rect: CGRect) -> CGPoint {
        switch corner {
        case .topLeft:     return CGPoint(x: rect.minX, y: rect.minY)
        case .topRight:    return CGPoint(x: rect.maxX, y: rect.minY)
        case .bottomLeft:  return CGPoint(x: rect.minX, y: rect.maxY)
        case .bottomRight: return CGPoint(x: rect.maxX, y: rect.maxY)
        }
    }

    static func opposite(_ corner: Corner) -> Corner {
        switch corner {
        case .topLeft:     return .bottomRight
        case .topRight:    return .bottomLeft
        case .bottomLeft:  return .topRight
        case .bottomRight: return .topLeft
        }
    }

    /// Corners win over the body, so a grab near an edge resizes rather than
    /// moving — the handles overlap the bubble's own bounds.
    static func hitTest(_ point: CGPoint, bubble: CGRect, subtitles: CGRect, grab: CGFloat) -> Target {
        if bubble.width > 0, bubble.height > 0 {
            for corner in Corner.allCases {
                let position = position(of: corner, in: bubble)
                if abs(point.x - position.x) <= grab && abs(point.y - position.y) <= grab {
                    return .corner(corner)
                }
            }
            if bubble.contains(point) { return .bubble }
        }

        // Captions are tested after the bubble: they're wide and low, and a
        // bubble parked over them should still win.
        if subtitles.width > 0, subtitles.height > 0 {
            if abs(point.y - subtitles.midY) <= subtitles.height / 2 + grab / 2 {
                if abs(point.x - subtitles.minX) <= grab { return .subtitleEdge(leading: true) }
                if abs(point.x - subtitles.maxX) <= grab { return .subtitleEdge(leading: false) }
            }
            if subtitles.contains(point) { return .subtitles }
        }
        return .none
    }

    // MARK: - Drag handling

    private func handle(_ value: DragGesture.Value) {
        switch dragTarget {
        case .some(.bubble):
            moveBubble(by: value.translation)
        case .some(.corner(let corner)):
            resizeBubble(corner, by: value.translation)
        case .some(.subtitles):
            moveSubtitles(by: value.translation)
        case .some(.subtitleEdge(let leading)):
            resizeSubtitles(leading: leading, by: value.translation)
        case .some(.none), nil:
            panZoomFocus(value)
        }
    }

    private func moveBubble(by translation: CGSize) {
        guard videoRect.width > 0, videoRect.height > 0 else { return }
        let centre = CGPoint(x: dragStartRect.midX + translation.width,
                             y: dragStartRect.midY + translation.height)
        model.moveCamera(toCenter: CGPoint(
            x: (centre.x - videoRect.minX) / videoRect.width,
            y: (centre.y - videoRect.minY) / videoRect.height
        ))
    }

    /// Resizes with the **opposite corner pinned**, the way every bounding box
    /// behaves. The aspect ratio is fixed by the bubble's shape, so the drag
    /// drives height and width follows.
    private func resizeBubble(_ corner: Corner, by translation: CGSize) {
        guard videoRect.height > 0 else { return }

        let anchor = Self.position(of: Self.opposite(corner), in: dragStartRect)
        let start = Self.position(of: corner, in: dragStartRect)
        let dragged = CGPoint(x: start.x + translation.width, y: start.y + translation.height)

        model.resizeCamera(toHeightFraction: Double(abs(dragged.y - anchor.y) / videoRect.height))

        // Re-derive the centre so the anchor corner stays put at the new size.
        let resolved = model.cameraNormalizedRect
        let width = resolved.width * videoRect.width
        let height = resolved.height * videoRect.height
        let centreX = anchor.x + (dragged.x >= anchor.x ? width / 2 : -width / 2)
        let centreY = anchor.y + (dragged.y >= anchor.y ? height / 2 : -height / 2)

        model.moveCamera(toCenter: CGPoint(
            x: (centreX - videoRect.minX) / videoRect.width,
            y: (centreY - videoRect.minY) / videoRect.height
        ))
    }

    private func moveSubtitles(by translation: CGSize) {
        guard videoRect.width > 0, videoRect.height > 0 else { return }
        let centre = CGPoint(x: dragStartRect.midX + translation.width,
                             y: dragStartRect.midY + translation.height)
        model.moveSubtitles(toCenter: CGPoint(
            x: (centre.x - videoRect.minX) / videoRect.width,
            y: (centre.y - videoRect.minY) / videoRect.height
        ))
    }

    /// Dragging an edge changes the wrap width symmetrically about the centre,
    /// which keeps a centred caption centred.
    private func resizeSubtitles(leading: Bool, by translation: CGSize) {
        guard videoRect.width > 0 else { return }
        let delta = leading ? -translation.width : translation.width
        let width = (dragStartRect.width + delta * 2) / videoRect.width
        model.resizeSubtitles(toWidthFraction: Double(width))
    }

    private func panZoomFocus(_ value: DragGesture.Value) {
        guard !model.isCropping, model.selectedZoomID != nil else { return }
        model.panFocus(dx: value.translation.width - lastPanTranslation.width,
                       dy: value.translation.height - lastPanTranslation.height,
                       viewSize: videoRect.size)
        lastPanTranslation = value.translation
    }
}
