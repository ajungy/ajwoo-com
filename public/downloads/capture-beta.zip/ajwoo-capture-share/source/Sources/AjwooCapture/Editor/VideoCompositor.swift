import Foundation
import AVFoundation
import CoreImage
import CoreMedia
import Metal

/// Carries the render state from the editor into AVFoundation's compositor.
///
/// AVFoundation instantiates the compositor class itself, with no arguments, so
/// there is no constructor to hand a `RenderContext` to. The instruction is the
/// supported channel: it's attached to the video composition and handed back on
/// every request. Using it (rather than a global) means a preview and an export
/// can run at the same time with different state.
final class RenderInstruction: NSObject, AVVideoCompositionInstructionProtocol, @unchecked Sendable {
    let timeRange: CMTimeRange
    let enablePostProcessing: Bool = false
    /// Every frame differs — zoom ramps and the cursor move continuously — so
    /// AVFoundation must never reuse a composed frame across a time range.
    let containsTweening: Bool = true
    // `[NSValue]` isn't Sendable, but this array is built once in `init` and
    // never mutated, so concurrent reads are safe.
    let requiredSourceTrackIDs: [NSValue]?
    let passthroughTrackID: CMPersistentTrackID = kCMPersistentTrackID_Invalid

    let context: RenderContext
    let screenTrackID: CMPersistentTrackID
    let cameraTrackID: CMPersistentTrackID?
    /// Composition time → recording time, so the renderer can look up cursor
    /// positions and zoom segments even when cuts have shifted the timeline.
    let timeMap: TimeMap

    init(timeRange: CMTimeRange,
         context: RenderContext,
         screenTrackID: CMPersistentTrackID,
         cameraTrackID: CMPersistentTrackID?,
         timeMap: TimeMap) {
        self.timeRange = timeRange
        self.context = context
        self.screenTrackID = screenTrackID
        self.cameraTrackID = cameraTrackID
        self.timeMap = timeMap

        var ids: [NSValue] = [NSNumber(value: screenTrackID)]
        if let cameraTrackID { ids.append(NSNumber(value: cameraTrackID)) }
        self.requiredSourceTrackIDs = ids
        super.init()
    }
}

/// Wraps `FrameRenderer` in the `AVVideoCompositing` protocol.
///
/// Doing it this way is what lets preview and export share one pipeline for
/// free: `AVPlayer` gets it via `AVPlayerItem.videoComposition`, and the
/// exporter gets it via `AVAssetReaderVideoCompositionOutput`. Both call the
/// exact same `render(...)`.
final class AjwooCaptureCompositor: NSObject, AVVideoCompositing {

    private let renderQueue = DispatchQueue(label: "com.ajwoo.capture.compositor", qos: .userInitiated)
    private let ciContext: CIContext
    private let renderer = FrameRenderer()
    private let colorSpace = CGColorSpace(name: CGColorSpace.sRGB) ?? CGColorSpaceCreateDeviceRGB()

    override init() {
        if let device = MTLCreateSystemDefaultDevice() {
            ciContext = CIContext(mtlDevice: device, options: [.cacheIntermediates: false])
        } else {
            ciContext = CIContext(options: [.cacheIntermediates: false])
        }
        super.init()
    }

    var sourcePixelBufferAttributes: [String: any Sendable]? {
        [
            kCVPixelBufferPixelFormatTypeKey as String: [kCVPixelFormatType_32BGRA],
            kCVPixelBufferMetalCompatibilityKey as String: true,
        ]
    }

    var requiredPixelBufferAttributesForRenderContext: [String: any Sendable] {
        [
            kCVPixelBufferPixelFormatTypeKey as String: [kCVPixelFormatType_32BGRA],
            kCVPixelBufferMetalCompatibilityKey as String: true,
        ]
    }

    func renderContextChanged(_ newRenderContext: AVVideoCompositionRenderContext) {
        // Nothing cached against the render context; the renderer reads its size
        // from each request.
    }

    func startRequest(_ request: AVAsynchronousVideoCompositionRequest) {
        // Serial queue: `FrameRenderer` holds a mask cache and is not reentrant.
        renderQueue.async { [self] in
            guard let instruction = request.videoCompositionInstruction as? RenderInstruction else {
                request.finish(with: CompositorError.missingInstruction)
                return
            }
            guard let screenBuffer = request.sourceFrame(byTrackID: instruction.screenTrackID) else {
                request.finish(with: CompositorError.missingSourceFrame)
                return
            }
            guard let destination = request.renderContext.newPixelBuffer() else {
                request.finish(with: CompositorError.noPixelBuffer)
                return
            }

            // Returns nil outside the camera track's time range, which is exactly
            // what we want — the renderer just skips the bubble.
            let cameraBuffer = instruction.cameraTrackID.flatMap { request.sourceFrame(byTrackID: $0) }

            let size = request.renderContext.size
            let image = renderer.render(
                screen: CIImage(cvPixelBuffer: screenBuffer),
                camera: cameraBuffer.map { CIImage(cvPixelBuffer: $0) },
                // Cuts shift the timeline, so composition time is translated
                // back to recording time — the space `events.json` and every
                // zoom segment live in. With no cuts this is the identity.
                time: instruction.timeMap.recordingTime(
                    forComposition: CMTimeGetSeconds(request.compositionTime)
                ),
                snapshot: instruction.context.snapshot(),
                outputSize: size
            )

            ciContext.render(image,
                             to: destination,
                             bounds: CGRect(origin: .zero, size: size),
                             colorSpace: colorSpace)
            request.finish(withComposedVideoFrame: destination)
        }
    }

    func cancelAllPendingVideoCompositionRequests() {}

    enum CompositorError: LocalizedError {
        case missingInstruction, missingSourceFrame, noPixelBuffer

        var errorDescription: String? {
            switch self {
            case .missingInstruction:  return "Video composition instruction was not an ajwoo capture instruction."
            case .missingSourceFrame:  return "This recording has no picture in it."
            case .noPixelBuffer:       return "Render context could not vend a pixel buffer."
            }
        }
    }
}
