import Foundation
import Speech
import AVFoundation

/// Word-level transcript of the microphone track.
///
/// # Why Apple's `Speech` framework
/// It's first-party, free, and — with `requiresOnDeviceRecognition` — runs
/// entirely on this Mac. That last part is not a detail: the whole product
/// promise is that nothing leaves the machine, and a transcription service that
/// uploaded audio would break it. If on-device recognition isn't available for
/// the chosen language, transcription is refused rather than quietly falling
/// back to the network.
///
/// The brief originally ruled out transcription. It was asked for later, so it's
/// here — but under the same local-only constraint as everything else.
struct Transcript: Codable, Equatable {
    struct Word: Codable, Equatable {
        var text: String
        /// Seconds from the start of the **recording**.
        var start: Double
        var duration: Double
        var end: Double { start + duration }
        /// Recogniser's confidence, 0–1. Zero means it didn't say.
        var confidence: Double
    }

    var words: [Word]
    var locale: String
    /// Which recogniser produced this. Recorded so a cached transcript from the
    /// slow path can be told apart from a fresh one.
    var engine: String = "SFSpeechRecognizer"
    /// Schema marker, so a future change can invalidate cached transcripts.
    var version: Int = 1

    var isEmpty: Bool { words.isEmpty }

    func write(to url: URL) throws {
        let encoder = JSONEncoder()
        encoder.outputFormatting = [.sortedKeys]
        try encoder.encode(self).write(to: url, options: .atomic)
    }

    static func read(from url: URL) throws -> Transcript {
        try JSONDecoder().decode(Transcript.self, from: Data(contentsOf: url))
    }
}

enum Transcriber {

    enum TranscriptionError: LocalizedError {
        case noMicrophoneTrack
        case notAuthorised
        case onDeviceUnavailable
        case recognitionFailed(String)

        var errorDescription: String? {
            switch self {
            case .noMicrophoneTrack:
                return "This recording has no microphone track to transcribe."
            case .notAuthorised:
                return "No permission to read speech. Turn it on in System Settings, under Privacy & Security."
            case .onDeviceUnavailable:
                return "On-device speech recognition isn't available for this language. Add it in System Settings → Keyboard → Dictation, then try again."
            case .recognitionFailed(let message):
                return "Couldn't turn the speech into text."
            }
        }
    }

    static func requestAuthorisation() async -> Bool {
        switch SFSpeechRecognizer.authorizationStatus() {
        case .authorized: return true
        case .notDetermined:
            return await withCheckedContinuation { continuation in
                SFSpeechRecognizer.requestAuthorization { status in
                    continuation.resume(returning: status == .authorized)
                }
            }
        default: return false
        }
    }

    /// Transcribes `mic.m4a` with word-level timings.
    ///
    /// `SFSpeechURLRecognitionRequest` reports progressive results; only the
    /// final one has stable timings, so intermediate results drive progress and
    /// the last one is kept.
    static func transcribe(session: RecordingSession,
                           overrideAudioURL: URL? = nil,
                           progress: @escaping @Sendable (Double) -> Void) async throws -> Transcript {
        let audioURL = overrideAudioURL ?? session.micAudioURL
        guard FileManager.default.fileExists(atPath: audioURL.path) else {
            throw TranscriptionError.noMicrophoneTrack
        }
        // `SpeechAnalyzer` reads a file as fast as the model can consume it;
        // `SFSpeechRecognizer` below streams it at close to the rate it was
        // recorded. The difference on a five-minute take is minutes versus
        // seconds, so the old path is now only a fallback for macOS 14 and 15.
        //
        // It also works on a local file without `SFSpeechRecognizer`'s
        // authorisation prompt, so the check below is deliberately after this.
        if #available(macOS 26.0, *), FastTranscriber.isAvailable {
            return try await FastTranscriber.transcribe(url: audioURL, progress: progress)
        }

        guard await requestAuthorisation() else { throw TranscriptionError.notAuthorised }

        let recogniser = SFSpeechRecognizer(locale: Locale.current) ?? SFSpeechRecognizer()
        guard let recogniser, recogniser.isAvailable else {
            throw TranscriptionError.recognitionFailed("no recogniser for \(Locale.current.identifier)")
        }
        guard recogniser.supportsOnDeviceRecognition else {
            throw TranscriptionError.onDeviceUnavailable
        }

        let asset = AVURLAsset(url: audioURL)
        let duration = (try? await asset.load(.duration))?.seconds ?? 0

        let request = SFSpeechURLRecognitionRequest(url: audioURL)
        request.shouldReportPartialResults = true
        // Never leaves the machine.
        request.requiresOnDeviceRecognition = true
        request.taskHint = .dictation
        request.addsPunctuation = true

        let locale = recogniser.locale.identifier

        return try await withCheckedThrowingContinuation { continuation in
            let box = ResultBox()
            recogniser.recognitionTask(with: request) { result, error in
                if let error {
                    box.finishOnce { continuation.resume(throwing: TranscriptionError.recognitionFailed(error.localizedDescription)) }
                    return
                }
                guard let result else { return }

                if !result.isFinal {
                    if duration > 0, let last = result.bestTranscription.segments.last {
                        progress(min(0.99, (last.timestamp + last.duration) / duration))
                    }
                    return
                }

                let words = result.bestTranscription.segments.map {
                    Transcript.Word(text: $0.substring,
                                    start: $0.timestamp,
                                    duration: $0.duration,
                                    confidence: Double($0.confidence))
                }
                progress(1)
                box.finishOnce {
                    continuation.resume(returning: Transcript(words: words, locale: locale))
                }
            }
        }
    }

    /// A recognition task can report an error *after* delivering a final result;
    /// the continuation must only be resumed once.
    private final class ResultBox: @unchecked Sendable {
        private let lock = NSLock()
        private var done = false

        func finishOnce(_ body: () -> Void) {
            lock.lock()
            let first = !done
            done = true
            lock.unlock()
            if first { body() }
        }
    }
}

// MARK: - Derived edits

/// Turns a transcript into cuts and subtitle cues.
enum TranscriptAnalysis {

    /// Words treated as filler.
    ///
    /// Kept deliberately short and unambiguous. "Like" and "so" are excluded:
    /// they're filler roughly half the time and load-bearing the other half, and
    /// silently deleting a real word is far worse than leaving a stray "um".
    static let fillers: Set<String> = [
        "um", "uh", "erm", "er", "ah", "hmm", "mm", "mhm", "uhh", "umm", "eh",
    ]

    static func isFiller(_ word: Transcript.Word) -> Bool {
        let cleaned = word.text
            .trimmingCharacters(in: .whitespacesAndNewlines)
            .trimmingCharacters(in: CharacterSet.punctuationCharacters)
            .lowercased()
        return fillers.contains(cleaned)
    }

    /// Cut ranges covering every filler word, padded slightly so the cut lands in
    /// the gap either side rather than clipping the neighbouring word.
    static func fillerCuts(in transcript: Transcript, padding: Double = 0.04) -> [ProjectState.CutRange] {
        transcript.words
            .filter(isFiller)
            .map { ProjectState.CutRange(start: max(0, $0.start - padding),
                                         end: $0.end + padding,
                                         origin: .filler) }
    }

    /// Gaps between words longer than `threshold`.
    ///
    /// Superseded by `SilenceDetector`, which works on the audio envelope
    /// instead — word gaps miss most real pauses in a room with any background
    /// noise. Kept because the self-test pins its behaviour and it documents
    /// what the transcript alone can and can't tell you.
    static func silenceCuts(in transcript: Transcript,
                            duration: Double,
                            threshold: Double,
                            keep: Double = 0.2) -> [ProjectState.CutRange] {
        guard threshold > keep else { return [] }
        var cuts: [ProjectState.CutRange] = []
        var previousEnd: Double?

        for word in transcript.words.sorted(by: { $0.start < $1.start }) {
            if let end = previousEnd, word.start - end > threshold {
                cuts.append(.init(start: end + keep / 2,
                                  end: word.start - keep / 2,
                                  origin: .silence))
            }
            previousEnd = max(previousEnd ?? 0, word.end)
        }
        return cuts
    }

    /// Groups words into subtitle cues of at most `wordsPerCue`.
    ///
    /// A cue also breaks at sentence-ending punctuation and at any gap longer
    /// than a second, so captions track the shape of the speech rather than
    /// chopping every N words regardless.
    static func cues(from transcript: Transcript, wordsPerCue: Int) -> [SubtitleCue] {
        let limit = max(1, wordsPerCue)
        var cues: [SubtitleCue] = []
        var current: [Transcript.Word] = []

        func flush() {
            guard let first = current.first, let last = current.last else { return }
            cues.append(SubtitleCue(
                text: current.map(\.text).joined(separator: " "),
                start: first.start,
                end: last.end
            ))
            current = []
        }

        for word in transcript.words.sorted(by: { $0.start < $1.start }) {
            if let previous = current.last, word.start - previous.end > 1.0 { flush() }
            current.append(word)
            let endsSentence = word.text.hasSuffix(".") || word.text.hasSuffix("?") || word.text.hasSuffix("!")
            if current.count >= limit || endsSentence { flush() }
        }
        flush()
        return cues
    }
}

struct SubtitleCue: Equatable {
    var text: String
    var start: Double
    var end: Double
}

/// Binary-searchable cue list for the renderer.
struct SubtitleTrack {
    private let cues: [SubtitleCue]

    init(cues: [SubtitleCue]) {
        self.cues = cues.sorted { $0.start < $1.start }
    }

    var isEmpty: Bool { cues.isEmpty }
    var all: [SubtitleCue] { cues }

    func cue(at t: Double) -> SubtitleCue? {
        guard !cues.isEmpty else { return nil }
        var low = 0, high = cues.count - 1, found = -1
        while low <= high {
            let mid = (low + high) / 2
            if cues[mid].start <= t { found = mid; low = mid + 1 } else { high = mid - 1 }
        }
        guard found >= 0, t <= cues[found].end else { return nil }
        return cues[found]
    }
}
