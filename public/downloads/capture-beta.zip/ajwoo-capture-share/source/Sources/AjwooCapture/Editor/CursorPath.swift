import Foundation
import CoreGraphics

/// The cursor path from `events.json`, resampled onto a uniform grid and
/// smoothed for playback.
///
/// # Why resample
/// `events.json` is deduplicated and irregularly spaced. The renderer needs a
/// position at an arbitrary instant, cheaply, in random order (scrubbing). A
/// uniform grid built once at load turns that into an array index.
///
/// # Why a *centered* moving average
/// The raw 120 Hz path is jittery — hand tremor plus pointer acceleration. A
/// causal filter (one-pole, or a trailing average) would smooth it but lag
/// behind the real position, and a laggy cursor looks broken next to the clicks
/// it's supposed to be making. A centered window has **zero phase lag**: the
/// smoothed cursor arrives at a target at the same instant the real one did.
/// We can do this because the whole recording is on disk — it's not a live
/// signal, so we're allowed to look into the future.
struct CursorPath {

    /// Grid resolution. Matches the capture sampler so we never invent detail.
    static let sampleRate: Double = 120

    private let xs: [Double]
    private let ys: [Double]
    private let step: Double
    let duration: Double

    var isEmpty: Bool { xs.isEmpty }

    /// - Parameter smoothing: 0 = raw samples, 1 = heavily smoothed (~200 ms window).
    init(samples: [EventLog.CursorSample], duration: Double, smoothing: Double) {
        self.init(samples: samples, duration: duration,
                  halfWindow: Int((min(1, max(0, smoothing)) * 12).rounded()))
    }

    /// Heavily smoothed path used to drive **zoom follow**.
    ///
    /// A zoom that tracks the raw pointer is unwatchable — every small hand
    /// movement swings the whole frame. This uses a ~0.7 s window, an order of
    /// magnitude more than cursor rendering, so the framing drifts like a slow
    /// camera pan instead of chasing the mouse.
    static func follow(samples: [EventLog.CursorSample], duration: Double) -> CursorPath {
        CursorPath(samples: samples, duration: duration, halfWindow: Int(0.35 * sampleRate))
    }

    private init(samples: [EventLog.CursorSample], duration: Double, halfWindow: Int) {
        let step = 1.0 / Self.sampleRate
        self.step = step
        self.duration = max(0, duration)

        guard !samples.isEmpty, duration > 0 else {
            xs = []; ys = []
            return
        }

        let count = max(2, Int((duration / step).rounded(.up)) + 1)
        var gridX = [Double](repeating: 0, count: count)
        var gridY = [Double](repeating: 0, count: count)

        // Linear interpolation between logged samples. This is exactly right
        // for a deduplicated log: two consecutive samples with the same position
        // mean "didn't move", and interpolating between equal values holds still.
        var cursor = 0
        for i in 0..<count {
            let t = Double(i) * step
            while cursor + 1 < samples.count, samples[cursor + 1].t <= t { cursor += 1 }

            let a = samples[cursor]
            if cursor + 1 < samples.count {
                let b = samples[cursor + 1]
                let span = b.t - a.t
                let f = span > 0 ? min(1, max(0, (t - a.t) / span)) : 0
                gridX[i] = a.x + (b.x - a.x) * f
                gridY[i] = a.y + (b.y - a.y) * f
            } else {
                gridX[i] = a.x
                gridY[i] = a.y
            }
        }

        // Window: 1 sample (off) up to 25 samples (~208 ms) at full smoothing.
        // The 0.25 default lands on 7 samples (~58 ms) — enough to kill jitter,
        // short enough that the cursor still feels attached to your hand.
        if halfWindow > 0 {
            xs = Self.movingAverage(gridX, halfWindow: halfWindow)
            ys = Self.movingAverage(gridY, halfWindow: halfWindow)
        } else {
            xs = gridX
            ys = gridY
        }
    }

    /// Centered box filter with edge clamping, via a running sum (O(n)).
    private static func movingAverage(_ values: [Double], halfWindow: Int) -> [Double] {
        let n = values.count
        guard n > 0 else { return values }
        var out = [Double](repeating: 0, count: n)
        let window = halfWindow * 2 + 1

        var sum = 0.0
        for i in -halfWindow...halfWindow {
            sum += values[min(n - 1, max(0, i))]
        }
        for i in 0..<n {
            out[i] = sum / Double(window)
            let leaving = values[min(n - 1, max(0, i - halfWindow))]
            let entering = values[min(n - 1, max(0, i + halfWindow + 1))]
            sum += entering - leaving
        }
        return out
    }

    /// Position at `t`, normalized to the capture frame (top-left origin).
    /// Values can fall outside 0...1 — that means the pointer left the captured
    /// area, and the renderer hides it rather than pinning it to an edge.
    func position(at t: Double) -> CGPoint? {
        guard !xs.isEmpty else { return nil }
        let clamped = min(duration, max(0, t))
        let exact = clamped / step
        let i = Int(exact)
        guard i >= 0, i < xs.count else { return nil }
        if i + 1 >= xs.count { return CGPoint(x: xs[i], y: ys[i]) }

        let f = exact - Double(i)
        return CGPoint(
            x: xs[i] + (xs[i + 1] - xs[i]) * f,
            y: ys[i] + (ys[i + 1] - ys[i]) * f
        )
    }
}

/// Click lookups for the pulse and ripple animations.
struct ClickTrack {
    /// Mouse-down events only, sorted by time. `up` events aren't animated.
    private let downs: [EventLog.ClickEvent]

    init(clicks: [EventLog.ClickEvent]) {
        downs = clicks.filter { $0.phase == .down }.sorted { $0.t < $1.t }
    }

    var isEmpty: Bool { downs.isEmpty }
    var times: [Double] { downs.map(\.t) }

    /// Seconds since the most recent click at or before `t`, or nil if none.
    func timeSinceLastClick(at t: Double) -> Double? {
        guard !downs.isEmpty else { return nil }
        var low = 0, high = downs.count - 1, found = -1
        while low <= high {
            let mid = (low + high) / 2
            if downs[mid].t <= t { found = mid; low = mid + 1 } else { high = mid - 1 }
        }
        guard found >= 0 else { return nil }
        return t - downs[found].t
    }

    /// Click times grouped into bursts, for the auto-zoom suggestions.
    /// A gap longer than `maxGap` starts a new cluster.
    func clusters(maxGap: Double = 2.5) -> [[EventLog.ClickEvent]] {
        guard !downs.isEmpty else { return [] }
        var result: [[EventLog.ClickEvent]] = []
        var current: [EventLog.ClickEvent] = [downs[0]]
        for click in downs.dropFirst() {
            if click.t - (current.last?.t ?? click.t) > maxGap {
                result.append(current)
                current = [click]
            } else {
                current.append(click)
            }
        }
        result.append(current)
        return result
    }
}


/// Drives "hide the pointer after N seconds of no movement."
///
/// Built from the raw, deduplicated `events.json` samples — never the
/// smoothed 120 Hz grid `CursorPath` draws from, which is essentially never
/// exactly stationary (a moving average blurs across any real movement, so
/// it never reports "didn't move" cleanly). The dedup log already encodes
/// stillness directly: a run of samples at the same position, bridged by
/// `EventLog.keepaliveInterval`-spaced keepalives.
struct IdleTrack {
    /// Every instant the pointer's position actually changed, sorted.
    private let movementTimes: [Double]

    init(samples: [EventLog.CursorSample]) {
        var times: [Double] = []
        times.reserveCapacity(samples.count)
        var last: EventLog.CursorSample?
        let epsilon = 0.0005
        for sample in samples.sorted(by: { $0.t < $1.t }) {
            if let last, abs(sample.x - last.x) < epsilon, abs(sample.y - last.y) < epsilon {
                continue
            }
            times.append(sample.t)
            last = sample
        }
        movementTimes = times
    }

    private func lastMovementIndex(at t: Double) -> Int? {
        guard !movementTimes.isEmpty else { return nil }
        var low = 0, high = movementTimes.count - 1, found = -1
        while low <= high {
            let mid = (low + high) / 2
            if movementTimes[mid] <= t { found = mid; low = mid + 1 } else { high = mid - 1 }
        }
        return found >= 0 ? found : nil
    }

    /// 1 while the pointer is moving (or `hideAfter` is 0, meaning the
    /// feature is off), ramping down to 0 across `fadeDuration` once it's
    /// been still for `hideAfter` seconds, and ramping back up across the
    /// same window once it starts moving again.
    ///
    /// The fade-in isn't just "time since idle hit zero" — that would snap
    /// straight back to visible the instant movement resumes, since idle time
    /// resets to zero on the very next sample. It's "how long the *current*
    /// streak of movement has run," walked backward from `t` only until
    /// either `fadeDuration` of continuous motion is accounted for (fully
    /// faded in — no need to look further back) or a gap wide enough to have
    /// actually hidden the pointer turns up (that gap is where the streak,
    /// and the ramp, began).
    func visibility(at t: Double, hideAfter: Double, fadeDuration: Double = 0.35) -> Double {
        guard hideAfter > 0, let idx = lastMovementIndex(at: t) else { return 1 }
        let idleSince = t - movementTimes[idx]
        let fadeOut = 1 - min(1, max(0, (idleSince - hideAfter) / fadeDuration))

        var streak = idleSince
        var i = idx
        while streak < fadeDuration, i > 0 {
            let gap = movementTimes[i] - movementTimes[i - 1]
            if gap >= hideAfter { break }
            streak += gap
            i -= 1
        }
        let fadeIn = min(1, streak / fadeDuration)

        return min(fadeOut, fadeIn)
    }
}

/// Which shape the system pointer had at a given instant.
///
/// Stored sparsely in `events.json` — one entry per change — so this holds the
/// changes and binary-searches them. A recording made before shapes were logged
/// has none, and everything resolves to `.arrow`.
struct PointerShapeTrack {
    private let changes: [EventLog.PointerShapeChange]

    init(changes: [EventLog.PointerShapeChange]?) {
        self.changes = (changes ?? []).sorted { $0.t < $1.t }
    }

    var isEmpty: Bool { changes.isEmpty }

    func shape(at t: Double) -> EventLog.PointerShapeChange.Shape {
        guard !changes.isEmpty else { return .arrow }
        var low = 0, high = changes.count - 1, found = -1
        while low <= high {
            let mid = (low + high) / 2
            if changes[mid].t <= t { found = mid; low = mid + 1 } else { high = mid - 1 }
        }
        return found >= 0 ? changes[found].shape : .arrow
    }
}
