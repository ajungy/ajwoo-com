import Foundation
import AVFoundation
import Speech

/// Transcription through `SpeechAnalyzer`, macOS 26's replacement for
/// `SFSpeechRecognizer`.
///
/// `SFSpeechRecognizer` runs a file at close to real time — a five-minute take
/// takes minutes — because it was built for live dictation and streams the audio
/// past the model at the rate it was recorded. `SpeechAnalyzer` is built for
/// files: it reads as fast as the model can consume and typically finishes a
/// several-minute recording in a few seconds.
///
/// Still entirely on-device. The one caveat worth being explicit about: the
/// language model is a system asset, and if it isn't installed yet macOS fetches
/// it once, on our behalf, through `AssetInventory`. That's the same asset
/// `SFSpeechRecognizer`'s on-device mode already required, so it isn't new
/// exposure — but it is the only point in this app where a network request can
/// happen, and it's the OS making it, not us. Nothing about the recording is
/// sent anywhere.
@available(macOS 26.0, *)
enum FastTranscriber {

    static var isAvailable: Bool { SpeechTranscriber.isAvailable }

    static func transcribe(url: URL,
                           progress: @escaping @Sendable (Double) -> Void) async throws -> Transcript {

        let asset = AVURLAsset(url: url)
        let duration = (try? await asset.load(.duration))?.seconds ?? 0

        var chosen = await SpeechTranscriber.supportedLocale(equivalentTo: Locale.current)
        if chosen == nil { chosen = await SpeechTranscriber.supportedLocales.first }
        guard let locale = chosen else {
            throw Transcriber.TranscriptionError.recognitionFailed(
                "no supported locale for \(Locale.current.identifier)")
        }

        // Word timings are the whole point — subtitles, filler cuts and the
        // timeline's speech row all key off them. Volatile (partial) results are
        // left off: for a file they only cause the same span to be re-reported.
        let transcriber = SpeechTranscriber(locale: locale,
                                            transcriptionOptions: [],
                                            reportingOptions: [],
                                            attributeOptions: [.audioTimeRange])

        if let request = try await AssetInventory.assetInstallationRequest(supporting: [transcriber]) {
            try await request.downloadAndInstall()
        }

        let analyzer = SpeechAnalyzer(modules: [transcriber])
        let file = try AVAudioFile(forReading: url)

        // The results sequence has to be drained while the analyser runs, or it
        // back-pressures and the analysis stalls.
        let collector = Task { () -> [Transcript.Word] in
            var words: [Transcript.Word] = []
            for try await result in transcriber.results {
                words.append(contentsOf: Self.words(in: result.text))
                if duration > 0 {
                    progress(min(0.99, result.range.end.seconds / duration))
                }
            }
            return words
        }

        do {
            if let last = try await analyzer.analyzeSequence(from: file) {
                try await analyzer.finalizeAndFinish(through: last)
            } else {
                try await analyzer.finalizeAndFinishThroughEndOfInput()
            }
        } catch {
            collector.cancel()
            throw Transcriber.TranscriptionError.recognitionFailed(error.localizedDescription)
        }

        let words = try await collector.value
        progress(1)
        return Transcript(words: words.sorted { $0.start < $1.start },
                          locale: locale.identifier(.bcp47),
                          engine: "SpeechAnalyzer")
    }

    /// Splits a result into words.
    ///
    /// Runs carry `.audioTimeRange`, but a run is not reliably one word — the
    /// recogniser groups whatever shares a timing. Where a run holds several
    /// words their span is divided by character count, which is close enough for
    /// a caption boundary and for spotting an "um".
    private static func words(in text: AttributedString) -> [Transcript.Word] {
        var result: [Transcript.Word] = []

        for run in text.runs {
            guard let range = run.audioTimeRange else { continue }
            let piece = String(text[run.range].characters)
            let tokens = piece.split(whereSeparator: \.isWhitespace).map(String.init)
            guard !tokens.isEmpty else { continue }

            let start = range.start.seconds
            let span = max(0.01, range.duration.seconds)
            let confidence = run.transcriptionConfidence.map { Double($0) / 100 } ?? 1

            if tokens.count == 1 {
                result.append(Transcript.Word(text: tokens[0], start: start,
                                              duration: span, confidence: confidence))
                continue
            }

            let characters = Double(tokens.reduce(0) { $0 + $1.count })
            var cursor = start
            for token in tokens {
                let share = span * Double(token.count) / max(1, characters)
                result.append(Transcript.Word(text: token, start: cursor,
                                              duration: share, confidence: confidence))
                cursor += share
            }
        }
        return result
    }
}
