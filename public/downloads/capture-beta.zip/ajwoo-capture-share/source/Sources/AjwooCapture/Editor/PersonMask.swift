import CoreImage
import Vision

/// Cuts the background out of the camera picture, leaving just the person.
///
/// Uses Vision's on-device person segmentation. Nothing leaves the machine and
/// no model has to be downloaded or licensed — it ships with macOS, which is the
/// only reason this feature is possible under the project's constraints.
///
/// The request is run at `.balanced` quality on the already-downscaled bubble
/// rather than the full camera frame. Segmenting a 1080p frame to draw it 240 px
/// wide costs roughly ten times as much for no visible difference.
///
/// Vision returns a mask at its own resolution, so the result is scaled back to
/// the image it came from and softened by a pixel — a hard mask edge on a human
/// outline reads as a cheap cutout.
final class PersonMask {

    private let request = VNGeneratePersonSegmentationRequest()

    /// Segmenting is the single most expensive thing in a frame, and a person
    /// does not change shape much in 1/60 s. The last mask is reused when the
    /// request fails, so a dropped frame doesn't flash the background back in.
    private var lastMask: CIImage?

    init() {
        request.qualityLevel = .balanced
        request.outputPixelFormat = kCVPixelFormatType_OneComponent8
    }

    /// Returns `image` with everything that isn't a person made transparent, or
    /// `nil` if no mask could be produced and none was cached.
    func cutout(_ image: CIImage) -> CIImage? {
        let extent = image.extent
        guard extent.width > 8, extent.height > 8 else { return nil }

        var mask = lastMask
        let handler = VNImageRequestHandler(ciImage: image, options: [:])
        if (try? handler.perform([request])) != nil,
           let buffer = request.results?.first?.pixelBuffer {
            let raw = CIImage(cvPixelBuffer: buffer)
            let scale = CGAffineTransform(scaleX: extent.width / raw.extent.width,
                                          y: extent.height / raw.extent.height)
            mask = raw
                .transformed(by: scale)
                .transformed(by: CGAffineTransform(translationX: extent.minX, y: extent.minY))
                .applyingGaussianBlur(sigma: max(0.6, extent.height / 240))
                .cropped(to: extent)
            lastMask = mask
        }

        guard let mask else { return nil }

        return image.applyingFilter("CIBlendWithMask", parameters: [
            kCIInputBackgroundImageKey: CIImage(color: .clear).cropped(to: extent),
            kCIInputMaskImageKey: mask,
        ])
    }
}
