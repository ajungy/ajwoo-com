import Foundation
import CoreImage
import AppKit

/// Resolves a background photo — bundled preset or user upload — to an image,
/// and copies a newly-picked file into the app's own storage.
///
/// Two sources, one interface: a **bundled** image ships inside the app itself
/// (`Resources/Backgrounds`, copied into the `.app` by `scripts/make_app.sh`)
/// and is looked up by name; a **custom** one is a file the user picked, copied
/// once into `AppInfo.backgroundsDirectory` under a generated name so the
/// background keeps working even if the original file is moved, renamed, or
/// deleted. `ProjectState` only ever stores the filename and which of the two
/// it is — never a raw path, which would break the moment a recording's
/// project file was opened on another Mac.
enum BackgroundImageStore {

    /// Copies `sourceURL` into the backgrounds folder under a fresh name and
    /// returns that name, or `nil` if the file couldn't be read or copied.
    static func importImage(from sourceURL: URL) -> String? {
        guard (try? sourceURL.checkResourceIsReachable()) == true else { return nil }
        do {
            try AppInfo.ensureBackgroundsDirectory()
        } catch {
            return nil
        }

        let ext = sourceURL.pathExtension.isEmpty ? "jpg" : sourceURL.pathExtension
        let filename = "\(UUID().uuidString).\(ext)"
        let destination = AppInfo.backgroundsDirectory.appendingPathComponent(filename)

        do {
            try FileManager.default.copyItem(at: sourceURL, to: destination)
            return filename
        } catch {
            return nil
        }
    }

    /// Deletes a previously-imported custom image. Never call this for a
    /// bundled preset — there's nothing on disk to remove, and nothing should
    /// try.
    static func deleteCustomImage(filename: String) {
        try? FileManager.default.removeItem(at: AppInfo.backgroundsDirectory.appendingPathComponent(filename))
    }

    static func url(filename: String, bundled: Bool) -> URL? {
        guard bundled else {
            return AppInfo.backgroundsDirectory.appendingPathComponent(filename)
        }
        // `Bundle.main` resolves to the real `Contents/Resources` only once
        // this is running as the assembled `.app` — under `swift run` there's
        // no such folder, and every bundled preset just falls back to its
        // flat tint color. That's fine: it's the same graceful fallback a
        // corrupted or missing custom image gets below.
        let name = (filename as NSString).deletingPathExtension
        let ext = (filename as NSString).pathExtension
        return Bundle.main.url(forResource: name, withExtension: ext, subdirectory: "Backgrounds")
    }

    static func nsImage(filename: String, bundled: Bool) -> NSImage? {
        guard let url = url(filename: filename, bundled: bundled) else { return nil }
        return NSImage(contentsOf: url)
    }

    static func ciImage(filename: String, bundled: Bool) -> CIImage? {
        guard let url = url(filename: filename, bundled: bundled) else { return nil }
        return CIImage(contentsOf: url)
    }
}
