import Foundation

/// All motion in the app eases. Nothing moves linearly — linear zoom ramps and
/// linear cursor scaling read as mechanical and are the main thing that makes
/// screen-recording output look cheap.
enum Easing {
    /// The house default: smooth in, smooth out.
    static func inOutCubic(_ t: Double) -> Double {
        let p = min(1, max(0, t))
        return p < 0.5
            ? 4 * p * p * p
            : 1 - pow(-2 * p + 2, 3) / 2
    }

    static func outCubic(_ t: Double) -> Double {
        let p = min(1, max(0, t))
        return 1 - pow(1 - p, 3)
    }

    static func lerp(_ a: Double, _ b: Double, _ t: Double) -> Double {
        a + (b - a) * t
    }
}
