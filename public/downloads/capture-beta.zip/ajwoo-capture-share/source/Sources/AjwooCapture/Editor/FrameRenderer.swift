import Foundation
import CoreImage
import CoreImage.CIFilterBuiltins
import CoreGraphics
import AppKit

/// The single compositing pipeline: `(sourceFrame, time, projectState) -> frame`.
///
/// **The preview and the exporter both call this and nothing else.** There is
/// deliberately no second renderer — if preview and export can diverge, they
/// eventually will, and you find out after a twenty-minute export.
///
/// # Order of operations (this order is the feature)
/// 1. Apply the user's crop → the *effective frame*. Everything downstream sizes
///    against this, not the raw capture.
/// 2. Evaluate zoom for `time` → a crop rect **in source pixels**, inside the
///    effective frame.
/// 3. Crop the master and scale that crop to the output. Zoom is therefore a
///    crop of native pixels, never an upscale of something already downscaled.
/// 4. Optional background: inset the content, round its corners, drop a shadow.
/// 5. **Draw the cursor — after the crop, in output space.** Its size comes from
///    the output height alone, so it stays visually constant through a 3x zoom
///    and identical between a 1080p and a 4K export. Drawing it before the crop
///    would make it balloon as you zoom in, which is the classic version of this
///    bug.
/// 6. Camera bubble.
/// 7. Subtitles last, so nothing can cover them.
extension CGRect {
    /// Snapped to whole pixels, clamped back inside `bounds` — see the
    /// comment where `cropAbs` is built in `FrameRenderer.render(...)` for
    /// why this exists. Rounding the two edges independently (rather than,
    /// say, rounding the origin and keeping the size) is deliberate: it
    /// keeps whichever edge the user is actually dragging pinned under the
    /// pointer instead of the whole rect drifting by up to a pixel as its
    /// size gets rounded too.
    func integralized(in bounds: CGRect) -> CGRect {
        let minX = self.minX.rounded()
        let minY = self.minY.rounded()
        let maxX = self.maxX.rounded()
        let maxY = self.maxY.rounded()
        let rect = CGRect(x: minX, y: minY, width: max(1, maxX - minX), height: max(1, maxY - minY))
        return rect.intersection(bounds)
    }
}

final class FrameRenderer {

    /// Cursor glyph height as a fraction of output height, at 1x multiplier.
    private static let cursorHeightFraction: CGFloat = 0.045
    /// Click pulse at speed 1.0. Deliberately shallow — a big shrink reads as a
    /// glitch rather than a press. `clickEmphasis` scales it if you want more.
    private static let pulseDuration: Double = 0.22
    private static let pulseDepth: Double = 0.11
    /// Ripple ring lifetime at speed 1.0.
    private static let rippleDuration: Double = 0.45

    private var maskCache: [String: CIImage] = [:]
    private var subtitleCache: [String: CIImage] = [:]
    private lazy var personMask = PersonMask()

    // MARK: - Entry point

    func render(screen: CIImage,
                camera: CIImage?,
                time: Double,
                snapshot: RenderContext.Snapshot,
                outputSize: CGSize) -> CIImage {

        let project = snapshot.project
        let sourceExtent = screen.extent
        let sourceSize = sourceExtent.size
        let outputRect = CGRect(origin: .zero, size: outputSize)

        guard sourceSize.width > 0, sourceSize.height > 0 else {
            return CIImage(color: .black).cropped(to: outputRect)
        }

        // --- 1. user crop -> the effective frame ---
        let baseRect = Self.effectiveFrame(sourceExtent: sourceExtent, crop: project.crop)

        // --- 2. zoom -> crop rect in source pixels (Core Image space) ---
        let zoom = ZoomTrack.state(at: time, segments: project.zoomSegments) { t in
            snapshot.followPath.position(at: t)
        }
        // Snapped to whole source pixels — a crop/zoom rect is built entirely
        // from normalized 0...1 doubles (a dragged rectangle, a focus point),
        // so its edges land at arbitrary sub-pixel positions. Cropping there
        // and then Lanczos-scaling the result (below) blends across that
        // fractional edge, which is exactly the "soft, sometimes shows a
        // sliver of what's outside the crop" look — the scale kernel spans
        // several pixels, and at a mid-pixel boundary it has real data on
        // both sides to blend. Rounding first removes the fractional edge
        // entirely, at a cost of at most half a pixel of position error.
        let cropAbs = ZoomTrack.cropRect(level: zoom.level, focus: zoom.focus,
                                         base: baseRect, sourceExtent: sourceExtent)
            .integralized(in: sourceExtent)

        // --- 3. where the screen content lands in the output ---
        let contentRect = contentRect(in: outputSize,
                                      sourceAspect: cropAbs.width / cropAbs.height,
                                      project: project)
        let scale = contentRect.width / cropAbs.width

        var content = screen
            .cropped(to: cropAbs)
            .transformed(by: CGAffineTransform(translationX: -cropAbs.minX, y: -cropAbs.minY))
        content = lanczos(content, scale: scale)
        content = content.cropped(to: CGRect(origin: .zero, size: contentRect.size))

        // --- 4. background / rounded corners / shadow ---
        var output: CIImage
        if project.background.enabled {
            let radius = min(contentRect.width, contentRect.height) * project.background.cornerRadius
            let mask = roundedMask(size: contentRect.size, radius: radius)
            content = content.applyingFilter("CIBlendWithAlphaMask", parameters: [
                kCIInputBackgroundImageKey: CIImage(color: .clear).cropped(to: CGRect(origin: .zero, size: contentRect.size)),
                kCIInputMaskImageKey: mask,
            ])
            content = content.transformed(by: CGAffineTransform(translationX: contentRect.minX, y: contentRect.minY))

            output = backgroundImage(project.background, outputRect: outputRect)
            if project.background.shadow {
                let blur = min(contentRect.width, contentRect.height) * 0.03
                let shadow = mask
                    .applyingFilter("CIColorMatrix", parameters: [
                        "inputRVector": CIVector(x: 0, y: 0, z: 0, w: 0),
                        "inputGVector": CIVector(x: 0, y: 0, z: 0, w: 0),
                        "inputBVector": CIVector(x: 0, y: 0, z: 0, w: 0),
                        "inputAVector": CIVector(x: 0, y: 0, z: 0, w: 0.55),
                    ])
                    .transformed(by: CGAffineTransform(translationX: contentRect.minX,
                                                       y: contentRect.minY - blur * 0.6))
                    .applyingFilter("CIGaussianBlur", parameters: [kCIInputRadiusKey: blur])
                output = shadow.composited(over: output)
            }
            output = content.composited(over: output)
        } else {
            content = content.transformed(by: CGAffineTransform(translationX: contentRect.minX,
                                                                y: contentRect.minY))
            // Always resolve onto something opaque — the encoder wants opaque frames.
            output = content.composited(over: CIImage(color: .black).cropped(to: outputRect))
        }

        // --- 5. cursor, in OUTPUT space, after the crop ---
        output = drawCursor(over: output,
                            time: time,
                            snapshot: snapshot,
                            sourceExtent: sourceExtent,
                            cropAbs: cropAbs,
                            contentRect: contentRect,
                            scale: scale,
                            outputSize: outputSize)

        // --- 6. camera bubble ---
        if project.camera.enabled, let camera {
            output = drawCamera(camera, over: output, settings: project.camera, outputSize: outputSize)
        }

        // --- 7. subtitles, last, so nothing covers them ---
        if project.subtitles.enabled, let cue = snapshot.subtitles.cue(at: time) {
            output = drawSubtitle(cue, over: output, settings: project.subtitles, outputSize: outputSize)
        }

        return output.cropped(to: outputRect)
    }

    // MARK: - Layout

    /// The user's crop, resolved into an absolute rect in Core Image space.
    ///
    /// `Crop` is stored top-left origin (the `events.json` convention) so it can
    /// be edited against what you see; Core Image is bottom-left, hence the flip
    /// on `y`.
    static func effectiveFrame(sourceExtent: CGRect, crop: ProjectState.Crop) -> CGRect {
        guard crop.enabled else { return sourceExtent }
        let rect = CGRect(
            x: sourceExtent.minX + crop.x * sourceExtent.width,
            y: sourceExtent.minY + (1 - crop.y - crop.height) * sourceExtent.height,
            width: crop.width * sourceExtent.width,
            height: crop.height * sourceExtent.height
        ).intersection(sourceExtent)
        return rect.width > 8 && rect.height > 8 ? rect : sourceExtent
    }

    /// Where the screen content sits in the output.
    ///
    /// With the background off this is the whole frame: export sizes are derived
    /// from the source aspect ratio (see `ExportSettings`), so there is never a
    /// letterbox or a silent crop. With the background on, the content is inset
    /// and re-fitted to preserve aspect.
    private func contentRect(in outputSize: CGSize, sourceAspect: CGFloat, project: ProjectState) -> CGRect {
        guard project.background.enabled else {
            return CGRect(origin: .zero, size: outputSize)
        }
        let pad = min(outputSize.width, outputSize.height) * project.background.padding
        let available = CGRect(origin: .zero, size: outputSize).insetBy(dx: pad, dy: pad)

        var width = available.width
        var height = width / max(0.0001, sourceAspect)
        if height > available.height {
            height = available.height
            width = height * sourceAspect
        }
        return CGRect(x: available.midX - width / 2, y: available.midY - height / 2,
                      width: width, height: height)
    }

    // MARK: - Cursor

    private func drawCursor(over base: CIImage,
                            time: Double,
                            snapshot: RenderContext.Snapshot,
                            sourceExtent: CGRect,
                            cropAbs: CGRect,
                            contentRect: CGRect,
                            scale: CGFloat,
                            outputSize: CGSize) -> CIImage {

        let style = snapshot.project.cursor
        guard style.kind != .hidden else { return base }
        guard let normalized = snapshot.cursorPath.position(at: time) else { return base }

        // events.json is top-left origin; Core Image is bottom-left.
        let sourcePoint = CGPoint(
            x: sourceExtent.minX + normalized.x * sourceExtent.width,
            y: sourceExtent.minY + (1 - normalized.y) * sourceExtent.height
        )

        // Let it travel a little past the crop before disappearing, so it slides
        // off the edge instead of vanishing mid-frame.
        let tolerance = cropAbs.insetBy(dx: -cropAbs.width * 0.08, dy: -cropAbs.height * 0.08)
        guard tolerance.contains(sourcePoint) else { return base }

        // Idle fade: 1 while moving, ramping to 0 after sitting still for
        // `hideAfterIdleSeconds`, back to 1 over the same window once it moves
        // again. Skip the rest of the draw entirely once it's fully hidden.
        let idleFade = snapshot.idle.visibility(at: time, hideAfter: style.hideAfterIdleSeconds)
        guard idleFade > 0.001 else { return base }

        let point = CGPoint(
            x: contentRect.minX + (sourcePoint.x - cropAbs.minX) * scale,
            y: contentRect.minY + (sourcePoint.y - cropAbs.minY) * scale
        )

        // Size depends only on the output height: constant on screen at any zoom
        // level, and identical across export resolutions.
        let baseHeight = outputSize.height * Self.cursorHeightFraction * CGFloat(style.sizeMultiplier)
        let sinceClick = snapshot.clicks.timeSinceLastClick(at: time)
        // One knob scales how big the feedback is, another how fast it plays.
        let emphasis = min(2.0, max(0.5, style.clickEmphasis))
        let speed = min(3.0, max(0.4, style.clickSpeed))
        let pulseDuration = Self.pulseDuration / speed
        let rippleDuration = Self.rippleDuration / speed

        var result = base

        // Ripple sits under the cursor.
        if style.clickRipple, let dt = sinceClick, dt >= 0, dt < rippleDuration {
            let progress = Easing.outCubic(dt / rippleDuration)
            let diameter = baseHeight * CGFloat(0.7 + 2.4 * emphasis * progress)
            let alpha = (1 - progress) * 0.5 * min(1.0, emphasis) * idleFade
            result = place(CursorSprites.ring, glyphSize: diameter, at: point, alpha: alpha)
                .composited(over: result)
        }

        // Pulse: shrink and spring back, eased both ways — the visual echo of
        // pressing a physical button, and what makes a click legible in a
        // silent recording.
        var pulse = 1.0
        if style.clickPulse, let dt = sinceClick, dt >= 0, dt < pulseDuration {
            let p = dt / pulseDuration
            let shape = p < 0.5 ? Easing.inOutCubic(p * 2) : Easing.inOutCubic((1 - p) * 2)
            pulse = 1 - min(0.45, Self.pulseDepth * emphasis) * shape
        }

        switch style.kind {
        case .hidden:
            break
        case .arrow:
            // Draw whatever the system was actually showing — the pointing hand
            // over a link, the I-beam over text, a resize bar on a divider, the
            // grab hands while dragging a canvas. An arrow throughout is quietly
            // wrong about what the viewer is watching happen.
            let sprite = style.matchSystemShape
                ? CursorSprites.system(snapshot.pointerShapes.shape(at: time),
                                       tone: style.arrowTone,
                                       shadow: style.shadow)
                    ?? CursorSprites.arrow(style.arrowTone, shadow: style.shadow)
                : CursorSprites.arrow(style.arrowTone, shadow: style.shadow)
            result = place(sprite, glyphSize: baseHeight * pulse, at: point, alpha: idleFade)
                .composited(over: result)
        case .dot:
            result = place(CursorSprites.dot(shadow: style.shadow),
                           glyphSize: baseHeight * pulse,
                           at: point,
                           alpha: style.dotOpacity * idleFade,
                           tint: (style.dotRed, style.dotGreen, style.dotBlue))
                .composited(over: result)
        }

        return result
    }

    /// Scales a sprite so its glyph is `glyphSize` tall, puts its hotspot on
    /// `point`, and applies tint/alpha.
    private func place(_ sprite: CursorSprites.Sprite,
                       glyphSize: CGFloat,
                       at point: CGPoint,
                       alpha: Double,
                       tint: (r: Double, g: Double, b: Double)? = nil) -> CIImage {
        let s = glyphSize / sprite.glyphHeight
        guard s > 0, s.isFinite else { return CIImage.empty() }

        var image = sprite.image.transformed(by: CGAffineTransform(scaleX: s, y: s))
        let hotspot = CGPoint(x: sprite.hotspot.x * s, y: sprite.hotspot.y * s)
        image = image.transformed(by: CGAffineTransform(translationX: point.x - hotspot.x,
                                                        y: point.y - hotspot.y))

        // Sprites are premultiplied, so a correct fade scales all four channels
        // by the same factor. Scaling only alpha would leave bright fringes.
        let a = min(1, max(0, alpha))
        guard a < 1 || tint != nil else { return image }
        let (r, g, b) = tint ?? (1, 1, 1)
        return image.applyingFilter("CIColorMatrix", parameters: [
            "inputRVector": CIVector(x: r * a, y: 0, z: 0, w: 0),
            "inputGVector": CIVector(x: 0, y: g * a, z: 0, w: 0),
            "inputBVector": CIVector(x: 0, y: 0, z: b * a, w: 0),
            "inputAVector": CIVector(x: 0, y: 0, z: 0, w: a),
        ])
    }

    // MARK: - Camera bubble

    /// Circle, rounded rectangle, rectangle or star.
    ///
    /// All four go through one alpha mask drawn with Core Graphics rather than
    /// per-shape Core Image filters: a star has no filter equivalent, and one
    /// code path means the rim and shadow work identically for every shape
    /// (they're the same mask, grown and blurred).
    private func drawCamera(_ camera: CIImage,
                            over base: CIImage,
                            settings: ProjectState.CameraOverlay,
                            outputSize: CGSize) -> CIImage {
        let height = outputSize.height * CGFloat(settings.size)
        let width = height * CGFloat(settings.effectiveAspect)
        guard height > 4, width > 4 else { return base }

        // Centre-crop the full-frame camera to the bubble's aspect, then scale.
        let extent = camera.extent
        let targetAspect = width / height
        var sourceWidth = extent.width
        var sourceHeight = sourceWidth / targetAspect
        if sourceHeight > extent.height {
            sourceHeight = extent.height
            sourceWidth = sourceHeight * targetAspect
        }
        let sourceRect = CGRect(x: extent.midX - sourceWidth / 2,
                                y: extent.midY - sourceHeight / 2,
                                width: sourceWidth, height: sourceHeight)

        var bubble = camera
            .cropped(to: sourceRect)
            .transformed(by: CGAffineTransform(translationX: -sourceRect.minX, y: -sourceRect.minY))
        bubble = lanczos(bubble, scale: width / sourceWidth)
        bubble = bubble.cropped(to: CGRect(x: 0, y: 0, width: width, height: height))

        // Grade after scaling: the same look for a fraction of the pixels.
        bubble = applyCameraFilter(settings.filter, to: bubble, bubbleHeight: height)

        // Segmentation also runs on the scaled bubble, for the same reason.
        // When it succeeds the outline comes from the person, so none of the
        // geometric shape, rim or shape-shadow work below applies — the cutout
        // composites straight onto the frame.
        //
        // When it fails (nobody in shot, or Vision declines) the bubble falls
        // through to the plain rectangle path rather than vanishing.
        if settings.shape.isSegmented, let cut = personMask.cutout(bubble) {
            let center = CGPoint(x: CGFloat(settings.centerX) * outputSize.width,
                                 y: (1 - CGFloat(settings.centerY)) * outputSize.height)
            var placed = cut.transformed(by: CGAffineTransform(
                translationX: (center.x - width / 2).rounded(),
                y: (center.y - height / 2).rounded()))

            if settings.shadow {
                // Grown from the cutout's own alpha, so it traces the person.
                let blur = min(width, height) * 0.05
                let shadow = placed
                    .applyingFilter("CIColorMatrix", parameters: [
                        "inputRVector": CIVector(x: 0, y: 0, z: 0, w: 0),
                        "inputGVector": CIVector(x: 0, y: 0, z: 0, w: 0),
                        "inputBVector": CIVector(x: 0, y: 0, z: 0, w: 0),
                        "inputAVector": CIVector(x: 0, y: 0, z: 0, w: 0.45),
                    ])
                    .transformed(by: CGAffineTransform(translationX: 0, y: -blur * 0.6))
                    .applyingFilter("CIGaussianBlur", parameters: [kCIInputRadiusKey: blur])
                placed = placed.composited(over: shadow)
            }
            return placed.composited(over: base)
        }

        // Position is stored top-left normalized (what the drag handle in the
        // editor manipulates); Core Image is bottom-left.
        let center = CGPoint(x: CGFloat(settings.centerX) * outputSize.width,
                             y: (1 - CGFloat(settings.centerY)) * outputSize.height)

        let bubbleRect = CGRect(x: center.x - width / 2, y: center.y - height / 2,
                                width: width, height: height)
        bubble = bubble.transformed(by: CGAffineTransform(translationX: bubbleRect.minX,
                                                          y: bubbleRect.minY))

        let radius = min(width, height) * CGFloat(settings.cornerRadius)
        // `.cutout` only reaches here when segmentation failed; a rectangle is
        // the honest fallback.
        let shape = settings.shape.isSegmented ? .rectangle : settings.shape
        let mask = shapeMask(shape, size: bubbleRect.size, cornerRadius: radius)
            .transformed(by: CGAffineTransform(translationX: bubbleRect.minX, y: bubbleRect.minY))

        bubble = bubble.applyingFilter("CIBlendWithAlphaMask", parameters: [
            kCIInputBackgroundImageKey: CIImage(color: .clear).cropped(to: bubbleRect),
            kCIInputMaskImageKey: mask,
        ]).cropped(to: bubbleRect)

        // Rim and shadow are the same mask grown by a border width, so they
        // trace the shape exactly — points and all, for the star.
        let border = max(1, min(width, height) * 0.014)
        let rimRect = bubbleRect.insetBy(dx: -border, dy: -border)
        let rimMask = shapeMask(shape,
                                size: rimRect.size,
                                cornerRadius: radius + border)
            .transformed(by: CGAffineTransform(translationX: rimRect.minX, y: rimRect.minY))

        var result = base
        if settings.shadow {
            let blur = min(width, height) * 0.06
            let shadow = rimMask
                .applyingFilter("CIColorMatrix", parameters: [
                    "inputRVector": CIVector(x: 0, y: 0, z: 0, w: 0),
                    "inputGVector": CIVector(x: 0, y: 0, z: 0, w: 0),
                    "inputBVector": CIVector(x: 0, y: 0, z: 0, w: 0),
                    "inputAVector": CIVector(x: 0, y: 0, z: 0, w: 0.5),
                ])
                .transformed(by: CGAffineTransform(translationX: 0, y: -blur * 0.5))
                .applyingFilter("CIGaussianBlur", parameters: [kCIInputRadiusKey: blur])
            result = shadow.composited(over: result)
        }

        let rim = rimMask.applyingFilter("CIColorMatrix", parameters: [
            "inputRVector": CIVector(x: 0.85, y: 0, z: 0, w: 0),
            "inputGVector": CIVector(x: 0, y: 0.85, z: 0, w: 0),
            "inputBVector": CIVector(x: 0, y: 0, z: 0.85, w: 0),
            "inputAVector": CIVector(x: 0, y: 0, z: 0, w: 0.85),
        ])
        result = rim.composited(over: result)

        return bubble.composited(over: result)
    }

    // MARK: - Subtitles

    /// Draws a caption as a bitmap and composites it.
    ///
    /// Text is rendered with Core Text into a CGImage rather than assembled from
    /// Core Image primitives — layout, wrapping and font metrics are solved
    /// problems in AppKit and nowhere near solved in CI. The result is cached on
    /// the cue's text plus every style input, so a caption is rasterised once and
    /// then reused for every frame it's on screen.
    private func drawSubtitle(_ cue: SubtitleCue,
                              over base: CIImage,
                              settings: ProjectState.Subtitles,
                              outputSize: CGSize) -> CIImage {
        let blockWidth = outputSize.width * CGFloat(min(0.95, max(0.2, settings.width)))
        let pixelSize = outputSize.height * CGFloat(min(0.12, max(0.015, settings.fontSize)))
        let text = settings.uppercase ? cue.text.uppercased() : cue.text

        let key = [
            text, settings.font.rawValue, settings.backdrop.rawValue,
            String(Int(pixelSize)), String(Int(blockWidth)), settings.uppercase ? "u" : "l",
            String(Int(settings.shadowStrength * 100)), String(Int(settings.boxOpacity * 100)),
        ].joined(separator: "|")

        let image: CIImage
        if let cached = subtitleCache[key] {
            image = cached
        } else {
            guard let rendered = Self.renderSubtitle(text: text,
                                                     font: settings.nsFont(pixelSize: pixelSize),
                                                     backdrop: settings.backdrop,
                                                     shadowStrength: settings.shadowStrength,
                                                     boxOpacity: settings.boxOpacity,
                                                     maxWidth: blockWidth) else { return base }
            // Bounded: a long recording would otherwise cache every cue it ever
            // scrubbed past.
            if subtitleCache.count > 120 { subtitleCache.removeAll(keepingCapacity: true) }
            subtitleCache[key] = rendered
            image = rendered
        }

        let extent = image.extent
        let centre = CGPoint(x: CGFloat(settings.centerX) * outputSize.width,
                             y: (1 - CGFloat(settings.centerY)) * outputSize.height)
        return image
            .transformed(by: CGAffineTransform(translationX: (centre.x - extent.width / 2).rounded(),
                                               y: (centre.y - extent.height / 2).rounded()))
            .composited(over: base)
    }

    /// Core Image composites in linear light, not the gamma-encoded space a
    /// display (and every design tool's opacity slider) works in. Blending a
    /// black fill "over" something at alpha 0.5 in linear light only cuts the
    /// *displayed* brightness by roughly 27%, not 50% — physically correct
    /// for a translucent gel, but nothing like what "50% opacity" means in
    /// Figma or Photoshop, where the blend happens directly on the encoded
    /// pixel values. This is the inverse of the sRGB transfer curve (using the
    /// standard 2.2 approximation): feeding it the boosted alpha makes the
    /// *result*, after CI's linear blend, land where a straight gamma-space
    /// blend at the slider's own value would have.
    private static func gammaBoostedAlpha(_ opacity: Double) -> CGFloat {
        let clamped = min(1, max(0, opacity))
        return CGFloat(1 - pow(1 - clamped, 2.2))
    }

    /// Lays the caption out with Core Text and paints it, plus its backdrop.
    private static func renderSubtitle(text: String,
                                       font: NSFont,
                                       backdrop: ProjectState.Subtitles.Backdrop,
                                       shadowStrength: Double,
                                       boxOpacity: Double,
                                       maxWidth: CGFloat) -> CIImage? {
        let paragraph = NSMutableParagraphStyle()
        paragraph.alignment = .center
        paragraph.lineBreakMode = .byWordWrapping
        paragraph.lineSpacing = font.pointSize * 0.14

        var attributes: [NSAttributedString.Key: Any] = [
            .font: font,
            .foregroundColor: NSColor.white,
            .paragraphStyle: paragraph,
        ]
        // The shadow is no longer tied to the `.shadow` backdrop: a shadow under
        // a semi-transparent box is what keeps captions readable when the box is
        // turned down, and at strength 0 it costs nothing.
        if shadowStrength > 0.001 {
            let shadow = NSShadow()
            shadow.shadowColor = NSColor.black.withAlphaComponent(gammaBoostedAlpha(shadowStrength))
            // Blur scales with strength too, so the slider reads as one control
            // rather than only changing the darkness — but capped well short of
            // the old ceiling. A wide blur spreads the same ink over more
            // pixels, which dilutes exactly the peak darkness a "100%" shadow
            // is supposed to deliver; a tighter spread stays legible as an
            // actual dark shadow instead of a grey haze.
            shadow.shadowBlurRadius = font.pointSize * (0.06 + 0.12 * CGFloat(shadowStrength))
            shadow.shadowOffset = NSSize(width: 0, height: -font.pointSize * 0.06 * CGFloat(shadowStrength))
            attributes[.shadow] = shadow
        }

        let attributed = NSAttributedString(string: text, attributes: attributes)
        // Padding has to clear the shadow blur as well as the box, or a strong
        // shadow gets clipped at the edge of the bitmap.
        let blurRoom = font.pointSize * 0.34 * CGFloat(shadowStrength)
        let padding = backdrop == .box
            ? NSSize(width: max(font.pointSize * 0.7, blurRoom), height: max(font.pointSize * 0.42, blurRoom))
            : NSSize(width: max(font.pointSize * 0.45, blurRoom), height: max(font.pointSize * 0.3, blurRoom))

        let textWidth = maxWidth - padding.width * 2
        let bounds = attributed.boundingRect(with: NSSize(width: textWidth, height: .greatestFiniteMagnitude),
                                             options: [.usesLineFragmentOrigin, .usesFontLeading])
        let canvas = CGSize(width: ceil(bounds.width) + padding.width * 2,
                            height: ceil(bounds.height) + padding.height * 2)
        guard canvas.width > 1, canvas.height > 1 else { return nil }

        let width = Int(canvas.width.rounded())
        let height = Int(canvas.height.rounded())
        guard let ctx = CGContext(data: nil, width: width, height: height,
                                  bitsPerComponent: 8, bytesPerRow: 0,
                                  space: CGColorSpace(name: CGColorSpace.sRGB) ?? CGColorSpaceCreateDeviceRGB(),
                                  bitmapInfo: CGImageAlphaInfo.premultipliedLast.rawValue) else { return nil }

        let graphics = NSGraphicsContext(cgContext: ctx, flipped: false)
        NSGraphicsContext.saveGraphicsState()
        NSGraphicsContext.current = graphics

        if backdrop == .box, boxOpacity > 0.001 {
            let radius = min(canvas.height / 2, font.pointSize * 0.3)
            let box = NSBezierPath(roundedRect: NSRect(origin: .zero, size: canvas),
                                   xRadius: radius, yRadius: radius)
            NSColor.black.withAlphaComponent(gammaBoostedAlpha(boxOpacity)).setFill()
            box.fill()
        }

        let textRect = NSRect(x: padding.width, y: padding.height,
                              width: ceil(bounds.width), height: ceil(bounds.height))
        // A second pass at high strength, so the shadow builds up density
        // under the blur instead of maxing out as a single soft, half-
        // transparent halo — a blurred edge is inherently partial coverage,
        // and one pass alone can't read as genuinely dark no matter how high
        // its alpha is set.
        if shadowStrength > 0.5 {
            attributed.draw(with: textRect, options: [.usesLineFragmentOrigin, .usesFontLeading])
        }
        attributed.draw(with: textRect, options: [.usesLineFragmentOrigin, .usesFontLeading])

        NSGraphicsContext.restoreGraphicsState()
        return ctx.makeImage().map(CIImage.init(cgImage:))
    }

    /// Webcam colour grading.
    ///
    /// Laptop cameras are flat, grey and slightly cold, so the default preset
    /// lifts brightness a touch, adds a little contrast and saturation, warms the
    /// white point and takes the edge off sensor noise. Nothing exotic — the
    /// combination is what makes a face look intentional rather than surveilled.
    private func applyCameraFilter(_ filter: ProjectState.CameraFilter,
                                   to image: CIImage,
                                   bubbleHeight: CGFloat) -> CIImage {
        guard !filter.isNeutral else { return image }
        let extent = image.extent
        var result = image

        if abs(filter.brightness) > 0.001 || abs(filter.contrast - 1) > 0.001 || abs(filter.saturation - 1) > 0.001 {
            let controls = CIFilter.colorControls()
            controls.inputImage = result
            controls.brightness = Float(filter.brightness)
            controls.contrast = Float(filter.contrast)
            controls.saturation = Float(filter.saturation)
            result = controls.outputImage ?? result
        }

        if abs(filter.warmth) > 1 {
            // Pulling the *target* neutral below 6500 K warms the image.
            let temperature = CIFilter.temperatureAndTint()
            temperature.inputImage = result
            temperature.neutral = CIVector(x: 6500, y: 0)
            temperature.targetNeutral = CIVector(x: 6500 - filter.warmth, y: 0)
            result = temperature.outputImage ?? result
        }

        // Clarity before softness: sharpening a blurred image just undoes the
        // blur, and no preset asks for both anyway.
        if filter.clarity > 0.01 {
            let sharpen = CIFilter.sharpenLuminance()
            sharpen.inputImage = result
            sharpen.sharpness = Float(filter.clarity * 1.6)
            sharpen.radius = Float(max(1.2, bubbleHeight * 0.006))
            result = sharpen.outputImage ?? result
        }

        if filter.softness > 0.01 {
            // Radius scales with the bubble so the look holds at any size, and
            // the result is clamped first or the blur eats the edges.
            let blur = CIFilter.gaussianBlur()
            blur.inputImage = result.clampedToExtent()
            blur.radius = Float(bubbleHeight * 0.012 * filter.softness)
            result = (blur.outputImage ?? result).cropped(to: extent)
        }

        return result.cropped(to: extent)
    }

    /// White-on-transparent alpha mask for a camera bubble shape, cached by
    /// shape + size + radius (all stable across a render pass).
    private func shapeMask(_ shape: ProjectState.CameraOverlay.Shape,
                           size: CGSize,
                           cornerRadius: CGFloat) -> CIImage {
        let key = "\(shape.rawValue)-\(Int(size.width))x\(Int(size.height))-r\(Int(cornerRadius))"
        if let cached = maskCache[key] { return cached }

        let width = max(1, Int(size.width.rounded()))
        let height = max(1, Int(size.height.rounded()))
        guard let ctx = CGContext(data: nil, width: width, height: height,
                                  bitsPerComponent: 8, bytesPerRow: 0,
                                  space: CGColorSpace(name: CGColorSpace.sRGB) ?? CGColorSpaceCreateDeviceRGB(),
                                  bitmapInfo: CGImageAlphaInfo.premultipliedLast.rawValue) else {
            return CIImage(color: .white).cropped(to: CGRect(origin: .zero, size: size))
        }

        let rect = CGRect(x: 0, y: 0, width: CGFloat(width), height: CGFloat(height))
        ctx.setFillColor(NSColor.white.cgColor)
        ctx.setAllowsAntialiasing(true)

        switch shape {
        case .circle:
            ctx.fillEllipse(in: rect)
        // `.cutout` gets its outline from Vision, not from here; it only reaches
        // this function as the fallback when segmentation found nobody.
        case .rectangle, .cutout:
            ctx.fill(rect)
        case .roundedRectangle:
            let radius = min(cornerRadius, min(rect.width, rect.height) / 2)
            ctx.addPath(CGPath(roundedRect: rect, cornerWidth: radius, cornerHeight: radius, transform: nil))
            ctx.fillPath()
        case .star:
            ctx.addPath(Self.starPath(in: rect))
            ctx.fillPath()
        }

        let image = ctx.makeImage().map(CIImage.init(cgImage:))
            ?? CIImage(color: .white).cropped(to: rect)
        maskCache[key] = image
        return image
    }

    /// Five-pointed star inscribed in `rect`, point upwards.
    ///
    /// The mask context is y-up (unlike the cursor sprites, which flip), so the
    /// first vertex needs `+π/2` to land at the top — with `-π/2` the star came
    /// out upside down.
    ///
    /// The inner radius is 0.62 rather than the textbook 0.38: narrow points look
    /// like a sheriff's badge and lose the face at bubble size. A fatter star
    /// keeps more of the picture and reads better small.
    private static func starPath(in rect: CGRect) -> CGPath {
        let path = CGMutablePath()
        let center = CGPoint(x: rect.midX, y: rect.midY)
        let outer = min(rect.width, rect.height) / 2
        let inner = outer * 0.62
        let points = 5

        for index in 0..<(points * 2) {
            let radius = index.isMultiple(of: 2) ? outer : inner
            let angle = .pi / 2 + Double(index) * .pi / Double(points)
            let point = CGPoint(x: center.x + CGFloat(cos(angle)) * radius,
                                y: center.y + CGFloat(sin(angle)) * radius)
            if index == 0 { path.move(to: point) } else { path.addLine(to: point) }
        }
        path.closeSubpath()
        return path
    }

    // MARK: - Helpers

    private func lanczos(_ image: CIImage, scale: CGFloat) -> CIImage {
        guard scale.isFinite, scale > 0, abs(scale - 1) > 0.0005 else { return image }
        let filter = CIFilter.lanczosScaleTransform()
        filter.inputImage = image
        filter.scale = Float(scale)
        filter.aspectRatio = 1
        return filter.outputImage ?? image.transformed(by: CGAffineTransform(scaleX: scale, y: scale))
    }

    private func backgroundImage(_ settings: ProjectState.Background, outputRect: CGRect) -> CIImage {
        if let filename = settings.backgroundImageFilename,
           let image = BackgroundImageStore.ciImage(filename: filename, bundled: settings.backgroundImageIsBundled) {
            return aspectFill(image, in: outputRect)
        }

        let filter = CIFilter.linearGradient()
        filter.point0 = CGPoint(x: 0, y: 0)
        filter.point1 = CGPoint(x: 0, y: outputRect.height)
        filter.color0 = CIColor(red: settings.bottomRed, green: settings.bottomGreen, blue: settings.bottomBlue)
        filter.color1 = CIColor(red: settings.topRed, green: settings.topGreen, blue: settings.topBlue)
        return (filter.outputImage ?? CIImage(color: .black)).cropped(to: outputRect)
    }

    /// Scales and crops so `image` fills `rect` completely with no
    /// letterboxing — the same "cover" behaviour a phone wallpaper or a CSS
    /// `background-size: cover` uses, centred on whichever axis has spare.
    private func aspectFill(_ image: CIImage, in rect: CGRect) -> CIImage {
        let extent = image.extent
        guard extent.width > 0, extent.height > 0 else { return CIImage(color: .black).cropped(to: rect) }

        let scale = max(rect.width / extent.width, rect.height / extent.height)
        let scaled = lanczos(image, scale: scale)
        // `lanczos` scales the whole coordinate space about the origin, so the
        // image's own origin moves too — centring has to work from the
        // *scaled* extent, not the original.
        let scaledExtent = CGRect(x: extent.minX * scale, y: extent.minY * scale,
                                  width: extent.width * scale, height: extent.height * scale)
        let translate = CGAffineTransform(translationX: rect.midX - scaledExtent.midX,
                                          y: rect.midY - scaledExtent.midY)
        return scaled.transformed(by: translate).cropped(to: rect)
    }

    /// Rounded-rect alpha mask, cached: the content rect size is stable across a
    /// render pass, so this is generated once per export rather than per frame.
    private func roundedMask(size: CGSize, radius: CGFloat) -> CIImage {
        let key = "\(Int(size.width))x\(Int(size.height))r\(Int(radius))"
        if let cached = maskCache[key] { return cached }

        let width = max(1, Int(size.width.rounded()))
        let height = max(1, Int(size.height.rounded()))
        guard let ctx = CGContext(data: nil, width: width, height: height,
                                  bitsPerComponent: 8, bytesPerRow: 0,
                                  space: CGColorSpace(name: CGColorSpace.sRGB) ?? CGColorSpaceCreateDeviceRGB(),
                                  bitmapInfo: CGImageAlphaInfo.premultipliedLast.rawValue),
              radius >= 0 else {
            return CIImage(color: .white).cropped(to: CGRect(origin: .zero, size: size))
        }
        ctx.setFillColor(NSColor.white.cgColor)
        let path = CGPath(roundedRect: CGRect(x: 0, y: 0, width: CGFloat(width), height: CGFloat(height)),
                          cornerWidth: radius, cornerHeight: radius, transform: nil)
        ctx.addPath(path)
        ctx.fillPath()

        let image = ctx.makeImage().map(CIImage.init(cgImage:))
            ?? CIImage(color: .white).cropped(to: CGRect(origin: .zero, size: size))
        maskCache[key] = image
        return image
    }
}
