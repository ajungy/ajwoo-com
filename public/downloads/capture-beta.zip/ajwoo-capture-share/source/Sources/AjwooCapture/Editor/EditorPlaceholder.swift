// Phase 4-6 live here: the player, the timeline, zoom segments, and the
// Core Image / Metal compositing pipeline.
//
// The pipeline is the load-bearing piece: one function of
// (sourceFrame, time, ProjectState) -> composited frame, used unchanged by both
// the preview and the exporter. Order of operations is fixed by Phase 6:
// crop-and-scale for zoom first, cursor drawn afterwards in screen space, so
// the cursor keeps a constant on-screen size through a zoom.
