import Foundation
import CoreGraphics
import CoreImage
import AppKit

/// Pre-rendered cursor artwork.
///
/// Drawn once at 512 px and scaled per frame rather than re-drawn each frame:
/// a 4x cursor on a 4K export is ~350 px tall, so 512 px of source keeps it
/// crisp at every size we support, and per-frame cost drops to one transform.
///
/// The arrow is drawn from a vector path rather than lifted from
/// `NSCursor.arrow.image`, for two reasons: the system image is only ~32 px at
/// 2x and turns to mush at a 4x size multiplier, and it changes with the user's
/// accessibility settings, which would make exports non-reproducible.
enum CursorSprites {

    struct Sprite {
        let image: CIImage
        let size: CGSize
        /// Where the pointer actually points, in **Core Image space**
        /// (origin bottom-left), pixels.
        let hotspot: CGPoint
        /// Height of the glyph itself, excluding shadow padding. On-screen size
        /// is specified against this so padding never changes the visual size.
        let glyphHeight: CGFloat
    }

    /// Glyph height in pixels for every sprite.
    private static let glyphPixels: CGFloat = 512
    /// Room for the drop shadow and stroke, so neither gets clipped.
    private static let padding: CGFloat = 48

    // Four arrow variants and two dots, all built as `static let` so they're
    // created once, lazily, and are safe to read from the preview and export
    // compositors at the same time. A mutable cache would need a lock for no
    // real saving — there are only six.

    /// Black body, white outline — what macOS actually draws.
    static let arrowDarkShadowed: Sprite = makeArtwork(CursorArtwork.arrow, body: darkBody, edge: .white, shadow: true)
    static let arrowDarkFlat: Sprite = makeArtwork(CursorArtwork.arrow, body: darkBody, edge: .white, shadow: false)
    /// White body, black outline — the Windows pointer.
    static let arrowLightShadowed: Sprite = makeArtwork(CursorArtwork.arrow, body: .white, edge: darkBody, shadow: true)
    static let arrowLightFlat: Sprite = makeArtwork(CursorArtwork.arrow, body: .white, edge: darkBody, shadow: false)

    static func arrow(_ tone: ProjectState.CursorStyle.ArrowTone, shadow: Bool) -> Sprite {
        switch (tone, shadow) {
        case (.dark, true):   return arrowDarkShadowed
        case (.dark, false):  return arrowDarkFlat
        case (.light, true):  return arrowLightShadowed
        case (.light, false): return arrowLightFlat
        }
    }

    // The pointing hand is white with a black outline on *both* systems — macOS
    // only inverts the arrow, not the hand. So both tones share a fill and
    // differ only in outline weight, which is the visible difference between
    // the two platforms' hands.
    static let handDarkShadowed: Sprite = makeArtwork(CursorArtwork.pointingHand, body: .white, edge: darkBody, shadow: true)
    static let handDarkFlat: Sprite = makeArtwork(CursorArtwork.pointingHand, body: .white, edge: darkBody, shadow: false)
    static let handLightShadowed: Sprite = handDarkShadowed
    static let handLightFlat: Sprite = handDarkFlat

    /// The artwork's own colour.
    private static let darkBody = NSColor.black

    static func hand(_ tone: ProjectState.CursorStyle.ArrowTone, shadow: Bool) -> Sprite {
        switch (tone, shadow) {
        case (.dark, true):   return handDarkShadowed
        case (.dark, false):  return handDarkFlat
        case (.light, true):  return handLightShadowed
        case (.light, false): return handLightFlat
        }
    }

    static let dotShadowed: Sprite = makeDot(shadow: true)
    static let dotFlat: Sprite = makeDot(shadow: false)

    static func dot(shadow: Bool) -> Sprite { shadow ? dotShadowed : dotFlat }
    /// Expanding ring used by the click ripple.
    static let ring: Sprite = makeRing()

    // MARK: - Artwork-backed cursors

    /// Renders one exported cursor at `glyphPixels` tall.
    ///
    /// The artwork is authored as a white body with a black outline. `body` and
    /// `edge` are handed in rather than baked so the same path can produce the
    /// macOS arrow (dark body, white edge) and the Windows one (the reverse)
    /// without two copies of the geometry.
    private static func makeArtwork(_ artwork: CursorArtwork.Artwork,
                                    body: NSColor,
                                    edge: NSColor,
                                    shadow: Bool) -> Sprite {
        let scale = glyphPixels / artwork.height
        let glyphWidth = artwork.width * scale
        let size = CGSize(width: glyphWidth + padding * 2, height: glyphPixels + padding * 2)

        // Artwork is y-down; `render` already flips, so the paths go in as
        // authored and only need translating into the padded box.
        var transform = CGAffineTransform(translationX: padding, y: padding).scaledBy(x: scale, y: scale)

        let fill = (try? SVGPath.path(from: artwork.fill))?.copy(using: &transform)
        let stroked = (try? SVGPath.path(from: artwork.strokePath))?.copy(using: &transform)

        let image = render(size: size) { ctx in
            guard let fill, let stroked else { return }

            // An outside-aligned stroke is drawn at double width with the fill
            // on top: the fill covers the inner half, leaving exactly the
            // authored width outside the shape. A centred stroke is drawn at its
            // authored width and then re-applied at 62% over the fill, or the
            // shape reads too thin against a light background.
            let outerWidth = artwork.strokeWidth * scale * (artwork.strokeOutside ? 2 : 1)

            ctx.saveGState()
            if shadow {
                ctx.setShadow(offset: CGSize(width: 0, height: glyphPixels * 0.02),
                              blur: glyphPixels * 0.045,
                              color: NSColor.black.withAlphaComponent(0.5).cgColor)
            }
            // The outline carries the shadow: it's the outermost thing, so it
            // defines the silhouette the shadow traces.
            ctx.addPath(stroked)
            ctx.setLineWidth(outerWidth)
            ctx.setLineCap(.round)
            ctx.setLineJoin(.round)
            ctx.setStrokeColor(edge.cgColor)
            ctx.strokePath()
            ctx.restoreGState()

            ctx.addPath(fill)
            ctx.setFillColor(body.cgColor)
            ctx.fillPath()

            if !artwork.strokeOutside {
                ctx.addPath(stroked)
                ctx.setLineWidth(artwork.strokeWidth * scale * 0.62)
                ctx.setLineCap(.round)
                ctx.setLineJoin(.round)
                ctx.setStrokeColor(edge.cgColor)
                ctx.strokePath()
            }
        }

        return Sprite(
            image: image,
            size: size,
            hotspot: CGPoint(x: padding + artwork.hotspot.x * glyphWidth,
                             y: size.height - padding - artwork.hotspot.y * glyphPixels),
            glyphHeight: glyphPixels
        )
    }

    // MARK: - The rest of the system cursors

    /// Everything the recorder can classify.
    ///
    /// The four hands and the arrow come from the exported Figma artwork; the
    /// I-beam, resize bars, crosshair and magnifiers are drawn here, because
    /// they're pure geometry and a path export would be more to keep in sync
    /// than it's worth. All share the arrow's glyph height so switching between
    /// them never makes the pointer jump in size.
    static func system(_ shape: EventLog.PointerShapeChange.Shape,
                       tone: ProjectState.CursorStyle.ArrowTone,
                       shadow: Bool) -> Sprite? {
        switch shape {
        case .arrow:      return nil
        case .hand:       return hand(tone, shadow: shadow)
        case .text:       return shadow ? iBeamShadowed : iBeamFlat
        case .resizeH:    return shadow ? resizeHShadowed : resizeHFlat
        case .resizeV:    return shadow ? resizeVShadowed : resizeVFlat
        case .openHand:   return shadow ? openHandShadowed : openHandFlat
        case .closedHand: return shadow ? closedHandShadowed : closedHandFlat
        case .crosshair:  return shadow ? crosshairShadowed : crosshairFlat
        case .zoomIn:     return shadow ? zoomInShadowed : zoomInFlat
        case .zoomOut:    return shadow ? zoomOutShadowed : zoomOutFlat
        }
    }

    static let openHandShadowed: Sprite = makeArtwork(CursorArtwork.openHand, body: .white, edge: darkBody, shadow: true)
    static let openHandFlat: Sprite = makeArtwork(CursorArtwork.openHand, body: .white, edge: darkBody, shadow: false)
    static let closedHandShadowed: Sprite = makeArtwork(CursorArtwork.closedHand, body: .white, edge: darkBody, shadow: true)
    static let closedHandFlat: Sprite = makeArtwork(CursorArtwork.closedHand, body: .white, edge: darkBody, shadow: false)

    static let iBeamShadowed: Sprite = makeIBeam(shadow: true)
    static let iBeamFlat: Sprite = makeIBeam(shadow: false)
    static let resizeHShadowed: Sprite = makeResize(vertical: false, shadow: true)
    static let resizeHFlat: Sprite = makeResize(vertical: false, shadow: false)
    static let resizeVShadowed: Sprite = makeResize(vertical: true, shadow: true)
    static let resizeVFlat: Sprite = makeResize(vertical: true, shadow: false)
    static let crosshairShadowed: Sprite = makeCrosshair(shadow: true)
    static let crosshairFlat: Sprite = makeCrosshair(shadow: false)
    static let zoomInShadowed: Sprite = makeMagnifier(plus: true, shadow: true)
    static let zoomInFlat: Sprite = makeMagnifier(plus: true, shadow: false)
    static let zoomOutShadowed: Sprite = makeMagnifier(plus: false, shadow: true)
    static let zoomOutFlat: Sprite = makeMagnifier(plus: false, shadow: false)

    /// Dark shadow, then outline, then fill.
    ///
    /// Stroking before filling means the stroke's inner half is painted over, so
    /// the visible outline sits entirely outside the silhouette and the glyph
    /// keeps its intended weight.
    private static func outline(_ ctx: CGContext,
                                fill: NSColor,
                                stroke: NSColor,
                                shadow: Bool,
                                lineWidth: CGFloat,
                                unit: CGFloat) {
        let path = ctx.path
        ctx.saveGState()
        if shadow {
            ctx.setShadow(offset: CGSize(width: 0, height: unit * 0.02),
                          blur: unit * 0.045,
                          color: NSColor.black.withAlphaComponent(0.5).cgColor)
        }
        ctx.setLineWidth(lineWidth)
        ctx.setLineJoin(.round)
        ctx.setStrokeColor(stroke.cgColor)
        ctx.strokePath()
        ctx.restoreGState()

        if let path { ctx.addPath(path) }
        ctx.setFillColor(fill.cgColor)
        ctx.fillPath()
    }

    /// Black bar with flared serifs, as macOS draws it. The hot spot is the
    /// centre, not the top — an I-beam marks a line, not a point.
    private static func makeIBeam(shadow: Bool) -> Sprite {
        let unit = glyphPixels
        let glyphWidth = unit * 0.40
        let size = CGSize(width: glyphWidth + padding * 2, height: unit + padding * 2)

        let image = render(size: size) { ctx in
            let stem = unit * 0.085
            let serif = unit * 0.30
            let cap = unit * 0.075
            let midX = padding + glyphWidth / 2

            // The bar swells out to the caps rather than meeting them square,
            // which is what stops it reading as a lowercase L.
            let path = CGMutablePath()
            path.move(to: CGPoint(x: midX - serif / 2, y: padding))
            path.addLine(to: CGPoint(x: midX + serif / 2, y: padding))
            path.addLine(to: CGPoint(x: midX + serif / 2, y: padding + cap))
            path.addQuadCurve(to: CGPoint(x: midX + stem / 2, y: padding + cap * 2.1),
                              control: CGPoint(x: midX + stem / 2, y: padding + cap))
            path.addLine(to: CGPoint(x: midX + stem / 2, y: padding + unit - cap * 2.1))
            path.addQuadCurve(to: CGPoint(x: midX + serif / 2, y: padding + unit - cap),
                              control: CGPoint(x: midX + stem / 2, y: padding + unit - cap))
            path.addLine(to: CGPoint(x: midX + serif / 2, y: padding + unit))
            path.addLine(to: CGPoint(x: midX - serif / 2, y: padding + unit))
            path.addLine(to: CGPoint(x: midX - serif / 2, y: padding + unit - cap))
            path.addQuadCurve(to: CGPoint(x: midX - stem / 2, y: padding + unit - cap * 2.1),
                              control: CGPoint(x: midX - stem / 2, y: padding + unit - cap))
            path.addLine(to: CGPoint(x: midX - stem / 2, y: padding + cap * 2.1))
            path.addQuadCurve(to: CGPoint(x: midX - serif / 2, y: padding + cap),
                              control: CGPoint(x: midX - stem / 2, y: padding + cap))
            path.closeSubpath()

            ctx.addPath(path)
            outline(ctx, fill: darkBody, stroke: .white, shadow: shadow,
                    lineWidth: unit * 0.07, unit: unit)
        }

        return Sprite(image: image, size: size,
                      hotspot: CGPoint(x: size.width / 2, y: size.height / 2),
                      glyphHeight: unit)
    }

    /// Double-headed arrow with the divider bar through the middle.
    private static func makeResize(vertical: Bool, shadow: Bool) -> Sprite {
        let unit = glyphPixels
        let long = unit
        let short = unit * 0.62
        let size = vertical
            ? CGSize(width: short + padding * 2, height: long + padding * 2)
            : CGSize(width: long + padding * 2, height: short + padding * 2)

        let image = render(size: size) { ctx in
            let head = unit * 0.22
            let shaft = unit * 0.10
            let midA = padding + short / 2

            // Built horizontally, then rotated into place — one set of numbers to
            // get right instead of two that can drift apart.
            let path = CGMutablePath()
            path.addRect(CGRect(x: padding + head, y: midA - shaft / 2,
                                width: long - head * 2, height: shaft))
            path.move(to: CGPoint(x: padding, y: midA))
            path.addLine(to: CGPoint(x: padding + head, y: midA - head * 0.75))
            path.addLine(to: CGPoint(x: padding + head, y: midA + head * 0.75))
            path.closeSubpath()
            path.move(to: CGPoint(x: padding + long, y: midA))
            path.addLine(to: CGPoint(x: padding + long - head, y: midA - head * 0.75))
            path.addLine(to: CGPoint(x: padding + long - head, y: midA + head * 0.75))
            path.closeSubpath()

            var transform = CGAffineTransform.identity
            if vertical {
                transform = CGAffineTransform(translationX: size.width / 2, y: size.height / 2)
                    .rotated(by: .pi / 2)
                    .translatedBy(x: -(long / 2 + padding), y: -(short / 2 + padding))
            }
            guard let placed = path.copy(using: &transform) else { return }
            ctx.addPath(placed)
            outline(ctx, fill: darkBody, stroke: .white, shadow: shadow,
                    lineWidth: unit * 0.06, unit: unit)
        }

        return Sprite(image: image, size: size,
                      hotspot: CGPoint(x: size.width / 2, y: size.height / 2),
                      glyphHeight: unit)
    }

    /// Thin plus with a gap at the centre, so the exact point stays visible.
    private static func makeCrosshair(shadow: Bool) -> Sprite {
        let unit = glyphPixels
        let size = CGSize(width: unit + padding * 2, height: unit + padding * 2)

        let image = render(size: size) { ctx in
            let arm = unit * 0.40
            let thickness = unit * 0.055
            let gap = unit * 0.075
            let mid = padding + unit / 2

            let path = CGMutablePath()
            path.addRect(CGRect(x: mid - arm - gap, y: mid - thickness / 2, width: arm, height: thickness))
            path.addRect(CGRect(x: mid + gap, y: mid - thickness / 2, width: arm, height: thickness))
            path.addRect(CGRect(x: mid - thickness / 2, y: mid - arm - gap, width: thickness, height: arm))
            path.addRect(CGRect(x: mid - thickness / 2, y: mid + gap, width: thickness, height: arm))

            ctx.addPath(path)
            outline(ctx, fill: darkBody, stroke: .white, shadow: shadow,
                    lineWidth: unit * 0.05, unit: unit)
        }

        return Sprite(image: image, size: size,
                      hotspot: CGPoint(x: size.width / 2, y: size.height / 2),
                      glyphHeight: unit)
    }

    /// Magnifier with a plus or a minus in the lens.
    private static func makeMagnifier(plus: Bool, shadow: Bool) -> Sprite {
        let unit = glyphPixels
        let size = CGSize(width: unit + padding * 2, height: unit + padding * 2)

        let image = render(size: size) { ctx in
            let radius = unit * 0.30
            let centre = CGPoint(x: padding + unit * 0.40, y: padding + unit * 0.36)
            let ringWidth = unit * 0.085

            // Lens ring as an annulus plus the handle, as one path, so the white
            // outline traces the whole glyph rather than each piece separately.
            let path = CGMutablePath()
            path.addEllipse(in: CGRect(x: centre.x - radius, y: centre.y - radius,
                                       width: radius * 2, height: radius * 2))
            path.addEllipse(in: CGRect(x: centre.x - radius + ringWidth, y: centre.y - radius + ringWidth,
                                       width: (radius - ringWidth) * 2, height: (radius - ringWidth) * 2))

            let handle = CGMutablePath()
            handle.move(to: CGPoint(x: centre.x + radius * 0.72, y: centre.y + radius * 0.72))
            handle.addLine(to: CGPoint(x: padding + unit * 0.90, y: padding + unit * 0.90))
            path.addPath(handle.copy(strokingWithWidth: unit * 0.11, lineCap: .round,
                                     lineJoin: .round, miterLimit: 10))

            ctx.addPath(path)
            ctx.saveGState()
            if shadow {
                ctx.setShadow(offset: CGSize(width: 0, height: unit * 0.02),
                              blur: unit * 0.045,
                              color: NSColor.black.withAlphaComponent(0.5).cgColor)
            }
            ctx.setLineWidth(unit * 0.05)
            ctx.setLineJoin(.round)
            ctx.setStrokeColor(NSColor.white.cgColor)
            ctx.strokePath()
            ctx.restoreGState()

            ctx.addPath(path)
            ctx.setFillColor(darkBody.cgColor)
            ctx.fillPath(using: .evenOdd)

            let bar = unit * 0.055
            let reach = radius * 0.46
            ctx.setFillColor(darkBody.cgColor)
            ctx.fill(CGRect(x: centre.x - reach, y: centre.y - bar / 2, width: reach * 2, height: bar))
            if plus {
                ctx.fill(CGRect(x: centre.x - bar / 2, y: centre.y - reach, width: bar, height: reach * 2))
            }
        }

        return Sprite(image: image, size: size,
                      hotspot: CGPoint(x: padding + unit * 0.40,
                                       y: size.height - padding - unit * 0.36),
                      glyphHeight: unit)
    }

    // MARK: - Dot ("tap dot")

    private static func makeDot(shadow: Bool) -> Sprite {
        let diameter = glyphPixels
        let size = CGSize(width: diameter + padding * 2, height: diameter + padding * 2)
        let center = CGPoint(x: size.width / 2, y: size.height / 2)

        let image = render(size: size) { ctx in
            if shadow {
                ctx.setShadow(offset: CGSize(width: 0, height: diameter * 0.025),
                              blur: diameter * 0.07,
                              color: NSColor.black.withAlphaComponent(0.45).cgColor)
            }

            // White so the renderer can tint it with a colour matrix; a feathered
            // edge keeps it from aliasing when scaled down on a 1080p export.
            let colors = [
                NSColor.white.cgColor,
                NSColor.white.cgColor,
                NSColor.white.withAlphaComponent(0).cgColor,
            ] as CFArray
            guard let gradient = CGGradient(colorsSpace: CGColorSpaceCreateDeviceRGB(),
                                            colors: colors,
                                            locations: [0.0, 0.90, 1.0]) else { return }
            ctx.drawRadialGradient(gradient,
                                   startCenter: center, startRadius: 0,
                                   endCenter: center, endRadius: diameter / 2,
                                   options: [])
        }

        return Sprite(image: image, size: size, hotspot: center, glyphHeight: diameter)
    }

    // MARK: - Ripple ring

    private static func makeRing() -> Sprite {
        let diameter = glyphPixels
        let size = CGSize(width: diameter + padding * 2, height: diameter + padding * 2)
        let center = CGPoint(x: size.width / 2, y: size.height / 2)
        let lineWidth = diameter * 0.06

        let image = render(size: size) { ctx in
            ctx.setStrokeColor(NSColor.white.cgColor)
            ctx.setLineWidth(lineWidth)
            ctx.strokeEllipse(in: CGRect(
                x: center.x - diameter / 2 + lineWidth / 2,
                y: center.y - diameter / 2 + lineWidth / 2,
                width: diameter - lineWidth,
                height: diameter - lineWidth
            ))
        }

        return Sprite(image: image, size: size, hotspot: center, glyphHeight: diameter)
    }

    // MARK: - Bitmap helper

    /// Draws into a premultiplied sRGB bitmap. The CTM is flipped so `draw`
    /// works in y-down coordinates, which is how the path data above is written.
    private static func render(size: CGSize, draw: (CGContext) -> Void) -> CIImage {
        let width = Int(size.width.rounded())
        let height = Int(size.height.rounded())

        guard let ctx = CGContext(
            data: nil,
            width: width,
            height: height,
            bitsPerComponent: 8,
            bytesPerRow: 0,
            space: CGColorSpace(name: CGColorSpace.sRGB) ?? CGColorSpaceCreateDeviceRGB(),
            bitmapInfo: CGImageAlphaInfo.premultipliedLast.rawValue
        ) else {
            return CIImage.empty()
        }

        ctx.translateBy(x: 0, y: CGFloat(height))
        ctx.scaleBy(x: 1, y: -1)
        ctx.setAllowsAntialiasing(true)
        ctx.interpolationQuality = .high
        draw(ctx)

        guard let cgImage = ctx.makeImage() else { return CIImage.empty() }
        return CIImage(cgImage: cgImage)
    }
}
