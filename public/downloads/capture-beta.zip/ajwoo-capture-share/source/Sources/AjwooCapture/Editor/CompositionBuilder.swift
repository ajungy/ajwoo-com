import Foundation
import AVFoundation
import CoreMedia
import CoreGraphics

/// Assembles the `.ajwoocapture` package into an `AVComposition` plus the video
/// composition and audio mix that drive both preview and export.
///
/// **The full asset is always inserted at time zero.** Trimming happens at
/// playback (the player's loop bounds) and at export (the reader's time range),
/// never by shifting the timeline — so composition time always equals recording
/// time, and every timestamp in `events.json` can be used directly without an
/// offset. Getting this wrong is how cursor positions end up correct at the
/// start of a trimmed clip and progressively wrong later.
struct EditorComposition {
    let composition: AVMutableComposition
    let videoComposition: AVMutableVideoComposition
    let audioMix: AVMutableAudioMix?
    let sourceSize: CGSize
    /// Length of the spliced composition — shorter than the recording when cuts
    /// are present.
    let duration: CMTime
    /// Untouched length of the capture.
    let recordingDuration: CMTime
    let timeMap: TimeMap
    let hasCamera: Bool
    let hasSystemAudio: Bool
    let hasMicAudio: Bool
}

enum CompositionBuilder {

    // Fixed track IDs so the compositor and the audio mix can refer to them
    // without hunting through the composition.
    static let screenTrackID: CMPersistentTrackID = 1
    static let cameraTrackID: CMPersistentTrackID = 2
    static let systemAudioTrackID: CMPersistentTrackID = 3
    static let micAudioTrackID: CMPersistentTrackID = 4

    enum BuildError: LocalizedError {
        case noScreenVideo
        var errorDescription: String? {
            "This recording has no usable screen.mov — it was probably interrupted mid-capture."
        }
    }

    static func build(session: RecordingSession,
                      context: RenderContext,
                      renderSize: CGSize,
                      frameRate: Int) async throws -> EditorComposition {

        let composition = AVMutableComposition()

        // --- screen video ---
        let screenAsset = AVURLAsset(url: session.screenVideoURL)
        guard let screenSource = try await screenAsset.loadTracks(withMediaType: .video).first else {
            throw BuildError.noScreenVideo
        }
        let screenDuration = try await screenAsset.load(.duration)
        let naturalSize = try await screenSource.load(.naturalSize)

        // Cuts are spliced out here, once, for every track. Everything else in
        // the app keeps working in recording time and goes through `TimeMap`.
        let timeMap = TimeMap(cuts: context.project.cuts, duration: screenDuration.seconds)

        guard let screenTrack = composition.addMutableTrack(withMediaType: .video,
                                                            preferredTrackID: screenTrackID) else {
            throw BuildError.noScreenVideo
        }
        insert(timeMap: timeMap, from: screenSource, into: screenTrack, sourceDuration: screenDuration)

        // --- camera video (optional) ---
        var hasCamera = false
        if FileManager.default.fileExists(atPath: session.cameraVideoURL.path) {
            let cameraAsset = AVURLAsset(url: session.cameraVideoURL)
            if let cameraSource = try? await cameraAsset.loadTracks(withMediaType: .video).first,
               let cameraDuration = try? await cameraAsset.load(.duration),
               cameraDuration.seconds > 0,
               let cameraTrack = composition.addMutableTrack(withMediaType: .video,
                                                             preferredTrackID: cameraTrackID) {
                // Where the camera's real content starts, within camera.mov's
                // own timeline. **Not** `cameraSource.load(.timeRange).start` —
                // that reports `0` unconditionally here, regardless of when the
                // first sample actually landed (see `insertCamera`'s doc
                // comment for why, and how that was found). The one place this
                // offset is actually recorded is at capture time, in
                // `TrackWriter.startOffset`, threaded through to
                // `events.json`.
                let cameraStartOffset = context.log.recording.media
                    .first { $0.kind == "camera" }?.startOffsetSeconds ?? 0
                // `end`, not `duration` — `cameraDuration` is the asset's own
                // duration, which (like `.timeRange` above) already measures
                // from a start pinned at zero, so it already *is* the true end
                // instant. Adding `cameraStartOffset` on top would double-count
                // it and overshoot.
                let cameraRange = CMTimeRange(start: CMTime(seconds: max(0, cameraStartOffset), preferredTimescale: 600),
                                              end: cameraDuration)
                insertCamera(timeMap: timeMap, from: cameraSource, into: cameraTrack,
                            cameraRange: cameraRange)
                hasCamera = true
            }
        }

        // --- audio ---
        let hasSystemAudio = await insertAudio(url: session.systemAudioURL,
                                               trackID: systemAudioTrackID,
                                               into: composition, timeMap: timeMap)
        let hasMicAudio = await insertAudio(url: session.micAudioURL,
                                            trackID: micAudioTrackID,
                                            into: composition, timeMap: timeMap)

        let compositionDuration = CMTime(seconds: max(0.001, timeMap.compositionDuration),
                                         preferredTimescale: 600)

        // Only loaded when the gate is actually on — `EditorModel` builds and
        // caches this same envelope for the "remove long silences" cut and
        // reuses it on every later mix rebuild (a volume slider move, say);
        // this one-off load only fires for the initial build, or for a
        // caller (the exporter) that doesn't already have one cached.
        var micEnvelope: [Float] = []
        if hasMicAudio, context.project.audio.noiseReduction > 0.001 {
            let buckets = max(64, Int(screenDuration.seconds * Double(SilenceDetector.bucketsPerSecond)))
            micEnvelope = await WaveformLoader.load(url: session.micAudioURL, buckets: buckets)
        }

        let videoComposition = makeVideoComposition(context: context,
                                                    duration: compositionDuration,
                                                    renderSize: renderSize,
                                                    frameRate: frameRate,
                                                    hasCamera: hasCamera,
                                                    timeMap: timeMap)

        return EditorComposition(
            composition: composition,
            videoComposition: videoComposition,
            audioMix: audioMix(for: composition, project: context.project,
                              micEnvelope: micEnvelope, timeMap: timeMap),
            sourceSize: naturalSize,
            duration: compositionDuration,
            recordingDuration: screenDuration,
            timeMap: timeMap,
            hasCamera: hasCamera,
            hasSystemAudio: hasSystemAudio,
            hasMicAudio: hasMicAudio
        )
    }

    /// Built fresh whenever the edit changes.
    ///
    /// `AVPlayerItem` only re-renders when it's handed a video composition it
    /// hasn't seen — mutating the existing one in place does nothing, and a
    /// paused player will happily keep showing a stale frame. So every edit
    /// makes a new object. They're just descriptors; this is cheap.
    static func makeVideoComposition(context: RenderContext,
                                     duration: CMTime,
                                     renderSize: CGSize,
                                     frameRate: Int,
                                     hasCamera: Bool,
                                     timeMap: TimeMap) -> AVMutableVideoComposition {
        let videoComposition = AVMutableVideoComposition()
        videoComposition.renderSize = renderSize
        videoComposition.frameDuration = CMTime(value: 1, timescale: CMTimeScale(max(1, frameRate)))
        videoComposition.renderScale = 1
        videoComposition.customVideoCompositorClass = AjwooCaptureCompositor.self
        videoComposition.instructions = [
            RenderInstruction(
                timeRange: CMTimeRange(start: .zero, duration: duration),
                context: context,
                screenTrackID: screenTrackID,
                cameraTrackID: hasCamera ? cameraTrackID : nil,
                timeMap: timeMap
            )
        ]
        return videoComposition
    }

    /// Inserts every kept range back-to-back, which is what actually removes the
    /// cuts. Ranges past the end of a shorter track are skipped rather than
    /// failing the whole build — the right behaviour for audio, where a track
    /// that ends early just means less sound, nothing has to fill the silence.
    ///
    /// Camera video does **not** use this — see `insertCamera` below — because
    /// for video, a short source doesn't just mean "less content," it means a
    /// visible gap where the bubble disappears.
    private static func insert(timeMap: TimeMap,
                               from source: AVAssetTrack,
                               into track: AVMutableCompositionTrack,
                               sourceDuration: CMTime) {
        for segment in timeMap.segments where segment.duration > 0.001 {
            guard segment.recordingStart < sourceDuration.seconds else { continue }
            let available = min(segment.duration, sourceDuration.seconds - segment.recordingStart)
            guard available > 0.001 else { continue }

            let range = CMTimeRange(start: CMTime(seconds: segment.recordingStart, preferredTimescale: 600),
                                    duration: CMTime(seconds: available, preferredTimescale: 600))
            let at = CMTime(seconds: segment.compositionStart, preferredTimescale: 600)
            try? track.insertTimeRange(range, of: source, at: at)
        }
    }

    /// Inserts the camera track so it spans exactly the same composition range
    /// as the screen track, even though the camera itself never starts or stops
    /// in lockstep with it.
    ///
    /// # Why the camera track is short to begin with
    /// `AVCaptureSession.startRunning()` takes real time to produce its first
    /// frame — a few hundred milliseconds is ordinary, more for an external or
    /// Continuity camera — and stopping loses a similar sliver at the tail.
    /// `CameraMicRecorder` already buffers frames until the shared origin
    /// (`t0`, the screen's first frame) is known, but buffering can't invent a
    /// frame the camera hadn't produced yet: `camera.mov`'s decodable content
    /// genuinely doesn't begin until `cameraRange.start`, because
    /// `AVAssetWriter` maps real time to file time 1:1 from
    /// `startSession(atSourceTime:)` onward — there's no "blank lead-in" to ask
    /// for, the frames simply don't exist yet. The old code asked
    /// `insertTimeRange` for source time 0 regardless, which left the leading
    /// stretch of the composition with nothing in it at all.
    ///
    /// # Why `cameraRange` comes in as a parameter instead of being read here
    /// The obvious way to find where a track's real content starts is to ask
    /// it: `AVAssetTrack.load(.timeRange)`. That turns out to be actively
    /// misleading for a file `AVAssetWriter` produced this way — `.start`
    /// reports `0` unconditionally, regardless of how much later the first
    /// *appended* sample's timestamp was, and asking for content at that
    /// falsely-claimed start succeeds without error while decoding nothing.
    /// (Confirmed by hand: a track whose real samples begin at 0.4s still
    /// reports `timeRange.start == 0`.) The one place the true offset is ever
    /// recorded is at capture time, in `TrackWriter.startOffset` — so the
    /// caller builds `cameraRange` from that, saved in `events.json`, rather
    /// than from the asset's own unreliable bookkeeping. The *end* of the
    /// range doesn't have this problem — a track's reported duration does end
    /// exactly where its last real sample does — so `cameraDuration` from the
    /// asset is trustworthy there.
    ///
    /// # The fix
    /// For the portion of any kept segment that falls before `cameraRange.start`
    /// or after `cameraRange.end`, this holds the nearest real frame — the
    /// first, or the last — frozen for that stretch, via `insertTimeRange` on a
    /// short probe range followed by `scaleTimeRange(_:toDuration:)` to stretch
    /// it. Wherever a segment overlaps real camera content, that's inserted
    /// normally, unchanged from `insert(_:from:into:sourceDuration:)` above.
    /// The result: every composition frame that has a screen frame also has a
    /// camera frame, real or held.
    private static func insertCamera(timeMap: TimeMap,
                                     from source: AVAssetTrack,
                                     into track: AVMutableCompositionTrack,
                                     cameraRange: CMTimeRange) {
        let realStart = cameraRange.start.seconds
        let realEnd = cameraRange.end.seconds
        guard realEnd > realStart else { return }

        // Shorter than any real frame interval, so it always lands on exactly
        // one sample wherever it's aimed — that sample is what gets stretched.
        let nominalRate = source.nominalFrameRate > 0 ? Double(source.nominalFrameRate) : 30
        let probeSeconds = min(1.0 / nominalRate, 0.05, realEnd - realStart)
        let probeDuration = CMTime(seconds: max(0.001, probeSeconds), preferredTimescale: 600)

        /// Freezes the frame at `sourceInstant` for `holdSeconds`, starting at
        /// `compositionInstant`.
        ///
        /// Kept a full `probeDuration` clear of both edges of the real range,
        /// rather than clamped to touch them — a probe asked to start exactly
        /// on a boundary risks a sub-tick rounding difference between the
        /// `Double`-seconds value passed in and the source track's own native
        /// timescale, and `insertTimeRange` matches nothing rather than
        /// snapping to the nearest sample.
        func hold(_ sourceInstant: Double, at compositionInstant: Double, for holdSeconds: Double) {
            guard holdSeconds > 0.001 else { return }
            let clampedStart = max(realStart + probeDuration.seconds,
                                   min(sourceInstant, realEnd - probeDuration.seconds))
            let probeRange = CMTimeRange(start: CMTime(seconds: clampedStart, preferredTimescale: 600),
                                         duration: probeDuration)
            let at = CMTime(seconds: compositionInstant, preferredTimescale: 600)
            guard (try? track.insertTimeRange(probeRange, of: source, at: at)) != nil else { return }

            let inserted = CMTimeRange(start: at, duration: probeDuration)
            let held = CMTime(seconds: holdSeconds, preferredTimescale: 600)
            try? track.scaleTimeRange(inserted, toDuration: held)
        }

        for segment in timeMap.segments where segment.duration > 0.001 {
            var cursor = segment.recordingStart
            var compositionCursor = segment.compositionStart
            let segmentEnd = segment.recordingEnd

            // Before the camera has any real content: hold its first frame.
            if cursor < realStart {
                let holdEnd = min(realStart, segmentEnd)
                hold(realStart, at: compositionCursor, for: holdEnd - cursor)
                compositionCursor += holdEnd - cursor
                cursor = holdEnd
            }

            // Real content, wherever this segment actually overlaps it.
            if cursor < segmentEnd, cursor < realEnd {
                let realSegmentEnd = min(segmentEnd, realEnd)
                let range = CMTimeRange(start: CMTime(seconds: cursor, preferredTimescale: 600),
                                        duration: CMTime(seconds: realSegmentEnd - cursor, preferredTimescale: 600))
                let at = CMTime(seconds: compositionCursor, preferredTimescale: 600)
                try? track.insertTimeRange(range, of: source, at: at)
                compositionCursor += realSegmentEnd - cursor
                cursor = realSegmentEnd
            }

            // After wherever the camera stopped: hold its last frame.
            if cursor < segmentEnd {
                hold(realEnd, at: compositionCursor, for: segmentEnd - cursor)
            }
        }
    }

    private static func insertAudio(url: URL,
                                    trackID: CMPersistentTrackID,
                                    into composition: AVMutableComposition,
                                    timeMap: TimeMap) async -> Bool {
        guard FileManager.default.fileExists(atPath: url.path) else { return false }
        let asset = AVURLAsset(url: url)
        guard let source = try? await asset.loadTracks(withMediaType: .audio).first,
              let duration = try? await asset.load(.duration),
              duration.seconds > 0,
              let track = composition.addMutableTrack(withMediaType: .audio, preferredTrackID: trackID)
        else { return false }

        insert(timeMap: timeMap, from: source, into: track, sourceDuration: duration)
        return true
    }

    /// Rebuilt whenever a volume slider moves — mixes are cheap, and reassigning
    /// one on the player item is how a live volume change takes effect.
    /// Builds the mix from the project's levels.
    ///
    /// Volumes above 1.0 are passed straight through: `setVolume` is a gain
    /// multiplier, not a normalised fader, so 2.0 really is twice as loud. A
    /// take that was already close to full scale will clip at that setting —
    /// which is the honest behaviour for a gain control, and the alternative
    /// (silently capping at 1.0) would leave a quiet recording unrescuable.
    ///
    /// - Parameters:
    ///   - micEnvelope: The mic's peak-per-bucket envelope at
    ///     `SilenceDetector.bucketsPerSecond`, on the **original recording**
    ///     timeline — the same data `EditorModel.silenceEnvelope` builds for
    ///     the "remove long silences" cut. Drives the "Remove noise" gate.
    ///     Omit it (or pass an empty array) to skip gating entirely, which is
    ///     also what happens automatically whenever `noiseReduction` is 0.
    ///   - timeMap: Needed to translate the envelope's recording-time quiet
    ///     ranges into composition-time ranges the audio mix can actually use
    ///     — see `applyNoiseGate` below. Required alongside `micEnvelope` for
    ///     gating to take effect; omit both together.
    static func audioMix(for composition: AVComposition,
                         project: ProjectState,
                         micEnvelope: [Float] = [],
                         timeMap: TimeMap? = nil) -> AVMutableAudioMix? {
        var parameters: [AVMutableAudioMixInputParameters] = []

        for track in composition.tracks(withMediaType: .audio) {
            let params = AVMutableAudioMixInputParameters(track: track)
            switch track.trackID {
            case systemAudioTrackID:
                params.setVolume(project.audio.systemMuted ? 0 : Float(project.audio.systemVolume), at: .zero)
            case micAudioTrackID:
                let baseVolume = project.audio.micMuted ? 0 : Float(project.audio.micVolume)
                params.setVolume(baseVolume, at: .zero)
                if !project.audio.micMuted, project.audio.noiseReduction > 0.001, let timeMap {
                    applyNoiseGate(to: params, baseVolume: baseVolume,
                                   amount: Float(project.audio.noiseReduction),
                                   envelope: micEnvelope, timeMap: timeMap)
                }
            default:
                params.setVolume(1, at: .zero)
            }
            parameters.append(params)
        }

        guard !parameters.isEmpty else { return nil }
        let mix = AVMutableAudioMix()
        mix.inputParameters = parameters
        return mix
    }

    /// The "Remove noise" slider: ducks the mic during stretches where
    /// nothing is being said, rather than applying real spectral denoising.
    /// That's a deliberate, much simpler choice — a gate needs only the same
    /// envelope `SilenceDetector` already builds for cuts, reused here
    /// instead of a second analysis pass, and it can't introduce the
    /// artifacts a denoiser risks on speech itself.
    ///
    /// A real gate, not a mute switch: it only engages after a genuine pause
    /// (`minimumHold`, not the gap between two words), and ramps the volume
    /// down and back up (`ramp`) rather than snapping — snapping reads as a
    /// edit, a ramp reads as the room actually going quieter.
    private static func applyNoiseGate(to params: AVMutableAudioMixInputParameters,
                                       baseVolume: Float,
                                       amount: Float,
                                       envelope: [Float],
                                       timeMap: TimeMap) {
        guard baseVolume > 0.0001, !envelope.isEmpty else { return }

        let bucketsPerSecond = Double(SilenceDetector.bucketsPerSecond)
        let threshold = SilenceDetector.threshold(for: envelope)
        let minimumHold = 0.35   // seconds of quiet before the gate engages
        let ramp = 0.12          // seconds to fade the gate in and back out
        // Never fully silent, even at 100% — a hard drop to true zero reads
        // as a dropout rather than "quieter", and a floor this low is
        // already well below where background noise is audible.
        let duckVolume = baseVolume * (1 - min(1, max(0, amount)) * 0.95)

        // Contiguous quiet runs, in recording time — same threshold logic
        // `SilenceDetector` uses for cuts, but every run regardless of
        // length; the `minimumHold` filter below is this function's own.
        var quietRanges: [(start: Double, end: Double)] = []
        var runStart: Double?
        for (index, level) in envelope.enumerated() {
            let t = Double(index) / bucketsPerSecond
            if level < threshold {
                if runStart == nil { runStart = t }
            } else if let start = runStart {
                quietRanges.append((start, t))
                runStart = nil
            }
        }
        if let start = runStart {
            quietRanges.append((start, Double(envelope.count) / bucketsPerSecond))
        }

        for range in quietRanges where range.end - range.start >= minimumHold {
            // Full mic volume up to `ramp` before the duck starts and after
            // it ends, so only the sustained middle of a real pause is
            // touched — the words right up against the pause keep their
            // natural level.
            let duckStart = range.start + ramp
            let duckEnd = range.end - ramp
            guard duckEnd > duckStart else { continue }

            // A cut can land inside a quiet range, or the range can span a
            // cut boundary — clip against every kept segment and project
            // each surviving piece into composition time separately, the
            // same way `insert(timeMap:...)` splices the audio itself.
            for segment in timeMap.segments {
                let clippedStart = max(duckStart, segment.recordingStart)
                let clippedEnd = min(duckEnd, segment.recordingEnd)
                guard clippedEnd > clippedStart else { continue }

                let offset = segment.compositionStart - segment.recordingStart
                func compositionTime(_ recordingTime: Double) -> CMTime {
                    CMTime(seconds: recordingTime + offset, preferredTimescale: 600)
                }

                let fadeOutStart = compositionTime(max(segment.recordingStart, clippedStart - ramp))
                let fadeInEnd = compositionTime(min(segment.recordingEnd, clippedEnd + ramp))
                let duckStartTime = compositionTime(clippedStart)
                let duckEndTime = compositionTime(clippedEnd)

                params.setVolumeRamp(fromStartVolume: baseVolume, toEndVolume: duckVolume,
                                     timeRange: CMTimeRange(start: fadeOutStart, end: duckStartTime))
                params.setVolumeRamp(fromStartVolume: duckVolume, toEndVolume: baseVolume,
                                     timeRange: CMTimeRange(start: duckEndTime, end: fadeInEnd))
            }
        }
    }
}
