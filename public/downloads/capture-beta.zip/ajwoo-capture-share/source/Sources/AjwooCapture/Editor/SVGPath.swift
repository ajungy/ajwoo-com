import CoreGraphics
import Foundation

/// Turns an SVG `d` attribute into a `CGPath`.
///
/// The cursor artwork is authored in Figma and exported as SVG, so the honest
/// thing is to keep the exported path data verbatim and parse it, rather than
/// re-tracing curves by hand into `addQuadCurve` calls. Two earlier attempts at
/// hand-tracing the pointing hand both came out wrong; a parser is about eighty
/// lines and is right by construction.
///
/// Supports the subset Figma emits: `M m L l H h V v C c S s Q q T t Z z`. Arcs
/// are not supported — Figma doesn't produce them for these shapes, and a silent
/// wrong answer would be worse than a visible gap, so an `A` command throws.
enum SVGPath {

    struct ParseError: LocalizedError {
        let command: Character
        var errorDescription: String? { "unsupported SVG path command '\(command)'" }
    }

    static func path(from d: String) throws -> CGPath {
        let path = CGMutablePath()
        var scanner = Scanner(d)

        var current = CGPoint.zero
        var start = CGPoint.zero
        // Reflection point for the shorthand curve commands.
        var lastControl = CGPoint.zero
        var lastCommand: Character = " "
        var command: Character = " "

        while let next = scanner.peekCommandOrNumber() {
            if next.isLetter {
                command = scanner.takeCommand()
            } else if command == "M" {
                // A repeated coordinate pair after a moveto is an implicit lineto.
                command = "L"
            } else if command == "m" {
                command = "l"
            }

            let relative = command.isLowercase
            func resolve(_ point: CGPoint) -> CGPoint {
                relative ? CGPoint(x: current.x + point.x, y: current.y + point.y) : point
            }

            switch Character(command.uppercased()) {
            case "M":
                current = resolve(try scanner.takePoint())
                start = current
                path.move(to: current)
            case "L":
                current = resolve(try scanner.takePoint())
                path.addLine(to: current)
            case "H":
                let x = try scanner.takeNumber()
                current = CGPoint(x: relative ? current.x + x : x, y: current.y)
                path.addLine(to: current)
            case "V":
                let y = try scanner.takeNumber()
                current = CGPoint(x: current.x, y: relative ? current.y + y : y)
                path.addLine(to: current)
            case "C":
                let c1 = resolve(try scanner.takePoint())
                let c2 = resolve(try scanner.takePoint())
                current = resolve(try scanner.takePoint())
                path.addCurve(to: current, control1: c1, control2: c2)
                lastControl = c2
            case "S":
                let c1 = "CS".contains(lastCommand.uppercased()) ? reflect(lastControl, about: current) : current
                let c2 = resolve(try scanner.takePoint())
                current = resolve(try scanner.takePoint())
                path.addCurve(to: current, control1: c1, control2: c2)
                lastControl = c2
            case "Q":
                let c = resolve(try scanner.takePoint())
                current = resolve(try scanner.takePoint())
                path.addQuadCurve(to: current, control: c)
                lastControl = c
            case "T":
                let c = "QT".contains(lastCommand.uppercased()) ? reflect(lastControl, about: current) : current
                current = resolve(try scanner.takePoint())
                path.addQuadCurve(to: current, control: c)
                lastControl = c
            case "Z":
                path.closeSubpath()
                current = start
            default:
                throw ParseError(command: command)
            }
            lastCommand = command
        }
        return path
    }

    private static func reflect(_ point: CGPoint, about origin: CGPoint) -> CGPoint {
        CGPoint(x: 2 * origin.x - point.x, y: 2 * origin.y - point.y)
    }

    /// Character-level cursor over the `d` string.
    private struct Scanner {
        private let characters: [Character]
        private var index = 0

        init(_ string: String) { characters = Array(string) }

        private mutating func skipSeparators() {
            while index < characters.count,
                  characters[index] == " " || characters[index] == ","
                    || characters[index] == "\n" || characters[index] == "\t" {
                index += 1
            }
        }

        mutating func peekCommandOrNumber() -> Character? {
            skipSeparators()
            return index < characters.count ? characters[index] : nil
        }

        mutating func takeCommand() -> Character {
            skipSeparators()
            defer { index += 1 }
            return characters[index]
        }

        mutating func takeNumber() throws -> CGFloat {
            skipSeparators()
            var text = ""
            if index < characters.count, characters[index] == "-" || characters[index] == "+" {
                text.append(characters[index]); index += 1
            }
            while index < characters.count {
                let c = characters[index]
                if c.isNumber || c == "." {
                    text.append(c); index += 1
                } else if c == "e" || c == "E" {
                    text.append(c); index += 1
                    if index < characters.count, characters[index] == "-" || characters[index] == "+" {
                        text.append(characters[index]); index += 1
                    }
                } else {
                    break
                }
            }
            guard let value = Double(text) else { throw ParseError(command: "#") }
            return CGFloat(value)
        }

        mutating func takePoint() throws -> CGPoint {
            CGPoint(x: try takeNumber(), y: try takeNumber())
        }
    }
}
