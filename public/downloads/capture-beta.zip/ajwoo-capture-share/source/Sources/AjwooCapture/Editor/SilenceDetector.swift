import Foundation

/// Finds the quiet stretches in an audio envelope.
///
/// # Why this doesn't use the transcript
/// The first implementation took the gaps between transcribed words. That fails
/// in exactly the case people care about: a room with a fan, a keyboard, a
/// street outside. The recogniser happily emits words across low-level noise and
/// stretches their timings over it, so the gaps it leaves are shorter than the
/// actual pauses and most of them fall under the threshold. You end up with a
/// checkbox that appears to do nothing.
///
/// So this works on the audio itself, and — as asked — treats micro sounds as
/// silence rather than as speech. The threshold is *relative* to how loud the
/// speech in this recording actually is, which is what makes it survive a noisy
/// room: a fan that reads as 4% of speech level is silence, and the same fan on
/// a quietly-recorded take is still 4% of that take's speech level.
enum SilenceDetector {

    /// Envelope resolution. Fine enough to place a cut inside a half-second
    /// pause without the buckets themselves smearing speech into silence.
    static let bucketsPerSecond = 50

    /// Quiet runs at least `minimumLength` long, in seconds.
    ///
    /// - Parameters:
    ///   - envelope: peak magnitude per bucket, 0...1.
    ///   - keep: beat left at each end. Cutting a pause to nothing makes the
    ///     speech either side sound spliced together.
    static func silences(in envelope: [Float],
                         duration: Double,
                         minimumLength: Double,
                         keep: Double = 0.18) -> [ClosedRange<Double>] {
        guard envelope.count > 1, duration > 0, minimumLength > keep else { return [] }

        let threshold = self.threshold(for: envelope)
        let secondsPerBucket = duration / Double(envelope.count)

        var runs: [ClosedRange<Double>] = []
        var runStart: Int?

        func close(at index: Int) {
            guard let start = runStart else { return }
            runStart = nil
            let from = Double(start) * secondsPerBucket
            let to = Double(index) * secondsPerBucket
            guard to - from >= minimumLength else { return }
            let trimmedStart = from + keep / 2
            let trimmedEnd = to - keep / 2
            guard trimmedEnd > trimmedStart else { return }
            runs.append(trimmedStart...trimmedEnd)
        }

        for (index, value) in envelope.enumerated() {
            if value <= threshold {
                if runStart == nil { runStart = index }
            } else {
                close(at: index)
            }
        }
        close(at: envelope.count)
        return runs
    }

    /// The level below which a bucket counts as silence.
    ///
    /// Taken as a fraction of the recording's *speech* level rather than as a
    /// fixed number. The 90th percentile stands in for "how loud is this person"
    /// — the mean would be dragged down by the pauses this function exists to
    /// find, and the maximum would be set by a single door slam.
    ///
    /// The absolute floor catches the other case: a track that is silent
    /// throughout has a meaningless percentile, and without a floor 4% of
    /// near-nothing would classify the whole thing as speech.
    static func threshold(for envelope: [Float]) -> Float {
        let sorted = envelope.sorted()
        let reference = sorted[min(sorted.count - 1, Int(Double(sorted.count) * 0.9))]
        return max(0.012, reference * 0.10)
    }
}
