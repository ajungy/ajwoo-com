import Foundation

/// Turns a click log into zoom segments — pure data in, data out, no
/// `EditorModel` state. Split out from `EditorModel.buildAutoZooms` so it can
/// be tested directly, the same reasoning `TranscriptAnalysis` was split out
/// from the transcript-editing code it serves.
enum AutoZoomGenerator {

    /// A click cluster in the top slice of the frame counts as reaching for the
    /// menu bar, not for content. On a full-display recording that strip
    /// literally *is* the menu bar; on a region recording, a menu-bar click
    /// almost always lands outside the region entirely and never reaches this
    /// function at all — see the `focusX`/`focusY` bounds guard below.
    ///
    /// A fixed fraction rather than a measured menu-bar height, deliberately:
    /// the real height varies by Mac (24pt on most, up to ~38pt with the
    /// notch), and a recording gets edited long after the display it was made
    /// on might be disconnected or swapped. 4% is generous enough to cover
    /// every real menu bar with margin, and tight enough that ordinary
    /// near-the-top content — a browser's tab strip, a toolbar — sits below it.
    static let menuBarZoneFraction = 0.04

    /// Builds the full set of zoom segments: `existing` (hand-placed zooms,
    /// untouched) plus one generated segment per click cluster, merged where
    /// adjacent clusters would otherwise produce overlapping zooms.
    ///
    /// - Parameter excludingTrailingMenuBarClick: when true, the *last* click
    ///   cluster is dropped if it sits in the menu bar's strip — someone
    ///   reaching for Stop, not content worth zooming into. `EditorModel`
    ///   passes `false` when computing the blueprint the wand tool compares
    ///   against, so a click this excludes still shows up there as "removed,"
    ///   with the normal one-click restore, rather than simply never having
    ///   existed.
    static func segments(clicks: [EventLog.ClickEvent],
                         settings: ProjectState.AutoZoom,
                         duration: Double,
                         existing: [ProjectState.ZoomSegment],
                         excludingTrailingMenuBarClick: Bool) -> [ProjectState.ZoomSegment] {
        var segments = existing

        if settings.enabled {
            let clusters = ClickTrack(clicks: clicks).clusters(maxGap: settings.clusterGap)

            for (index, cluster) in clusters.enumerated() {
                guard let first = cluster.first, let last = cluster.last else { continue }
                let start = max(0, first.t - settings.leadIn)
                let end = min(duration, last.t + settings.holdAfter)
                guard end - start >= 0.4 else { continue }

                let focusX = cluster.map(\.x).reduce(0, +) / Double(cluster.count)
                let focusY = cluster.map(\.y).reduce(0, +) / Double(cluster.count)
                guard focusX >= 0, focusX <= 1, focusY >= 0, focusY <= 1 else { continue }

                // The very last click cluster in the recording, up in the menu
                // bar's own strip, is someone reaching for Stop — opening the
                // menu bar and clicking it, which is exactly what ends the
                // recording a moment later, not something to zoom into. Only
                // the *last* cluster is judged this way: the same click
                // position in the middle of a take is just as likely to be
                // legitimate content (a tutorial pointing at the menu bar,
                // say), and nothing about its position alone says otherwise.
                if excludingTrailingMenuBarClick, index == clusters.count - 1,
                   focusY <= menuBarZoneFraction {
                    continue
                }

                // Merge with the previous auto segment when they'd overlap, so
                // two zooms never fight over the same stretch of timeline.
                if var previous = segments.last, previous.isAuto, start < previous.end {
                    previous.end = max(previous.end, end)
                    previous.focusX = (previous.focusX + focusX) / 2
                    previous.focusY = (previous.focusY + focusY) / 2
                    segments[segments.count - 1] = previous
                    continue
                }

                segments.append(ProjectState.ZoomSegment(
                    start: start, end: end,
                    level: settings.level,
                    focusX: focusX, focusY: focusY,
                    followsCursor: settings.followsCursor,
                    isAuto: true
                ))
            }
        }

        segments.sort { $0.start < $1.start }
        return segments
    }
}
