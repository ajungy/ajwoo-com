import Foundation
import CoreGraphics

/// Evaluates the zoom segments in a `ProjectState` down to a single
/// (level, focus) pair for a given instant.
enum ZoomTrack {

    struct State {
        var level: Double
        /// Normalized to the capture frame, top-left origin — the same space as
        /// `events.json`.
        var focus: CGPoint

        static let identity = State(level: 1.0, focus: CGPoint(x: 0.5, y: 0.5))
    }

    static let minLevel: Double = 1.0
    static let maxLevel: Double = 4.0

    /// A segment's influence at time `t`, 0...1, eased at both ends.
    ///
    /// The ramp is clamped to half the segment length so a 0.6 s ramp on a 0.5 s
    /// segment doesn't overshoot — it just ramps faster.
    static func weight(of segment: ProjectState.ZoomSegment, at t: Double) -> Double {
        guard t >= segment.start, t <= segment.end else { return 0 }
        let span = segment.end - segment.start
        guard span > 0 else { return 0 }

        let ramp = max(0.01, min(segment.rampDuration, span / 2))
        let rampIn = Easing.inOutCubic((t - segment.start) / ramp)
        let rampOut = Easing.inOutCubic((segment.end - t) / ramp)
        return min(rampIn, rampOut)
    }

    /// Blends every overlapping segment rather than letting the topmost one win,
    /// so crossing segments cross-fade instead of popping.
    ///
    /// - Parameter followFocus: heavily-smoothed pointer position at `t`, used by
    ///   segments with `followsCursor` set. See `CursorPath.follow`.
    static func state(at t: Double,
                      segments: [ProjectState.ZoomSegment],
                      followFocus: (Double) -> CGPoint?) -> State {
        var weightSum = 0.0
        var levelSum = 0.0
        var focusX = 0.0
        var focusY = 0.0

        for segment in segments {
            let w = weight(of: segment, at: t)
            guard w > 0 else { continue }

            var fx = segment.focusX
            var fy = segment.focusY
            if segment.followsCursor, let tracked = followFocus(t) {
                fx = min(1, max(0, Double(tracked.x)))
                fy = min(1, max(0, Double(tracked.y)))
            }

            weightSum += w
            levelSum += w * segment.level
            focusX += w * fx
            focusY += w * fy
        }

        guard weightSum > 0 else { return .identity }

        // Two separate normalizations, deliberately:
        //  - focus is a weighted average of the contributing segments,
        //  - level fades toward 1.0 as total influence drops below 1, which is
        //    what makes the ramp in/out actually ramp.
        let blend = min(1.0, weightSum)
        let averageLevel = levelSum / weightSum
        return State(
            level: 1.0 + (averageLevel - 1.0) * blend,
            focus: CGPoint(x: focusX / weightSum, y: focusY / weightSum)
        )
    }

    /// The rectangle to crop, in **Core Image space** (origin bottom-left),
    /// absolute within the source image.
    ///
    /// Zoom is a crop of the master, never an upscale of an already-downscaled
    /// frame — that's the whole reason the capture is kept at native resolution.
    /// The crop is clamped inside `base`, so a focus point near an edge slides
    /// the crop rather than exposing black bars.
    ///
    /// - Parameters:
    ///   - base: the effective frame — the whole source, or the user's crop.
    ///     Zoom sizing is relative to this.
    ///   - sourceExtent: the *full* source. `focus` is normalized against this
    ///     regardless of any crop, so it stays in `events.json` space and a
    ///     cursor-follow focus needs no conversion.
    static func cropRect(level: Double, focus: CGPoint, base: CGRect, sourceExtent: CGRect) -> CGRect {
        let clampedLevel = min(maxLevel, max(minLevel, level))
        let width = base.width / clampedLevel
        let height = base.height / clampedLevel

        // events.json focus is top-left origin; Core Image is bottom-left.
        let centerX = sourceExtent.minX + focus.x * sourceExtent.width
        let centerY = sourceExtent.minY + (1.0 - focus.y) * sourceExtent.height

        let clampedX = min(base.maxX - width / 2, max(base.minX + width / 2, centerX))
        let clampedY = min(base.maxY - height / 2, max(base.minY + height / 2, centerY))

        return CGRect(x: clampedX - width / 2, y: clampedY - height / 2, width: width, height: height)
    }

    /// True when the requested zoom would sample fewer source pixels than the
    /// output needs — i.e. we'd be upscaling and the result goes soft.
    static func exceedsNativeDensity(level: Double, sourceSize: CGSize, outputSize: CGSize) -> Bool {
        (sourceSize.width / max(minLevel, level)) < outputSize.width - 1
    }

    /// The highest zoom that still samples at or above 1:1 for this output size.
    static func maxNativeLevel(sourceSize: CGSize, outputSize: CGSize) -> Double {
        guard outputSize.width > 0 else { return maxLevel }
        return max(minLevel, sourceSize.width / outputSize.width)
    }
}
