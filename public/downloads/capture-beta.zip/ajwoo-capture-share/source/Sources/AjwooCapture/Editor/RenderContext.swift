import Foundation
import CoreGraphics

/// The state the renderer needs, shared between the UI thread that edits it and
/// the AVFoundation queues that read it.
///
/// One instance per open recording. The editor mutates `project`; the preview
/// compositor and the exporter read snapshots. Derived data (the resampled
/// cursor path) is rebuilt only when the input that feeds it actually changes,
/// because rebuilding a 120 Hz grid for a ten-minute recording on every slider
/// tick would be noticeable.
final class RenderContext {

    struct Snapshot {
        let project: ProjectState
        let cursorPath: CursorPath
        /// Much heavier smoothing; drives zoom-follow only.
        let followPath: CursorPath
        let clicks: ClickTrack
        let pointerShapes: PointerShapeTrack
        let subtitles: SubtitleTrack
        let sourceSize: CGSize
        let idle: IdleTrack
    }

    let log: EventLog
    let sourceSize: CGSize
    let duration: Double
    let frameRate: Int

    private let lock = NSLock()
    private var _project: ProjectState
    private var _cursorPath: CursorPath
    private let _followPath: CursorPath
    private let _clicks: ClickTrack
    private let _pointerShapes: PointerShapeTrack
    private let _idle: IdleTrack
    private var _subtitles = SubtitleTrack(cues: [])
    private var _transcript: Transcript?
    private var _cuesBuiltFor: Int = -1
    private var _editsBuiltFor: [String: String] = [:]
    private var _smoothingUsed: Double

    init(log: EventLog, project: ProjectState) {
        self.log = log
        self.sourceSize = CGSize(width: log.recording.geometry.framePixelWidth,
                                 height: log.recording.geometry.framePixelHeight)
        self.duration = log.recording.durationSeconds
        self.frameRate = log.recording.frameRate
        self._project = project
        self._smoothingUsed = project.cursor.smoothing
        self._cursorPath = CursorPath(samples: log.cursor,
                                      duration: log.recording.durationSeconds,
                                      smoothing: project.cursor.smoothing)
        // Built once: its smoothing is fixed, so no edit can invalidate it.
        self._followPath = CursorPath.follow(samples: log.cursor,
                                             duration: log.recording.durationSeconds)
        self._clicks = ClickTrack(clicks: log.clicks)
        self._pointerShapes = PointerShapeTrack(changes: log.pointerShapes)
        self._idle = IdleTrack(samples: log.cursor)
    }

    var project: ProjectState {
        get { lock.lock(); defer { lock.unlock() }; return _project }
        set {
            lock.lock(); defer { lock.unlock() }
            let smoothingChanged = abs(newValue.cursor.smoothing - _smoothingUsed) > 0.0001
            _project = newValue
            if newValue.subtitles.wordsPerCue != _cuesBuiltFor
                || newValue.subtitles.edits != _editsBuiltFor {
                rebuildCues(newValue)
            }
            if smoothingChanged {
                _smoothingUsed = newValue.cursor.smoothing
                _cursorPath = CursorPath(samples: log.cursor,
                                         duration: duration,
                                         smoothing: newValue.cursor.smoothing)
            }
        }
    }

    /// The transcript, once it exists. Setting it rebuilds the subtitle cues.
    var transcript: Transcript? {
        get { lock.lock(); defer { lock.unlock() }; return _transcript }
        set {
            lock.lock(); defer { lock.unlock() }
            _transcript = newValue
            rebuildCues(_project)
        }
    }

    /// Cue grouping only depends on the transcript and the words-per-cue
    /// setting, so it's rebuilt when either changes rather than per frame.
    private func rebuildCues(_ project: ProjectState) {
        guard let transcript = _transcript else {
            _subtitles = SubtitleTrack(cues: [])
            _cuesBuiltFor = -1
            _editsBuiltFor = [:]
            return
        }
        let edits = project.subtitles.edits
        let cues = TranscriptAnalysis
            .cues(from: transcript, wordsPerCue: project.subtitles.wordsPerCue)
            .map { cue -> SubtitleCue in
                guard let corrected = edits[ProjectState.Subtitles.editKey(forCueStart: cue.start)] else {
                    return cue
                }
                var edited = cue
                edited.text = corrected
                return edited
            }
        _subtitles = SubtitleTrack(cues: cues)
        _cuesBuiltFor = project.subtitles.wordsPerCue
        _editsBuiltFor = edits
    }

    /// Source size after the user's crop. Export dimensions and aspect derive
    /// from this, not the raw capture, so a cropped recording exports at the
    /// shape you cropped it to rather than being letterboxed back.
    var effectiveSourceSize: CGSize {
        let crop = project.crop
        guard crop.enabled else { return sourceSize }
        return CGSize(width: max(2, (sourceSize.width * crop.width).rounded()),
                      height: max(2, (sourceSize.height * crop.height).rounded()))
    }

    /// What the export (and the live preview, via `EditorModel`'s own copy of
    /// this) actually renders into: `effectiveSourceSize` by default, or a fixed
    /// aspect ratio holding the same pixel area once the background section
    /// picks one. See `ProjectState.Background.canvasSize(for:)`.
    var canvasSize: CGSize {
        project.background.canvasSize(for: effectiveSourceSize)
    }

    /// One consistent read for a single frame — never read `project` and the
    /// cursor path separately, or a mid-frame edit can tear them apart.
    func snapshot() -> Snapshot {
        lock.lock(); defer { lock.unlock() }
        return Snapshot(project: _project, cursorPath: _cursorPath, followPath: _followPath,
                        clicks: _clicks, pointerShapes: _pointerShapes,
                        subtitles: _subtitles, sourceSize: sourceSize, idle: _idle)
    }
}
