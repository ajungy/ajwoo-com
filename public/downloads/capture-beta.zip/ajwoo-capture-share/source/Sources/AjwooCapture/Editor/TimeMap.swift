import Foundation
import CoreMedia

/// Translates between **recording time** and **composition time**.
///
/// # Why this exists
/// Until cuts arrived, the two were the same number: the whole asset was inserted
/// at zero, so `events.json` timestamps could be used directly. Cutting breaks
/// that — remove four seconds at 0:10 and everything after it happens four
/// seconds earlier in the finished video, while the cursor log still says 0:14.
///
/// The alternative would be rewriting `events.json` on every cut, which throws
/// away the original timing and makes cuts destructive. Instead the log stays
/// untouched and this piecewise-linear map does the translation, in one place.
///
/// - **Recording time** — what `events.json`, zoom segments, cuts and the editor
///   timeline all speak. Never changes.
/// - **Composition time** — position in the spliced `AVComposition`, i.e. what
///   the player and the exporter see.
struct TimeMap: Equatable {

    struct Segment: Equatable {
        let recordingStart: Double
        let compositionStart: Double
        let duration: Double

        var recordingEnd: Double { recordingStart + duration }
        var compositionEnd: Double { compositionStart + duration }
    }

    /// Kept ranges, in order, with no gaps in composition time.
    let segments: [Segment]
    let recordingDuration: Double

    var compositionDuration: Double {
        segments.last.map { $0.compositionEnd } ?? 0
    }

    var hasCuts: Bool { segments.count > 1 || compositionDuration < recordingDuration - 0.001 }

    /// Identity map — the whole recording, nothing removed.
    static func identity(duration: Double) -> TimeMap {
        TimeMap(segments: [Segment(recordingStart: 0, compositionStart: 0, duration: max(0, duration))],
                recordingDuration: max(0, duration))
    }

    /// Builds the map for a set of cuts. Overlapping and out-of-order cuts are
    /// merged first, so the caller doesn't have to keep the array tidy.
    init(cuts: [ProjectState.CutRange], duration: Double) {
        let recordingDuration = max(0, duration)
        self.recordingDuration = recordingDuration

        let sorted = cuts
            .map { (start: max(0, min($0.start, $0.end)), end: min(recordingDuration, max($0.start, $0.end))) }
            .filter { $0.end - $0.start > 0.001 }
            .sorted { $0.start < $1.start }

        var merged: [(start: Double, end: Double)] = []
        for cut in sorted {
            if var last = merged.last, cut.start <= last.end {
                last.end = max(last.end, cut.end)
                merged[merged.count - 1] = last
            } else {
                merged.append(cut)
            }
        }

        var result: [Segment] = []
        var recordingCursor = 0.0
        var compositionCursor = 0.0

        for cut in merged {
            let keptLength = cut.start - recordingCursor
            if keptLength > 0.001 {
                result.append(Segment(recordingStart: recordingCursor,
                                      compositionStart: compositionCursor,
                                      duration: keptLength))
                compositionCursor += keptLength
            }
            recordingCursor = max(recordingCursor, cut.end)
        }

        let tail = recordingDuration - recordingCursor
        if tail > 0.001 {
            result.append(Segment(recordingStart: recordingCursor,
                                  compositionStart: compositionCursor,
                                  duration: tail))
        }

        // Everything cut away: keep a degenerate segment so nothing divides by
        // zero downstream. The UI blocks export in this state.
        self.segments = result.isEmpty
            ? [Segment(recordingStart: 0, compositionStart: 0, duration: 0)]
            : result
    }

    private init(segments: [Segment], recordingDuration: Double) {
        self.segments = segments
        self.recordingDuration = recordingDuration
    }

    // MARK: - Translation

    func recordingTime(forComposition t: Double) -> Double {
        guard let first = segments.first else { return t }
        if t <= first.compositionStart { return first.recordingStart }
        for segment in segments where t < segment.compositionEnd {
            guard t >= segment.compositionStart else { continue }
            return segment.recordingStart + (t - segment.compositionStart)
        }
        guard let last = segments.last else { return t }
        return last.recordingEnd
    }

    /// Inverse. A time that falls **inside** a cut has no exact composition
    /// position, so it resolves to the start of the next kept segment — which is
    /// where playback would actually land.
    func compositionTime(forRecording t: Double) -> Double {
        guard let first = segments.first else { return t }
        if t <= first.recordingStart { return first.compositionStart }
        for segment in segments {
            if t < segment.recordingStart { return segment.compositionStart }
            if t <= segment.recordingEnd {
                return segment.compositionStart + (t - segment.recordingStart)
            }
        }
        guard let last = segments.last else { return t }
        return last.compositionEnd
    }

    /// True when this instant is spliced out.
    func isCut(_ t: Double) -> Bool {
        for segment in segments where t >= segment.recordingStart && t <= segment.recordingEnd {
            return false
        }
        return true
    }
}
