import Foundation
import AVFoundation
import Accelerate

/// Reads an audio file down to a small array of peak values for the timeline.
///
/// Peak rather than RMS: on a screen recording the useful signal is "was
/// something happening here", and peaks make short transients — a click, the
/// start of a sentence — visible at timeline scale, where RMS flattens them.
enum WaveformLoader {

    static let bucketCount = 900
    private static let envelopeSampleRate: Double = 8_000

    static func load(url: URL, buckets: Int = bucketCount) async -> [Float] {
        guard FileManager.default.fileExists(atPath: url.path) else { return [] }

        let asset = AVURLAsset(url: url)
        guard let track = try? await asset.loadTracks(withMediaType: .audio).first,
              let duration = try? await asset.load(.duration),
              duration.seconds > 0,
              let reader = try? AVAssetReader(asset: asset)
        else { return [] }

        // Decode to 8 kHz mono. A timeline waveform is an envelope, not audio —
        // this is ~40x less data to walk, and forcing mono means one decoded
        // sample equals one frame, so the bucket index can't drift out by the
        // channel count (a stereo file would otherwise draw into half the strip).
        let output = AVAssetReaderTrackOutput(track: track, outputSettings: [
            AVFormatIDKey: kAudioFormatLinearPCM,
            AVSampleRateKey: envelopeSampleRate,
            AVNumberOfChannelsKey: 1,
            AVLinearPCMBitDepthKey: 32,
            AVLinearPCMIsFloatKey: true,
            AVLinearPCMIsNonInterleaved: false,
            AVLinearPCMIsBigEndianKey: false,
        ])
        guard reader.canAdd(output) else { return [] }
        reader.add(output)
        guard reader.startReading() else { return [] }

        var peaks = [Float](repeating: 0, count: buckets)

        // Bucket while streaming, so memory stays flat regardless of length.
        let totalFrames = max(1.0, duration.seconds * envelopeSampleRate)
        var frameIndex = 0.0

        while reader.status == .reading, let sample = output.copyNextSampleBuffer() {
            guard let blockBuffer = CMSampleBufferGetDataBuffer(sample) else { continue }
            var length = 0
            var pointer: UnsafeMutablePointer<Int8>?
            guard CMBlockBufferGetDataPointer(blockBuffer, atOffset: 0, lengthAtOffsetOut: nil,
                                              totalLengthOut: &length, dataPointerOut: &pointer) == noErr,
                  let raw = pointer else { continue }

            let count = length / MemoryLayout<Float>.size
            raw.withMemoryRebound(to: Float.self, capacity: count) { floats in
                for i in 0..<count {
                    let bucket = min(buckets - 1, max(0, Int(frameIndex / totalFrames * Double(buckets))))
                    peaks[bucket] = max(peaks[bucket], abs(floats[i]))
                    frameIndex += 1
                }
            }
            CMSampleBufferInvalidate(sample)
        }

        // Buckets past the end of the data stay at zero rather than repeating
        // the last value, so a short file reads as short.
        return peaks
    }
}
