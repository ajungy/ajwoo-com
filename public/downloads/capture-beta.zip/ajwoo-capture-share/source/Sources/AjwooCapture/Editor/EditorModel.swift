import Foundation
import SwiftUI
import AVFoundation
import AppKit
import CoreMedia

/// Everything the editor window binds to.
@MainActor
final class EditorModel: ObservableObject {

    enum LoadState: Equatable {
        case loading
        case ready
        case failed(String)
    }

    let session: RecordingSession
    let player = AVPlayer()

    @Published private(set) var loadState: LoadState = .loading
    @Published private(set) var currentTime: Double = 0
    @Published private(set) var duration: Double = 0
    @Published private(set) var isPlaying = false
    @Published private(set) var sourceSize: CGSize = .zero
    @Published private(set) var hasCamera = false
    @Published private(set) var hasSystemAudio = false
    @Published private(set) var hasMicAudio = false
    @Published private(set) var thumbnails: [NSImage] = []
    /// How many filmstrip tiles are still expected. The timeline draws that many
    /// placeholder bars so the row has its final shape from the first paint.
    @Published private(set) var thumbnailSlots: Int = 0
    /// High-resolution mic envelope, used for silence detection. Separate from
    /// `waveformMic`, which is 900 buckets sized for drawing the timeline.
    private var silenceEnvelope: [Float] = []
    /// Drawn separately rather than mixed: the whole point of keeping the tracks
    /// apart is that you can see and balance them independently.
    @Published private(set) var waveformMic: [Float] = []
    @Published private(set) var waveformSystem: [Float] = []
    @Published var selectedZoomID: UUID?
    @Published var statusMessage: String?

    // MARK: - Timeline view zoom
    //
    // The zoom *track* (`project.zoomSegments`) is the video's own Ken Burns
    // effect; this is unrelated — how much of the timeline's own width one
    // second of recording occupies on screen. 1.0 is "fit": the whole
    // recording exactly fills the timeline's width, same as before this
    // existed. Above that the timeline scrolls horizontally.
    @Published var timelineZoom: CGFloat = 1
    private let timelineZoomMin: CGFloat = 1
    private let timelineZoomMax: CGFloat = 8
    private let timelineZoomStep: CGFloat = 1.25

    func zoomTimelineIn() {
        timelineZoom = min(timelineZoomMax, timelineZoom * timelineZoomStep)
    }

    func zoomTimelineOut() {
        timelineZoom = max(timelineZoomMin, timelineZoom / timelineZoomStep)
    }

    func fitTimeline() {
        timelineZoom = timelineZoomMin
    }

    /// For continuous input — a trackpad pinch — rather than the fixed step
    /// the buttons use.
    func setTimelineZoom(_ value: CGFloat) {
        timelineZoom = min(timelineZoomMax, max(timelineZoomMin, value))
    }

    /// Every mutation flows through here; `didSet` pushes it to the renderer,
    /// refreshes the preview and schedules a save.
    @Published var project = ProjectState() {
        didSet {
            guard !isApplyingLoadedProject else { return }
            recordUndo(from: oldValue)
            // Cuts change the shape of the composition itself, so the whole
            // thing has to be rebuilt; everything else only needs a new video
            // composition.
            if oldValue.speech != project.speech {
                regenerateSpeechCuts()
            }
            if oldValue.cuts != project.cuts {
                scheduleCompositionRebuild()
            } else {
                // Audio levels and camera grading are continuous controls: a
                // 40 ms debounce on a slider drag reads as lag, and for audio it
                // means the preview keeps playing at the old level while you're
                // still moving the fader.
                let immediate = oldValue.audio != project.audio
                    || oldValue.camera.filter != project.camera.filter
                pushProjectToRenderer(immediate: immediate)
            }
            scheduleSave()
        }
    }

    @Published var selectedCutID: UUID?

    /// While cropping, the preview shows the whole uncropped, unzoomed frame so
    /// you can see what you're selecting from.
    @Published var isCropping = false {
        didSet {
            guard oldValue != isCropping else { return }
            if isCropping {
                cropBeforeEditing = project.crop
                if !project.crop.enabled { project.crop = .full }
            }
            pushProjectToRenderer()
        }
    }

    private var cropBeforeEditing: ProjectState.Crop = .full
    private var log: EventLog?
    private var context: RenderContext?
    private var composition: EditorComposition?
    private var timeObserver: Any?
    private var refreshTask: Task<Void, Never>?
    private var saveTask: Task<Void, Never>?
    private var rebuildTask: Task<Void, Never>?
    private var isApplyingLoadedProject = false

    /// Composition ↔ recording time. Identity until the first cut.
    private(set) var timeMap: TimeMap = .identity(duration: 0)

    // Undo is snapshot-based: the whole `ProjectState` is small, and edits touch
    // enough separate fields that command objects would be more code and more
    // ways to be wrong.
    private var undoStack: [ProjectState] = []
    private var redoStack: [ProjectState] = []
    private var pendingUndoBase: ProjectState?
    private var undoCommitTask: Task<Void, Never>?
    private var isUndoing = false

    @Published private(set) var canUndo = false
    @Published private(set) var canRedo = false

    // MARK: - Transcript

    enum TranscriptState: Equatable {
        case none
        case running(Double)
        case ready(Int)
        case failed(String)
    }

    @Published private(set) var transcriptState: TranscriptState = .none
    private var transcript: Transcript?
    private var transcribeTask: Task<Void, Never>?
    private var creepTask: Task<Void, Never>?

    var hasTranscript: Bool { !(transcript?.isEmpty ?? true) }
    var canTranscribe: Bool { session.hasMicAudio }

    // The preview composites to this at most; the export always runs at full
    // resolution. Compositing a 4K frame 60 times a second for a window that's
    // 900 px wide is wasted work, and dropping preview frames looks worse than
    // a slightly softer preview.
    // Lowered from 1600 deliberately. With camera, background and subtitles all
    // on, compositing at 1600 dropped preview frames on a 4K source; 1200 holds
    // the frame rate. The preview is visibly softer while editing and the export
    // is unaffected — it always runs at full resolution.
    private static let previewMaxDimension: CGFloat = 1200

    var previewIsDownscaled: Bool {
        max(canvasSize.width, canvasSize.height) > Self.previewMaxDimension
    }

    var sourceFrameRate: Int { context?.frameRate ?? 60 }

    /// The frame after cropping — what the canvas's size and aspect derive from.
    var effectiveSourceSize: CGSize {
        guard project.crop.enabled, !isCropping else { return sourceSize }
        return CGSize(
            width: max(2, (sourceSize.width * project.crop.width).rounded()),
            height: max(2, (sourceSize.height * project.crop.height).rounded())
        )
    }

    /// What actually gets rendered into — the frame everything on screen is
    /// positioned against. Equal to `effectiveSourceSize` by default, or a fixed
    /// aspect ratio once the background section picks one.
    ///
    /// Forced back to `effectiveSourceSize` while cropping, regardless of the
    /// chosen ratio: cropping already shows the whole uncropped frame so you can
    /// see what you're selecting from (`isCropping`'s own doc comment), and
    /// letterboxing that into an unrelated canvas shape while you're trying to
    /// draw a rectangle on it would be actively confusing. `effectiveSourceSize`
    /// already ignores the crop for the same reason while `isCropping` is true,
    /// so this just inherits that.
    var canvasSize: CGSize {
        guard !isCropping else { return effectiveSourceSize }
        return project.background.canvasSize(for: effectiveSourceSize)
    }

    var hasClicks: Bool { !(log?.clicks.isEmpty ?? true) }

    /// Pixel size the current crop rectangle would produce, ignoring whether the
    /// crop is switched on yet — the live readout while dragging the crop tool.
    var effectiveSourceSizeIfCropApplied: CGSize {
        CGSize(width: max(2, (sourceSize.width * project.crop.width).rounded()),
               height: max(2, (sourceSize.height * project.crop.height).rounded()))
    }

    /// Where the video sits inside a preview view of `viewSize`, accounting for
    /// `AVPlayerLayer`'s aspect-fit letterboxing.
    ///
    /// Based on `canvasSize`, not `effectiveSourceSize` — `AVPlayerLayer` fits
    /// the *rendered* frame, and once the background section picks an aspect
    /// ratio that's a different shape than the cropped recording. Camera-bubble
    /// and subtitle dragging both read this rect, so it has to agree with
    /// whatever `outputAspect` (below) uses for the same reason.
    func videoRect(in viewSize: CGSize) -> CGRect {
        let size = canvasSize
        guard size.width > 0, size.height > 0, viewSize.width > 0, viewSize.height > 0 else {
            return CGRect(origin: .zero, size: viewSize)
        }
        let aspect = size.width / size.height
        var width = viewSize.width
        var height = width / aspect
        if height > viewSize.height {
            height = viewSize.height
            width = height * aspect
        }
        return CGRect(x: (viewSize.width - width) / 2, y: (viewSize.height - height) / 2,
                      width: width, height: height)
    }

    var selectedZoom: ProjectState.ZoomSegment? {
        guard let id = selectedZoomID else { return nil }
        return project.zoomSegments.first { $0.id == id }
    }

    var trimStart: Double { project.trimStart }
    var trimEnd: Double { project.trimEnd ?? duration }

    /// Length of the finished video: trimmed range minus whatever the cuts remove.
    var exportedDuration: Double {
        max(0, timeMap.compositionTime(forRecording: trimEnd) - timeMap.compositionTime(forRecording: trimStart))
    }

    var selectedCut: ProjectState.CutRange? {
        guard let id = selectedCutID else { return nil }
        return project.cuts.first { $0.id == id }
    }

    init(session: RecordingSession) {
        self.session = session
    }

    deinit {
        if let timeObserver {
            player.removeTimeObserver(timeObserver)
        }
    }

    // MARK: - Load

    func load() async {
        do {
            // Both of these are JSON decodes — the event log runs to tens of
            // thousands of cursor samples on a long take — so they happen off
            // the main actor. Doing them inline stalled the window before it had
            // drawn anything.
            let eventsURL = session.eventsURL
            let projectURL = session.projectURL
            let (log, stored) = try await Task.detached(priority: .userInitiated) {
                (try EventLog.read(from: eventsURL), try? ProjectState.read(from: projectURL))
            }.value
            self.log = log
            var loaded = stored ?? ProjectState()
            loaded.migrate()

            let context = RenderContext(log: log, project: loaded)
            self.context = context

            let sourceSize = context.sourceSize
            self.sourceSize = sourceSize

            // `loaded.background.canvasSize(for:)` rather than `sourceSize`
            // directly, so a project saved with a custom export aspect opens
            // already showing that shape instead of the recording's own aspect
            // for one frame until the first edit rebuilds it. Based on the raw,
            // uncropped `sourceSize` here rather than the crop-adjusted one —
            // `self.project` (and therefore `effectiveSourceSize`) isn't set
            // until just below, and duplicating that sequencing for this one
            // frame isn't worth the risk to it.
            let composition = try await CompositionBuilder.build(
                session: session,
                context: context,
                renderSize: Self.previewSize(for: loaded.background.canvasSize(for: sourceSize)),
                frameRate: log.recording.frameRate
            )
            self.composition = composition
            self.hasCamera = composition.hasCamera
            self.hasSystemAudio = composition.hasSystemAudio
            self.hasMicAudio = composition.hasMicAudio
            // The timeline works in recording time throughout, so `duration` is
            // the untouched capture length, not the spliced composition length.
            self.duration = max(0.01, composition.recordingDuration.seconds)
            self.timeMap = composition.timeMap

            if loaded.trimEnd == nil { loaded.trimEnd = duration }
            isApplyingLoadedProject = true
            self.project = loaded
            isApplyingLoadedProject = false
            context.project = loaded

            // Auto-zoom ships on, so a project that has never been generated
            // needs its segments built now. The `generated` flag is what stops
            // this resurrecting zooms the user deleted one at a time.
            if loaded.autoZoom.enabled, !loaded.autoZoom.generated {
                regenerateAutoZooms()
            }

            let item = AVPlayerItem(asset: composition.composition)
            item.videoComposition = composition.videoComposition
            item.audioMix = CompositionBuilder.audioMix(for: composition.composition, project: loaded, micEnvelope: silenceEnvelope, timeMap: composition.timeMap)
            player.replaceCurrentItem(with: item)
            player.actionAtItemEnd = .pause

            installTimeObserver()
            loadState = .ready

            seek(to: project.trimStart)

            // Non-blocking extras, in the order they're noticed: filmstrip
            // first because it's the biggest empty area, then the waveform.
            Task(priority: .userInitiated) { await loadThumbnails() }
            Task(priority: .utility) { await loadWaveform() }

            // Transcription starts on its own so subtitles are ready when asked
            // for, but not immediately: for the first second or two the window
            // is still decoding thumbnails and filling the preview, and the
            // recogniser competes with both. A cached transcript is free, so
            // that path applies at once.
            if let cached = try? Transcript.read(from: session.transcriptURL) {
                applyTranscript(cached)
            } else if canTranscribe {
                Task { @MainActor [weak self] in
                    try? await Task.sleep(nanoseconds: 1_500_000_000)
                    guard let self, !Task.isCancelled else { return }
                    self.transcribeIfNeeded()
                }
            }

        } catch {
            loadState = .failed(error.localizedDescription)
        }
    }

    /// Rebuilds the whole `AVComposition`. Only cuts need this — they change the
    /// timeline's shape rather than how a frame is drawn — so it's debounced and
    /// preserves the playhead in recording time.
    private func scheduleCompositionRebuild() {
        context?.project = project
        rebuildTask?.cancel()
        rebuildTask = Task { @MainActor [weak self] in
            try? await Task.sleep(nanoseconds: 250_000_000)
            guard !Task.isCancelled else { return }
            await self?.rebuildComposition()
        }
    }

    private func rebuildComposition() async {
        guard let context, loadState == .ready else { return }
        let resumeAt = currentTime
        let wasPlaying = isPlaying
        pause()

        guard let rebuilt = try? await CompositionBuilder.build(
            session: session,
            context: context,
            renderSize: Self.previewSize(for: canvasSize),
            frameRate: context.frameRate
        ) else { return }

        composition = rebuilt
        timeMap = rebuilt.timeMap

        let item = AVPlayerItem(asset: rebuilt.composition)
        item.videoComposition = rebuilt.videoComposition
        item.audioMix = CompositionBuilder.audioMix(for: rebuilt.composition, project: project, micEnvelope: silenceEnvelope, timeMap: rebuilt.timeMap)
        player.replaceCurrentItem(with: item)
        player.actionAtItemEnd = .pause
        installTimeObserver()

        seek(to: resumeAt)
        if wasPlaying { play() }
    }

    private static func previewSize(for sourceSize: CGSize) -> CGSize {
        guard sourceSize.width > 0, sourceSize.height > 0 else { return CGSize(width: 1280, height: 720) }
        let longest = max(sourceSize.width, sourceSize.height)
        guard longest > previewMaxDimension else { return evenSize(sourceSize) }
        let scale = previewMaxDimension / longest
        return evenSize(CGSize(width: sourceSize.width * scale, height: sourceSize.height * scale))
    }

    private static func evenSize(_ size: CGSize) -> CGSize {
        CGSize(width: CGFloat(Int(size.width.rounded()) & ~1), height: CGFloat(Int(size.height.rounded()) & ~1))
    }

    private func installTimeObserver() {
        if let timeObserver { player.removeTimeObserver(timeObserver) }
        // 10 Hz, not 60.
        //
        // `currentTime` is `@Published`, so every tick re-evaluates the timeline,
        // the inspector and the toolbar — at 60 Hz that was the single biggest
        // source of stutter during playback, and it bought nothing: the playhead
        // is drawn inside a `TimelineView(.animation)` that reads the player's
        // clock directly, so it already moves at display rate. This observer only
        // feeds the timecode readout and the trim-end check.
        timeObserver = player.addPeriodicTimeObserver(
            forInterval: CMTime(value: 1, timescale: 10),
            queue: .main
        ) { [weak self] time in
            MainActor.assumeIsolated {
                guard let self else { return }
                // The player runs on composition time; the whole editor UI runs
                // on recording time. Translate once, here.
                self.currentTime = self.timeMap.recordingTime(forComposition: time.seconds)

                // Playback is bounded by the trim handles, so what you hear and
                // see while editing is what the export will contain.
                let endComposition = self.timeMap.compositionTime(forRecording: self.trimEnd)
                if self.isPlaying, time.seconds >= endComposition - 0.001 {
                    self.pause()
                    self.seek(to: self.trimEnd)
                }
            }
        }
    }

    // MARK: - Transport

    func togglePlayback() { isPlaying ? pause() : play() }

    func play() {
        guard loadState == .ready else { return }
        if currentTime >= trimEnd - 0.05 || currentTime < trimStart {
            seek(to: trimStart)
        }
        player.play()
        isPlaying = true
    }

    func pause() {
        player.pause()
        isPlaying = false
    }

    /// Takes a **recording** time and seeks the player to the matching
    /// composition time. A time inside a cut lands at the start of the next kept
    /// segment, which is where playback would go anyway.
    func seek(to time: Double) {
        let clamped = min(max(0, duration), max(0, time))
        currentTime = clamped
        let composition = timeMap.compositionTime(forRecording: clamped)
        player.seek(to: CMTime(seconds: composition, preferredTimescale: 600),
                    toleranceBefore: .zero, toleranceAfter: .zero)
    }

    func step(by delta: Double) { seek(to: currentTime + delta) }

    /// Playhead position for drawing, in recording time.
    ///
    /// Read straight from `AVPlayer` rather than from the published
    /// `currentTime`, which only updates 60 times a second through an observer
    /// and lands the playhead on visibly quantised steps. Called once per display
    /// frame from the timeline, this is smooth to the pixel.
    func playheadTime() -> Double {
        guard isPlaying else { return currentTime }
        let composition = player.currentTime().seconds
        guard composition.isFinite else { return currentTime }
        return timeMap.recordingTime(forComposition: composition)
    }

    /// Seek for hover scrubbing.
    ///
    /// Deliberately sloppy: a zero-tolerance seek decodes to an exact frame,
    /// which is right when you click but far too slow to fire on every pointer
    /// move. Allowing a frame of slack lets AVFoundation land on the nearest
    /// keyframe-ish position and keeps the preview fluid under the cursor.
    func scrub(to time: Double) {
        guard !isPlaying else { return }
        let clamped = min(max(0, duration), max(0, time))
        guard abs(clamped - currentTime) > 1.0 / 120.0 else { return }
        currentTime = clamped
        let composition = timeMap.compositionTime(forRecording: clamped)
        let tolerance = CMTime(seconds: 1.0 / 30.0, preferredTimescale: 600)
        player.seek(to: CMTime(seconds: composition, preferredTimescale: 600),
                    toleranceBefore: tolerance, toleranceAfter: tolerance)
    }

    // MARK: - Zoom editing

    /// Adds a zoom at the playhead, focused on wherever the cursor actually was.
    /// That's almost always what you want — you're zooming in on the thing you
    /// were pointing at — and it saves a drag in the common case.
    func addZoom() {
        let start = min(currentTime, max(0, duration - 0.5))
        let end = min(duration, start + 2.0)
        guard end > start + 0.2 else { return }

        var focus = CGPoint(x: 0.5, y: 0.5)
        if let snapshot = context?.snapshot(),
           let position = snapshot.cursorPath.position(at: (start + end) / 2) {
            focus = CGPoint(x: min(1, max(0, position.x)), y: min(1, max(0, position.y)))
        }

        let segment = ProjectState.ZoomSegment(
            start: start, end: end, level: 2.0,
            focusX: Double(focus.x), focusY: Double(focus.y)
        )
        project.zoomSegments.append(segment)
        project.zoomSegments.sort { $0.start < $1.start }
        selectedZoomID = segment.id
    }

    func deleteZoom(_ id: UUID) {
        project.zoomSegments.removeAll { $0.id == id }
        if selectedZoomID == id { selectedZoomID = nil }
    }

    func updateZoom(_ id: UUID, _ mutate: (inout ProjectState.ZoomSegment) -> Void) {
        guard let index = project.zoomSegments.firstIndex(where: { $0.id == id }) else { return }
        var segment = project.zoomSegments[index]
        mutate(&segment)

        // Keep segments sane: minimum length, inside the recording.
        segment.start = min(max(0, segment.start), duration - 0.2)
        segment.end = min(duration, max(segment.start + 0.2, segment.end))
        segment.level = min(ZoomTrack.maxLevel, max(ZoomTrack.minLevel, segment.level))
        segment.focusX = min(1, max(0, segment.focusX))
        segment.focusY = min(1, max(0, segment.focusY))
        project.zoomSegments[index] = segment
    }

    /// Pans the selected zoom's focus by a drag on the preview. The content
    /// follows the pointer, so dragging left moves the view left.
    func panFocus(dx: Double, dy: Double, viewSize: CGSize) {
        guard let id = selectedZoomID, viewSize.width > 0, viewSize.height > 0 else { return }
        guard selectedZoom?.followsCursor != true else { return }
        updateZoom(id) { segment in
            let level = max(1, segment.level)
            segment.focusX -= dx / viewSize.width / level
            segment.focusY -= dy / viewSize.height / level
        }
    }

    /// True when the selected zoom would sample below 1:1 for this export size.
    func exceedsNativeDensity(level: Double, outputWidth: CGFloat) -> Bool {
        effectiveSourceSize.width / max(1, level) < outputWidth - 1
    }

    var maxNativeLevelForSource: Double {
        ZoomTrack.maxNativeLevel(sourceSize: effectiveSourceSize, outputSize: effectiveSourceSize)
    }

    // MARK: - Crop

    func beginCropping() {
        pause()
        isCropping = true
    }

    func applyCrop() {
        var crop = project.crop
        crop.clampToFrame()
        // A full-frame crop is the same as no crop; storing it as "enabled"
        // would just be a trap for the aspect-ratio maths later.
        crop.enabled = !(crop.x == 0 && crop.y == 0 && crop.width == 1 && crop.height == 1)
        project.crop = crop
        isCropping = false
    }

    func cancelCropping() {
        project.crop = cropBeforeEditing
        isCropping = false
    }

    func resetCrop() {
        project.crop = .full
    }

    // MARK: - Auto-zoom on click

    /// Rebuilds the auto-generated zooms from the click log.
    ///
    /// Auto segments are tagged with `isAuto`, so regenerating replaces exactly
    /// those and never disturbs a zoom you placed by hand.
    // MARK: - Style sets

    /// Everything back to the shipped defaults, keeping the timeline.
    ///
    /// Cuts, zooms, trim and crop survive: this is a "start the look again"
    /// button, and losing an hour of trimming to it would be unforgivable. It
    /// goes through `project` in one assignment so undo captures it as a single
    /// step.
    func resetStyleToDefaults() {
        var reset = project
        StyleSet(from: ProjectState()).apply(to: &reset)
        // The timeline is not this button's business — including the zooms
        // already on it. Restoring those is the wand's reset, in the toolbar
        // next to the timeline they'd appear on.
        reset.autoZoom.generated = project.autoZoom.generated
        reset.zoomSegments = project.zoomSegments
        project = reset
    }

    func applyStyleSet(_ slot: StyleSet.Slot) {
        guard let set = StyleSet.load(slot) else { return }
        var updated = project
        set.apply(to: &updated)
        updated.autoZoom.generated = project.autoZoom.generated
        updated.zoomSegments = project.zoomSegments
        project = updated
        statusMessage = "Applied \(slot.label)"
    }

    func saveStyleSet(_ slot: StyleSet.Slot) {
        StyleSet.save(StyleSet(from: project), to: slot)
        // Republished so the buttons for empty slots enable straight away.
        objectWillChange.send()
        statusMessage = "Saved \(slot.label)"
    }

    func styleSetExists(_ slot: StyleSet.Slot) -> Bool { StyleSet.exists(slot) }

    /// True when the panel is already showing the shipped defaults.
    ///
    /// Compared as a `StyleSet` rather than field by field, so the comparison
    /// covers exactly what Reset would write — a new setting can't drift out of
    /// this check the way an explicit list of fields would.
    var styleIsDefault: Bool {
        StyleSet(from: project) == StyleSet(from: ProjectState())
    }

    /// True when the panel already matches a saved set, so applying it again
    /// would do nothing.
    func styleMatches(_ slot: StyleSet.Slot) -> Bool {
        guard let stored = StyleSet.load(slot) else { return false }
        return stored == StyleSet(from: project)
    }

    func applyBackgroundPreset(_ preset: ProjectState.Background.Preset) {
        project.background.apply(preset)
        if !project.background.enabled { project.background.enabled = true }
    }

    func backgroundMatches(_ preset: ProjectState.Background.Preset) -> Bool {
        project.background.matches(preset)
    }

    /// Imports a user-picked photo and makes it the background. Copies it
    /// into the app's own storage first — see `BackgroundImageStore` — so it
    /// keeps working even if the original file is moved or deleted.
    func applyCustomBackgroundImage(from url: URL) {
        guard let filename = BackgroundImageStore.importImage(from: url) else {
            statusMessage = "Couldn't read that image"
            return
        }
        project.background.applyCustomImage(filename: filename)
        if !project.background.enabled { project.background.enabled = true }
    }

    /// The photo on the Upload button, so it shows what's actually applied
    /// rather than just a generic icon — `nil` whenever the background isn't
    /// currently a custom upload (a bundled preset or a gradient is active
    /// instead), which is exactly when the button should look like an empty
    /// invitation rather than claim a photo is in use.
    var customBackgroundThumbnail: NSImage? {
        guard let filename = project.background.backgroundImageFilename,
              !project.background.backgroundImageIsBundled
        else { return nil }
        return BackgroundImageStore.nsImage(filename: filename, bundled: false)
    }

    /// The auto zooms this recording's clicks and current settings would
    /// produce, without touching the timeline.
    ///
    /// Used to tell the panel what "as generated" looks like, so an edited or
    /// deleted zoom can be reported as such and put back.
    /// The full set auto-zoom would generate, with nothing excluded — this is
    /// what the wand tool compares the live timeline against, so a click near
    /// the end that `regenerateAutoZooms` chose to leave out still shows up
    /// there as "removed," with the normal one-click restore. Excluding it here
    /// too would mean it simply never existed as far as the wand is concerned,
    /// and there'd be nothing to click.
    func autoZoomBlueprint() -> [ProjectState.ZoomSegment] {
        buildAutoZooms(existing: [], excludingTrailingMenuBarClick: false)
    }

    func regenerateAutoZooms() {
        project.zoomSegments = buildAutoZooms(existing: project.zoomSegments.filter { !$0.isAuto },
                                              excludingTrailingMenuBarClick: true)
        project.autoZoom.generated = true
    }

    private func buildAutoZooms(existing: [ProjectState.ZoomSegment],
                                excludingTrailingMenuBarClick: Bool) -> [ProjectState.ZoomSegment] {
        guard let log else { return existing.sorted { $0.start < $1.start } }
        return AutoZoomGenerator.segments(clicks: log.clicks,
                                          settings: project.autoZoom,
                                          duration: duration,
                                          existing: existing,
                                          excludingTrailingMenuBarClick: excludingTrailingMenuBarClick)
    }

    var autoZoomCount: Int { project.zoomSegments.filter(\.isAuto).count }

    // MARK: - Auto zooms (the wand)

    /// One generated zoom, and what's become of it.
    struct AutoZoomStatus: Identifiable {
        enum State { case unchanged, edited, removed }
        let id: Int
        let blueprint: ProjectState.ZoomSegment
        let live: ProjectState.ZoomSegment?
        let state: State
    }

    /// Compares what auto-zoom would generate against what's on the timeline.
    ///
    /// Matching is by overlap rather than by id: an auto segment keeps its id
    /// through an edit but gets a fresh one on regeneration, so ids can't be
    /// relied on across both. Overlap is what a person would use to say "that's
    /// the same zoom, moved".
    var autoZoomStatuses: [AutoZoomStatus] {
        let live = project.zoomSegments.filter(\.isAuto)
        return autoZoomBlueprint().enumerated().map { index, blueprint in
            let match = live.first { $0.start < blueprint.end && $0.end > blueprint.start }
            guard let match else {
                return AutoZoomStatus(id: index, blueprint: blueprint, live: nil, state: .removed)
            }
            let same = abs(match.start - blueprint.start) < 0.05
                && abs(match.end - blueprint.end) < 0.05
                && abs(match.level - blueprint.level) < 0.01
            return AutoZoomStatus(id: index, blueprint: blueprint, live: match,
                                  state: same ? .unchanged : .edited)
        }
    }

    var autoZoomsAreModified: Bool {
        autoZoomStatuses.contains { $0.state != .unchanged }
    }

    /// Puts one generated zoom back exactly as it was made.
    func restoreAutoZoom(_ status: AutoZoomStatus) {
        var segments = project.zoomSegments
        if let live = status.live {
            segments.removeAll { $0.id == live.id }
        }
        segments.append(status.blueprint)
        segments.sort { $0.start < $1.start }
        project.zoomSegments = segments
    }

    func removeAutoZoom(_ status: AutoZoomStatus) {
        guard let live = status.live else { return }
        project.zoomSegments.removeAll { $0.id == live.id }
        if selectedZoomID == live.id { selectedZoomID = nil }
    }

    /// Every generated zoom back as first made, leaving hand-added ones alone.
    func restoreAllAutoZooms() {
        regenerateAutoZooms()
        statusMessage = "Automatic zooms restored"
    }

    /// Clears the generated zooms without touching anything added by hand.
    func removeAllAutoZooms() {
        project.zoomSegments.removeAll(where: \.isAuto)
        selectedZoomID = nil
        statusMessage = "Automatic zooms removed"
    }

    // MARK: - Trim

    func setTrimStart(_ t: Double) {
        project.trimStart = min(max(0, t), trimEnd - 0.2)
    }

    func setTrimEnd(_ t: Double) {
        project.trimEnd = max(min(duration, t), trimStart + 0.2)
    }

    // MARK: - Transcription

    /// Transcribes the microphone track, caching the result in the package so
    /// re-opening a recording doesn't re-run it.
    func transcribeIfNeeded() {
        guard canTranscribe, transcript == nil, transcribeTask == nil else { return }

        if let cached = try? Transcript.read(from: session.transcriptURL) {
            applyTranscript(cached)
            return
        }

        transcriptState = .running(0.01)
        startTranscriptionCreep()
        transcribeTask = Task { @MainActor in
            do {
                let result = try await Transcriber.transcribe(session: session) { value in
                    Task { @MainActor in
                        guard case .running(let shown) = self.transcriptState else { return }
                        // Never go backwards: the creep may already be ahead of
                        // the recogniser's first real report.
                        self.transcriptState = .running(max(shown, value))
                    }
                }
                try? result.write(to: session.transcriptURL)
                applyTranscript(result)
            } catch {
                transcriptState = .failed(error.localizedDescription)
            }
            creepTask?.cancel()
            creepTask = nil
            transcribeTask = nil
        }
    }

    /// Speech recognition reports nothing until it has decoded a chunk, so the
    /// bar sits at zero for several seconds and reads as hung. This advances it
    /// on a curve that decelerates toward 85% — it never claims to be finished,
    /// and real progress overtakes it as soon as it arrives.
    private func startTranscriptionCreep() {
        creepTask?.cancel()
        creepTask = Task { @MainActor [weak self] in
            var elapsed = 0.0
            while !Task.isCancelled {
                try? await Task.sleep(nanoseconds: 120_000_000)
                guard let self, case .running(let shown) = self.transcriptState else { return }
                elapsed += 0.12
                let ceiling = 0.85 * (1 - exp(-elapsed / 4))
                if ceiling > shown { self.transcriptState = .running(ceiling) }
            }
        }
    }

    private func applyTranscript(_ result: Transcript) {
        transcript = result
        context?.transcript = result
        transcriptState = .ready(result.words.count)
        regenerateSpeechCuts()
        scheduleRefresh()
    }

    /// Rebuilds the transcript-derived cuts — filler words and long silences.
    ///
    /// They're ordinary `CutRange`s tagged `isAuto`, so they show on the timeline,
    /// can be dragged or deleted individually, and reuse the whole existing cut
    /// pipeline rather than needing a second mechanism.
    func regenerateSpeechCuts() {
        var cuts = project.cuts.filter { $0.origin == .manual }

        // `fillerCutState`/`silenceCutState` used to re-run this same analysis
        // on every SwiftUI render — including every frame of playback, since
        // `currentTime` publishes constantly — to compare what's on the
        // timeline against what a fresh run would produce. On a several-
        // thousand-word transcript that made the whole editor, checkboxes
        // included, stutter unresponsive for as long as playback kept the
        // redraws coming. The generated counts are cached here instead, the
        // one place this analysis actually needs to run, and the tri-state
        // checkboxes below just compare against the cached number.
        if let transcript, project.speech.removeFillers {
            let fillerCuts = TranscriptAnalysis.fillerCuts(in: transcript)
            cuts += fillerCuts
            generatedFillerCutCount = fillerCuts.count
        } else {
            generatedFillerCutCount = 0
        }

        // Silence comes from the audio, not the transcript — see SilenceDetector
        // for why. It's deliberately independent of `transcript` so it still
        // works while transcription is running.
        if project.speech.removeSilences, !silenceEnvelope.isEmpty {
            let silences = SilenceDetector.silences(in: silenceEnvelope,
                                                     duration: duration,
                                                     minimumLength: project.speech.silenceThreshold)
            cuts += silences.map { ProjectState.CutRange(start: $0.lowerBound, end: $0.upperBound, origin: .silence) }
            generatedSilenceCutCount = silences.count
        } else {
            generatedSilenceCutCount = 0
        }

        cuts.sort { $0.start < $1.start }
        guard cuts != project.cuts else { return }
        project.cuts = cuts
        if let id = selectedCutID, !cuts.contains(where: { $0.id == id }) { selectedCutID = nil }

        // Ticking these boxes changes the length of the video, so waiting out the
        // 250 ms cut debounce means the timeline and the preview disagree with
        // the checkbox you just clicked. Cut regeneration is a discrete action,
        // not a drag, so there's nothing to coalesce.
        rebuildTask?.cancel()
        rebuildTask = Task { @MainActor [weak self] in
            await self?.rebuildComposition()
        }
    }

    var autoCutCount: Int { project.cuts.filter(\.isAuto).count }

    /// Whether a speech-editing checkbox reads as off, fully applied, or
    /// mixed — mixed meaning the box is checked but the user has individually
    /// deleted (or the box otherwise no longer matches) some of what would be
    /// freshly generated right now.
    enum SpeechCutState { case off, on, mixed }

    /// How many filler/silence cuts the *last* `regenerateSpeechCuts()` run
    /// generated — cheap to compare against on every render, unlike redoing
    /// the transcript scan or silence detection itself. See the comment in
    /// `regenerateSpeechCuts()`.
    private var generatedFillerCutCount = 0
    private var generatedSilenceCutCount = 0

    var fillerCutState: SpeechCutState {
        guard project.speech.removeFillers else { return .off }
        guard generatedFillerCutCount > 0 else { return .on }
        let surviving = project.cuts.filter { $0.origin == .filler }.count
        return surviving == generatedFillerCutCount ? .on : .mixed
    }

    var silenceCutState: SpeechCutState {
        guard project.speech.removeSilences else { return .off }
        guard generatedSilenceCutCount > 0 else { return .on }
        let surviving = project.cuts.filter { $0.origin == .silence }.count
        return surviving == generatedSilenceCutCount ? .on : .mixed
    }

    /// Position and length *in the exported video*, or nil when the export is
    /// the same as the recording.
    ///
    /// The white line above it counts through the recording; this one counts
    /// through what will actually be produced. With cuts in place those two
    /// disagree, and the second number is the one you quote to someone.
    var exportedTimecode: String? {
        guard duration - exportedDuration > 0.05, exportedDuration > 0 else { return nil }
        let position = timeMap.compositionTime(forRecording: currentTime)
            - timeMap.compositionTime(forRecording: trimStart)
        let clamped = min(max(0, position), exportedDuration)
        return "\(Timecode.format(clamped)) / \(Timecode.format(exportedDuration))"
    }

    // MARK: - Subtitle editing

    /// The caption on screen at the playhead, if any.
    ///
    /// Built from the same grouping the renderer uses, so what you double-click
    /// is exactly what's being drawn — including any correction already applied.
    var currentCue: SubtitleCue? {
        guard project.subtitles.enabled, let transcript, !transcript.isEmpty else { return nil }
        let cues = TranscriptAnalysis.cues(from: transcript,
                                           wordsPerCue: project.subtitles.wordsPerCue)
        guard let cue = SubtitleTrack(cues: cues).cue(at: currentTime) else { return nil }
        var resolved = cue
        if let corrected = project.subtitles.edits[ProjectState.Subtitles.editKey(forCueStart: cue.start)] {
            resolved.text = corrected
        }
        return resolved
    }

    /// Stores a correction for the cue starting at `cueStart`.
    ///
    /// Setting it back to the recogniser's own text removes the override rather
    /// than storing a no-op, so `edits` only ever holds real corrections and a
    /// later re-transcription isn't shadowed by stale identical entries.
    func setSubtitleText(_ text: String, forCueStart cueStart: Double) {
        let key = ProjectState.Subtitles.editKey(forCueStart: cueStart)
        let trimmed = text.trimmingCharacters(in: .whitespacesAndNewlines)

        let original = transcript.map {
            TranscriptAnalysis.cues(from: $0, wordsPerCue: project.subtitles.wordsPerCue)
                .first { ProjectState.Subtitles.editKey(forCueStart: $0.start) == key }?.text
        } ?? nil

        if trimmed.isEmpty || trimmed == original {
            guard project.subtitles.edits[key] != nil else { return }
            project.subtitles.edits.removeValue(forKey: key)
        } else {
            guard project.subtitles.edits[key] != trimmed else { return }
            project.subtitles.edits[key] = trimmed
        }
    }

    /// Bubble-style placement for the caption block, in output-normalized space.
    var subtitleNormalizedRect: CGRect {
        let settings = project.subtitles
        // Height is an estimate: two lines at the chosen size plus padding. It
        // only drives the drag target, and being a little generous is better
        // than a target smaller than the text.
        let height = min(0.4, settings.fontSize * 2.9)
        return CGRect(x: settings.centerX - settings.width / 2,
                      y: settings.centerY - height / 2,
                      width: settings.width,
                      height: height)
    }

    func moveSubtitles(toCenter point: CGPoint) {
        project.subtitles.centerX = min(1, max(0, Double(point.x)))
        project.subtitles.centerY = min(1, max(0, Double(point.y)))
    }

    func resizeSubtitles(toWidthFraction width: Double) {
        project.subtitles.width = min(0.95, max(0.2, width))
    }

    // MARK: - Cuts

    /// Adds a cut at the playhead. Like zooms, it starts at a workable default
    /// length and you drag its edges — no modal range-selection step.
    func addCut() {
        let start = min(currentTime, max(0, duration - 0.4))
        let end = min(duration, start + 1.5)
        guard end > start + 0.2 else { return }

        // Don't stack a cut on top of an existing one; extend instead.
        if let index = project.cuts.firstIndex(where: { start < $0.end && end > $0.start }) {
            var existing = project.cuts[index]
            existing.start = min(existing.start, start)
            existing.end = max(existing.end, end)
            project.cuts[index] = existing
            selectedCutID = existing.id
            return
        }

        let cut = ProjectState.CutRange(start: start, end: end)
        project.cuts.append(cut)
        project.cuts.sort { $0.start < $1.start }
        selectedCutID = cut.id
        selectedZoomID = nil
    }

    func deleteCut(_ id: UUID) {
        project.cuts.removeAll { $0.id == id }
        if selectedCutID == id { selectedCutID = nil }
    }

    func updateCut(_ id: UUID, _ mutate: (inout ProjectState.CutRange) -> Void) {
        guard let index = project.cuts.firstIndex(where: { $0.id == id }) else { return }
        var cut = project.cuts[index]
        mutate(&cut)
        cut.start = min(max(0, cut.start), duration - 0.1)
        cut.end = min(duration, max(cut.start + 0.1, cut.end))
        project.cuts[index] = cut
    }

    var totalCutDuration: Double {
        let map = TimeMap(cuts: project.cuts, duration: duration)
        return max(0, duration - map.compositionDuration)
    }

    // MARK: - Undo / redo

    /// Coalesces a burst of edits into one undo entry.
    ///
    /// Dragging a slider fires `didSet` sixty times a second; without this you'd
    /// need sixty ⌘Z presses to get back. The base state is captured on the first
    /// change and committed once the edits stop for 500 ms.
    private func recordUndo(from previous: ProjectState) {
        guard !isUndoing else { return }
        if pendingUndoBase == nil { pendingUndoBase = previous }

        undoCommitTask?.cancel()
        undoCommitTask = Task { @MainActor [weak self] in
            try? await Task.sleep(nanoseconds: 500_000_000)
            guard !Task.isCancelled, let self, let base = self.pendingUndoBase else { return }
            self.pendingUndoBase = nil
            guard base != self.project else { return }
            self.undoStack.append(base)
            if self.undoStack.count > 100 { self.undoStack.removeFirst() }
            self.redoStack.removeAll()
            self.refreshUndoFlags()
        }
        refreshUndoFlags()
    }

    /// Flushes any in-flight edit burst so ⌘Z right after a drag does the
    /// expected thing rather than nothing.
    private func commitPendingUndo() {
        undoCommitTask?.cancel()
        undoCommitTask = nil
        if let base = pendingUndoBase, base != project {
            undoStack.append(base)
            redoStack.removeAll()
        }
        pendingUndoBase = nil
    }

    func undo() {
        commitPendingUndo()
        guard let previous = undoStack.popLast() else { return }
        redoStack.append(project)
        apply(previous)
    }

    func redo() {
        commitPendingUndo()
        guard let next = redoStack.popLast() else { return }
        undoStack.append(project)
        apply(next)
    }

    private func apply(_ state: ProjectState) {
        isUndoing = true
        let cutsChanged = state.cuts != project.cuts
        project = state
        isUndoing = false
        if cutsChanged { scheduleCompositionRebuild() }
        if let id = selectedZoomID, !state.zoomSegments.contains(where: { $0.id == id }) {
            selectedZoomID = nil
        }
        if let id = selectedCutID, !state.cuts.contains(where: { $0.id == id }) {
            selectedCutID = nil
        }
        refreshUndoFlags()
    }

    private func refreshUndoFlags() {
        canUndo = !undoStack.isEmpty || pendingUndoBase != nil
        canRedo = !redoStack.isEmpty
    }

    // MARK: - Camera placement

    /// Aspect of the actual render canvas — what `FrameRenderer` positions the
    /// camera bubble's normalized fractions against. Has to be `canvasSize`,
    /// not the content's own aspect, or the bubble would drag to one place in
    /// the preview and render in another the moment a custom export aspect is
    /// chosen.
    var outputAspect: Double {
        let size = canvasSize
        guard size.height > 0 else { return 16.0 / 9.0 }
        return size.width / size.height
    }

    /// Bubble rect normalized to the output frame, top-left origin.
    var cameraNormalizedRect: CGRect {
        project.camera.normalizedRect(outputAspect: outputAspect)
    }

    func moveCamera(toCenter point: CGPoint) {
        project.camera.centerX = Double(point.x)
        project.camera.centerY = Double(point.y)
        project.camera.clampToFrame(outputAspect: outputAspect)
    }

    func resizeCamera(toHeightFraction height: Double) {
        project.camera.size = height
        project.camera.clampToFrame(outputAspect: outputAspect)
    }

    func applyCameraFilterPreset(_ preset: ProjectState.CameraFilter.Preset) {
        project.camera.filter = .values(for: preset)
    }

    // MARK: - Preview refresh

    /// Coalesces the storm of edits a slider drag produces into one refresh per
    /// ~40 ms. Without this, dragging the zoom slider rebuilds the video
    /// composition sixty times a second and the preview stutters.
    private func scheduleRefresh() {
        refreshTask?.cancel()
        refreshTask = Task { @MainActor [weak self] in
            try? await Task.sleep(nanoseconds: 40_000_000)
            guard !Task.isCancelled else { return }
            self?.refreshPreview()
        }
    }

    /// Hands the renderer what it should currently draw. That is normally just
    /// `project`, but while the crop tool is open it's a doctored copy with the
    /// crop and all zooms disabled — you can't choose a crop region from a frame
    /// that's already cropped and zoomed into.
    private func pushProjectToRenderer(immediate: Bool = false) {
        guard let context else { return }
        if isCropping {
            var preview = project
            preview.crop.enabled = false
            preview.zoomSegments = []
            // The padded background insets the picture and rounds its corners,
            // so cropping against it means dragging a rectangle over a shrunken,
            // clipped version of the frame — every edge you pick is wrong by the
            // padding. It's switched off for the duration and restored on exit;
            // the setting itself is untouched.
            preview.background.enabled = false
            context.project = preview
        } else {
            context.project = project
        }

        // The mix is cheap to rebuild and takes effect on the playing item, so
        // it's applied straight away rather than waiting for the refresh.
        if immediate, let composition, let item = player.currentItem {
            item.audioMix = CompositionBuilder.audioMix(for: composition.composition, project: project, micEnvelope: silenceEnvelope, timeMap: composition.timeMap)
            refreshPreview()
        } else {
            scheduleRefresh()
        }
    }

    private func refreshPreview() {
        guard let composition, let context, let item = player.currentItem else { return }

        item.videoComposition = CompositionBuilder.makeVideoComposition(
            context: context,
            duration: composition.duration,
            renderSize: Self.previewSize(for: canvasSize),
            frameRate: context.frameRate,
            hasCamera: composition.hasCamera,
            timeMap: timeMap
        )
        item.audioMix = CompositionBuilder.audioMix(for: composition.composition, project: project, micEnvelope: silenceEnvelope, timeMap: composition.timeMap)

        // A paused player won't redraw on its own; a zero-tolerance seek to the
        // current time forces the new composition through.
        if !isPlaying {
            let composition = timeMap.compositionTime(forRecording: currentTime)
            player.seek(to: CMTime(seconds: composition, preferredTimescale: 600),
                        toleranceBefore: .zero, toleranceAfter: .zero)
        }
    }

    // MARK: - Save

    private func scheduleSave() {
        saveTask?.cancel()
        let snapshot = project
        let url = session.projectURL
        saveTask = Task { @MainActor in
            try? await Task.sleep(nanoseconds: 400_000_000)
            guard !Task.isCancelled else { return }
            try? snapshot.write(to: url)
        }
    }

    func saveNow() {
        saveTask?.cancel()
        try? project.write(to: session.projectURL)
    }

    // MARK: - Filmstrip

    /// Thumbnails come from the raw screen file, not the composited output, so
    /// the filmstrip is a stable map of the recording rather than something that
    /// reshuffles every time you add a zoom.
    /// Fills the filmstrip.
    ///
    /// This used to ask for fourteen frames one at a time and publish nothing
    /// until the last arrived, so the strip sat empty for a second or more on a
    /// long recording. `images(for:)` batches the requests into one decode pass,
    /// and each frame is published as it lands so the strip fills in visibly
    /// instead of appearing all at once at the end.
    ///
    /// `maximumSize` is the displayed size, not the source size — decoding 320 px
    /// tiles to draw them 48 pt tall was most of the cost.
    private func loadThumbnails() async {
        let asset = AVURLAsset(url: session.screenVideoURL)
        let generator = AVAssetImageGenerator(asset: asset)
        generator.appliesPreferredTrackTransform = true
        generator.maximumSize = CGSize(width: 240, height: 120)
        // Wide tolerance means it can decode the nearest keyframe rather than
        // hunting for an exact one. At filmstrip size the difference is invisible.
        generator.requestedTimeToleranceBefore = CMTime(seconds: 1.5, preferredTimescale: 600)
        generator.requestedTimeToleranceAfter = CMTime(seconds: 1.5, preferredTimescale: 600)

        let count = 14
        thumbnailSlots = count
        let times = (0..<count).map {
            CMTime(seconds: duration * (Double($0) + 0.5) / Double(count), preferredTimescale: 600)
        }

        var images: [NSImage] = []
        for await result in generator.images(for: times) {
            guard !Task.isCancelled else { return }
            guard let cgImage = try? result.image else { continue }
            images.append(NSImage(cgImage: cgImage, size: .zero))
            thumbnails = images
        }
        thumbnailSlots = 0
    }

    /// Loads both tracks.
    ///
    /// This used to load only one, preferring `system.m4a` whenever it existed —
    /// which is always, since system audio is captured by default. A take where
    /// nothing was playing therefore drew a flat line even though the mic track
    /// was full of narration.
    private func loadWaveform() async {
        async let mic = WaveformLoader.load(url: session.micAudioURL)
        async let system = WaveformLoader.load(url: session.systemAudioURL)
        let (micSamples, systemSamples) = await (mic, system)
        waveformMic = micSamples
        waveformSystem = systemSamples

        // Silence detection needs far finer buckets than the drawn waveform.
        let buckets = max(64, Int(duration * Double(SilenceDetector.bucketsPerSecond)))
        silenceEnvelope = await WaveformLoader.load(url: session.micAudioURL, buckets: buckets)
        if project.speech.removeSilences { regenerateSpeechCuts() }
    }

    var hasAnyWaveform: Bool { !waveformMic.isEmpty || !waveformSystem.isEmpty }


    // MARK: - Export support

    func makeExportContext() -> (RenderContext, RecordingSession)? {
        guard let context else { return nil }
        return (context, session)
    }
}
