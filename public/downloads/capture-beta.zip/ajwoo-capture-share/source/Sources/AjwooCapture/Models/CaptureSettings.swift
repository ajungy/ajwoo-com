import Foundation
import AVFoundation
import VideoToolbox

struct CaptureSettings: Equatable {
    enum MasterCodec: String, Codable, CaseIterable, Identifiable {
        case hevc, h264
        var id: String { rawValue }
        var displayName: String { self == .hevc ? "HEVC" : "H.264" }
        var avCodec: AVVideoCodecType { self == .hevc ? .hevc : .h264 }
    }

    /// Frame rates worth offering.
    ///
    /// 15 and 24 are there for the "this is a walkthrough, not a game" case,
    /// where the file is the thing you care about; 120 is for demonstrating
    /// something that actually moves. File size scales close to linearly with
    /// this, so 15 fps is roughly a quarter of 60.
    static let frameRateOptions = [15, 24, 30, 60, 120]

    var frameRate: Int = 60
    var codec: MasterCodec = .hevc
    var quality: Quality = .balanced

    /// How fat the capture master runs.
    ///
    /// The master is never shown to anyone — it exists to be cropped and
    /// re-encoded at export, and a zoom crop magnifies whatever artifacts are in
    /// it. `balanced` is what shipped and is right for almost everything;
    /// `fine` exists for recordings that will be zoomed hard or archived, and
    /// `light` for long sessions where the disk matters more than a zoom into
    /// eight-point text.
    enum Quality: String, Codable, CaseIterable, Identifiable {
        case light, balanced, fine

        var id: String { rawValue }

        var label: String {
            switch self {
            case .light:    return "Smaller file"
            case .balanced: return "Balanced"
            case .fine:     return "Best quality"
            }
        }

        var detail: String {
            switch self {
            case .light:    return "About a third the size. Fine unless you zoom in hard."
            case .balanced: return "The right choice for almost everything."
            case .fine:     return "About double the size. For heavy zooming or archiving."
            }
        }

        /// Multiplies the bits-per-pixel budget and the floor together, so the
        /// setting still means something at 1080p where the floor dominates.
        var bitrateScale: Double {
            switch self {
            case .light:    return 0.35
            case .balanced: return 1.0
            case .fine:     return 2.0
            }
        }
    }
    var capturesSystemAudio: Bool = true

    /// `AVCaptureDevice.uniqueID`, or nil to record without that device.
    var cameraDeviceID: String?
    var microphoneDeviceID: String?
    /// Where the floating webcam preview parks while recording. This is purely a
    /// capture-time convenience — the bubble's real position is chosen later by
    /// dragging it on the editor preview, and `camera.mov` is always full-frame.
    var cameraPreviewCorner: PreviewCorner = .bottomRight

    enum PreviewCorner: String, Codable, CaseIterable, Identifiable {
        case bottomLeft, bottomRight, topLeft, topRight
        var id: String { rawValue }
        var label: String {
            switch self {
            case .bottomLeft:  return "Bottom Left"
            case .bottomRight: return "Bottom Right"
            case .topLeft:     return "Top Left"
            case .topRight:    return "Top Right"
            }
        }
    }

    /// Include ajwoo capture's own windows in the recording.
    ///
    /// Off by default — `SCContentFilter` excludes us, so the recorder never
    /// appears in its own output. Switch it on to record the app itself: the
    /// main window, the editor, popovers, the camera preview, all of it. That's
    /// the only way to make a video *about* ajwoo capture.
    var includeAppWindows: Bool = false

    /// Draws a crosshair on screen at the position we just logged, round-tripped
    /// through `CaptureGeometry`. Verification aid, off by default.

    /// Bits per pixel for the capture master.
    ///
    /// The master is never shown to anyone — it exists to be cropped and
    /// re-encoded at export, and a zoom crop magnifies whatever artifacts are in
    /// it. So this runs deliberately fat: ~99 Mbps at 4K60, ~44 Mbps at 1440p60,
    /// with a 40 Mbps floor so 1080p masters don't get starved.
    static let masterBitsPerPixel: Double = 0.2
    /// Floor **per frame per second**, not an absolute number.
    ///
    /// An absolute 40 Mbps floor meant 1080p at 15 fps and 1080p at 60 fps came
    /// out at the same target — so choosing a lower frame rate to get a smaller
    /// file did nothing at exactly the resolutions where people would try it.
    /// This is the old floor divided by 60, so 60 fps is unchanged and 15 fps
    /// gets a quarter of the budget, which is the point of picking it.
    static let masterBitrateFloorPerFPS = 40_000_000.0 / 60.0
    static let masterBitrateCeiling = 240_000_000

    func masterBitrate(pixelWidth: Int, pixelHeight: Int) -> Int {
        let scale = quality.bitrateScale
        let raw = Double(pixelWidth * pixelHeight * frameRate) * Self.masterBitsPerPixel * scale
        let floor = Self.masterBitrateFloorPerFPS * Double(frameRate) * scale
        return min(Self.masterBitrateCeiling, max(Int(floor), Int(raw)))
    }

    func videoOutputSettings(pixelWidth: Int, pixelHeight: Int) -> [String: Any] {
        var compression: [String: Any] = [
            AVVideoAverageBitRateKey: masterBitrate(pixelWidth: pixelWidth, pixelHeight: pixelHeight),
            AVVideoExpectedSourceFrameRateKey: frameRate,
            AVVideoMaxKeyFrameIntervalKey: frameRate * 2,
            // Screen content: no B-frames. Cheaper to encode, and keeps the
            // decode order identical to presentation order for scrubbing.
            AVVideoAllowFrameReorderingKey: false,
        ]
        switch codec {
        case .hevc:
            compression[AVVideoProfileLevelKey] = kVTProfileLevel_HEVC_Main_AutoLevel
        case .h264:
            compression[AVVideoProfileLevelKey] = AVVideoProfileLevelH264HighAutoLevel
        }

        return [
            AVVideoCodecKey: codec.avCodec,
            AVVideoWidthKey: pixelWidth,
            AVVideoHeightKey: pixelHeight,
            AVVideoCompressionPropertiesKey: compression,
            AVVideoColorPropertiesKey: [
                AVVideoColorPrimariesKey: AVVideoColorPrimaries_ITU_R_709_2,
                AVVideoTransferFunctionKey: AVVideoTransferFunction_ITU_R_709_2,
                AVVideoYCbCrMatrixKey: AVVideoYCbCrMatrix_ITU_R_709_2,
            ],
        ]
    }

    static let audioSampleRate: Double = 48_000
    static let audioChannelCount: Int = 2

    static var audioOutputSettings: [String: Any] {
        [
            AVFormatIDKey: kAudioFormatMPEG4AAC,
            AVSampleRateKey: audioSampleRate,
            AVNumberOfChannelsKey: audioChannelCount,
            AVEncoderBitRateKey: 256_000,
        ]
    }
}
