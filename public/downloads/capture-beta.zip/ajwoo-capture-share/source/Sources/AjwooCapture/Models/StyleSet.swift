import Foundation

/// A saved look — everything about *how* a recording is presented, with nothing
/// about *what* it contains.
///
/// # What's in and what's out
/// Cursor, background, camera, subtitle styling, audio levels and the auto-zoom
/// parameters are in: they're choices about presentation that you'd want applied
/// to the next recording too.
///
/// Zoom segments, cuts, trim points, the crop rectangle and hand-corrected
/// caption text are out. They're bound to one recording's timeline, and applying
/// them to a different take would produce cuts at meaningless timestamps. That's
/// the line: a set is a style, not an edit.
///
/// Stored in `UserDefaults` rather than beside a recording, because the whole
/// point is to carry a look from one recording to the next.
struct StyleSet: Codable, Equatable {

    var autoZoom: ProjectState.AutoZoom
    var cursor: ProjectState.CursorStyle
    var background: ProjectState.Background
    var camera: ProjectState.CameraOverlay
    var subtitles: ProjectState.Subtitles
    var audio: ProjectState.AudioMix
    var speech: ProjectState.SpeechEdits

    init(from project: ProjectState) {
        autoZoom = project.autoZoom
        cursor = project.cursor
        background = project.background
        camera = project.camera
        subtitles = project.subtitles
        audio = project.audio
        speech = project.speech
        // Corrections belong to the words they correct, not to a look.
        subtitles.edits = [:]
        // `generated` records whether this recording's zooms have been built
        // yet. It's bookkeeping, not a setting — and leaving it in meant a
        // freshly-opened project could never compare equal to the defaults,
        // because opening one builds its zooms and flips the flag. That's why
        // Reset stayed enabled on a project that was already untouched.
        autoZoom.generated = false
    }

    /// Applies the look, leaving the timeline alone.
    func apply(to project: inout ProjectState) {
        // `generated` is cleared so the incoming auto-zoom settings actually
        // produce segments on this recording rather than being ignored because
        // the old ones were already built.
        var incoming = autoZoom
        incoming.generated = false
        project.autoZoom = incoming

        project.cursor = cursor
        project.background = background
        project.camera = camera
        project.audio = audio
        project.speech = speech

        // The recording's own corrections survive a set being applied — they're
        // about this recording's words, and losing them would be the expensive
        // kind of surprise.
        let edits = project.subtitles.edits
        project.subtitles = subtitles
        project.subtitles.edits = edits
    }

    // MARK: - Storage

    /// Three slots. Enough to keep, say, a dark look, a light one and a
    /// no-frills one; more than that and picking becomes its own chore.
    enum Slot: Int, CaseIterable, Identifiable {
        case one = 1, two, three
        var id: Int { rawValue }
        var label: String { "Set \(rawValue)" }
        fileprivate var key: String { "AjwooCapture.styleSet.\(rawValue)" }
    }

    static func load(_ slot: Slot) -> StyleSet? {
        guard let data = UserDefaults.standard.data(forKey: slot.key) else { return nil }
        return try? JSONDecoder().decode(StyleSet.self, from: data)
    }

    static func save(_ set: StyleSet, to slot: Slot) {
        guard let data = try? JSONEncoder().encode(set) else { return }
        UserDefaults.standard.set(data, forKey: slot.key)
    }

    static func exists(_ slot: Slot) -> Bool {
        UserDefaults.standard.data(forKey: slot.key) != nil
    }
}
