import Foundation

/// One recording on disk: a `Name.ajwoocapture` package directory.
///
/// ```
/// My Recording.ajwoocapture/
///   screen.mov      raw screen capture, native pixels, no cursor burned in
///   camera.mov      raw webcam                    (Phase 3)
///   system.m4a      system audio
///   mic.m4a         microphone                    (Phase 3)
///   events.json     cursor path + clicks + capture geometry
///   project.json    non-destructive edit state
/// ```
///
/// Nothing in the package is ever modified by editing — `project.json` is the
/// only file the editor writes, and export reads the originals.
struct RecordingSession: Identifiable, Hashable {
    let url: URL

    var id: URL { url }
    var name: String { url.deletingPathExtension().lastPathComponent }

    var screenVideoURL: URL { url.appendingPathComponent("screen.mov") }
    var cameraVideoURL: URL { url.appendingPathComponent("camera.mov") }
    var systemAudioURL: URL { url.appendingPathComponent("system.m4a") }
    var micAudioURL: URL { url.appendingPathComponent("mic.m4a") }
    var eventsURL: URL { url.appendingPathComponent("events.json") }
    var projectURL: URL { url.appendingPathComponent("project.json") }
    /// Cached word-level transcript. Absent until transcription is run.
    var transcriptURL: URL { url.appendingPathComponent("transcript.json") }

    var hasScreenVideo: Bool { FileManager.default.fileExists(atPath: screenVideoURL.path) }
    var hasSystemAudio: Bool { FileManager.default.fileExists(atPath: systemAudioURL.path) }
    var hasEvents: Bool { FileManager.default.fileExists(atPath: eventsURL.path) }
    var hasMicAudio: Bool { FileManager.default.fileExists(atPath: micAudioURL.path) }
    var hasCameraVideo: Bool { FileManager.default.fileExists(atPath: cameraVideoURL.path) }
    var hasTranscript: Bool { FileManager.default.fileExists(atPath: transcriptURL.path) }

    var createdAt: Date {
        (try? url.resourceValues(forKeys: [.creationDateKey]).creationDate) ?? .distantPast
    }

    var sizeOnDisk: Int64 {
        guard let e = FileManager.default.enumerator(at: url, includingPropertiesForKeys: [.fileSizeKey]) else { return 0 }
        var total: Int64 = 0
        for case let f as URL in e {
            total += Int64((try? f.resourceValues(forKeys: [.fileSizeKey]).fileSize) ?? 0)
        }
        return total
    }

    // MARK: - Creation / discovery

    /// Creates a new, empty package with a timestamped name.
    static func create(in directory: URL = AppInfo.recordingsDirectory, date: Date = Date()) throws -> RecordingSession {
        let formatter = DateFormatter()
        formatter.dateFormat = "yyyy-MM-dd 'at' HH.mm.ss"
        formatter.locale = Locale(identifier: "en_US_POSIX")

        var candidate = directory.appendingPathComponent("Recording \(formatter.string(from: date))")
            .appendingPathExtension(AppInfo.packageExtension)
        var suffix = 2
        while FileManager.default.fileExists(atPath: candidate.path) {
            candidate = directory.appendingPathComponent("Recording \(formatter.string(from: date)) (\(suffix))")
                .appendingPathExtension(AppInfo.packageExtension)
            suffix += 1
        }

        try FileManager.default.createDirectory(at: directory, withIntermediateDirectories: true)
        try FileManager.default.createDirectory(at: candidate, withIntermediateDirectories: false)
        return RecordingSession(url: candidate)
    }

    static func all(in directory: URL = AppInfo.recordingsDirectory) -> [RecordingSession] {
        let contents = (try? FileManager.default.contentsOfDirectory(
            at: directory,
            includingPropertiesForKeys: [.creationDateKey],
            options: [.skipsHiddenFiles])) ?? []

        return contents
            .filter { $0.pathExtension == AppInfo.packageExtension }
            .map(RecordingSession.init(url:))
            .sorted { $0.createdAt > $1.createdAt }
    }

    func delete() throws {
        try FileManager.default.removeItem(at: url)
    }
}
