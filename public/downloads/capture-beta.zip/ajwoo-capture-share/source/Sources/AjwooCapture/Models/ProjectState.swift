import Foundation
import CoreGraphics
import AppKit

/// `project.json` — the non-destructive edit state. The capture files are never
/// touched; everything here is applied by the compositing pipeline at preview
/// and export time.
struct ProjectState: Codable, Equatable {
    var version: Int = 1

    /// Trim, in seconds of **recording time**. `trimEnd == nil` means "to the end".
    var trimStart: Double = 0
    var trimEnd: Double?

    /// Ranges removed from the output entirely. See `TimeMap`.
    var cuts: [CutRange] = []

    var crop: Crop = Crop()
    var zoomSegments: [ZoomSegment] = []
    var autoZoom: AutoZoom = AutoZoom()
    var cursor: CursorStyle = CursorStyle()
    var audio: AudioMix = AudioMix()
    var camera: CameraOverlay = CameraOverlay()
    var background: Background = Background()
    var speech: SpeechEdits = SpeechEdits()
    var subtitles: Subtitles = Subtitles()

    // MARK: - Cuts

    /// A stretch of the recording that is spliced out. Everything after it moves
    /// earlier in the finished video, but timestamps in `events.json` are never
    /// rewritten — `TimeMap` translates between the two.
    struct CutRange: Codable, Identifiable, Equatable {
        /// What produced this cut. Manual cuts are made by hand; `.filler` and
        /// `.silence` are derived from the transcript/audio, and regenerating
        /// replaces exactly the ones tagged with that origin — which is also
        /// what lets the two "Remove filler words"/"Remove long silences"
        /// checkboxes show a mixed state when the user has deleted some, but
        /// not all, of what they generated.
        enum Origin: String, Codable, Equatable {
            case manual, filler, silence
        }

        var id: UUID = UUID()
        var start: Double
        var end: Double
        var origin: Origin = .manual

        var duration: Double { max(0, end - start) }

        /// Kept for every call site written before `origin` existed — reads as
        /// "not manual" the way the old stored flag did.
        var isAuto: Bool { origin != .manual }

        init(id: UUID = UUID(), start: Double, end: Double, origin: Origin = .manual) {
            self.id = id
            self.start = start
            self.end = end
            self.origin = origin
        }

        private enum CodingKeys: String, CodingKey {
            case id, start, end, origin, isAuto
        }

        /// A project saved before `origin` existed only has `isAuto`. Old auto
        /// cuts don't record which kind they were, so they're treated as
        /// filler cuts — wrong for a silence-only project, but it keeps them
        /// showing as "generated" rather than silently turning into untouched
        /// manual cuts the regenerate logic would never revisit.
        init(from decoder: Decoder) throws {
            let container = try decoder.container(keyedBy: CodingKeys.self)
            id = try container.decodeIfPresent(UUID.self, forKey: .id) ?? UUID()
            start = try container.decode(Double.self, forKey: .start)
            end = try container.decode(Double.self, forKey: .end)
            if let origin = try container.decodeIfPresent(Origin.self, forKey: .origin) {
                self.origin = origin
            } else if let legacyAuto = try container.decodeIfPresent(Bool.self, forKey: .isAuto), legacyAuto {
                self.origin = .filler
            } else {
                self.origin = .manual
            }
        }

        func encode(to encoder: Encoder) throws {
            var container = encoder.container(keyedBy: CodingKeys.self)
            try container.encode(id, forKey: .id)
            try container.encode(start, forKey: .start)
            try container.encode(end, forKey: .end)
            try container.encode(origin, forKey: .origin)
        }
    }

    // MARK: - Crop

    /// A sub-rectangle of the capture to keep, normalized to the source frame
    /// with (0,0) at the top-left — the same space as `events.json`.
    struct Crop: Codable, Equatable {
        var enabled: Bool = false
        var x: Double = 0
        var y: Double = 0
        var width: Double = 1
        var height: Double = 1

        var rect: CGRect { CGRect(x: x, y: y, width: width, height: height) }
        static let full = Crop()

        mutating func clampToFrame() {
            width = min(1, max(0.05, width))
            height = min(1, max(0.05, height))
            x = min(1 - width, max(0, x))
            y = min(1 - height, max(0, y))
        }
    }

    // MARK: - Zoom

    struct ZoomSegment: Codable, Identifiable, Equatable {
        var id: UUID = UUID()
        var start: Double
        var end: Double
        /// 1.0 = no zoom. Clamped to 4.0.
        var level: Double = 2.0
        /// Focus point, normalized to the **full source frame** (same space as
        /// `events.json`), regardless of any crop. Ignored when `followsCursor`.
        var focusX: Double = 0.5
        var focusY: Double = 0.5
        /// Eased ramp in/out duration, seconds.
        var rampDuration: Double = 0.6
        /// Focus tracks the pointer instead of sitting still.
        var followsCursor: Bool = false
        /// Generated by auto-zoom. Regenerating replaces exactly these.
        var isAuto: Bool = false
    }

    /// Drops a zoom onto the timeline around every click burst. **On by default** —
    /// a click is nearly always the thing worth looking at, and it's one toggle
    /// to switch off.
    struct AutoZoom: Codable, Equatable {
        var enabled: Bool = true
        var level: Double = 1.5
        /// On by default: a zoom that tracks the pointer keeps whatever you're
        /// doing in frame, where a fixed focus drifts off it the moment you move.
        var followsCursor: Bool = true
        /// Start this far before the first click of a burst.
        var leadIn: Double = 1.0
        /// Hold this long after the last click of a burst.
        var holdAfter: Double = 2.0
        /// Clicks closer together than this belong to the same burst.
        var clusterGap: Double = 1.2
        /// Set once the segments have been produced, so re-opening a project
        /// doesn't resurrect auto zooms the user deleted one by one.
        var generated: Bool = false
    }

    // MARK: - Cursor

    struct CursorStyle: Codable, Equatable {
        enum Kind: String, Codable { case arrow, dot, hidden }

        /// macOS draws a black pointer with a white outline; Windows draws a
        /// white pointer with a black outline.
        enum ArrowTone: String, Codable, CaseIterable, Identifiable {
            case dark, light
            var id: String { rawValue }
        }

        var kind: Kind = .arrow
        var arrowTone: ArrowTone = .dark
        /// Draw a pointing hand wherever macOS drew one — over links, buttons
        /// and anything else clickable. Uses the pointer shapes recorded in
        /// `events.json`; older recordings have none and stay an arrow.
        /// Off by default.
        ///
        /// The pointer changing shape mid-take draws the eye to the pointer
        /// rather than to what's being demonstrated, and an arrow throughout
        /// reads as calmer. It's one toggle away for anyone who wants the real
        /// shapes — the artwork for all ten is there either way.
        var matchSystemShape: Bool = false
        var sizeMultiplier: Double = 2.0
        /// 0 = raw samples, 1 = heavily smoothed.
        var smoothing: Double = 0.25
        /// Drop shadow under the pointer.
        ///
        /// Both real cursors have one, and it's what keeps them visible on
        /// content that matches their body colour — a dark pointer on a dark
        /// window, a light one on a white page. Without it the outline is the
        /// only separation, and an outline disappears against its own colour.
        var shadow: Bool = true
        var clickPulse: Bool = true
        /// Off by default — the shrink-and-bounce alone reads as a click, and the
        /// ring on top of it is a lot of motion for one event.
        var clickRipple: Bool = false
        /// Scales pulse depth and ripple size, 0.5-2.0.
        var clickEmphasis: Double = 1.5
        /// How quickly the shrink-and-bounce plays. 1.0 is the default timing;
        /// higher is snappier.
        var clickSpeed: Double = 1.0
        var dotRed: Double = 1.0
        var dotGreen: Double = 1.0
        var dotBlue: Double = 1.0
        var dotOpacity: Double = 0.45
        /// Fades the pointer out once it's sat still this long, 0...20 seconds.
        /// 0 means "never". On by default at a conservative 2s — long enough
        /// that a normal pause between actions doesn't flicker the pointer
        /// away, short enough that it actually clears out of frame during
        /// the stretches where nothing is happening.
        var hideAfterIdleSeconds: Double = 2
    }

    // MARK: - Audio

    struct AudioMix: Codable, Equatable {
        var systemVolume: Double = 1.0
        var systemMuted: Bool = false
        var micVolume: Double = 1.0
        var micMuted: Bool = false
        /// A noise gate on the microphone track: 0 leaves it untouched, 1
        /// ducks it hard during the stretches where nothing is being said.
        /// Off by default — it's an audible effect, not a neutral cleanup,
        /// and shouldn't apply itself to a recording nobody asked to change.
        var noiseReduction: Double = 0
    }

    // MARK: - Camera

    /// The webcam bubble. Position and size are dragged directly on the preview
    /// rather than picked from a corner list — you can see what you're doing, and
    /// it isn't limited to four places.
    struct CameraOverlay: Codable, Equatable {
        enum Shape: String, Codable, CaseIterable, Identifiable {
            case circle, roundedRectangle, rectangle, star, cutout
            var id: String { rawValue }
            var label: String {
                switch self {
                case .circle:           return "Circle"
                case .roundedRectangle: return "Rounded"
                case .rectangle:        return "Rectangle"
                case .star:             return "Star"
                case .cutout:           return "No background"
                }
            }
            var forcesSquare: Bool { self == .circle || self == .star }
            /// The only shape whose outline comes from the picture rather than
            /// geometry — everything behind the person is cut away.
            var isSegmented: Bool { self == .cutout }
        }

        var enabled: Bool = true
        var shape: Shape = .circle
        /// Centre of the bubble, normalized to the **output frame**, top-left origin.
        // Tucked into the bottom-right corner: 16 pt of margin at 1080p, which
        // is 1.5% of the height. Expressed as the bubble's centre, so it's the
        // margin plus half the bubble's own size.
        var centerX: Double = 1 - (0.015 * (9.0 / 16.0)) - 0.22 / 2 * (9.0 / 16.0)
        var centerY: Double = 1 - 0.015 - 0.22 / 2
        /// Bubble height as a fraction of output height.
        var size: Double = 0.22
        /// width / height. Forced to 1 for circle and star.
        var aspect: Double = 1.0
        /// Corner rounding as a fraction of the bubble's shorter side.
        var cornerRadius: Double = 0.18
        var shadow: Bool = true
        var filter: CameraFilter = CameraFilter()

        var effectiveAspect: Double {
            shape.forcesSquare ? 1.0 : min(2.5, max(0.4, aspect))
        }

        /// Bubble rect normalized to the output, top-left origin.
        func normalizedRect(outputAspect: Double) -> CGRect {
            let height = size
            let width = size * effectiveAspect / max(0.0001, outputAspect)
            return CGRect(x: centerX - width / 2, y: centerY - height / 2,
                          width: width, height: height)
        }

        mutating func clampToFrame(outputAspect: Double) {
            size = min(0.9, max(0.06, size))
            let rect = normalizedRect(outputAspect: outputAspect)
            centerX = min(1 - rect.width / 2, max(rect.width / 2, centerX))
            centerY = min(1 - rect.height / 2, max(rect.height / 2, centerY))
        }
    }

    /// Colour grading for the webcam. Everything here is `CIColorControls` plus
    /// `CITemperatureAndTint` plus a touch of blur — cheap, and enough for the
    /// thing people actually want, which is to not look grey and flat on a
    /// laptop camera.
    struct CameraFilter: Codable, Equatable {
        enum Preset: String, Codable, CaseIterable, Identifiable {
            case none, natural, warm, bright, soft, punchy
            var id: String { rawValue }
            var label: String {
                switch self {
                case .none:    return "Off"
                case .natural: return "Natural"
                case .warm:    return "Warm"
                case .bright:  return "Bright"
                case .soft:    return "Soft"
                case .punchy:  return "Punchy"
                }
            }
        }

        var preset: Preset = .natural
        /// -0.3...0.3, additive.
        var brightness: Double = 0.03
        /// 0.5...1.6, multiplicative around mid grey.
        var contrast: Double = 1.14
        /// 0...2.
        var saturation: Double = 1.2
        /// Kelvin offset; positive is warmer.
        var warmth: Double = 450
        /// 0...1, a light blur that takes the edge off camera noise.
        var softness: Double = 0.0
        /// 0...1, luminance sharpening. Laptop sensors are soft; a little of
        /// this is what actually makes a face look crisp rather than merely
        /// brighter.
        var clarity: Double = 0.45

        var isNeutral: Bool {
            preset == .none
        }

        static func values(for preset: Preset) -> CameraFilter {
            var filter = CameraFilter()
            filter.preset = preset
            // Deliberately far apart. Presets a few percent from each other are
            // indistinguishable on a 200 px bubble, which makes the whole control
            // feel broken — each of these should be obvious at a glance.
            switch preset {
            case .none:
                filter.brightness = 0;    filter.contrast = 1.0;  filter.saturation = 1.0
                filter.warmth = 0;        filter.softness = 0;    filter.clarity = 0
            case .natural:
                filter.brightness = 0.03; filter.contrast = 1.14; filter.saturation = 1.2
                filter.warmth = 450;      filter.softness = 0;    filter.clarity = 0.45
            case .warm:
                filter.brightness = 0.1;  filter.contrast = 1.1;  filter.saturation = 1.45
                filter.warmth = 1100;     filter.softness = 0;    filter.clarity = 0.35
            case .bright:
                filter.brightness = 0.13; filter.contrast = 0.98; filter.saturation = 1.12
                filter.warmth = 200;      filter.softness = 0;    filter.clarity = 0.5
            case .soft:
                // Soft is a gentler *grade*, not a blur. A heavy blur just looks
                // out of focus, so this keeps some clarity and only takes the
                // hard edge off.
                filter.brightness = 0.1;  filter.contrast = 0.94; filter.saturation = 1.0
                filter.warmth = 600;      filter.softness = 0.22; filter.clarity = 0.2
            case .punchy:
                // Enough contrast to have presence, not so much that skin tones
                // clip into poster art.
                filter.brightness = 0.02; filter.contrast = 1.18; filter.saturation = 1.32
                filter.warmth = 80;       filter.softness = 0;    filter.clarity = 0.75
            }
            return filter
        }
    }

    // MARK: - Speech

    /// Edits derived from the transcript. All off by default: they delete
    /// footage, and nothing should do that until it's asked for.
    struct SpeechEdits: Codable, Equatable {
        var removeFillers: Bool = false
        var removeSilences: Bool = false
        /// Gaps longer than this are candidates for removal.
        var silenceThreshold: Double = 1.2
    }

    // MARK: - Subtitles

    struct Subtitles: Codable, Equatable {
        /// Typefaces that ship with macOS and carry no licensing restriction on
        /// embedding in exported video.
        enum FontChoice: String, Codable, CaseIterable, Identifiable {
            case system, systemRounded, helvetica, avenir, georgia, menlo
            var id: String { rawValue }
            var label: String {
                switch self {
                case .system:        return "System"
                case .systemRounded: return "System Rounded"
                case .helvetica:     return "Helvetica Neue"
                case .avenir:        return "Avenir Next"
                case .georgia:       return "Georgia"
                case .menlo:         return "Menlo"
                }
            }
        }

        enum Backdrop: String, Codable, CaseIterable, Identifiable {
            case none, shadow, box
            var id: String { rawValue }
            var label: String {
                switch self {
                case .none:   return "None"
                case .shadow: return "Shadow"
                case .box:    return "Box"
                }
            }
        }

        var enabled: Bool = false
        var font: FontChoice = .system
        /// Cap height as a fraction of output height, so captions stay the same
        /// relative size at every export resolution.
        var fontSize: Double = 0.042
        var wordsPerCue: Int = 6
        var backdrop: Backdrop = .box
        /// Centre of the caption block, normalized to the output, top-left origin.
        var centerX: Double = 0.5
        var centerY: Double = 0.86
        /// Block width as a fraction of output width. Narrower wraps sooner,
        /// which is how you trade line length against line count.
        var width: Double = 0.7
        var uppercase: Bool = false
        /// Strength of the drop shadow behind the text, 0...1. Applies to every
        /// backdrop — a shadow under a box still helps on a bright frame.
        var shadowStrength: Double = 0.9
        /// Opacity of the box backdrop, 0...1. Zero is a box that isn't there,
        /// which is a legitimate choice once the shadow is doing the work.
        var boxOpacity: Double = 0.72
        /// Hand-corrected caption text, keyed by the cue's start time to two
        /// decimal places.
        ///
        /// Keyed by time rather than by index because indices shift the moment a
        /// cut lands or a word is re-grouped, which would silently reassign your
        /// correction to a different caption. Time is stable against both.
        /// Changing "words per caption" *does* move cue boundaries, so an edit
        /// whose start no longer matches a cue is dropped — the alternative is
        /// text appearing over the wrong speech.
        var edits: [String: String] = [:]

        static func editKey(forCueStart start: Double) -> String {
            String(format: "%.2f", start)
        }

        func nsFont(pixelSize: CGFloat) -> NSFont {
            switch font {
            case .system:        return .systemFont(ofSize: pixelSize, weight: .semibold)
            case .systemRounded:
                let base = NSFont.systemFont(ofSize: pixelSize, weight: .semibold)
                guard let descriptor = base.fontDescriptor.withDesign(.rounded) else { return base }
                return NSFont(descriptor: descriptor, size: pixelSize) ?? base
            case .helvetica:     return NSFont(name: "HelveticaNeue-Medium", size: pixelSize)
                                    ?? .systemFont(ofSize: pixelSize, weight: .medium)
            case .avenir:        return NSFont(name: "AvenirNext-DemiBold", size: pixelSize)
                                    ?? .systemFont(ofSize: pixelSize, weight: .semibold)
            case .georgia:       return NSFont(name: "Georgia", size: pixelSize)
                                    ?? .systemFont(ofSize: pixelSize, weight: .regular)
            case .menlo:         return NSFont(name: "Menlo-Regular", size: pixelSize)
                                    ?? .monospacedSystemFont(ofSize: pixelSize, weight: .regular)
            }
        }
    }

    // MARK: - Background

    struct Background: Codable, Equatable {
        /// On by default: the inset, rounded, shadowed frame is the look people
        /// expect from a shared demo, and it costs nothing to switch off.
        var enabled: Bool = true
        var padding: Double = 0.05
        var cornerRadius: Double = 0.02
        var shadow: Bool = true
        // #1C1E26 — dark enough that the screen content is still the brightest
        // thing in frame, light enough to read as deliberate rather than as an
        // absence of background.
        var topRed: Double = 0.109,  topGreen: Double = 0.118,  topBlue: Double = 0.149
        var bottomRed: Double = 0.02, bottomGreen: Double = 0.022, bottomBlue: Double = 0.03

        /// A photo backdrop instead of the gradient above. `nil` means "use
        /// the gradient" — the two colours above are kept either way, as the
        /// swatch/fallback if the image can't be found (a custom upload that
        /// got moved or deleted, or a bundled preset missing under `swift run`
        /// — see `BackgroundImageStore`).
        var backgroundImageFilename: String?
        /// Whether `backgroundImageFilename` names a file bundled with the app
        /// (a built-in preset photo) or one copied into
        /// `AppInfo.backgroundsDirectory` when the user uploaded it.
        var backgroundImageIsBundled: Bool = false

        /// The gradients, solids and photo backdrops worth having as one
        /// click.
        ///
        /// Colour components are kept as plain `Double`s rather than `Color`
        /// so the model stays free of SwiftUI; the inspector builds swatches
        /// from these. A photo preset still carries `top`/`bottom` — it's the
        /// swatch and export fallback if the bundled image is missing.
        struct Preset: Identifiable, Equatable {
            let id: String
            let name: String
            let top: (r: Double, g: Double, b: Double)
            let bottom: (r: Double, g: Double, b: Double)
            var imageFilename: String? = nil
            var isBundledImage: Bool = false

            static func == (a: Preset, b: Preset) -> Bool { a.id == b.id }
        }

        /// Nine, in one row: the five gradients first, darkest to lightest,
        /// then black, then three photo backdrops. Ordering the gradients by
        /// lightness means picking one is a left-to-right scan rather than a
        /// hunt; the photos close the row because a picture reads as a
        /// heavier choice than a flat colour.
        static let presets: [Preset] = [
            // Gradients, dark to light.
            Preset(id: "graphite", name: "Graphite",
                   top: (0.109, 0.118, 0.149), bottom: (0.02, 0.022, 0.03)),
            Preset(id: "plum", name: "Plum",
                   top: (0.16, 0.07, 0.26), bottom: (0.42, 0.10, 0.30)),
            Preset(id: "ember", name: "Ember",
                   top: (0.99, 0.80, 0.58), bottom: (0.96, 0.55, 0.51)),
            Preset(id: "daylight", name: "Daylight",
                   top: (0.62, 0.80, 0.95), bottom: (0.98, 0.99, 1.0)),
            Preset(id: "paper", name: "Paper",
                   top: (1.0, 1.0, 1.0), bottom: (0.87, 0.87, 0.89)),

            // One flat solid kept from the original four.
            Preset(id: "ink", name: "Ink",
                   top: (0.0, 0.0, 0.0), bottom: (0.0, 0.0, 0.0)),

            // Three photo backdrops, replacing the dark-gray/gray/white
            // solids. Fallback tints approximate each photo's dominant
            // colour, so the swatch (and any export rendered before the
            // bundled file exists) still reads as "that one", not as a
            // random grey.
            Preset(id: "canyon", name: "Canyon",
                   top: (0.62, 0.42, 0.32), bottom: (0.45, 0.28, 0.22),
                   imageFilename: "preset-canyon.jpg", isBundledImage: true),
            Preset(id: "skyline", name: "Skyline",
                   top: (0.60, 0.63, 0.67), bottom: (0.42, 0.45, 0.49),
                   imageFilename: "preset-skyline.jpg", isBundledImage: true),
            Preset(id: "peak", name: "Peak",
                   top: (0.45, 0.52, 0.42), bottom: (0.22, 0.27, 0.22),
                   imageFilename: "preset-peak.jpg", isBundledImage: true),
        ]

        mutating func apply(_ preset: Preset) {
            topRed = preset.top.r; topGreen = preset.top.g; topBlue = preset.top.b
            bottomRed = preset.bottom.r; bottomGreen = preset.bottom.g; bottomBlue = preset.bottom.b
            backgroundImageFilename = preset.imageFilename
            backgroundImageIsBundled = preset.isBundledImage
        }

        /// Points the background at a user-uploaded photo — not one of the
        /// static `presets`, so it's applied directly rather than through
        /// `apply(_:)`. The gradient colours are left as whatever they were;
        /// switching back to a gradient preset or picking new wells still
        /// works exactly as before.
        mutating func applyCustomImage(filename: String) {
            backgroundImageFilename = filename
            backgroundImageIsBundled = false
        }

        func matches(_ preset: Preset) -> Bool {
            if let presetImage = preset.imageFilename {
                return backgroundImageFilename == presetImage && backgroundImageIsBundled == preset.isBundledImage
            }
            guard backgroundImageFilename == nil else { return false }
            func near(_ a: Double, _ b: Double) -> Bool { abs(a - b) < 0.02 }
            return near(topRed, preset.top.r) && near(topGreen, preset.top.g) && near(topBlue, preset.top.b)
                && near(bottomRed, preset.bottom.r) && near(bottomGreen, preset.bottom.g)
                && near(bottomBlue, preset.bottom.b)
        }

        // MARK: - Canvas aspect ratio

        /// The exported frame's shape. `recording` means the canvas follows
        /// whatever the crop produces — no letterboxing, the padding is the only
        /// margin. Anything else fixes the canvas to that ratio and lets the
        /// background fill whatever the recording doesn't cover, so a 16:9
        /// capture can still be delivered as a 9:16 clip.
        enum CanvasAspect: String, Codable, CaseIterable, Identifiable {
            case recording, widescreen, standard, square, portraitStandard, portraitTall
            var id: String { rawValue }

            var label: String {
                switch self {
                case .recording:        return "Recording"
                case .widescreen:       return "16:9"
                case .standard:         return "4:3"
                case .square:           return "1:1"
                case .portraitStandard: return "3:4"
                case .portraitTall:     return "9:16"
                }
            }

            /// Width over height, or `nil` to mean "whatever the recording is".
            var ratio: Double? {
                switch self {
                case .recording:        return nil
                case .widescreen:       return 16.0 / 9.0
                case .standard:         return 4.0 / 3.0
                case .square:           return 1.0
                case .portraitStandard: return 3.0 / 4.0
                case .portraitTall:     return 9.0 / 16.0
                }
            }
        }

        /// Sixteen-by-nine first since it's the one most people reach for, then
        /// narrowing toward square, then on into portrait — a left-to-right scan
        /// from "wide" to "tall", matching how the presets above scan light to
        /// dark.
        var aspectRatio: CanvasAspect = .recording

        /// The exported frame for `content` at this background's chosen aspect.
        ///
        /// Only takes effect while the background itself is on — with it off
        /// there's nothing to letterbox into, so the canvas always follows the
        /// recording. The result holds the same pixel area as `content` rather
        /// than, say, its width or height, so switching from 16:9 to 9:16
        /// doesn't quietly change the export's resolution budget along with its
        /// shape.
        func canvasSize(for content: CGSize) -> CGSize {
            guard enabled, let ratio = aspectRatio.ratio,
                  content.width > 0, content.height > 0
            else { return content }

            let area = Double(content.width) * Double(content.height)
            let rawWidth = (area * ratio).squareRoot()
            let rawHeight = rawWidth / ratio
            // Even pixel dimensions — encoders reject odd sizes.
            let width = max(2.0, (rawWidth / 2).rounded() * 2)
            let height = max(2.0, (rawHeight / 2).rounded() * 2)
            return CGSize(width: width, height: height)
        }
    }

    /// Schema marker for migrations. Optional so a file written before it
    /// existed decodes as `nil` rather than throwing — synthesized `Codable`
    /// requires every non-optional key to be present, so adding a plain `Int`
    /// here would silently reset every existing project to defaults.
    var schemaVersion: Int?

    static let currentSchemaVersion = 4

    /// Brings a stored project up to date.
    ///
    /// Version 2 forced `cursor.matchSystemShape` on, on the theory that anyone
    /// who'd switched it off had done so while the pointer artwork was wrong.
    /// That was the wrong call — the shipped default is now off — so v2's
    /// migration is gone rather than kept and then immediately contradicted.
    /// Whatever is stored in an existing project is left alone.
    ///
    /// Version 4: `subtitles.backdrop == .none` becomes `.shadow`. The case is
    /// kept in the model — decoding an old file that stored it must keep
    /// working — but the two have drawn identically ever since the shadow
    /// slider stopped being tied to which backdrop was picked, and the picker
    /// no longer offers "None" as a choice. Without this, a project last saved
    /// with it selected would load into a segmented control with nothing
    /// highlighted.
    mutating func migrate() {
        if subtitles.backdrop == .none {
            subtitles.backdrop = .shadow
        }
        schemaVersion = Self.currentSchemaVersion
    }

    // MARK: - Persistence

    func write(to url: URL) throws {
        let encoder = JSONEncoder()
        encoder.outputFormatting = [.prettyPrinted, .sortedKeys]
        try encoder.encode(self).write(to: url, options: .atomic)
    }

    /// Loads a project, tolerating anything the file is missing or has wrong.
    ///
    /// # Why this isn't just `JSONDecoder().decode`
    /// Synthesized `Codable` requires every non-optional key to be present. So
    /// the moment a setting is added, every project.json written before it fails
    /// to decode — and the caller falls back to `ProjectState()`, silently
    /// discarding all of that recording's cuts, zooms, trims and crops. Adding
    /// a setting to `autoZoom` did exactly this to projects saved the day
    /// before.
    ///
    /// The fix is to merge the stored values *over* an encoded set of defaults,
    /// so a missing key simply keeps its default and everything else survives.
    /// A value whose JSON type doesn't match the default's is also ignored,
    /// which covers a setting changing type — a `Bool` becoming a slider's
    /// `Double`, say — rather than letting one renamed field cost the user their
    /// edits.
    ///
    /// Arrays are replaced wholesale, not merged: `cuts` and `zoomSegments` are
    /// lists of things, and merging them element-wise would be nonsense.
    static func read(from url: URL) throws -> ProjectState {
        let data = try Data(contentsOf: url)
        let decoder = JSONDecoder()

        guard
            let stored = try? JSONSerialization.jsonObject(with: data) as? [String: Any],
            let defaultsData = try? JSONEncoder().encode(ProjectState()),
            let defaults = try? JSONSerialization.jsonObject(with: defaultsData) as? [String: Any]
        else {
            // Not an object at all — let the strict path produce the real error.
            return try decoder.decode(ProjectState.self, from: data)
        }

        let merged = Self.merge(stored: stored, over: defaults)
        let mergedData = try JSONSerialization.data(withJSONObject: merged)
        return try decoder.decode(ProjectState.self, from: mergedData)
    }

    /// Recursively overlays `stored` onto `defaults`, keeping the default
    /// wherever the stored value is absent or of a different shape.
    private static func merge(stored: [String: Any], over defaults: [String: Any]) -> [String: Any] {
        var result = defaults
        for (key, storedValue) in stored {
            guard let defaultValue = defaults[key] else {
                // A key the current model doesn't have. Carried through rather
                // than dropped: decoding ignores unknown keys, and keeping it
                // means downgrading to an older build doesn't lose the setting.
                result[key] = storedValue
                continue
            }
            if let storedDict = storedValue as? [String: Any],
               let defaultDict = defaultValue as? [String: Any] {
                result[key] = merge(stored: storedDict, over: defaultDict)
            } else if sameShape(storedValue, defaultValue) {
                result[key] = storedValue
            }
            // Otherwise the stored value is the wrong type for this key, and the
            // default stands.
        }
        return result
    }

    /// Whether two JSON values are the same kind of thing.
    ///
    /// `NSNumber` covers both booleans and numbers in `JSONSerialization`, so
    /// booleans are separated out explicitly — otherwise a stored `true` would
    /// happily satisfy a `Double` field and decode as 1.
    private static func sameShape(_ a: Any, _ b: Any) -> Bool {
        if isBool(a) || isBool(b) { return isBool(a) && isBool(b) }
        switch (a, b) {
        case (is NSNumber, is NSNumber): return true
        case (is String, is String): return true
        case (is [Any], is [Any]): return true
        case (is NSNull, _), (_, is NSNull): return true
        default: return false
        }
    }

    private static func isBool(_ value: Any) -> Bool {
        (value as? NSNumber).map { CFGetTypeID($0) == CFBooleanGetTypeID() } ?? false
    }
}
