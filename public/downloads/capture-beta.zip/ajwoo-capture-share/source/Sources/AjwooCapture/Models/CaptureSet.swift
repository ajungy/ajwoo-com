import Foundation

/// A saved capture configuration — frame rate, codec, quality, and what gets
/// recorded alongside the screen.
///
/// The same idea as the editor's `StyleSet`, for the other half of the app: if
/// you always want 30 fps H.264 with system audio off, that shouldn't be four
/// clicks every time.
///
/// Device *identities* are deliberately excluded. A set that pinned "this
/// webcam" would silently do nothing on a Mac where that camera isn't plugged
/// in, which is worse than not restoring it at all.
struct CaptureSet: Codable, Equatable {

    var frameRate: Int
    var codec: CaptureSettings.MasterCodec
    var quality: CaptureSettings.Quality
    var capturesSystemAudio: Bool
    var includeAppWindows: Bool
    var cameraPreviewCorner: CaptureSettings.PreviewCorner

    init(from settings: CaptureSettings) {
        frameRate = settings.frameRate
        codec = settings.codec
        quality = settings.quality
        capturesSystemAudio = settings.capturesSystemAudio
        includeAppWindows = settings.includeAppWindows
        cameraPreviewCorner = settings.cameraPreviewCorner
    }

    func apply(to settings: inout CaptureSettings) {
        settings.frameRate = frameRate
        settings.codec = codec
        settings.quality = quality
        settings.capturesSystemAudio = capturesSystemAudio
        settings.includeAppWindows = includeAppWindows
        settings.cameraPreviewCorner = cameraPreviewCorner
    }

    // MARK: - Storage

    /// Two slots. Three was one more than anyone was filling, and the row has
    /// to fit on one line beside Reset and Save set.
    enum Slot: Int, CaseIterable, Identifiable {
        case one = 1, two
        var id: Int { rawValue }
        var label: String { "Set \(rawValue)" }
        fileprivate var key: String { "AjwooCapture.captureSet.\(rawValue)" }
    }

    static func load(_ slot: Slot) -> CaptureSet? {
        guard let data = UserDefaults.standard.data(forKey: slot.key) else { return nil }
        return try? JSONDecoder().decode(CaptureSet.self, from: data)
    }

    static func save(_ set: CaptureSet, to slot: Slot) {
        guard let data = try? JSONEncoder().encode(set) else { return }
        UserDefaults.standard.set(data, forKey: slot.key)
    }

    static func exists(_ slot: Slot) -> Bool {
        UserDefaults.standard.data(forKey: slot.key) != nil
    }
}
