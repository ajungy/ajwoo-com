import Foundation
import CoreGraphics

/// `events.json` — the sidecar that makes non-destructive cursor rendering possible.
///
/// See NOTES.md for the prose version of this schema. Summary:
///
/// - `t` is **seconds since recording start**, on the same monotonic host clock
///   as every video and audio sample (see `CaptureClock`).
/// - `x` / `y` are **normalized to the capture frame**, (0,0) = top-left.
///   Values outside 0...1 mean the pointer was off the captured area.
/// - Cursor samples are **deduplicated**: a sample is only written when the
///   position changed, with a forced keepalive at least every
///   `EventLog.keepaliveInterval` seconds so gaps are bounded. Consumers should
///   hold the last known position across a gap.
struct EventLog: Codable {
    static let schemaVersion = 1
    /// Even when idle, never let more than this many seconds pass without a sample.
    static let keepaliveInterval: Double = 0.5

    var version: Int = EventLog.schemaVersion
    var recording: RecordingInfo
    var cursor: [CursorSample]
    var clicks: [ClickEvent]
    /// Sparse: one entry each time the system pointer *changes shape*, so the
    /// renderer can draw a pointing hand over links and buttons exactly where
    /// macOS drew one. Absent in recordings made before this existed, which
    /// simply render as an arrow throughout.
    var pointerShapes: [PointerShapeChange]?

    struct RecordingInfo: Codable {
        /// Wall-clock start, for display only. Never use this for sync.
        var startedAt: Date
        /// Name of the clock all `t` values are measured against.
        var clock: String = CaptureClock.name
        var durationSeconds: Double
        var frameRate: Int
        var geometry: CaptureGeometry
        /// Per-file offsets from t=0, in seconds. All writers are started at
        /// the same source time, so this is ~0 for the screen track (which
        /// defines t=0 in the first place) and a few ms for audio — but it is
        /// **not** negligible for the camera, which can take a few hundred
        /// milliseconds to produce its first frame after `startRunning()`,
        /// more for an external or Continuity camera. This is the only place
        /// that gap is ever recorded: `CompositionBuilder` reads the camera
        /// entry's offset here, rather than the asset's own `.timeRange`,
        /// which reports `0` regardless of where the real content starts. See
        /// `CompositionBuilder.insertCamera`.
        var media: [MediaFile]
    }

    struct MediaFile: Codable {
        var file: String
        var kind: String          // "screenVideo" | "systemAudio" | "micAudio" | "camera"
        var startOffsetSeconds: Double
        var sampleCount: Int
    }

    struct CursorSample: Codable {
        var t: Double
        var x: Double
        var y: Double

        enum CodingKeys: String, CodingKey { case t, x, y }
    }

    /// The pointer's shape from `t` until the next entry.
    struct PointerShapeChange: Codable {
        /// Which pointer the system was showing.
        ///
        /// Decoding falls back to `.arrow` for anything unrecognised, so a log
        /// written by a newer build still opens in an older one.
        enum Shape: String, Codable {
            case arrow, hand, text
            case resizeH, resizeV
            case openHand, closedHand
            case crosshair
            case zoomIn, zoomOut

            init(from decoder: Decoder) throws {
                let raw = try decoder.singleValueContainer().decode(String.self)
                self = Shape(rawValue: raw) ?? .arrow
            }
        }
        var t: Double
        var shape: Shape
    }

    struct ClickEvent: Codable {
        var t: Double
        var x: Double
        var y: Double
        var button: Button
        var phase: Phase

        enum Button: String, Codable { case left, right, other }
        enum Phase: String, Codable { case down, up }
    }
}

// MARK: - Writing

extension EventLog {
    /// Rounds coordinates before encoding. 5 decimals of a normalized coordinate
    /// is ~0.04 px on a 4K frame — far below anything visible, and it roughly
    /// halves the file size versus full Double precision.
    static func rounded(_ v: Double, places: Int) -> Double {
        let m = pow(10.0, Double(places))
        return (v * m).rounded() / m
    }

    func write(to url: URL) throws {
        var log = self
        log.cursor = log.cursor.map {
            CursorSample(t: Self.rounded($0.t, places: 4),
                         x: Self.rounded($0.x, places: 5),
                         y: Self.rounded($0.y, places: 5))
        }
        log.clicks = log.clicks.map {
            ClickEvent(t: Self.rounded($0.t, places: 4),
                       x: Self.rounded($0.x, places: 5),
                       y: Self.rounded($0.y, places: 5),
                       button: $0.button, phase: $0.phase)
        }

        log.pointerShapes = log.pointerShapes?.map {
            PointerShapeChange(t: Self.rounded($0.t, places: 4), shape: $0.shape)
        }

        let encoder = JSONEncoder()
        encoder.outputFormatting = [.sortedKeys]
        encoder.dateEncodingStrategy = .iso8601
        try encoder.encode(log).write(to: url, options: .atomic)
    }

    static func read(from url: URL) throws -> EventLog {
        let decoder = JSONDecoder()
        decoder.dateDecodingStrategy = .iso8601
        return try decoder.decode(EventLog.self, from: Data(contentsOf: url))
    }
}
