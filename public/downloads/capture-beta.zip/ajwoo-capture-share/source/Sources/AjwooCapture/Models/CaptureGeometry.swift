import Foundation
import CoreGraphics
import AppKit

/// Everything needed to map a pointer location into the captured frame, and back.
///
/// # Coordinate spaces in play (this is the #1 source of bugs, so read this)
///
/// 1. **CoreGraphics global display space** — origin at the *top-left* of the
///    primary display, Y increases *downward*, units are **points**.
///    `CGDisplayBounds(_:)` and `CGEvent.location` both live here.
///    This is ajwoo capture's canonical space for pointer input.
///
/// 2. **AppKit global screen space** — origin at the *bottom-left* of the
///    primary display, Y increases *upward*, units are **points**.
///    `NSScreen.frame` and `NSEvent.mouseLocation` live here. Used only for
///    positioning our own overlay windows.
///
/// 3. **Capture frame space** — origin at the top-left of the encoded video
///    frame, units are **pixels**. Size is `framePixelWidth x framePixelHeight`.
///
/// `events.json` stores positions **normalized against space 3**: (0,0) is the
/// top-left of the frame, (1,1) the bottom-right. Normalized values are scale-
/// and resolution-independent, which is what makes the same log render correctly
/// against a 1080p or a 4K export.
struct CaptureGeometry: Codable, Equatable {
    /// The rect (in CG global display points) that the encoded frame covers.
    /// For a full-display capture this is `CGDisplayBounds(displayID)`.
    /// Phase 2 will narrow this to the selected region.
    var sourceRectPoints: CGRect

    /// Encoded frame size in backing pixels.
    var framePixelWidth: Int
    var framePixelHeight: Int

    /// points -> pixels for this capture (2.0 on a Retina display).
    var pointPixelScale: CGFloat

    var displayID: UInt32

    // MARK: - Forward: pointer -> normalized frame position

    /// Maps a CoreGraphics global point into normalized capture-frame coordinates.
    ///
    /// Deliberately **not clamped**: when the pointer is on another display or
    /// outside a selected region the result falls outside 0...1, and the renderer
    /// uses that to hide the cursor rather than pinning it to an edge.
    func normalized(fromGlobalCG p: CGPoint) -> CGPoint {
        CGPoint(
            x: (p.x - sourceRectPoints.minX) / sourceRectPoints.width,
            y: (p.y - sourceRectPoints.minY) / sourceRectPoints.height
        )
    }

    func contains(normalized n: CGPoint) -> Bool {
        n.x >= 0 && n.x <= 1 && n.y >= 0 && n.y <= 1
    }

    // MARK: - Inverse: normalized -> pixels / pointer space

    /// Pixel position inside the encoded frame. Used by the export renderer.
    func framePixel(fromNormalized n: CGPoint) -> CGPoint {
        CGPoint(x: n.x * CGFloat(framePixelWidth), y: n.y * CGFloat(framePixelHeight))
    }

    /// Inverse of `normalized(fromGlobalCG:)`. Used by the debug overlay so the
    /// overlay exercises the exact same math in reverse — if the dot lands on the
    /// real cursor, the forward mapping is right.
    func globalCG(fromNormalized n: CGPoint) -> CGPoint {
        CGPoint(
            x: sourceRectPoints.minX + n.x * sourceRectPoints.width,
            y: sourceRectPoints.minY + n.y * sourceRectPoints.height
        )
    }
}

// MARK: - CG <-> AppKit conversion

enum ScreenSpace {
    /// Height in points of the primary display — the display whose CG bounds
    /// origin is (0,0), which is also the display AppKit measures from.
    static var primaryDisplayHeightPoints: CGFloat {
        let cg = CGDisplayBounds(CGMainDisplayID()).height
        if cg > 0 { return cg }
        return NSScreen.screens.first?.frame.height ?? 0
    }

    /// CoreGraphics global (top-left origin) -> AppKit global (bottom-left origin).
    static func appKit(fromGlobalCG p: CGPoint) -> CGPoint {
        CGPoint(x: p.x, y: primaryDisplayHeightPoints - p.y)
    }

    /// AppKit global (bottom-left origin) -> CoreGraphics global (top-left origin).
    static func globalCG(fromAppKit p: CGPoint) -> CGPoint {
        CGPoint(x: p.x, y: primaryDisplayHeightPoints - p.y)
    }

    /// Current pointer position in CG global points.
    ///
    /// Uses `CGEvent` rather than `NSEvent.mouseLocation` because the sampler runs
    /// on a background queue and CGEvent is safe there, and because it hands back
    /// CG coordinates directly — no flip, no chance of flipping twice.
    static func currentPointerGlobalCG() -> CGPoint? {
        CGEvent(source: nil)?.location
    }
}

// MARK: - CGRect Codable helper

extension CGRect {
    var evenRoundedPixelSize: (width: Int, height: Int) {
        (Int(width) & ~1, Int(height) & ~1)
    }
}
