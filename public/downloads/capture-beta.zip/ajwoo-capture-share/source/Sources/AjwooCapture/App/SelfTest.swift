import Foundation
import AVFoundation
import CoreImage
import CoreGraphics
import AppKit

/// End-to-end check of the render pipeline, runnable without any TCC permission:
///
///     make selftest
///     # or: "ajwoo capture.app/Contents/MacOS/AjwooCapture" --selftest
///
/// It synthesises a recording package (a four-colour quadrant video plus a
/// handmade `events.json`), exports it through the real `VideoExporter`, and
/// samples pixels out of the result.
///
/// This exists because XCTest and swift-testing both need a full Xcode install,
/// which this machine doesn't have. The checks it runs are the ones that would
/// otherwise only surface by eye:
///
/// - **Orientation.** Core Image is bottom-left origin, `events.json` is
///   top-left. A single missed flip puts every cursor and every zoom focus in
///   the wrong half of the frame, and it looks plausible until you compare.
/// - **Zoom crops the right rectangle**, exactly, at the right place.
/// - **The cursor is a constant on-screen size regardless of zoom** — the whole
///   reason it's composited after the crop rather than before.
enum SelfTest {

    private static let sourceWidth = 1280
    private static let sourceHeight = 720
    private static let frameRate = 30
    private static let durationSeconds = 2.0

    // Quadrants of the synthetic source, in top-left origin terms.
    private static let topLeftColor = (r: 1.0, g: 0.0, b: 0.0)      // red
    private static let topRightColor = (r: 0.0, g: 0.8, b: 0.0)     // green
    private static let bottomLeftColor = (r: 0.0, g: 0.3, b: 1.0)   // blue
    private static let bottomRightColor = (r: 1.0, g: 0.85, b: 0.0) // yellow
    /// Solid fill for the synthetic camera track. Magenta because none of
    /// the quadrant colours come close to it.
    private static let cameraColor = (r: 1.0, g: 0.0, b: 1.0)

    private static var failures = 0

    /// `--transcribe <audio file>` — times a real transcription end to end.
    ///
    /// Speech is the one part of the pipeline the synthetic recording can't
    /// exercise (it has no speech in it), and "is this fast now?" is only
    /// answerable against real audio. Generate some with:
    ///     say -o /tmp/x.m4a --data-format=aac "the quick brown fox"
    static func transcribeAndExit(path: String) {
        Task { @MainActor in
            let url = URL(fileURLWithPath: path)
            let clock = ContinuousClock()
            var lastReport = 0.0
            let start = clock.now
            do {
                let transcript = try await Transcriber.transcribe(
                    session: RecordingSession(url: url.deletingLastPathComponent()),
                    overrideAudioURL: url
                ) { value in
                    if value - lastReport > 0.19 {
                        lastReport = value
                        print(String(format: "    %3.0f%%", value * 100))
                    }
                }
                let elapsed = clock.now - start
                print("engine:  \(transcript.engine)")
                print("elapsed: \(elapsed)")
                print("words:   \(transcript.words.count)")
                for word in transcript.words.prefix(12) {
                    print(String(format: "  %6.2f  %@", word.start, word.text))
                }
                exit(0)
            } catch {
                print("failed: \(error.localizedDescription)")
                exit(1)
            }
        }
    }

    /// `--sprites <out.png>` — contact sheet of every cursor sprite.
    ///
    /// Cursor artwork is the one part of this pipeline that can't be checked by
    /// counting pixels: "does this look like a hand" has no assertion. So it gets
    /// written out and looked at instead.
    static func spritesAndExit(path: String) {
        let shapes: [(String, EventLog.PointerShapeChange.Shape?)] = [
            ("arrow", nil), ("hand", .hand), ("text", .text),
            ("resizeH", .resizeH), ("resizeV", .resizeV), ("crosshair", .crosshair),
            ("openHand", .openHand), ("closedHand", .closedHand),
            ("zoomIn", .zoomIn), ("zoomOut", .zoomOut),
        ]

        let cell = 180.0
        let columns = 5
        let rows = (shapes.count + columns - 1) / columns
        let width = Int(cell * Double(columns))
        let height = Int(cell * Double(rows))

        guard let ctx = CGContext(data: nil, width: width, height: height,
                                  bitsPerComponent: 8, bytesPerRow: 0,
                                  space: CGColorSpace(name: CGColorSpace.sRGB)!,
                                  bitmapInfo: CGImageAlphaInfo.premultipliedLast.rawValue) else {
            exit(1)
        }
        // Mid grey: both the white-filled and black-filled glyphs have to read
        // against it, which a white or black sheet wouldn't show.
        ctx.setFillColor(NSColor(white: 0.55, alpha: 1).cgColor)
        ctx.fill(CGRect(x: 0, y: 0, width: Double(width), height: Double(height)))

        let ciContext = CIContext()
        for (index, entry) in shapes.enumerated() {
            let sprite = entry.1.flatMap { CursorSprites.system($0, tone: .dark, shadow: true) }
                ?? CursorSprites.arrow(.dark, shadow: true)

            let scale = (cell * 0.72) / sprite.glyphHeight
            let scaled = sprite.image.transformed(by: CGAffineTransform(scaleX: scale, y: scale))
            guard let cg = ciContext.createCGImage(scaled, from: scaled.extent) else { continue }

            let column = index % columns
            let row = index / columns
            let origin = CGPoint(x: Double(column) * cell + (cell - Double(cg.width)) / 2,
                                 y: Double(rows - row - 1) * cell + (cell - Double(cg.height)) / 2)
            ctx.draw(cg, in: CGRect(origin: origin,
                                    size: CGSize(width: cg.width, height: cg.height)))
        }

        guard let image = ctx.makeImage() else { exit(1) }
        let rep = NSBitmapImageRep(cgImage: image)
        try? rep.representation(using: .png, properties: [:])?.write(to: URL(fileURLWithPath: path))
        print("wrote \(path)  (\(shapes.map(\.0).joined(separator: ", ")))")
        exit(0)
    }

    /// `--benchmark <recording.ajwoocapture>` — times what opening the editor does.
    ///
    /// Guessing at which stage is slow has been wrong twice here, so the stages
    /// report themselves. Everything before "ready" blocks the window from
    /// appearing; everything after fills it in.
    static func benchmarkAndExit(path: String) {
        Task { @MainActor in
            let session = RecordingSession(url: URL(fileURLWithPath: path))
            let clock = ContinuousClock()

            func time<T>(_ label: String, _ work: () async throws -> T) async rethrows -> T {
                let start = clock.now
                let value = try await work()
                print(String(format: "  %-26s %@", (label as NSString).utf8String!,
                             "\(clock.now - start)"))
                return value
            }

            do {
                print("blocking — the window can't draw until these finish")
                let log = try await time("EventLog.read") {
                    try EventLog.read(from: session.eventsURL)
                }
                let project = (try? ProjectState.read(from: session.projectURL)) ?? ProjectState()
                let context = RenderContext(log: log, project: project)

                let composition = try await time("CompositionBuilder.build") {
                    try await CompositionBuilder.build(
                        session: session, context: context,
                        renderSize: CGSize(width: 1200, height: 800),
                        frameRate: log.recording.frameRate)
                }
                let duration = composition.recordingDuration.seconds

                print("background — these fill the window in after it opens")
                _ = await time("thumbnails (14)") { () -> Int in
                    let asset = AVURLAsset(url: session.screenVideoURL)
                    let generator = AVAssetImageGenerator(asset: asset)
                    generator.appliesPreferredTrackTransform = true
                    generator.maximumSize = CGSize(width: 240, height: 120)
                    generator.requestedTimeToleranceBefore = CMTime(seconds: 1.5, preferredTimescale: 600)
                    generator.requestedTimeToleranceAfter = CMTime(seconds: 1.5, preferredTimescale: 600)
                    let times = (0..<14).map {
                        CMTime(seconds: duration * (Double($0) + 0.5) / 14, preferredTimescale: 600)
                    }
                    var count = 0
                    for await result in generator.images(for: times) where (try? result.image) != nil {
                        count += 1
                    }
                    return count
                }
                _ = await time("waveform (both tracks)") {
                    await WaveformLoader.load(url: session.micAudioURL)
                }
                _ = await time("silence envelope") {
                    await WaveformLoader.load(url: session.micAudioURL,
                                              buckets: max(64, Int(duration * 50)))
                }

                print(String(format: "recording is %.1fs, %@", duration,
                             ByteCountFormatter.string(fromByteCount: session.sizeOnDisk, countStyle: .file)))
                exit(0)
            } catch {
                print("failed: \(error.localizedDescription)")
                exit(1)
            }
        }
    }

    static func runAndExit() {
        Task {
            let code = await run()
            exit(Int32(code))
        }
    }

    static func run() async -> Int {
        print("ajwoo capture — pipeline self-test")
        print(String(repeating: "-", count: 56))

        let root = URL(fileURLWithPath: NSTemporaryDirectory())
            .appendingPathComponent("ajwoo-selftest-\(UUID().uuidString)")
        defer { try? FileManager.default.removeItem(at: root) }

        do {
            let session = try makeSyntheticRecording(at: root)
            let log = try EventLog.read(from: session.eventsURL)

            try await checkOrientation(session: session, log: log)
            try await checkZoomCrop(session: session, log: log)
            try await checkCursorSizeIsZoomInvariant(session: session, log: log)
            try await checkCrop(session: session, log: log)
            try await checkArrowTones(session: session, log: log)
            try await checkFollowCursorZoom(session: session, log: log)
            try await checkCameraShapes(session: session, log: log)
            try await checkCameraCoversFullDuration()
            checkAutoZoomExcludesTrailingMenuBarClick()
            try await checkCuts(session: session, log: log)
            checkTimeMap()
            checkDefaults()
            checkStyleSets()
            checkCaptureQuality()
            checkTimeRulerLabels()
            checkWaveformResponse()
            checkAudioGain()
            checkCanvasAspectMath()
            try await checkCanvasAspectExport(session: session, log: log)
            checkMinimumWindowWidth()
            checkResetScope()
            checkMigration()
            checkLenientProjectLoading()
            checkCameraHitTest()
            checkPointerShapes()
            checkTranscriptAnalysis()
            checkSilenceDetection()
            try await checkSubtitlesRender(session: session, log: log)
            try await checkPointingHand(session: session, log: log)
            try await checkCursorShadow(session: session, log: log)
        } catch {
            print("✗ self-test aborted: \(error.localizedDescription)")
            failures += 1
        }

        print(String(repeating: "-", count: 56))
        print(failures == 0 ? "PASS — all checks green" : "FAIL — \(failures) check(s) failed")
        return failures == 0 ? 0 : 1
    }

    // MARK: - Checks

    /// Baseline for every check that isn't about the camera.
    ///
    /// The synthetic package includes a camera track and `CameraOverlay` defaults
    /// to enabled, so without this a magenta bubble sits in the corner that most
    /// of these checks sample.
    private static func baseProject() -> ProjectState {
        var project = ProjectState()
        project.camera.enabled = false
        // The padded background ships on, which insets the content and frames it
        // in near-black. Every pixel check below samples the *content*, so they
        // opt out; `checkDefaults` asserts the shipped value separately.
        project.background.enabled = false
        return project
    }


    /// No zoom: each quadrant of the export must hold its source colour. Catches
    /// vertical flips and left/right mirroring.
    private static func checkOrientation(session: RecordingSession, log: EventLog) async throws {
        var project = baseProject()
        project.cursor.kind = .hidden
        let frame = try await exportAndSample(session: session, log: log, project: project, at: 1.0)

        expect(frame.color(atFraction: 0.25, 0.25).matches(topLeftColor),
               "orientation: top-left quadrant is red",
               got: frame.color(atFraction: 0.25, 0.25).description)
        expect(frame.color(atFraction: 0.75, 0.25).matches(topRightColor),
               "orientation: top-right quadrant is green",
               got: frame.color(atFraction: 0.75, 0.25).description)
        expect(frame.color(atFraction: 0.25, 0.75).matches(bottomLeftColor),
               "orientation: bottom-left quadrant is blue",
               got: frame.color(atFraction: 0.25, 0.75).description)
        expect(frame.color(atFraction: 0.75, 0.75).matches(bottomRightColor),
               "orientation: bottom-right quadrant is yellow",
               got: frame.color(atFraction: 0.75, 0.75).description)
    }

    /// A 2x zoom focused on (0.25, 0.25) crops to exactly the top-left quadrant,
    /// so every sampled pixel must be red.
    private static func checkZoomCrop(session: RecordingSession, log: EventLog) async throws {
        var project = baseProject()
        project.cursor.kind = .hidden
        project.zoomSegments = [
            ProjectState.ZoomSegment(start: 0, end: durationSeconds, level: 2.0,
                                     focusX: 0.25, focusY: 0.25, rampDuration: 0.15)
        ]
        let frame = try await exportAndSample(session: session, log: log, project: project, at: 1.0)

        let samples = [(0.1, 0.1), (0.5, 0.5), (0.9, 0.9), (0.9, 0.1), (0.1, 0.9)]
        let allRed = samples.allSatisfy { frame.color(atFraction: $0.0, $0.1).matches(topLeftColor) }
        expect(allRed,
               "zoom: 2x focused on (0.25, 0.25) crops to exactly the red quadrant",
               got: samples.map { frame.color(atFraction: $0.0, $0.1).description }.joined(separator: " "))
    }

    /// The cursor is drawn after the crop, in output space, so its on-screen size
    /// must not change with zoom level. Counting near-white pixels isolates it —
    /// none of the four quadrant colours are near-white.
    private static func checkCursorSizeIsZoomInvariant(session: RecordingSession, log: EventLog) async throws {
        func cursorPixels(zoom: Double) async throws -> Int {
            var project = baseProject()
            project.cursor.kind = .arrow
            project.cursor.sizeMultiplier = 2.5
            project.cursor.clickPulse = false
            project.cursor.clickRipple = false
            if zoom > 1 {
                project.zoomSegments = [
                    ProjectState.ZoomSegment(start: 0, end: durationSeconds, level: zoom,
                                             focusX: 0.5, focusY: 0.5, rampDuration: 0.15)
                ]
            }
            let frame = try await exportAndSample(session: session, log: log, project: project, at: 1.0)
            return frame.countNearWhite()
        }

        let atOne = try await cursorPixels(zoom: 1.0)
        let atThree = try await cursorPixels(zoom: 3.0)

        expect(atOne > 200, "cursor: arrow is actually drawn (\(atOne) white px at 1x)", got: "\(atOne)")

        let ratio = atOne > 0 ? Double(atThree) / Double(atOne) : 0
        expect(ratio > 0.85 && ratio < 1.15,
               "cursor: on-screen size is constant through a 3x zoom",
               got: String(format: "1x=%d px, 3x=%d px, ratio %.3f", atOne, atThree, ratio))
    }

    /// Cropping to the bottom-right quadrant must yield a uniformly yellow
    /// frame, at that quadrant's aspect ratio. Also proves the crop's top-left
    /// origin survives the flip into Core Image space.
    private static func checkCrop(session: RecordingSession, log: EventLog) async throws {
        var project = baseProject()
        project.cursor.kind = .hidden
        project.crop = ProjectState.Crop(enabled: true, x: 0.5, y: 0.5, width: 0.5, height: 0.5)

        let frame = try await exportAndSample(session: session, log: log, project: project, at: 1.0)

        let samples = [(0.1, 0.1), (0.5, 0.5), (0.9, 0.9)]
        let allYellow = samples.allSatisfy { frame.color(atFraction: $0.0, $0.1).matches(bottomRightColor) }
        expect(allYellow,
               "crop: bottom-right quadrant crop yields a yellow frame",
               got: samples.map { frame.color(atFraction: $0.0, $0.1).description }.joined(separator: " "))

        expect(frame.width == sourceWidth / 2 && frame.height == sourceHeight / 2,
               "crop: export size follows the cropped region",
               got: "\(frame.width)×\(frame.height), wanted \(sourceWidth / 2)×\(sourceHeight / 2)")
    }

    /// Dark and light arrows must actually differ, and each must contain a
    /// meaningful amount of its own body colour — catches a sprite that silently
    /// renders in one tone regardless of the setting.
    private static func checkArrowTones(session: RecordingSession, log: EventLog) async throws {
        func frame(_ tone: ProjectState.CursorStyle.ArrowTone) async throws -> Frame {
            var project = baseProject()
            project.cursor.kind = .arrow
            project.cursor.arrowTone = tone
            project.cursor.sizeMultiplier = 3.0
            project.cursor.clickPulse = false
            project.cursor.clickRipple = false
            return try await exportAndSample(session: session, log: log, project: project, at: 1.0)
        }

        let dark = try await frame(.dark)
        let light = try await frame(.light)

        // None of the quadrant colours are near-black or near-white, so these
        // counts isolate the pointer body in each tone.
        let darkBody = dark.countNearBlack()
        let lightBody = light.countNearWhite()

        expect(darkBody > 200, "cursor: dark arrow has a black body (\(darkBody) px)", got: "\(darkBody)")
        expect(lightBody > 200, "cursor: light arrow has a white body (\(lightBody) px)", got: "\(lightBody)")

        // Both frames contain black *and* white pixels — each tone outlines
        // itself in the opposite colour. What separates them is which colour
        // fills the body, so compare like for like: the dark arrow's black body
        // against the light arrow's much thinner black outline.
        let lightOutline = light.countNearBlack()
        expect(Double(darkBody) > Double(lightOutline) * 1.5,
               "cursor: the two tones are genuinely different",
               got: "dark body \(darkBody) px vs light outline \(lightOutline) px")
    }

    /// A cursor-following zoom must centre on the pointer. The synthetic cursor
    /// sits at (0.5, 0.5) — the exact meeting point of all four quadrants — so a
    /// correctly centred 2x crop shows all four colours, one per corner.
    private static func checkFollowCursorZoom(session: RecordingSession, log: EventLog) async throws {
        var project = baseProject()
        project.cursor.kind = .hidden
        project.zoomSegments = [
            ProjectState.ZoomSegment(start: 0, end: durationSeconds, level: 2.0,
                                     // Deliberately wrong: follow must override it.
                                     focusX: 0.1, focusY: 0.9,
                                     rampDuration: 0.15, followsCursor: true)
        ]
        let frame = try await exportAndSample(session: session, log: log, project: project, at: 1.0)

        let corners = [
            (frame.color(atFraction: 0.15, 0.15), topLeftColor, "top-left red"),
            (frame.color(atFraction: 0.85, 0.15), topRightColor, "top-right green"),
            (frame.color(atFraction: 0.15, 0.85), bottomLeftColor, "bottom-left blue"),
            (frame.color(atFraction: 0.85, 0.85), bottomRightColor, "bottom-right yellow"),
        ]
        let centred = corners.allSatisfy { $0.0.matches($0.1) }
        expect(centred,
               "zoom follow: focus tracks the cursor and overrides the static focus point",
               got: corners.map { "\($0.2)=\($0.0.description)" }.joined(separator: " "))
    }

    /// Each bubble shape must mask to its own area.
    ///
    /// Comparing pixel counts rather than sampling points: the ratios are fixed
    /// by geometry (a circle covers π/4 of its bounding box, a 5-point star with
    /// a 0.42 inner radius about 0.31), so this catches a mask that silently
    /// falls back to a rectangle — which is exactly how a broken star would look
    /// if the path failed to build.
    private static func checkCameraShapes(session: RecordingSession, log: EventLog) async throws {
        func bubblePixels(_ shape: ProjectState.CameraOverlay.Shape) async throws -> Int {
            var project = baseProject()
            project.cursor.kind = .hidden
            project.camera.enabled = true
            project.camera.shape = shape
            project.camera.size = 0.4
            project.camera.aspect = 1.0
            project.camera.shadow = false
            // Centred on purpose. These checks measure what fraction of the
            // bubble's box each mask fills, which only means anything while the
            // whole box is inside the frame — the shipped default now tucks it
            // into the corner, where a 0.4-size bubble would be clipped.
            project.camera.centerX = 0.5
            project.camera.centerY = 0.5
            let frame = try await exportAndSample(session: session, log: log, project: project, at: 1.0)
            return frame.count(matching: cameraColor)
        }

        let rectangle = try await bubblePixels(.rectangle)
        let circle = try await bubblePixels(.circle)
        let star = try await bubblePixels(.star)
        let rounded = try await bubblePixels(.roundedRectangle)

        expect(rectangle > 5000, "camera: rectangle bubble is composited (\(rectangle) px)", got: "\(rectangle)")

        let circleRatio = Double(circle) / Double(max(1, rectangle))
        expect(circleRatio > 0.70 && circleRatio < 0.85,
               "camera: circle mask covers ~π/4 of its box",
               got: String(format: "%.3f", circleRatio))

        // ~0.45. The old bound was 0.20-0.45 around "~0.31", which only held
        // because the bubble was being clipped by the right edge of the frame at
        // the position this check used to run at — the star was measured with a
        // slice missing. Centred and whole, a five-pointed star of these
        // proportions fills a little under half its box.
        let starRatio = Double(star) / Double(max(1, rectangle))
        expect(starRatio > 0.38 && starRatio < 0.52,
               "camera: star mask covers ~0.45 of its box",
               got: String(format: "%.3f", starRatio))

        let roundedRatio = Double(rounded) / Double(max(1, rectangle))
        expect(roundedRatio > 0.85 && roundedRatio < 1.0,
               "camera: rounded rectangle sits between a rectangle and a circle",
               got: String(format: "%.3f", roundedRatio))

        try await checkStarPointsUp(session: session, log: log)
    }

    /// The camera bubble must not disappear at the head or tail of the export,
    /// even when the camera hardware itself started late or stopped early —
    /// which it always does, by some amount, in a real recording. See
    /// `CompositionBuilder.insertCamera` for the mechanism this is pinning.
    ///
    /// Builds its own fixture rather than using the shared one: `camera.mov`
    /// here deliberately covers only the *middle* 1.2 s of the 2 s recording
    /// (0.4 s missing at each end, an exaggerated stand-in for the real
    /// hundred-or-so milliseconds a webcam takes to warm up and wind down), and
    /// that shouldn't leak into any other check that assumes a normal camera.
    private static func checkCameraCoversFullDuration() async throws {
        let root = URL(fileURLWithPath: NSTemporaryDirectory())
            .appendingPathComponent("ajwoo-camera-sync-\(UUID().uuidString)")
        defer { try? FileManager.default.removeItem(at: root) }

        let session = try makeSyntheticRecording(at: root, cameraTimeRange: 0.4...(durationSeconds - 0.4))
        let log = try EventLog.read(from: session.eventsURL)

        func cameraPixels(at time: Double) async throws -> Int {
            var project = baseProject()
            project.cursor.kind = .hidden
            project.camera.enabled = true
            project.camera.shape = .rectangle
            project.camera.size = 0.4
            project.camera.aspect = 1.0
            project.camera.shadow = false
            project.camera.centerX = 0.5
            project.camera.centerY = 0.5
            let frame = try await exportAndSample(session: session, log: log, project: project, at: time)
            return frame.count(matching: cameraColor)
        }

        // Comfortably inside the camera's *real* footage, as a sanity check on
        // the fixture itself before trusting what the edges say.
        let middle = try await cameraPixels(at: 1.0)
        expect(middle > 5000,
               "camera sync: the fixture's real camera footage shows up mid-clip",
               got: "\(middle) px")

        // Just after the export starts — real camera.mov has nothing here.
        let headHeld = try await cameraPixels(at: 0.05)
        expect(headHeld > 5000,
               "camera sync: the bubble still shows at the very start, held from the first real frame",
               got: "\(headHeld) px")

        // Just before the export ends — real camera.mov stopped 0.4 s earlier.
        let tailHeld = try await cameraPixels(at: durationSeconds - 0.05)
        expect(tailHeld > 5000,
               "camera sync: the bubble still shows at the very end, held from the last real frame",
               got: "\(tailHeld) px")
    }

    /// `AutoZoomGenerator` directly — no session, no export, no `EditorModel`.
    /// Pins the exact behaviour asked for: the trailing click cluster is
    /// dropped when it sits in the menu bar's strip, an *identical* click
    /// earlier in the recording is not touched, and the blueprint (what the
    /// wand tool compares against) keeps the dropped one so it can still be
    /// restored.
    private static func checkAutoZoomExcludesTrailingMenuBarClick() {
        func click(_ t: Double, y: Double) -> EventLog.ClickEvent {
            .init(t: t, x: 0.5, y: y, button: .left, phase: .down)
        }
        var settings = ProjectState.AutoZoom()
        settings.leadIn = 0.5
        settings.holdAfter = 0.5
        settings.clusterGap = 1.2

        // Two clusters, comfortably far apart (7 s, over the 1.2 s clusterGap):
        // ordinary content at t=1, then a menu-bar-height click at t=8 — a
        // stand-in for opening the menu bar and clicking Stop at the end.
        let clicks = [click(1.0, y: 0.5), click(8.0, y: 0.02)]

        let live = AutoZoomGenerator.segments(clicks: clicks, settings: settings, duration: 12.0,
                                              existing: [], excludingTrailingMenuBarClick: true)
        let liveFocusY = live.first?.focusY ?? -1
        expect(live.count == 1 && abs(liveFocusY - 0.5) < 0.01,
               "auto-zoom: a trailing menu-bar click is left out of the live timeline",
               got: "\(live.count) segment(s): \(live.map { $0.focusY })")

        let blueprint = AutoZoomGenerator.segments(clicks: clicks, settings: settings, duration: 12.0,
                                                   existing: [], excludingTrailingMenuBarClick: false)
        expect(blueprint.count == 2,
               "auto-zoom: the blueprint keeps it, so the wand tool can still offer it back",
               got: "\(blueprint.count) segment(s)")

        // Same menu-bar-height click, but now it's the *first* of two — a
        // legitimate reason to point at the menu bar mid-recording, not a sign
        // the take is about to end. Nothing should be excluded.
        let reordered = [click(1.0, y: 0.02), click(8.0, y: 0.5)]
        let notTrailing = AutoZoomGenerator.segments(clicks: reordered, settings: settings, duration: 12.0,
                                                     existing: [], excludingTrailingMenuBarClick: true)
        expect(notTrailing.count == 2,
               "auto-zoom: a menu-bar-height click earlier in the recording is left alone",
               got: "\(notTrailing.count) segment(s)")

        // A trailing click that *isn't* near the menu bar — ordinary content
        // right at the end of a take — must survive.
        let ordinaryTail = [click(1.0, y: 0.5), click(8.0, y: 0.6)]
        let untouched = AutoZoomGenerator.segments(clicks: ordinaryTail, settings: settings, duration: 12.0,
                                                    existing: [], excludingTrailingMenuBarClick: true)
        expect(untouched.count == 2,
               "auto-zoom: an ordinary trailing click, away from the menu bar, is kept",
               got: "\(untouched.count) segment(s)")
    }

    /// A five-pointed star pointing up has a single sharp point at top centre and
    /// a notch between two legs at bottom centre. Sampling the centre column at
    /// each end is decisive; comparing whole halves is not, because the wide arms
    /// sit above the midline and give the top more area either way — which is how
    /// the first version of this check managed to fail on correct output.
    private static func checkStarPointsUp(session: RecordingSession, log: EventLog) async throws {
        var project = baseProject()
        project.cursor.kind = .hidden
        project.camera.enabled = true
        project.camera.shape = .star
        project.camera.size = 0.5
        project.camera.aspect = 1.0
        project.camera.shadow = false
        project.camera.centerX = 0.5
        project.camera.centerY = 0.5

        let frame = try await exportAndSample(session: session, log: log, project: project, at: 1.0)

        // Bubble occupies the middle 50% of the height, centred.
        func centreColumnFill(yRange: ClosedRange<Double>) -> Int {
            var count = 0
            let xLow = Int(0.47 * Double(frame.width))
            let xHigh = Int(0.53 * Double(frame.width))
            for y in Int(yRange.lowerBound * Double(frame.height))...Int(yRange.upperBound * Double(frame.height)) {
                for x in xLow...xHigh {
                    let offset = (y * frame.width + x) * 4
                    guard offset + 2 < frame.pixels.count else { continue }
                    let colour = Frame.Color(r: Double(frame.pixels[offset]) / 255,
                                             g: Double(frame.pixels[offset + 1]) / 255,
                                             b: Double(frame.pixels[offset + 2]) / 255)
                    if colour.matches(cameraColor) { count += 1 }
                }
            }
            return count
        }

        let topPoint = centreColumnFill(yRange: 0.26...0.32)
        let bottomNotch = centreColumnFill(yRange: 0.68...0.74)

        expect(topPoint > 200,
               "camera: star has its point at the top",
               got: "top-centre \(topPoint) px")
        expect(bottomNotch < topPoint / 3,
               "camera: star has the notch between its legs at the bottom",
               got: "top-centre \(topPoint) px vs bottom-centre \(bottomNotch) px")
    }

    /// Cutting the first half must make the export half as long and start with
    /// what used to be at the midpoint.
    ///
    /// The synthetic clip is uniform in time, so a second track is needed to tell
    /// "before" from "after": a zoom that only fires in the back half. If the cut
    /// worked, that zoom is active at t=0 of the output.
    private static func checkCuts(session: RecordingSession, log: EventLog) async throws {
        var project = baseProject()
        project.cursor.kind = .hidden
        project.cuts = [ProjectState.CutRange(start: 0, end: durationSeconds / 2)]
        project.zoomSegments = [
            ProjectState.ZoomSegment(start: durationSeconds / 2, end: durationSeconds,
                                     level: 2.0, focusX: 0.25, focusY: 0.25, rampDuration: 0.05)
        ]

        let context = RenderContext(log: log, project: project)
        let output = session.url.appendingPathComponent("selftest-cut-\(UUID().uuidString).mov")
        defer { try? FileManager.default.removeItem(at: output) }

        var settings = ExportSettings()
        settings.preset = .original
        settings.codec = .h264

        _ = try await VideoExporter.export(session: session, context: context, settings: settings,
                                           to: output, token: ExportCancellationToken()) { _ in }

        let asset = AVURLAsset(url: output)
        let exported = (try? await asset.load(.duration))?.seconds ?? 0
        let expected = durationSeconds / 2
        expect(abs(exported - expected) < 0.25,
               "cuts: removing half the clip halves the export",
               got: String(format: "%.2fs, wanted ~%.2fs", exported, expected))

        let frame = try await Frame.sample(from: output, at: 0.3)
        expect(frame.color(atFraction: 0.5, 0.5).matches(topLeftColor),
               "cuts: output starts at the far side of the cut, with zoom still aligned",
               got: frame.color(atFraction: 0.5, 0.5).description)
    }

    /// `TimeMap` in isolation — the piece every cut-related bug would route through.
    private static func checkTimeMap() {
        let map = TimeMap(cuts: [ProjectState.CutRange(start: 2, end: 4)], duration: 10)

        expect(abs(map.compositionDuration - 8) < 0.001,
               "time map: a 2 s cut shortens a 10 s recording to 8 s",
               got: String(format: "%.3f", map.compositionDuration))
        expect(abs(map.recordingTime(forComposition: 1) - 1) < 0.001,
               "time map: before the cut, the two clocks agree",
               got: String(format: "%.3f", map.recordingTime(forComposition: 1)))
        expect(abs(map.recordingTime(forComposition: 3) - 5) < 0.001,
               "time map: after the cut, composition 3 s is recording 5 s",
               got: String(format: "%.3f", map.recordingTime(forComposition: 3)))
        expect(abs(map.compositionTime(forRecording: 5) - 3) < 0.001,
               "time map: the inverse agrees",
               got: String(format: "%.3f", map.compositionTime(forRecording: 5)))
        expect(map.isCut(3) && !map.isCut(1) && !map.isCut(5),
               "time map: reports which instants were removed",
               got: "isCut(3)=\(map.isCut(3)) isCut(1)=\(map.isCut(1)) isCut(5)=\(map.isCut(5))")

        let messy = TimeMap(cuts: [
            ProjectState.CutRange(start: 6, end: 8),
            ProjectState.CutRange(start: 1, end: 3),
            ProjectState.CutRange(start: 2, end: 4),
        ], duration: 10)
        expect(abs(messy.compositionDuration - 5) < 0.001,
               "time map: overlapping, out-of-order cuts merge",
               got: String(format: "%.3f", messy.compositionDuration))
    }

    /// The shipped defaults, since they're product decisions rather than an
    /// accident of whatever the struct happened to initialise to.
    /// A set carries the look and leaves the timeline alone.
    ///
    /// The failure this guards against is the expensive one: applying a saved
    /// look wiping out an hour of cutting because `apply` assigned the whole
    /// project instead of the style fields.
    private static func checkStyleSets() {
        var source = ProjectState()
        source.cursor.sizeMultiplier = 3.4
        source.background.enabled = false
        source.subtitles.uppercase = true
        source.audio.micVolume = 0.31

        let set = StyleSet(from: source)

        var target = ProjectState()
        target.cuts = [.init(start: 1, end: 2)]
        target.zoomSegments = [.init(start: 0, end: 1, level: 2)]
        target.trimStart = 0.5
        target.trimEnd = 9
        target.crop = .init(enabled: true, x: 0.1, y: 0.1, width: 0.5, height: 0.5)
        target.subtitles.edits = ["1.00": "corrected"]

        set.apply(to: &target)

        expect(target.cursor.sizeMultiplier == 3.4 && target.subtitles.uppercase
                && !target.background.enabled && target.audio.micVolume == 0.31,
               "style set: the look is applied",
               got: "size \(target.cursor.sizeMultiplier), caps \(target.subtitles.uppercase)")

        expect(target.cuts.count == 1 && target.zoomSegments.count == 1
                && target.trimStart == 0.5 && target.trimEnd == 9 && target.crop.enabled,
               "style set: cuts, zooms, trim and crop survive",
               got: "\(target.cuts.count) cuts, \(target.zoomSegments.count) zooms, crop \(target.crop.enabled)")

        expect(target.subtitles.edits["1.00"] == "corrected",
               "style set: hand-corrected captions survive",
               got: "\(target.subtitles.edits)")

        expect(StyleSet(from: source).subtitles.edits.isEmpty,
               "style set: corrections are never stored in a set",
               got: "\(StyleSet(from: source).subtitles.edits.count) entries")

        // Opening a project builds its auto zooms, which flips
        // `autoZoom.generated`. If that flag counts toward a set's identity then
        // an untouched project never matches the defaults, and Reset is
        // permanently offered on a project with nothing to reset.
        var opened = ProjectState()
        opened.autoZoom.generated = true
        expect(StyleSet(from: opened) == StyleSet(from: ProjectState()),
               "style set: an untouched project still equals the defaults",
               got: "generated flag \(StyleSet(from: opened) == StyleSet(from: ProjectState()) ? "ignored" : "counted")")
    }

    /// The quality tiers have to actually separate, and stay sane at 1080p
    /// where the floor rather than the pixel budget decides the number.
    private static func checkCaptureQuality() {
        func bitrate(_ quality: CaptureSettings.Quality, width: Int, height: Int, fps: Int) -> Int {
            var settings = CaptureSettings()
            settings.quality = quality
            settings.frameRate = fps
            return settings.masterBitrate(pixelWidth: width, pixelHeight: height)
        }

        // 4K60, where the pixel budget dominates.
        let light4K = bitrate(.light, width: 3840, height: 2160, fps: 60)
        let balanced4K = bitrate(.balanced, width: 3840, height: 2160, fps: 60)
        let fine4K = bitrate(.fine, width: 3840, height: 2160, fps: 60)
        expect(light4K < balanced4K && balanced4K < fine4K,
               "quality: the three tiers separate at 4K60",
               got: "\(light4K / 1_000_000) / \(balanced4K / 1_000_000) / \(fine4K / 1_000_000) Mbps")

        // 1080p60, where the floor used to flatten every tier to the same number.
        let light1080 = bitrate(.light, width: 1920, height: 1080, fps: 60)
        let balanced1080 = bitrate(.balanced, width: 1920, height: 1080, fps: 60)
        let fine1080 = bitrate(.fine, width: 1920, height: 1080, fps: 60)
        expect(light1080 < balanced1080 && balanced1080 < fine1080,
               "quality: the tiers still separate at 1080p, where the floor applies",
               got: "\(light1080 / 1_000_000) / \(balanced1080 / 1_000_000) / \(fine1080 / 1_000_000) Mbps")

        // The floor used to be absolute, which made 1080p15 and 1080p60 identical
        // — choosing a lower frame rate for a smaller file did nothing at exactly
        // the resolution where people would try it. This is that regression.
        for (width, height, name) in [(1920, 1080, "1080p"), (3840, 2160, "4K")] {
            let slow = bitrate(.balanced, width: width, height: height, fps: 15)
            let fast = bitrate(.balanced, width: width, height: height, fps: 60)
            expect(Double(slow) < Double(fast) * 0.4,
                   "quality: 15 fps costs far fewer bits than 60 at \(name)",
                   got: "\(slow / 1_000_000) vs \(fast / 1_000_000) Mbps")
        }

        expect(CaptureSettings.frameRateOptions.contains(CaptureSettings().frameRate),
               "quality: the shipped frame rate is one you can pick",
               got: "\(CaptureSettings().frameRate)")
    }

    /// The ruler's labels have to be readable as times, not as bare counts.
    private static func checkTimeRulerLabels() {
        // The first mark is 0, and it is drawn rather than clipped off the left
        // edge — a ruler that starts at 1 is missing the one number you can be
        // certain of.
        expect(TimeRuler.label(0) == "0",
               "ruler: the scale starts at 0",
               got: TimeRuler.label(0))

        expect(TimeRuler.label(0) == "0" && TimeRuler.label(12) == "12",
               "ruler: seconds under a minute are plain numbers",
               got: "\(TimeRuler.label(0)), \(TimeRuler.label(12))")
        expect(TimeRuler.label(60) == "1:00" && TimeRuler.label(65) == "1:05",
               "ruler: a minute and over reads as m:ss, not as 65",
               got: "\(TimeRuler.label(60)), \(TimeRuler.label(65))")
        expect(TimeRuler.label(605) == "10:05",
               "ruler: ten minutes and past it still pads the seconds",
               got: TimeRuler.label(605))
    }

    /// The window's minimum has to actually clear the action bar.
    ///
    /// This is the check that would have caught the clipping: the row's fixed
    /// controls plus their gaps plus both page margins, compared against the
    /// minimum the scene is given. It also reports the number, since it moves
    /// whenever a control or a label does.
    private static func checkMinimumWindowWidth() {
        let minimum = MainWindowView.minimumContentWidth

        // Recomputed independently of the property, so a mistake in one doesn't
        // silently agree with the same mistake in the other.
        let font = NSFont.systemFont(ofSize: 14, weight: .medium)
        func width(_ text: String) -> CGFloat {
            ceil((text as NSString).size(withAttributes: [.font: font]).width)
        }
        let segments = max(92, width("Full display") + 24) + max(92, width("Region") + 24)
        let fixed = 96 + 40 + 40 + segments + 200 + 40
        let margins = DS.Space.l * 2

        expect(minimum >= fixed + margins,
               "window: the minimum width clears the action bar's fixed controls",
               got: String(format: "minimum %.0f, controls + margins %.0f", minimum, fixed + margins))

        // A minimum wider than a small laptop's screen would be its own bug.
        expect(minimum < 1000,
               "window: and doesn't demand an unreasonable screen",
               got: String(format: "%.0f pt", minimum))
        print(String(format: "      minimum window width: %.0f pt", minimum))
    }

    /// The waveform has to use the row it's given.
    ///
    /// Drawn linearly, ordinary speech (peaks around 0.2-0.4 of full scale) sat
    /// as a barely-moving ripple near the centre line and the row's top and
    /// bottom went unused — you could see there *was* audio but not where it got
    /// louder. These checks pin the shape of the curve rather than the pixels.
    private static func checkWaveformResponse() {
        let size = CGSize(width: 100, height: 24)
        let midY = size.height / 2

        /// How far from the centre line a single sample is drawn, 0...1 of the
        /// half-height available.
        func reach(_ value: Float) -> CGFloat {
            let path = Waveform.envelope([value], in: size, midY: midY, gain: 1)
            let top = path.boundingRect.minY
            return (midY - top) / (midY - 1)
        }

        expect(reach(0.0) < 0.01,
               "waveform: silence sits on the centre line",
               got: String(format: "%.3f", reach(0.0)))
        expect(reach(0.004) < 0.01,
               "waveform: the noise floor is gated out, not lifted by the curve",
               got: String(format: "%.3f", reach(0.004)))

        // Ordinary speech should use a good half of the row, not a tenth of it.
        expect(reach(0.3) > 0.55,
               "waveform: ordinary speech reaches well up the row",
               got: String(format: "%.2f of the half-height", reach(0.3)))

        // And anything genuinely loud should reach the edge and clip there.
        expect(reach(0.85) >= 0.99,
               "waveform: loud audio hits the top of the row",
               got: String(format: "%.2f", reach(0.85)))

        // Still monotonic — louder must never draw shorter.
        expect(reach(0.1) < reach(0.3) && reach(0.3) < reach(0.6),
               "waveform: louder always draws taller",
               got: String(format: "%.2f / %.2f / %.2f", reach(0.1), reach(0.3), reach(0.6)))
    }

    /// Levels above 1.0 have to reach the mix unclamped.
    ///
    /// The point of a 2x range is rescuing a take recorded too quietly, and a
    /// fader that silently caps at 1.0 would look like it worked while doing
    /// nothing above the midpoint.
    private static func checkAudioGain() {
        var project = ProjectState()
        project.audio.systemVolume = 1.8
        project.audio.micVolume = 2.0

        let composition = AVMutableComposition()
        guard composition.addMutableTrack(withMediaType: .audio,
                                          preferredTrackID: CompositionBuilder.systemAudioTrackID) != nil,
              composition.addMutableTrack(withMediaType: .audio,
                                          preferredTrackID: CompositionBuilder.micAudioTrackID) != nil,
              let mix = CompositionBuilder.audioMix(for: composition, project: project)
        else {
            expect(false, "audio gain: a mix could be built", got: "no mix")
            return
        }

        func volume(for trackID: CMPersistentTrackID) -> Float? {
            guard let params = mix.inputParameters.first(where: { $0.trackID == trackID }) else { return nil }
            var start = Float(0)
            var range = CMTimeRange.zero
            _ = params.getVolumeRamp(for: .zero, startVolume: &start,
                                     endVolume: nil, timeRange: &range)
            return start
        }

        expect(volume(for: CompositionBuilder.systemAudioTrackID) == 1.8,
               "audio gain: system level above 1.0 reaches the mix intact",
               got: "\(String(describing: volume(for: CompositionBuilder.systemAudioTrackID)))")
        expect(volume(for: CompositionBuilder.micAudioTrackID) == 2.0,
               "audio gain: microphone level reaches 2x",
               got: "\(String(describing: volume(for: CompositionBuilder.micAudioTrackID)))")

        // Muting still wins over any level.
        project.audio.micMuted = true
        if let muted = CompositionBuilder.audioMix(for: composition, project: project),
           let params = muted.inputParameters.first(where: { $0.trackID == CompositionBuilder.micAudioTrackID }) {
            var start = Float(-1)
            var range = CMTimeRange.zero
            _ = params.getVolumeRamp(for: .zero, startVolume: &start, endVolume: nil, timeRange: &range)
            expect(start == 0,
                   "audio gain: mute overrides the level",
                   got: "\(start)")
        }
    }

    /// `Background.canvasSize(for:)` in isolation — the pure math the whole
    /// feature rests on, checked without a session, a renderer or an encoder in
    /// the way.
    private static func checkCanvasAspectMath() {
        let content = CGSize(width: 1280, height: 720) // 16:9, matches the fixture

        var off = ProjectState.Background()
        off.enabled = false
        off.aspectRatio = .square
        expect(off.canvasSize(for: content) == content,
               "canvas aspect: a disabled background always follows the recording",
               got: "\(off.canvasSize(for: content))")

        var recording = ProjectState.Background()
        recording.aspectRatio = .recording
        expect(recording.canvasSize(for: content) == content,
               "canvas aspect: \"Recording\" follows the recording even with the background on",
               got: "\(recording.canvasSize(for: content))")

        // Every fixed ratio: the result has to actually be that ratio, hold
        // roughly the same pixel area as the source (not its width or height),
        // and land on even dimensions.
        let cases: [(ProjectState.Background.CanvasAspect, Double)] = [
            (.widescreen, 16.0 / 9.0), (.standard, 4.0 / 3.0), (.square, 1.0),
            (.portraitStandard, 3.0 / 4.0), (.portraitTall, 9.0 / 16.0),
        ]
        let sourceArea = Double(content.width * content.height)
        for (aspect, ratio) in cases {
            var background = ProjectState.Background()
            background.aspectRatio = aspect
            let size = background.canvasSize(for: content)
            let gotRatio = Double(size.width / size.height)

            expect(abs(gotRatio - ratio) < 0.01,
                   "canvas aspect: \(aspect.label) actually measures \(aspect.label)",
                   got: String(format: "%.3f vs %.3f", gotRatio, ratio))

            let area = Double(size.width * size.height)
            expect(abs(area - sourceArea) / sourceArea < 0.03,
                   "canvas aspect: \(aspect.label) keeps roughly the source's pixel budget",
                   got: String(format: "%.0f vs %.0f px", area, sourceArea))

            expect(Int(size.width) % 2 == 0 && Int(size.height) % 2 == 0,
                   "canvas aspect: \(aspect.label) lands on even pixel dimensions",
                   got: "\(size)")
        }
    }

    /// End to end: a portrait export aspect has to actually change the exported
    /// file's pixel dimensions, not just the number reported by a helper
    /// function nothing else calls.
    private static func checkCanvasAspectExport(session: RecordingSession, log: EventLog) async throws {
        var project = baseProject()
        project.background.enabled = true
        project.background.aspectRatio = .portraitTall // 9:16

        let context = RenderContext(log: log, project: project)
        let output = session.url.appendingPathComponent("selftest-\(UUID().uuidString).mov")

        var settings = ExportSettings()
        settings.preset = .original
        settings.codec = .h264
        settings.frameRateMode = .matchSource

        _ = try await VideoExporter.export(
            session: session, context: context, settings: settings,
            to: output, token: ExportCancellationToken()
        ) { _ in }
        defer { try? FileManager.default.removeItem(at: output) }

        let asset = AVURLAsset(url: output)
        guard let track = try? await asset.loadTracks(withMediaType: .video).first,
              let natural = try? await track.load(.naturalSize)
        else {
            expect(false, "canvas aspect export: the exported file has a video track", got: "none")
            return
        }

        let gotRatio = Double(natural.width / natural.height)
        expect(abs(gotRatio - 9.0 / 16.0) < 0.02,
               "canvas aspect export: a portrait export ratio actually exports portrait",
               got: String(format: "%dx%d (%.3f)", Int(natural.width), Int(natural.height), gotRatio))

        // And the padded content should still be visible inside it, letterboxed
        // by the background rather than stretched or cropped away — the
        // synthetic frame's four quadrant colours are still findable somewhere
        // in the middle band.
        let frame = try await Frame.sample(from: output, at: 1.0)
        expect(frame.width == Int(natural.width) && frame.height == Int(natural.height),
               "canvas aspect export: the sampled frame matches the track's own size",
               got: "\(frame.width)x\(frame.height) vs \(Int(natural.width))x\(Int(natural.height))")
    }

    /// Reset is a panel button, not a timeline button.
    ///
    /// The version before this reset the zooms too, which meant clicking it to
    /// undo a colour choice silently put back every automatic zoom you had
    /// deleted. That's the failure being pinned here.
    private static func checkResetScope() {
        var project = ProjectState()
        project.cursor.sizeMultiplier = 3.9
        project.background.enabled = false
        project.zoomSegments = [
            .init(start: 0, end: 1, level: 2, isAuto: true),
            .init(start: 4, end: 5, level: 3, isAuto: false),
        ]
        project.cuts = [.init(start: 2, end: 3)]
        project.autoZoom.generated = true

        var reset = project
        StyleSet(from: ProjectState()).apply(to: &reset)
        reset.autoZoom.generated = project.autoZoom.generated
        reset.zoomSegments = project.zoomSegments

        expect(reset.cursor.sizeMultiplier == ProjectState().cursor.sizeMultiplier
                && reset.background.enabled,
               "reset: panel settings go back to their defaults",
               got: "size \(reset.cursor.sizeMultiplier), background \(reset.background.enabled)")
        expect(reset.zoomSegments.count == 2 && reset.cuts.count == 1
                && reset.autoZoom.generated,
               "reset: the timeline is untouched, automatic zooms included",
               got: "\(reset.zoomSegments.count) zooms, \(reset.cuts.count) cuts, generated \(reset.autoZoom.generated)")
    }

    /// A project file written by an older build must still load everything it
    /// does contain.
    ///
    /// This is the bug that cost real work: adding a field to `autoZoom` made
    /// every project.json written before it fail to decode, and the caller fell
    /// back to `ProjectState()` — discarding that recording's cuts, zooms, trim
    /// and crop without a word. The checks below drive the three ways a stored
    /// file can disagree with the current model.
    private static func checkLenientProjectLoading() {
        let root = URL(fileURLWithPath: NSTemporaryDirectory())
            .appendingPathComponent("ajwoo-project-\(UUID().uuidString)")
        try? FileManager.default.createDirectory(at: root, withIntermediateDirectories: true)
        defer { try? FileManager.default.removeItem(at: root) }

        func roundTrip(_ transform: (inout [String: Any]) -> Void) -> ProjectState? {
            var project = ProjectState()
            project.cuts = [.init(start: 1, end: 2)]
            project.zoomSegments = [.init(start: 3, end: 4, level: 2.5)]
            project.trimStart = 0.5
            project.cursor.sizeMultiplier = 3.25

            guard let data = try? JSONEncoder().encode(project),
                  var object = try? JSONSerialization.jsonObject(with: data) as? [String: Any]
            else { return nil }
            transform(&object)

            let url = root.appendingPathComponent("\(UUID().uuidString).json")
            guard let out = try? JSONSerialization.data(withJSONObject: object),
                  (try? out.write(to: url)) != nil
            else { return nil }
            return try? ProjectState.read(from: url)
        }

        func survived(_ loaded: ProjectState?) -> Bool {
            guard let loaded else { return false }
            return loaded.cuts.count == 1 && loaded.zoomSegments.count == 1
                && loaded.trimStart == 0.5 && loaded.cursor.sizeMultiplier == 3.25
        }

        // 1. A setting that didn't exist yet, nested inside a sub-object.
        let missing = roundTrip { object in
            if var autoZoom = object["autoZoom"] as? [String: Any] {
                autoZoom.removeValue(forKey: "followsCursor")
                object["autoZoom"] = autoZoom
            }
        }
        expect(survived(missing),
               "loading: a file missing a newer setting keeps everything else",
               got: missing.map { "\($0.cuts.count) cuts, trim \($0.trimStart)" } ?? "failed to load")
        expect(missing?.autoZoom.followsCursor == ProjectState().autoZoom.followsCursor,
               "loading: and the missing setting takes its default",
               got: "\(String(describing: missing?.autoZoom.followsCursor))")

        // 2. A setting that changed type. `motionBlur` went Bool -> Double and
        //    then away entirely; a stored value of the wrong shape must never
        //    cost the user their edits.
        let retyped = roundTrip { object in
            if var autoZoom = object["autoZoom"] as? [String: Any] {
                autoZoom["level"] = "not a number"
                object["autoZoom"] = autoZoom
            }
        }
        expect(survived(retyped),
               "loading: a setting that changed type doesn't discard the project",
               got: retyped.map { "\($0.cuts.count) cuts" } ?? "failed to load")
        expect(retyped?.autoZoom.level == ProjectState().autoZoom.level,
               "loading: the retyped setting falls back to its default",
               got: "\(String(describing: retyped?.autoZoom.level))")

        // 3. A setting from a newer build that this one doesn't know about.
        let extra = roundTrip { object in
            object["somethingFromTheFuture"] = 42
            if var autoZoom = object["autoZoom"] as? [String: Any] {
                autoZoom["futureKnob"] = "on"
                object["autoZoom"] = autoZoom
            }
        }
        expect(survived(extra),
               "loading: unknown settings from a newer build are ignored, not fatal",
               got: extra.map { "\($0.cuts.count) cuts" } ?? "failed to load")
    }

    /// A project saved before the schema marker existed must still load, and
    /// must keep every choice it recorded.
    private static func checkMigration() {
        var old = ProjectState()
        old.cursor.matchSystemShape = true
        old.cursor.sizeMultiplier = 2.5
        old.cuts = [.init(start: 1, end: 2)]
        old.schemaVersion = nil

        var migrated = old
        migrated.migrate()

        expect(migrated.schemaVersion == ProjectState.currentSchemaVersion,
               "migration: the schema stamp is written",
               got: "\(String(describing: migrated.schemaVersion))")
        expect(migrated.cursor.matchSystemShape && migrated.cursor.sizeMultiplier == 2.5
                && migrated.cuts.count == 1,
               "migration: stored choices survive untouched",
               got: "hand \(migrated.cursor.matchSystemShape), size \(migrated.cursor.sizeMultiplier)")

        // And the other way round: a project that switched it off keeps it off.
        var off = ProjectState()
        off.cursor.matchSystemShape = false
        off.schemaVersion = nil
        off.migrate()
        expect(!off.cursor.matchSystemShape,
               "migration: switching it off is respected too",
               got: "\(off.cursor.matchSystemShape)")

        // Version 4: the subtitle backdrop picker dropped "None" as a choice.
        // The case stays in the model so an old file that stored it still
        // decodes, but the migration steers it onto the option that draws the
        // same thing, so it isn't left selecting a segment the control no
        // longer shows.
        var noneBackdrop = ProjectState()
        noneBackdrop.subtitles.backdrop = .none
        noneBackdrop.schemaVersion = nil
        noneBackdrop.migrate()
        expect(noneBackdrop.subtitles.backdrop == .shadow,
               "migration: a subtitle backdrop of \"None\" becomes \"Shadow\"",
               got: "\(noneBackdrop.subtitles.backdrop)")

        // Backdrops already on a real choice are left alone.
        var boxBackdrop = ProjectState()
        boxBackdrop.subtitles.backdrop = .box
        boxBackdrop.schemaVersion = nil
        boxBackdrop.migrate()
        expect(boxBackdrop.subtitles.backdrop == .box,
               "migration: a subtitle backdrop of \"Box\" is untouched",
               got: "\(boxBackdrop.subtitles.backdrop)")
    }

    private static func checkDefaults() {
        let defaults = ProjectState()
        expect(defaults.autoZoom.enabled, "defaults: auto-zoom on click is on", got: "\(defaults.autoZoom.enabled)")
        expect(defaults.autoZoom.level == 1.5, "defaults: auto-zoom level is 1.5x",
               got: "\(defaults.autoZoom.level)")
        expect(defaults.autoZoom.leadIn == 1.0, "defaults: auto-zoom leads in by 1 s",
               got: "\(defaults.autoZoom.leadIn)")
        expect(defaults.autoZoom.holdAfter == 2.0, "defaults: auto-zoom holds for 2 s",
               got: "\(defaults.autoZoom.holdAfter)")
        expect(defaults.autoZoom.followsCursor, "defaults: auto zooms follow the cursor",
               got: "\(defaults.autoZoom.followsCursor)")
        expect(!defaults.cursor.clickRipple, "defaults: click ripple is off",
               got: "\(defaults.cursor.clickRipple)")
        expect(defaults.cursor.arrowTone == .dark, "defaults: arrow tone is dark (macOS)",
               got: "\(defaults.cursor.arrowTone)")
        expect(defaults.cursor.clickEmphasis == 1.5, "defaults: click strength is 1.5",
               got: "\(defaults.cursor.clickEmphasis)")
        expect(defaults.cursor.shadow, "defaults: cursor drop shadow is on",
               got: "\(defaults.cursor.shadow)")
        expect(!defaults.cursor.matchSystemShape,
               "defaults: system pointer shapes are off (a steady arrow is calmer)",
               got: "\(defaults.cursor.matchSystemShape)")
        expect(defaults.background.enabled, "defaults: padded background is on",
               got: "\(defaults.background.enabled)")
        // #1C1E26 at the top down to near-black. The top is deliberately no
        // longer near-black — it reads as an absence of background rather than a
        // choice — but it still has to stay well under the screen content's
        // brightness, and the gradient still has to run dark-downward.
        expect(abs(defaults.background.topRed - 0x1C / 255.0) < 0.005
                && abs(defaults.background.topGreen - 0x1E / 255.0) < 0.005
                && abs(defaults.background.topBlue - 0x26 / 255.0) < 0.005,
               "defaults: background gradient starts at #1C1E26",
               got: String(format: "#%02X%02X%02X",
                           Int(defaults.background.topRed * 255),
                           Int(defaults.background.topGreen * 255),
                           Int(defaults.background.topBlue * 255)))
        expect(defaults.background.topRed < 0.2 && defaults.background.bottomRed < defaults.background.topRed,
               "defaults: the background stays dark and gets darker downward",
               got: String(format: "top %.3f, bottom %.3f",
                           defaults.background.topRed, defaults.background.bottomRed))
        expect(AppTheme.current == .dark || UserDefaults.standard.string(forKey: AppTheme.storageKey) != nil,
               "defaults: dark appearance unless the user chose otherwise",
               got: "\(AppTheme.current)")
    }

    /// The shadow has to actually change the pixels, and it must not creep into
    /// the frame when switched off.
    private static func checkCursorShadow(session: RecordingSession, log: EventLog) async throws {
        func darkPixels(shadow: Bool) async throws -> Int {
            var project = baseProject()
            project.cursor.kind = .arrow
            project.cursor.arrowTone = .light   // white body, so only the outline
            project.cursor.shadow = shadow      // and shadow are dark
            project.cursor.sizeMultiplier = 3.0
            project.cursor.clickPulse = false
            project.cursor.clickRipple = false
            let frame = try await exportAndSample(session: session, log: log, project: project, at: 1.0)
            return frame.countNearBlack(threshold: 0.35)
        }

        let withShadow = try await darkPixels(shadow: true)
        let without = try await darkPixels(shadow: false)

        expect(withShadow > without,
               "cursor: the drop shadow adds dark pixels around the pointer",
               got: "shadow \(withShadow) px vs none \(without) px")
    }

    /// Geometry behind the camera bubble's drag targets.
    ///
    /// This is the part that can be checked without a pointer: given a bubble
    /// rectangle and a point, does the hit test name the right target? SwiftUI's
    /// event *routing* still can't be verified headlessly — but a coordinate
    /// mistake here would look exactly like a routing failure, so it's worth
    /// ruling out.
    private static func checkCameraHitTest() {
        typealias Layer = PreviewInteractionLayer
        let bubble = CGRect(x: 100, y: 100, width: 200, height: 200)
        let grab = Layer.handleGrab

        expect(Layer.hitTest(CGPoint(x: 200, y: 200), bubble: bubble, subtitles: .zero, grab: grab) == .bubble,
               "camera hit test: the middle of the bubble moves it",
               got: "\(Layer.hitTest(CGPoint(x: 200, y: 200), bubble: bubble, subtitles: .zero, grab: grab))")

        expect(Layer.hitTest(CGPoint(x: 100, y: 100), bubble: bubble, subtitles: .zero, grab: grab) == .corner(.topLeft),
               "camera hit test: the top-left corner resizes",
               got: "\(Layer.hitTest(CGPoint(x: 100, y: 100), bubble: bubble, subtitles: .zero, grab: grab))")

        expect(Layer.hitTest(CGPoint(x: 300, y: 300), bubble: bubble, subtitles: .zero, grab: grab) == .corner(.bottomRight),
               "camera hit test: the bottom-right corner resizes",
               got: "\(Layer.hitTest(CGPoint(x: 300, y: 300), bubble: bubble, subtitles: .zero, grab: grab))")

        // Corners beat the body, so grabbing near an edge resizes rather than moving.
        expect(Layer.hitTest(CGPoint(x: 106, y: 106), bubble: bubble, subtitles: .zero, grab: grab) == .corner(.topLeft),
               "camera hit test: just inside a corner still resizes",
               got: "\(Layer.hitTest(CGPoint(x: 106, y: 106), bubble: bubble, subtitles: .zero, grab: grab))")

        // Handles reach slightly outside the bubble, so near-misses still grab.
        expect(Layer.hitTest(CGPoint(x: 94, y: 94), bubble: bubble, subtitles: .zero, grab: grab) == .corner(.topLeft),
               "camera hit test: just outside a corner still resizes",
               got: "\(Layer.hitTest(CGPoint(x: 94, y: 94), bubble: bubble, subtitles: .zero, grab: grab))")

        expect(Layer.hitTest(CGPoint(x: 200, y: 140), bubble: bubble, subtitles: .zero, grab: grab) == .bubble,
               "camera hit test: mid-edge is the body, not a corner",
               got: "\(Layer.hitTest(CGPoint(x: 200, y: 140), bubble: bubble, subtitles: .zero, grab: grab))")

        expect(Layer.hitTest(CGPoint(x: 500, y: 500), bubble: bubble, subtitles: .zero, grab: grab) == Layer.Target.none,
               "camera hit test: away from the bubble falls through to zoom panning",
               got: "\(Layer.hitTest(CGPoint(x: 500, y: 500), bubble: bubble, subtitles: .zero, grab: grab))")

        // Captions are a separate target in the same layer.
        let captions = CGRect(x: 100, y: 500, width: 400, height: 60)
        expect(Layer.hitTest(CGPoint(x: 300, y: 530), bubble: bubble, subtitles: captions, grab: grab) == .subtitles,
               "subtitle hit test: the caption block moves",
               got: "\(Layer.hitTest(CGPoint(x: 300, y: 530), bubble: bubble, subtitles: captions, grab: grab))")
        expect(Layer.hitTest(CGPoint(x: 100, y: 530), bubble: bubble, subtitles: captions, grab: grab) == .subtitleEdge(leading: true),
               "subtitle hit test: the left edge sets the wrap width",
               got: "\(Layer.hitTest(CGPoint(x: 100, y: 530), bubble: bubble, subtitles: captions, grab: grab))")
        expect(Layer.hitTest(CGPoint(x: 500, y: 530), bubble: bubble, subtitles: captions, grab: grab) == .subtitleEdge(leading: false),
               "subtitle hit test: the right edge does too",
               got: "\(Layer.hitTest(CGPoint(x: 500, y: 530), bubble: bubble, subtitles: captions, grab: grab))")
        // The bubble wins where they overlap.
        expect(Layer.hitTest(CGPoint(x: 200, y: 200), bubble: bubble,
                             subtitles: CGRect(x: 0, y: 0, width: 600, height: 600), grab: grab) == .bubble,
               "subtitle hit test: the camera bubble takes priority where they overlap",
               got: "\(Layer.hitTest(CGPoint(x: 200, y: 200), bubble: bubble, subtitles: CGRect(x: 0, y: 0, width: 600, height: 600), grab: grab))")

        // And the rect the hit test runs against must match what the renderer draws.
        var overlay = ProjectState.CameraOverlay()
        overlay.shape = .circle
        overlay.size = 0.25
        overlay.centerX = 0.8
        overlay.centerY = 0.75
        let rect = overlay.normalizedRect(outputAspect: 16.0 / 9.0)
        expect(abs(rect.height - 0.25) < 0.0001 && abs(rect.width - 0.25 * 9.0 / 16.0) < 0.0001,
               "camera geometry: a circle is square in output pixels",
               got: String(format: "%.4f x %.4f", rect.width, rect.height))
        expect(abs(rect.midX - 0.8) < 0.0001 && abs(rect.midY - 0.75) < 0.0001,
               "camera geometry: the rect is centred on centerX/centerY",
               got: String(format: "(%.4f, %.4f)", rect.midX, rect.midY))

        // Clamping keeps the whole bubble on screen.
        var edge = overlay
        edge.centerX = 1.4
        edge.clampToFrame(outputAspect: 16.0 / 9.0)
        let clamped = edge.normalizedRect(outputAspect: 16.0 / 9.0)
        expect(clamped.maxX <= 1.0001,
               "camera geometry: clamping keeps the bubble inside the frame",
               got: String(format: "maxX %.4f", clamped.maxX))
    }

    /// The sparse shape track resolves the right shape at any instant, and an
    /// older recording with no track at all stays an arrow.
    private static func checkPointerShapes() {
        let track = PointerShapeTrack(changes: [
            .init(t: 1.0, shape: .hand),
            .init(t: 2.0, shape: .arrow),
            .init(t: 3.0, shape: .text),
        ])
        expect(track.shape(at: 0.5) == .arrow, "pointer shapes: arrow before the first change",
               got: "\(track.shape(at: 0.5))")
        expect(track.shape(at: 1.5) == .hand, "pointer shapes: hand while the hand is active",
               got: "\(track.shape(at: 1.5))")
        expect(track.shape(at: 2.5) == .arrow, "pointer shapes: back to arrow after it ends",
               got: "\(track.shape(at: 2.5))")
        expect(track.shape(at: 9.0) == .text, "pointer shapes: the last change persists",
               got: "\(track.shape(at: 9.0))")
        expect(PointerShapeTrack(changes: nil).shape(at: 5) == .arrow,
               "pointer shapes: a recording without a track renders an arrow",
               got: "\(PointerShapeTrack(changes: nil).shape(at: 5))")
    }

    /// The hand sprite has to be a genuinely different shape from the arrow, and
    /// it must only appear where the log says macOS drew one.
    private static func checkPointingHand(session: RecordingSession, log: EventLog) async throws {
        var handLog = log
        handLog.pointerShapes = [.init(t: 0, shape: .hand)]

        func bodyPixels(_ source: EventLog, matchShape: Bool) async throws -> Int {
            var project = baseProject()
            project.cursor.kind = .arrow
            project.cursor.arrowTone = .light
            project.cursor.matchSystemShape = matchShape
            project.cursor.sizeMultiplier = 3.0
            project.cursor.clickPulse = false
            project.cursor.clickRipple = false
            let frame = try await exportAndSample(session: session, log: source, project: project, at: 1.0)
            return frame.countNearWhite()
        }

        let arrow = try await bodyPixels(log, matchShape: true)
        let hand = try await bodyPixels(handLog, matchShape: true)
        let handIgnored = try await bodyPixels(handLog, matchShape: false)

        expect(hand > 200, "cursor: the pointing hand is drawn", got: "\(hand) px")
        // A hand is a chunkier silhouette than an arrow at the same glyph height.
        expect(hand > arrow, "cursor: the hand is a different, fuller shape than the arrow",
               got: "hand \(hand) px vs arrow \(arrow) px")
        expect(abs(handIgnored - arrow) < max(40, arrow / 8),
               "cursor: switching the option off returns the arrow",
               got: "off \(handIgnored) px vs arrow \(arrow) px")
    }

    /// Filler detection, silence detection and cue grouping — all pure, so all
    /// checkable without a microphone or a recogniser.
    private static func checkTranscriptAnalysis() {
        func word(_ text: String, _ start: Double, _ duration: Double = 0.3) -> Transcript.Word {
            .init(text: text, start: start, duration: duration, confidence: 1)
        }

        let transcript = Transcript(words: [
            word("So", 0.0), word("um", 0.4), word("this", 0.8), word("is", 1.1),
            word("Uh,", 1.5), word("a", 1.9), word("test.", 2.2),
            word("Then", 6.0), word("more.", 6.4),
        ], locale: "en_US")

        let fillers = TranscriptAnalysis.fillerCuts(in: transcript)
        expect(fillers.count == 2,
               "transcript: filler detection finds “um” and “Uh,” including punctuation and case",
               got: "\(fillers.count) cuts")
        expect(fillers.allSatisfy(\.isAuto),
               "transcript: filler cuts are tagged auto so they can be regenerated",
               got: "\(fillers.map(\.isAuto))")
        expect(!TranscriptAnalysis.isFiller(word("like", 0)) && !TranscriptAnalysis.isFiller(word("so", 0)),
               "transcript: ambiguous words are never treated as filler",
               got: "like/so classified as filler")

        // One gap over 3 s sits between "test." and "Then".
        let silences = TranscriptAnalysis.silenceCuts(in: transcript, duration: 8, threshold: 1.2)
        expect(silences.count == 1,
               "transcript: one long silence is found",
               got: "\(silences.count)")
        if let gap = silences.first {
            expect(gap.start > 2.4 && gap.end < 6.0,
                   "transcript: the silence cut leaves a beat at each end",
                   got: String(format: "%.2f–%.2f", gap.start, gap.end))
        }

        let cues = TranscriptAnalysis.cues(from: transcript, wordsPerCue: 4)
        expect(cues.count >= 3, "transcript: words group into cues", got: "\(cues.count) cues")
        expect(cues.allSatisfy { $0.end >= $0.start },
               "transcript: every cue has a sane time range", got: "one or more inverted")
        // "a test." ends a sentence, so a cue must break there rather than
        // running on to the next utterance.
        expect(cues.contains { $0.text.hasSuffix("test.") },
               "transcript: cues break at sentence ends",
               got: cues.map(\.text).joined(separator: " / "))

        let track = SubtitleTrack(cues: cues)
        expect(track.cue(at: 0.1) != nil, "subtitles: a cue is found at the start", got: "nil")
        expect(track.cue(at: 4.5) == nil,
               "subtitles: nothing is shown during the silence between cues", got: "a cue")
    }

    // MARK: - Harness

    /// Silence detection has to survive a noisy room.
    ///
    /// This is the case the transcript-gap version got wrong: a fan or a
    /// keyboard under the pause meant the recogniser stretched words across it
    /// and the gap fell under the threshold, so nothing was cut. The envelope
    /// below has a noise floor everywhere — the pauses are quiet, not silent.
    private static func checkSilenceDetection() {
        let rate = SilenceDetector.bucketsPerSecond
        func seconds(_ count: Double) -> Int { Int(count * Double(rate)) }

        // 10 s: speech 0-2, quiet-but-noisy 2-5, speech 5-6, brief pause 6-6.4,
        // speech 6.4-10.
        var envelope: [Float] = []
        func append(_ value: Float, _ length: Double) {
            envelope += Array(repeating: value, count: seconds(length))
        }
        append(0.8, 2)     // speech
        append(0.04, 3)    // room tone — a fan, not silence in the literal sense
        append(0.75, 1)    // speech
        append(0.05, 0.4)  // a breath, shorter than the threshold
        append(0.85, 3.6)  // speech

        let duration = Double(envelope.count) / Double(rate)
        let cuts = SilenceDetector.silences(in: envelope, duration: duration, minimumLength: 1.0)

        expect(cuts.count == 1,
               "silence: the noisy pause is found and the short breath is not",
               got: "\(cuts.count) run(s): \(cuts.map { String(format: "%.2f-%.2f", $0.lowerBound, $0.upperBound) })")

        if let first = cuts.first {
            expect(first.lowerBound > 2.0 && first.upperBound < 5.0,
                   "silence: the cut stays inside the pause",
                   got: String(format: "%.2f-%.2f", first.lowerBound, first.upperBound))
            expect(first.lowerBound - 2.0 > 0.05 && 5.0 - first.upperBound > 0.05,
                   "silence: a beat is left at each end",
                   got: String(format: "head %.3f, tail %.3f", first.lowerBound - 2.0, 5.0 - first.upperBound))
        }

        // A track that is quiet throughout must not be declared one long silence
        // relative to its own near-zero peak.
        let quiet = [Float](repeating: 0.004, count: seconds(10))
        let all = SilenceDetector.silences(in: quiet, duration: 10, minimumLength: 1.0)
        expect(all.count == 1 && all[0].lowerBound < 0.2,
               "silence: a silent track is one silence, not none",
               got: "\(all.count) run(s)")

        // And speech throughout must produce nothing.
        let loud = [Float](repeating: 0.7, count: seconds(10))
        expect(SilenceDetector.silences(in: loud, duration: 10, minimumLength: 1.0).isEmpty,
               "silence: continuous speech has no silences",
               got: "\(SilenceDetector.silences(in: loud, duration: 10, minimumLength: 1.0).count) run(s)")
    }

    /// Subtitles have to actually reach the frame.
    ///
    /// Everything between "Add subtitles" and painted pixels is invisible from
    /// the UI — the transcript has to exist, the cues have to be grouped, the cue
    /// has to be found for the frame's timestamp, and the bitmap has to land
    /// inside the output. This drives the whole chain with a known transcript and
    /// asserts white text appears where it was asked for and nowhere else.
    private static func checkSubtitlesRender(session: RecordingSession, log: EventLog) async throws {
        let transcript = Transcript(words: [
            .init(text: "SUBTITLE", start: 0.1, duration: 1.6, confidence: 1),
            .init(text: "CHECK", start: 1.7, duration: 1.6, confidence: 1),
        ], locale: "en-US")

        func whitePixels(enabled: Bool, centerY: Double) async throws -> Int {
            var project = baseProject()
            project.cursor.kind = .hidden
            project.subtitles.enabled = enabled
            project.subtitles.centerY = centerY
            project.subtitles.fontSize = 0.09
            project.subtitles.backdrop = .box
            project.subtitles.wordsPerCue = 1

            let context = RenderContext(log: log, project: project)
            context.transcript = transcript

            let output = session.url.appendingPathComponent("selftest-\(UUID().uuidString).mov")
            var settings = ExportSettings()
            settings.preset = .original
            settings.codec = .h264
            settings.frameRateMode = .matchSource
            _ = try await VideoExporter.export(session: session, context: context, settings: settings,
                                               to: output, token: ExportCancellationToken()) { _ in }
            defer { try? FileManager.default.removeItem(at: output) }
            return try await Frame.sample(from: output, at: 0.6).countNearWhite()
        }

        let off = try await whitePixels(enabled: false, centerY: 0.85)
        let on = try await whitePixels(enabled: true, centerY: 0.85)
        expect(on > off + 200,
               "subtitles paint text when enabled",
               got: "off \(off) px, on \(on) px")

        // And they move: the same cue placed near the top must not land in the
        // same place, which catches a caption drawn at a fixed position or one
        // flipped into the wrong half by the CI origin.
        let high = try await whitePixels(enabled: true, centerY: 0.15)
        expect(abs(high - on) < max(on, high) / 2 && high > off + 200,
               "subtitle position follows centerY",
               got: "bottom \(on) px, top \(high) px")

        // A hand-corrected cue has to reach the frame, not just the model. The
        // replacement is deliberately much longer than "SUBTITLE" so the check
        // is a pixel count rather than a guess at glyph shapes.
        var edited = baseProject()
        edited.cursor.kind = .hidden
        edited.subtitles.enabled = true
        edited.subtitles.centerY = 0.85
        edited.subtitles.fontSize = 0.09
        edited.subtitles.backdrop = .box
        edited.subtitles.wordsPerCue = 1
        edited.subtitles.edits[ProjectState.Subtitles.editKey(forCueStart: 0.1)] = "CORRECTED WORDING HERE"

        let context = RenderContext(log: log, project: edited)
        context.transcript = transcript
        let output = session.url.appendingPathComponent("selftest-\(UUID().uuidString).mov")
        var settings = ExportSettings()
        settings.preset = .original
        settings.codec = .h264
        settings.frameRateMode = .matchSource
        _ = try await VideoExporter.export(session: session, context: context, settings: settings,
                                           to: output, token: ExportCancellationToken()) { _ in }
        defer { try? FileManager.default.removeItem(at: output) }
        let corrected = try await Frame.sample(from: output, at: 0.6).countNearWhite()

        expect(corrected > on,
               "subtitles: a hand-corrected cue replaces the recognised text",
               got: "original \(on) px, corrected \(corrected) px")
    }

    private static func expect(_ condition: Bool, _ label: String, got: String) {
        if condition {
            print("  ✓ \(label)")
        } else {
            failures += 1
            print("  ✗ \(label)\n      got: \(got)")
        }
    }

    private static func exportAndSample(session: RecordingSession,
                                        log: EventLog,
                                        project: ProjectState,
                                        at time: Double) async throws -> Frame {
        let context = RenderContext(log: log, project: project)
        let output = session.url.appendingPathComponent("selftest-\(UUID().uuidString).mov")

        var settings = ExportSettings()
        settings.preset = .original
        settings.codec = .h264
        settings.frameRateMode = .matchSource

        _ = try await VideoExporter.export(
            session: session, context: context, settings: settings,
            to: output, token: ExportCancellationToken()
        ) { _ in }

        defer { try? FileManager.default.removeItem(at: output) }
        return try await Frame.sample(from: output, at: time)
    }

    // MARK: - Synthetic recording

    /// `cameraTimeRange` lets a caller simulate a camera that started late or
    /// stopped early relative to the screen — see `checkCameraCoversFullDuration`.
    /// Every existing caller omits it and gets a camera perfectly aligned with
    /// the screen, unchanged.
    private static func makeSyntheticRecording(at root: URL,
                                               cameraTimeRange: ClosedRange<Double>? = nil) throws -> RecordingSession {
        try FileManager.default.createDirectory(at: root, withIntermediateDirectories: true)
        let session = RecordingSession(url: root)

        try writeVideo(to: session.screenVideoURL, fill: .quadrants)
        try writeVideo(to: session.cameraVideoURL, fill: .solid(cameraColor), timeRange: cameraTimeRange)

        let geometry = CaptureGeometry(
            sourceRectPoints: CGRect(x: 0, y: 0, width: sourceWidth, height: sourceHeight),
            framePixelWidth: sourceWidth,
            framePixelHeight: sourceHeight,
            pointPixelScale: 1,
            displayID: 1
        )

        // Cursor parked dead centre for the whole clip, plus one click.
        var cursor: [EventLog.CursorSample] = []
        var t = 0.0
        while t <= durationSeconds {
            cursor.append(.init(t: t, x: 0.5, y: 0.5))
            t += 1.0 / 60.0
        }

        let log = EventLog(
            recording: .init(
                startedAt: Date(),
                durationSeconds: durationSeconds,
                frameRate: frameRate,
                geometry: geometry,
                // The camera entry's offset matters: `CompositionBuilder`
                // reads this, not the asset's own (unreliable) `.timeRange`,
                // to know where camera.mov's real content starts. Omitting it
                // here would silently retest the bug `insertCamera` exists to
                // fix — see `checkCameraCoversFullDuration`.
                media: [.init(file: "screen.mov", kind: "screenVideo",
                              startOffsetSeconds: 0, sampleCount: Int(durationSeconds * Double(frameRate))),
                        .init(file: "camera.mov", kind: "camera",
                              startOffsetSeconds: cameraTimeRange?.lowerBound ?? 0,
                              sampleCount: Int(((cameraTimeRange?.upperBound ?? durationSeconds)
                                                - (cameraTimeRange?.lowerBound ?? 0)) * Double(frameRate)))]
            ),
            cursor: cursor,
            clicks: [.init(t: 1.0, x: 0.5, y: 0.5, button: .left, phase: .down)]
        )
        try log.write(to: session.eventsURL)
        try ProjectState().write(to: session.projectURL)
        return session
    }

    private enum Fill {
        case quadrants
        case solid((r: Double, g: Double, b: Double))
    }

    /// `timeRange`, when given, writes samples for only that stretch of
    /// `[0, durationSeconds]` — everything outside it is simply never appended,
    /// the same shape a camera that started late or stopped early produces in
    /// the real pipeline (see `insertCamera`'s doc comment). The session still
    /// starts at zero either way; only the first *appended sample's* time
    /// determines where the file's decodable content actually begins, exactly
    /// as `TrackWriter` behaves against the shared `t0`.
    private static func writeVideo(to url: URL, fill: Fill, timeRange: ClosedRange<Double>? = nil) throws {
        try? FileManager.default.removeItem(at: url)
        let writer = try AVAssetWriter(outputURL: url, fileType: .mov)
        let input = AVAssetWriterInput(mediaType: .video, outputSettings: [
            AVVideoCodecKey: AVVideoCodecType.h264,
            AVVideoWidthKey: sourceWidth,
            AVVideoHeightKey: sourceHeight,
            AVVideoCompressionPropertiesKey: [AVVideoAverageBitRateKey: 20_000_000],
        ])
        input.expectsMediaDataInRealTime = false
        let adaptor = AVAssetWriterInputPixelBufferAdaptor(
            assetWriterInput: input,
            sourcePixelBufferAttributes: [
                kCVPixelBufferPixelFormatTypeKey as String: kCVPixelFormatType_32BGRA,
                kCVPixelBufferWidthKey as String: sourceWidth,
                kCVPixelBufferHeightKey as String: sourceHeight,
            ]
        )
        writer.add(input)
        writer.startWriting()
        writer.startSession(atSourceTime: .zero)

        let range = timeRange ?? 0...durationSeconds
        let frameCount = Int(durationSeconds * Double(frameRate))
        let firstIndex = max(0, Int((range.lowerBound * Double(frameRate)).rounded(.up)))
        let lastIndex = min(frameCount - 1, Int((range.upperBound * Double(frameRate)).rounded(.down)))
        guard firstIndex <= lastIndex else {
            input.markAsFinished()
            let done = DispatchSemaphore(value: 0)
            writer.finishWriting { done.signal() }
            done.wait()
            return
        }

        for index in firstIndex...lastIndex {
            guard let pool = adaptor.pixelBufferPool else { break }
            var buffer: CVPixelBuffer?
            CVPixelBufferPoolCreatePixelBuffer(nil, pool, &buffer)
            guard let pixelBuffer = buffer else { break }
            paint(pixelBuffer, fill: fill)

            while !input.isReadyForMoreMediaData { usleep(2000) }
            adaptor.append(pixelBuffer, withPresentationTime: CMTime(value: CMTimeValue(index),
                                                                     timescale: CMTimeScale(frameRate)))
        }

        input.markAsFinished()
        let done = DispatchSemaphore(value: 0)
        writer.finishWriting { done.signal() }
        done.wait()
    }

    /// Row 0 of a CVPixelBuffer is the top row, so this paints in the same
    /// top-left origin space that `events.json` uses.
    private static func paint(_ pixelBuffer: CVPixelBuffer, fill: Fill) {
        CVPixelBufferLockBaseAddress(pixelBuffer, [])
        defer { CVPixelBufferUnlockBaseAddress(pixelBuffer, []) }
        guard let base = CVPixelBufferGetBaseAddress(pixelBuffer) else { return }

        let bytesPerRow = CVPixelBufferGetBytesPerRow(pixelBuffer)
        let width = CVPixelBufferGetWidth(pixelBuffer)
        let height = CVPixelBufferGetHeight(pixelBuffer)
        let pointer = base.assumingMemoryBound(to: UInt8.self)

        for row in 0..<height {
            let isTop = row < height / 2
            for column in 0..<width {
                let isLeft = column < width / 2
                let color: (r: Double, g: Double, b: Double)
                switch fill {
                case .solid(let solid):
                    color = solid
                case .quadrants:
                    switch (isTop, isLeft) {
                    case (true, true):   color = topLeftColor
                    case (true, false):  color = topRightColor
                    case (false, true):  color = bottomLeftColor
                    case (false, false): color = bottomRightColor
                    }
                }
                let offset = row * bytesPerRow + column * 4
                pointer[offset + 0] = UInt8(color.b * 255) // B
                pointer[offset + 1] = UInt8(color.g * 255) // G
                pointer[offset + 2] = UInt8(color.r * 255) // R
                pointer[offset + 3] = 255
            }
        }
    }

    // MARK: - Frame sampling

    struct Frame {
        let width: Int
        let height: Int
        let pixels: [UInt8] // RGBA8

        struct Color: CustomStringConvertible {
            let r: Double, g: Double, b: Double
            var description: String { String(format: "(%.2f, %.2f, %.2f)", r, g, b) }
            /// Loose: the frame has been through a lossy encoder twice.
            func matches(_ other: (r: Double, g: Double, b: Double), tolerance: Double = 0.16) -> Bool {
                abs(r - other.r) < tolerance && abs(g - other.g) < tolerance && abs(b - other.b) < tolerance
            }
        }

        /// `fx`/`fy` are fractions with (0,0) at the **top-left**, matching how
        /// the rest of the app talks about frames.
        func color(atFraction fx: Double, _ fy: Double) -> Color {
            let x = min(width - 1, max(0, Int(fx * Double(width))))
            let y = min(height - 1, max(0, Int(fy * Double(height))))
            let offset = (y * width + x) * 4
            return Color(r: Double(pixels[offset]) / 255,
                         g: Double(pixels[offset + 1]) / 255,
                         b: Double(pixels[offset + 2]) / 255)
        }

        func countNearWhite(threshold: Double = 0.85) -> Int {
            var count = 0
            let limit = UInt8(threshold * 255)
            for index in stride(from: 0, to: pixels.count, by: 4) {
                if pixels[index] > limit, pixels[index + 1] > limit, pixels[index + 2] > limit {
                    count += 1
                }
            }
            return count
        }

        func count(matching target: (r: Double, g: Double, b: Double), tolerance: Double = 0.2) -> Int {
            var count = 0
            for index in stride(from: 0, to: pixels.count, by: 4) {
                let color = Color(r: Double(pixels[index]) / 255,
                                  g: Double(pixels[index + 1]) / 255,
                                  b: Double(pixels[index + 2]) / 255)
                if color.matches(target, tolerance: tolerance) { count += 1 }
            }
            return count
        }

        func countNearBlack(threshold: Double = 0.15) -> Int {
            var count = 0
            let limit = UInt8(threshold * 255)
            for index in stride(from: 0, to: pixels.count, by: 4) {
                if pixels[index] < limit, pixels[index + 1] < limit, pixels[index + 2] < limit {
                    count += 1
                }
            }
            return count
        }

        static func sample(from url: URL, at seconds: Double) async throws -> Frame {
            let generator = AVAssetImageGenerator(asset: AVURLAsset(url: url))
            generator.appliesPreferredTrackTransform = true
            generator.requestedTimeToleranceBefore = .zero
            generator.requestedTimeToleranceAfter = .zero
            let cgImage = try await generator.image(at: CMTime(seconds: seconds, preferredTimescale: 600)).image

            let width = cgImage.width
            let height = cgImage.height
            var pixels = [UInt8](repeating: 0, count: width * height * 4)
            pixels.withUnsafeMutableBytes { raw in
                guard let ctx = CGContext(
                    data: raw.baseAddress,
                    width: width, height: height,
                    bitsPerComponent: 8, bytesPerRow: width * 4,
                    space: CGColorSpace(name: CGColorSpace.sRGB) ?? CGColorSpaceCreateDeviceRGB(),
                    bitmapInfo: CGImageAlphaInfo.premultipliedLast.rawValue
                ) else { return }
                ctx.draw(cgImage, in: CGRect(x: 0, y: 0, width: width, height: height))
            }
            return Frame(width: width, height: height, pixels: pixels)
        }
    }
}
