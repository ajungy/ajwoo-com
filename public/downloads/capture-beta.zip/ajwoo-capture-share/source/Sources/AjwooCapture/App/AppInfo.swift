import Foundation

/// The one place the product name lives. Rename here and the bundle script,
/// and nothing else needs to change.
enum AppInfo {
    static let name = "ajwoo capture"
    static let bundleIdentifier = "com.ajwoo.capture"

    /// Recording packages are `<name>.ajwoocapture` directories.
    static let packageExtension = "ajwoocapture"

    /// ~/Movies/ajwoo capture
    static var recordingsDirectory: URL {
        let movies = FileManager.default.urls(for: .moviesDirectory, in: .userDomainMask).first
            ?? FileManager.default.homeDirectoryForCurrentUser.appendingPathComponent("Movies")
        return movies.appendingPathComponent(name, isDirectory: true)
    }

    static func ensureRecordingsDirectory() throws {
        try FileManager.default.createDirectory(at: recordingsDirectory, withIntermediateDirectories: true)
    }

    /// Where a user-uploaded background photo is copied to.
    ///
    /// Application Support rather than a recording's own folder: a background
    /// photo is a style choice, not part of any one take, so it should be
    /// available to every project rather than living inside whichever
    /// recording happened to be open when it was imported.
    static var backgroundsDirectory: URL {
        let support = FileManager.default.urls(for: .applicationSupportDirectory, in: .userDomainMask).first
            ?? FileManager.default.homeDirectoryForCurrentUser.appendingPathComponent("Library/Application Support")
        return support.appendingPathComponent(name, isDirectory: true).appendingPathComponent("Backgrounds", isDirectory: true)
    }

    static func ensureBackgroundsDirectory() throws {
        try FileManager.default.createDirectory(at: backgroundsDirectory, withIntermediateDirectories: true)
    }
}
