import SwiftUI
import AppKit

@main
struct AjwooCaptureApp: App {
    @NSApplicationDelegateAdaptor(AppDelegate.self) private var appDelegate
    @StateObject private var controller = RecordingController()

    var body: some Scene {
        Window(AppInfo.name, id: "main") {
            MainWindowView()
                .environmentObject(controller)
                // No minimum height: the shell sizes to its content, so a
                // window with no recordings in it is short rather than mostly
                // empty.
                // Measured from the action bar rather than guessed — see
                // `MainWindowView.minimumContentWidth`. Below it the row clips
                // from the right, and the first thing to vanish is the settings
                // button, which is the only way into the settings.
                .frame(minWidth: MainWindowView.minimumContentWidth)
                // Monochrome by default: colour in this product means status,
                // never decoration, so the system accent is replaced with the
                // primary text colour.
                .tint(DS.Text.primary)
        }
        // `contentMinSize`: the window can never be smaller than its content,
        // and opens at exactly that height — but it can still be dragged larger,
        // and the content stays pinned to the top when it is.
        .windowResizability(.contentMinSize)
        // As small as the action bar and summary row need — with the empty
        // state gone, that's all there is when there are no recordings yet.
        // 160 is deliberately below that true minimum: `.contentMinSize` clamps
        // the actual window up to whatever the content really requires, so this
        // just has to be small enough to never be the binding constraint.
        // `MainWindowView` grows the window itself, by one row, the moment the
        // first recording appears.
        .defaultSize(width: MainWindowView.minimumContentWidth, height: 160)

        // One editor window per recording, keyed by the package URL.
        WindowGroup(id: "editor", for: URL.self) { $url in
            if let url {
                EditorWindowView(recordingURL: url)
                    .frame(minWidth: 960, minHeight: 640)
                    .tint(DS.Text.primary)
                    .background(EditorWindowClaim(url: url))
            }
        }
        .defaultSize(width: 1180, height: 780)

        MenuBarExtra {
            MenuBarView()
                .environmentObject(controller)
        } label: {
            Image(nsImage: controller.menuBarImage)
        }
    }
}

final class AppDelegate: NSObject, NSApplicationDelegate {
    func applicationDidFinishLaunching(_ notification: Notification) {
        // AppKit waits ~2 s before showing a tooltip, and reads this the first
        // time it needs the value — so it has to be registered before any window
        // exists. This app leans on tooltips to explain icon-only controls, and
        // a two-second wait defeats the point. Milliseconds.
        UserDefaults.standard.register(defaults: ["NSInitialToolTipDelay": 1])

        // Headless pipeline check. Run after launch rather than from `App.init`
        // so there's a live run loop for AVFoundation to call back on.
        if let index = CommandLine.arguments.firstIndex(of: "--benchmark"),
           index + 1 < CommandLine.arguments.count {
            NSApp.setActivationPolicy(.prohibited)
            SelfTest.benchmarkAndExit(path: CommandLine.arguments[index + 1])
            return
        }

        if let index = CommandLine.arguments.firstIndex(of: "--sprites"),
           index + 1 < CommandLine.arguments.count {
            NSApp.setActivationPolicy(.prohibited)
            SelfTest.spritesAndExit(path: CommandLine.arguments[index + 1])
            return
        }

        if let index = CommandLine.arguments.firstIndex(of: "--transcribe"),
           index + 1 < CommandLine.arguments.count {
            NSApp.setActivationPolicy(.prohibited)
            SelfTest.transcribeAndExit(path: CommandLine.arguments[index + 1])
            return
        }

        if CommandLine.arguments.contains("--selftest") {
            NSApp.setActivationPolicy(.prohibited)
            SelfTest.runAndExit()
            return
        }

        ColorPanelDismisser.install()

        NSApp.setActivationPolicy(.regular)
        // Restore the pinned appearance before any window is shown, so the app
        // never flashes the system theme first.
        AppTheme.current.apply()
        try? AppInfo.ensureRecordingsDirectory()
    }

    func applicationShouldTerminateAfterLastWindowClosed(_ sender: NSApplication) -> Bool {
        false // menu bar app stays alive
    }
}
