import Foundation
import AVFoundation
import CoreMedia
import AppKit

/// Records the webcam to `camera.mov` and the microphone to `mic.m4a`, on the
/// same clock as the screen capture.
///
/// # Two files, never one
/// Mic and system audio are deliberately **not** mixed at capture time. Mixing
/// is destructive: if the mic is too hot relative to a video you were playing,
/// a single mixed track can't be repaired. Keeping them apart costs one extra
/// file and makes the balance an export-time slider.
///
/// # Clock
/// `AVCaptureSession` timestamps sample buffers against the host time clock on
/// macOS — the same base as ScreenCaptureKit. So the only thing needed for sync
/// is a shared origin, which arrives via `setOrigin(_:)` when the screen engine
/// sees its first frame. Buffers that show up before then are held, exactly as
/// the system-audio path does.
///
/// Failures here never take the screen recording down with them: a missing
/// camera, a denied permission or a disconnected device leaves `startedCamera` /
/// `startedMic` false and the screen capture carries on.
final class CameraMicRecorder: NSObject,
                               AVCaptureVideoDataOutputSampleBufferDelegate,
                               AVCaptureAudioDataOutputSampleBufferDelegate {

    private let captureSession = AVCaptureSession()
    private var cameraWriter: TrackWriter?
    private var micWriter: TrackWriter?
    /// Held onto past `start(...)` so the writer can be sized to whatever
    /// resolution the session actually negotiated for this device, once
    /// `captureSession.commitConfiguration()` has settled it.
    private var cameraDevice: AVCaptureDevice?

    private let lock = NSLock()
    private var origin: CMTime?
    private var pendingCamera: [CMSampleBuffer] = []
    private var pendingMic: [CMSampleBuffer] = []
    private var stopping = false

    private let cameraQueue = DispatchQueue(label: "com.ajwoo.capture.camera", qos: .userInitiated)
    private let micQueue = DispatchQueue(label: "com.ajwoo.capture.mic", qos: .userInitiated)

    private(set) var startedCamera = false
    private(set) var startedMic = false
    private(set) var warnings: [String] = []

    /// Peak level of the most recent mic buffer, 0...1, for the level meter.
    private var _micLevel: Float = 0
    var micLevel: Float {
        lock.lock(); defer { lock.unlock() }
        return _micLevel
    }

    /// Live preview only — the recorded file is always full-frame.
    var previewSession: AVCaptureSession? { startedCamera ? captureSession : nil }

    // MARK: - Devices

    static func cameras() -> [AVCaptureDevice] {
        AVCaptureDevice.DiscoverySession(
            deviceTypes: [.builtInWideAngleCamera, .external, .continuityCamera],
            mediaType: .video,
            position: .unspecified
        ).devices
    }

    static func microphones() -> [AVCaptureDevice] {
        AVCaptureDevice.DiscoverySession(
            deviceTypes: [.microphone, .external],
            mediaType: .audio,
            position: .unspecified
        ).devices
    }

    static func authorize(_ mediaType: AVMediaType) async -> Bool {
        switch AVCaptureDevice.authorizationStatus(for: mediaType) {
        case .authorized: return true
        case .notDetermined: return await AVCaptureDevice.requestAccess(for: mediaType)
        default: return false
        }
    }

    // MARK: - Start

    func start(session: RecordingSession, cameraID: String?, microphoneID: String?) async {
        warnings = []
        captureSession.beginConfiguration()
        captureSession.sessionPreset = .high

        // --- camera ---
        if let cameraID {
            if await Self.authorize(.video) {
                if let device = AVCaptureDevice(uniqueID: cameraID) ?? Self.cameras().first {
                    do {
                        let input = try AVCaptureDeviceInput(device: device)
                        guard captureSession.canAddInput(input) else { throw DeviceError.cannotAdd(device.localizedName) }
                        captureSession.addInput(input)

                        // `.high` (set above) already resolves to the best
                        // quality this device and session combination
                        // support — 4K on Continuity Camera or a capable
                        // external webcam, not just 1080p. A previous version
                        // of this forced the session back down to
                        // `.hd1920x1080` unconditionally, which capped every
                        // camera at 1080p even when it could do better; that
                        // downgrade is gone. The writer below records at
                        // whatever resolution actually comes out of the
                        // session, so the ceiling here is a real one.
                        let output = AVCaptureVideoDataOutput()
                        output.videoSettings = [
                            kCVPixelBufferPixelFormatTypeKey as String: kCVPixelFormatType_32BGRA,
                        ]
                        output.alwaysDiscardsLateVideoFrames = true
                        output.setSampleBufferDelegate(self, queue: cameraQueue)
                        if captureSession.canAddOutput(output) {
                            captureSession.addOutput(output)
                            // The recorded frames are mirrored to match the
                            // preview, so what you framed up is what you get.
                            CameraMirror.apply(to: output.connection(with: .video))
                            startedCamera = true
                            cameraDevice = device
                        }
                    } catch {
                        warnings.append("Couldn't use the camera. Recorded without it.")
                    }
                } else {
                    warnings.append("That camera was unplugged. Recorded without it.")
                }
            } else {
                warnings.append("No camera access. Recorded without it.")
            }
        }

        // --- microphone ---
        if let microphoneID {
            if await Self.authorize(.audio) {
                if let device = AVCaptureDevice(uniqueID: microphoneID) ?? Self.microphones().first {
                    do {
                        let input = try AVCaptureDeviceInput(device: device)
                        guard captureSession.canAddInput(input) else { throw DeviceError.cannotAdd(device.localizedName) }
                        captureSession.addInput(input)

                        let output = AVCaptureAudioDataOutput()
                        output.setSampleBufferDelegate(self, queue: micQueue)
                        if captureSession.canAddOutput(output) {
                            captureSession.addOutput(output)
                            startedMic = true
                        }
                    } catch {
                        warnings.append("Couldn't use the microphone. Recorded without sound.")
                    }
                } else {
                    warnings.append("That microphone was unplugged. Recorded without sound.")
                }
            } else {
                warnings.append("No microphone access. Recorded without sound.")
            }
        }

        captureSession.commitConfiguration()

        guard startedCamera || startedMic else { return }

        // Writers are created now but only started once `setOrigin` fires.
        do {
            if startedCamera {
                // `activeFormat` reflects what `commitConfiguration()` above
                // actually settled on — the real negotiated resolution, not
                // a guess — so the writer can be sized to match rather than
                // silently downscaling (or upscaling) whatever comes out of
                // the session.
                let dimensions = cameraDevice.map { CMVideoFormatDescriptionGetDimensions($0.activeFormat.formatDescription) }
                let width = dimensions.map { Int($0.width) } ?? 1920
                let height = dimensions.map { Int($0.height) } ?? 1080
                cameraWriter = try TrackWriter.cameraVideo(url: session.cameraVideoURL, width: width, height: height)
            }
            if startedMic {
                micWriter = try TrackWriter.audio(url: session.micAudioURL, kind: "microphone")
            }
        } catch {
            warnings.append("Couldn't save the camera or sound. The screen was still recorded.")
            startedCamera = false
            startedMic = false
            return
        }

        captureSession.startRunning()
    }

    /// Pins the camera/mic timelines to the screen recording's `t0`.
    func setOrigin(_ time: CMTime) {
        lock.lock()
        guard origin == nil else { lock.unlock(); return }
        lock.unlock()

        // Start writers before publishing the origin, so the delegate queues
        // never see a non-nil origin with an unstarted writer.
        try? cameraWriter?.start(atSourceTime: time)
        try? micWriter?.start(atSourceTime: time)

        lock.lock()
        origin = time
        lock.unlock()
    }

    // MARK: - Stop

    func finish() async -> [EventLog.MediaFile] {
        lock.lock(); stopping = true; lock.unlock()

        if captureSession.isRunning { captureSession.stopRunning() }

        await cameraWriter?.finish()
        await micWriter?.finish()

        var files: [EventLog.MediaFile] = []
        if let cameraWriter, cameraWriter.sampleCount > 0 {
            files.append(.init(file: cameraWriter.url.lastPathComponent, kind: "camera",
                               startOffsetSeconds: cameraWriter.startOffset,
                               sampleCount: cameraWriter.sampleCount))
        }
        if let micWriter, micWriter.sampleCount > 0 {
            files.append(.init(file: micWriter.url.lastPathComponent, kind: "micAudio",
                               startOffsetSeconds: micWriter.startOffset,
                               sampleCount: micWriter.sampleCount))
        }

        if startedCamera, (cameraWriter?.sampleCount ?? 0) == 0 {
            warnings.append("The camera produced no frames.")
        }
        if startedMic, (micWriter?.sampleCount ?? 0) == 0 {
            warnings.append("The microphone produced no audio.")
        }

        cameraWriter = nil
        micWriter = nil
        cameraDevice = nil
        return files
    }

    // MARK: - Sample delegates

    func captureOutput(_ output: AVCaptureOutput,
                       didOutput sampleBuffer: CMSampleBuffer,
                       from connection: AVCaptureConnection) {
        if output is AVCaptureVideoDataOutput {
            handle(sampleBuffer, writer: cameraWriter, pending: \.pendingCamera)
        } else if output is AVCaptureAudioDataOutput {
            updateMicLevel(sampleBuffer)
            handle(sampleBuffer, writer: micWriter, pending: \.pendingMic)
        }
    }

    /// Same buffer-until-origin dance as the system audio path. Each media type
    /// has its own serial delegate queue, so appends stay in presentation order.
    private func handle(_ sampleBuffer: CMSampleBuffer,
                        writer: TrackWriter?,
                        pending: ReferenceWritableKeyPath<CameraMicRecorder, [CMSampleBuffer]>) {
        lock.lock()
        let isStopping = stopping
        guard let origin else {
            if !isStopping, self[keyPath: pending].count < 240 {
                self[keyPath: pending].append(sampleBuffer)
            }
            lock.unlock()
            return
        }
        let backlog = self[keyPath: pending]
        self[keyPath: pending] = []
        lock.unlock()

        guard !isStopping else { return }
        for buffer in backlog { writer?.append(buffer, t0: origin) }
        writer?.append(sampleBuffer, t0: origin)
    }

    private func updateMicLevel(_ sampleBuffer: CMSampleBuffer) {
        guard let peak = AudioPeak.peak(of: sampleBuffer) else { return }
        lock.lock()
        _micLevel = AudioPeak.smooth(previous: _micLevel, peak: peak)
        lock.unlock()
    }

    enum DeviceError: LocalizedError {
        case cannotAdd(String)
        var errorDescription: String? {
            if case .cannotAdd(let name) = self { return "\(name) could not be added to the capture session." }
            return nil
        }
    }
}

// MARK: - Camera writer settings

extension TrackWriter {
    /// Records the camera at whatever resolution the capture session actually
    /// negotiated for the device, rather than a flat 1080p regardless of what
    /// the hardware can do.
    ///
    /// The bitrate scales with pixel count so a 4K source still carries real
    /// detail — the previous flat 12 Mbps was tuned for 1080p and looked
    /// noticeably soft on anything sharper — but is capped well short of a
    /// proportional 4K bitrate. The bubble in the final export is usually
    /// only ~20% of the frame height, so there's a point past which a bigger
    /// camera master buys detail nobody will see at that size; the cap keeps
    /// file size sane without giving back the sharpness gain that matters
    /// (a 4K master downsized to a small bubble looks meaningfully crisper
    /// than a 1080p master at the same size, even at a bitrate well under
    /// what native 4K would "deserve").
    static func cameraVideo(url: URL, width: Int, height: Int) throws -> TrackWriter {
        let pixels = Double(width * height)
        let bitrate = Int(min(30_000_000, max(8_000_000, pixels * 5.7)))

        return try TrackWriter(
            url: url,
            fileType: .mov,
            outputSettings: [
                AVVideoCodecKey: AVVideoCodecType.hevc,
                AVVideoWidthKey: width,
                AVVideoHeightKey: height,
                AVVideoScalingModeKey: AVVideoScalingModeResizeAspectFill,
                AVVideoCompressionPropertiesKey: [
                    AVVideoAverageBitRateKey: bitrate,
                    AVVideoAllowFrameReorderingKey: false,
                ],
            ],
            mediaType: .video,
            kind: "camera"
        )
    }
}
