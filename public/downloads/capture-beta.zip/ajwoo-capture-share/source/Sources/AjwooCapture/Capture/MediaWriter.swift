import Foundation
import AVFoundation
import CoreMedia

enum MediaWriterError: LocalizedError {
    case cannotAddInput(String)
    case writerFailed(String)

    var errorDescription: String? {
        switch self {
        case .cannotAddInput(let s): return "Could not add \(s) input to the asset writer."
        case .writerFailed(let s): return "Couldn't save the video file."
        }
    }
}

/// A single-track writer around `AVAssetWriter`.
///
/// Video and audio each get their own file and their own writer, but **all
/// writers are started at the same source time** (`t0`, the presentation
/// timestamp of the first screen frame). `AVAssetWriter` maps the session start
/// time to the beginning of the output file, so every file in a package shares
/// a timeline whose zero is the first video frame. Samples that arrive before
/// `t0` are dropped rather than written, which is why the audio path buffers
/// briefly until `t0` is known.
final class TrackWriter {
    private let writer: AVAssetWriter
    private let input: AVAssetWriterInput
    private let kind: String

    /// Guards against an in-flight capture callback appending while `stop()`
    /// is finishing the file.
    private let lock = NSLock()
    private var sessionStarted = false
    private var finished = false

    private(set) var sampleCount = 0
    /// PTS of the first sample actually written, relative to `t0`. Diagnostic.
    private(set) var startOffset: Double = 0
    private var recordedFirstOffset = false

    let url: URL

    init(url: URL, fileType: AVFileType, outputSettings: [String: Any], mediaType: AVMediaType, kind: String) throws {
        self.url = url
        self.kind = kind
        self.writer = try AVAssetWriter(outputURL: url, fileType: fileType)
        self.input = AVAssetWriterInput(mediaType: mediaType, outputSettings: outputSettings)
        // We are fed by live capture callbacks; never make them wait.
        self.input.expectsMediaDataInRealTime = true

        guard writer.canAdd(input) else { throw MediaWriterError.cannotAddInput(kind) }
        writer.add(input)
    }

    /// Starts writing and pins the timeline origin. Must be called before `append`.
    func start(atSourceTime t0: CMTime) throws {
        lock.lock(); defer { lock.unlock() }
        guard !sessionStarted else { return }
        guard writer.startWriting() else {
            throw MediaWriterError.writerFailed(writer.error?.localizedDescription ?? "unknown (\(kind))")
        }
        writer.startSession(atSourceTime: t0)
        sessionStarted = true
    }

    /// Appends a sample. Returns false if it was dropped (not ready, or pre-`t0`).
    @discardableResult
    func append(_ sampleBuffer: CMSampleBuffer, t0: CMTime) -> Bool {
        lock.lock(); defer { lock.unlock() }
        guard sessionStarted, !finished else { return false }
        guard writer.status == .writing else { return false }

        let pts = CMSampleBufferGetPresentationTimeStamp(sampleBuffer)
        guard pts.isValid, CMTimeCompare(pts, t0) >= 0 else { return false }
        guard input.isReadyForMoreMediaData else { return false }

        guard input.append(sampleBuffer) else { return false }

        if !recordedFirstOffset {
            startOffset = CMTimeGetSeconds(CMTimeSubtract(pts, t0))
            recordedFirstOffset = true
        }
        sampleCount += 1
        return true
    }

    func finish() async {
        guard markFinished() else { return }
        await writer.finishWriting()
    }

    /// Split out of `finish()` so the lock is never held across a suspension point.
    private func markFinished() -> Bool {
        lock.lock(); defer { lock.unlock() }
        guard sessionStarted, !finished else { return false }
        finished = true
        input.markAsFinished()
        return true
    }

    /// Tears down without producing a usable file (used when we bail before t0).
    func cancel() {
        lock.lock(); defer { lock.unlock() }
        guard !finished else { return }
        finished = true
        if writer.status == .writing { writer.cancelWriting() }
    }

    var failureDescription: String? {
        writer.status == .failed ? (writer.error?.localizedDescription ?? "unknown") : nil
    }
}

// MARK: - Convenience constructors

extension TrackWriter {
    static func screenVideo(url: URL, pixelWidth: Int, pixelHeight: Int, settings: CaptureSettings) throws -> TrackWriter {
        try TrackWriter(
            url: url,
            fileType: .mov,
            outputSettings: settings.videoOutputSettings(pixelWidth: pixelWidth, pixelHeight: pixelHeight),
            mediaType: .video,
            kind: "screen video"
        )
    }

    static func audio(url: URL, kind: String) throws -> TrackWriter {
        try TrackWriter(
            url: url,
            fileType: .m4a,
            outputSettings: CaptureSettings.audioOutputSettings,
            mediaType: .audio,
            kind: kind
        )
    }
}
