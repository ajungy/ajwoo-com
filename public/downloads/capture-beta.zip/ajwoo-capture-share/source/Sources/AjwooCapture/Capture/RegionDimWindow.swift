import AppKit

/// Dims everything outside the recorded region while a take is running.
///
/// Without it there's no way to tell what's in shot once the selection overlay
/// goes away — you're performing to a rectangle you can't see, and finding out
/// afterwards that you strayed outside it means recording again. The selector
/// already dims the surround while you're choosing, so this is the same language
/// carried into the take itself.
///
/// Click-through in the strongest sense: `ignoresMouseEvents = true` means the
/// window is never between the pointer and what you're demonstrating.
///
/// It belongs to this app, so `SCContentFilter` keeps it out of the capture
/// unless "record this app's own windows" is on — which is why the dimming
/// doesn't end up baked into the video.
@MainActor
final class RegionDimWindow {

    /// Matching the selector's surround. Dark enough to read as "not this",
    /// light enough to keep working in.
    private static let opacity: CGFloat = 0.3

    private var panel: OverlayPanel?
    private var view: DimView?

    func show(region: CaptureRegion) {
        guard let screen = NSScreen.screens.first(where: { $0.displayID == region.displayID }) else {
            hide()
            return
        }

        let hole = Self.appKitRect(for: region, screen: screen)

        if panel == nil {
            let panel = OverlayPanel(contentRect: screen.frame,
                                styleMask: [.borderless, .nonactivatingPanel],
                                backing: .buffered,
                                defer: false)
            panel.level = .floating
            panel.isOpaque = false
            panel.backgroundColor = .clear
            panel.hasShadow = false
            panel.ignoresMouseEvents = true
            panel.collectionBehavior = [.canJoinAllSpaces, .stationary, .fullScreenNone, .ignoresCycle]

            let view = DimView(frame: NSRect(origin: .zero, size: screen.frame.size))
            panel.contentView = view
            panel.orderFrontRegardless()

            self.panel = panel
            self.view = view
        }

        panel?.setFrame(screen.frame, display: false)
        view?.frame = NSRect(origin: .zero, size: screen.frame.size)
        view?.hole = hole
        view?.opacity = Self.opacity
        view?.needsDisplay = true
    }

    func hide() {
        panel?.orderOut(nil)
        panel = nil
        view = nil
    }

    private static func appKitRect(for region: CaptureRegion, screen: NSScreen) -> NSRect {
        let topLeft = ScreenSpace.appKit(fromGlobalCG: CGPoint(x: region.rectPoints.minX,
                                                               y: region.rectPoints.minY))
        return NSRect(x: topLeft.x - screen.frame.minX,
                      y: topLeft.y - screen.frame.minY - region.rectPoints.height,
                      width: region.rectPoints.width,
                      height: region.rectPoints.height)
    }
}

private final class DimView: NSView {
    var hole: NSRect = .zero
    var opacity: CGFloat = 0.3

    override var isFlipped: Bool { false }

    override func draw(_ dirtyRect: NSRect) {
        guard let ctx = NSGraphicsContext.current?.cgContext else { return }

        // One even-odd fill rather than four rectangles around the hole: no
        // seams where they meet, and nothing to get wrong when the region is
        // dragged to an edge of the display.
        let path = CGMutablePath()
        path.addRect(bounds)
        path.addRect(hole)
        ctx.addPath(path)
        ctx.setFillColor(NSColor.black.withAlphaComponent(opacity).cgColor)
        ctx.fillPath(using: .evenOdd)

        // A hairline on the boundary, so the edge is exact rather than implied
        // by a soft change in brightness.
        ctx.setStrokeColor(NSColor.white.withAlphaComponent(0.5).cgColor)
        ctx.setLineWidth(1)
        ctx.stroke(hole)
    }
}
