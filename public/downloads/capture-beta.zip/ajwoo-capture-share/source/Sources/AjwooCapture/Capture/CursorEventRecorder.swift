import Foundation
import AppKit
import CoreGraphics

/// Samples the pointer position and logs mouse clicks for the duration of a recording.
///
/// The cursor is deliberately **not** burned into the capture
/// (`SCStreamConfiguration.showsCursor = false`). This log is what lets the
/// renderer draw it later at any size, in any style, with click animations —
/// and lets it stay a constant on-screen size through a zoom, because it's
/// composited after the crop.
///
/// # Permissions
/// `NSEvent.addGlobalMonitorForEvents` needs the Accessibility permission for
/// **key** events only. Mouse events work without it, which is why this uses the
/// global monitor rather than a `CGEventTap` — no extra TCC prompt.
/// A matching *local* monitor is installed alongside, because a global monitor
/// never sees events delivered to our own app.
///
/// # Position sampling
/// Polling at 120 Hz via `CGEvent(source: nil)?.location` rather than
/// subscribing to `.mouseMoved`: it gives a regular, predictable cadence, it
/// returns CoreGraphics global coordinates directly (no flip to get wrong), and
/// it's safe to call off the main thread.
final class CursorEventRecorder {

    struct RawSample {
        let hostTime: Double
        let globalCG: CGPoint
    }

    struct RawClick {
        let hostTime: Double
        let globalCG: CGPoint
        let button: EventLog.ClickEvent.Button
        let phase: EventLog.ClickEvent.Phase
    }

    /// 120 Hz. Cheap (one CGEvent read), and oversampling relative to a 60 fps
    /// capture gives the smoothing filter something to work with.
    static let sampleRate: Double = 120

    struct RawShape {
        let hostTime: Double
        let shape: EventLog.PointerShapeChange.Shape
    }

    private let lock = NSLock()
    private var samples: [RawSample] = []
    private var clicks: [RawClick] = []
    private var shapes: [RawShape] = []
    private var lastShape: EventLog.PointerShapeChange.Shape?
    private var shapeTimer: Timer?

    private var timer: DispatchSourceTimer?
    private let timerQueue = DispatchQueue(label: "com.ajwoo.capture.cursor-sampler", qos: .userInitiated)
    private var monitors: [Any] = []

    private var geometry: CaptureGeometry?
    private var running = false

    /// Most recent normalized position, for the debug overlay. Nil until sampling starts.
    private var _latestNormalized: CGPoint?
    var latestNormalized: CGPoint? {
        lock.lock(); defer { lock.unlock() }
        return _latestNormalized
    }

    // MARK: - Lifecycle

    /// Begins sampling immediately — before `t0` is known. Samples that turn out
    /// to predate the first video frame are trimmed in `finish(t0:duration:)`.
    func start(geometry: CaptureGeometry) {
        lock.lock()
        guard !running else { lock.unlock(); return }
        running = true
        self.geometry = geometry
        samples.removeAll(keepingCapacity: true)
        clicks.removeAll(keepingCapacity: true)
        lock.unlock()

        installMonitors()

        // Cursor *shape* is an AppKit read, so it samples on the main thread —
        // and at 15 Hz rather than 120, because a shape change is a discrete
        // event, not a trajectory.
        let shapeTimer = Timer(timeInterval: 1.0 / 15.0, repeats: true) { [weak self] _ in
            self?.sampleShape()
        }
        RunLoop.main.add(shapeTimer, forMode: .common)
        self.shapeTimer = shapeTimer

        let t = DispatchSource.makeTimerSource(queue: timerQueue)
        t.schedule(deadline: .now(),
                   repeating: 1.0 / Self.sampleRate,
                   leeway: .milliseconds(1))
        t.setEventHandler { [weak self] in self?.sampleOnce() }
        timer = t
        t.resume()
    }

    func stop() {
        timer?.cancel()
        timer = nil
        shapeTimer?.invalidate()
        shapeTimer = nil
        removeMonitors()
        lock.lock()
        running = false
        lock.unlock()
    }

    // MARK: - Sampling

    private func sampleOnce() {
        guard let point = ScreenSpace.currentPointerGlobalCG() else { return }
        let now = CaptureClock.now()

        lock.lock()
        samples.append(RawSample(hostTime: now, globalCG: point))
        if let g = geometry { _latestNormalized = g.normalized(fromGlobalCG: point) }
        lock.unlock()
    }

    /// Classifies the current system cursor.
    ///
    /// `NSCursor` doesn't implement equality and `currentSystem` hands back a
    /// fresh object each call, so identity comparison is out. Hot spot is a cheap
    /// and reliable discriminator between the arrow, the pointing hand and the
    /// I-beam, and the image size confirms it — good enough for choosing between
    /// three sprites, and it costs nothing at 15 Hz.
    private func sampleShape() {
        guard let current = NSCursor.currentSystem else { return }
        let shape = Self.classify(current)

        lock.lock()
        defer { lock.unlock() }
        guard shape != lastShape else { return }
        lastShape = shape
        shapes.append(RawShape(hostTime: CaptureClock.now(), shape: shape))
    }

    /// Ordered most specific first. Several system cursors share a hot spot, so
    /// the image size in `matches` is doing real work here — the two hands, for
    /// instance, differ only in their bitmap.
    static func classify(_ cursor: NSCursor) -> EventLog.PointerShapeChange.Shape {
        if matches(cursor, NSCursor.pointingHand) { return .hand }
        if matches(cursor, NSCursor.iBeam) { return .text }
        if matches(cursor, NSCursor.closedHand) { return .closedHand }
        if matches(cursor, NSCursor.openHand) { return .openHand }
        if matches(cursor, NSCursor.crosshair) { return .crosshair }
        if #available(macOS 15.0, *) {
            if matches(cursor, NSCursor.zoomIn) { return .zoomIn }
            if matches(cursor, NSCursor.zoomOut) { return .zoomOut }
            if matches(cursor, NSCursor.columnResize) { return .resizeH }
            if matches(cursor, NSCursor.rowResize) { return .resizeV }
        }
        if matches(cursor, NSCursor.resizeLeftRight) { return .resizeH }
        if matches(cursor, NSCursor.resizeUpDown) { return .resizeV }
        return .arrow
    }

    private static func matches(_ a: NSCursor, _ b: NSCursor) -> Bool {
        abs(a.hotSpot.x - b.hotSpot.x) < 0.5
            && abs(a.hotSpot.y - b.hotSpot.y) < 0.5
            && abs(a.image.size.width - b.image.size.width) < 0.5
            && abs(a.image.size.height - b.image.size.height) < 0.5
    }

    // MARK: - Click monitors

    private func installMonitors() {
        let mask: NSEvent.EventTypeMask = [
            .leftMouseDown, .leftMouseUp,
            .rightMouseDown, .rightMouseUp,
            .otherMouseDown, .otherMouseUp,
        ]

        let install = {
            if let global = NSEvent.addGlobalMonitorForEvents(matching: mask, handler: { [weak self] event in
                self?.record(event)
            }) {
                self.monitors.append(global)
            }
            // Our own window's clicks never reach the global monitor.
            if let local = NSEvent.addLocalMonitorForEvents(matching: mask, handler: { [weak self] event in
                self?.record(event)
                return event
            }) {
                self.monitors.append(local)
            }
        }

        if Thread.isMainThread { install() } else { DispatchQueue.main.sync(execute: install) }
    }

    private func removeMonitors() {
        let toRemove = monitors
        monitors = []
        let remove = { toRemove.forEach(NSEvent.removeMonitor) }
        if Thread.isMainThread { remove() } else { DispatchQueue.main.sync(execute: remove) }
    }

    private func record(_ event: NSEvent) {
        // `event.timestamp` is seconds since system startup — the same mach
        // absolute time base as CaptureClock.now(). Synthetic events can report
        // 0, so fall back to reading the clock now.
        let t = event.timestamp > 0 ? event.timestamp : CaptureClock.now()

        // Prefer the CGEvent location: already in CG global space, no flip needed.
        let point = event.cgEvent?.location
            ?? ScreenSpace.globalCG(fromAppKit: NSEvent.mouseLocation)

        let button: EventLog.ClickEvent.Button
        let phase: EventLog.ClickEvent.Phase
        switch event.type {
        case .leftMouseDown:   button = .left;  phase = .down
        case .leftMouseUp:     button = .left;  phase = .up
        case .rightMouseDown:  button = .right; phase = .down
        case .rightMouseUp:    button = .right; phase = .up
        case .otherMouseDown:  button = .other; phase = .down
        case .otherMouseUp:    button = .other; phase = .up
        default: return
        }

        lock.lock()
        clicks.append(RawClick(hostTime: t, globalCG: point, button: button, phase: phase))
        // A click is a moment you care about; make sure there's a position
        // sample at exactly that instant rather than up to 8ms away.
        samples.append(RawSample(hostTime: t, globalCG: point))
        lock.unlock()
    }

    // MARK: - Output

    /// Converts everything collected into `events.json` form, rebased so that
    /// `t = 0` is the first written video frame.
    ///
    /// - Parameters:
    ///   - t0: host time of the first video frame, in seconds.
    ///   - duration: recording length in seconds; samples past this are dropped.
    func finish(t0: Double, duration: Double)
        -> (cursor: [EventLog.CursorSample],
            clicks: [EventLog.ClickEvent],
            shapes: [EventLog.PointerShapeChange]) {
        lock.lock()
        let rawSamples = samples.sorted { $0.hostTime < $1.hostTime }
        let rawClicks = clicks.sorted { $0.hostTime < $1.hostTime }
        let rawShapes = shapes.sorted { $0.hostTime < $1.hostTime }
        let geo = geometry
        lock.unlock()

        guard let geometry = geo else { return ([], [], []) }

        // --- cursor path ---
        var out: [EventLog.CursorSample] = []
        out.reserveCapacity(rawSamples.count / 2)

        // Seed with the last position known before t0 so the very first frame
        // has a cursor rather than nothing.
        var seed: EventLog.CursorSample?
        var lastKept: EventLog.CursorSample?

        // ~0.08 px on a 4K frame; anything smaller is not a real movement.
        let positionEpsilon = 0.00002

        for s in rawSamples {
            let t = s.hostTime - t0
            let n = geometry.normalized(fromGlobalCG: s.globalCG)
            let sample = EventLog.CursorSample(t: max(0, t), x: Double(n.x), y: Double(n.y))

            if t < 0 {
                seed = EventLog.CursorSample(t: 0, x: sample.x, y: sample.y)
                continue
            }
            if t > duration { break }

            if let previous = lastKept {
                let moved = abs(sample.x - previous.x) > positionEpsilon || abs(sample.y - previous.y) > positionEpsilon
                let stale = sample.t - previous.t >= EventLog.keepaliveInterval
                guard moved || stale else { continue }
            } else if let seeded = seed {
                out.append(seeded)
                lastKept = seeded
            }

            out.append(sample)
            lastKept = sample
        }

        if out.isEmpty, let seeded = seed { out.append(seeded) }

        // --- clicks ---
        let clickEvents: [EventLog.ClickEvent] = rawClicks.compactMap { c in
            let t = c.hostTime - t0
            guard t >= 0, t <= duration else { return nil }
            let n = geometry.normalized(fromGlobalCG: c.globalCG)
            return EventLog.ClickEvent(t: t, x: Double(n.x), y: Double(n.y), button: c.button, phase: c.phase)
        }

        // --- pointer shapes ---
        // Anything before t0 collapses into a single entry at 0, so the very
        // first frame knows which shape to draw.
        var shapeChanges: [EventLog.PointerShapeChange] = []
        for change in rawShapes {
            let t = change.hostTime - t0
            guard t <= duration else { break }
            if t < 0 {
                shapeChanges = [.init(t: 0, shape: change.shape)]
            } else {
                shapeChanges.append(.init(t: t, shape: change.shape))
            }
        }

        return (out, clickEvents, shapeChanges)
    }
}
