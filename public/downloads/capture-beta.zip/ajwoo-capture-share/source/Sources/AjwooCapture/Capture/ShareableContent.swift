import Foundation
import ScreenCaptureKit
import CoreGraphics
import AppKit

/// Thin wrappers so the UI doesn't have to hold `SCDisplay` / `SCWindow` directly.
struct DisplayOption: Identifiable, Hashable {
    let id: CGDirectDisplayID
    let localizedName: String
    let pointSize: CGSize
    let pixelSize: CGSize
    var scale: CGFloat { pointSize.width > 0 ? pixelSize.width / pointSize.width : 1 }

    var summary: String {
        "\(Int(pixelSize.width))x\(Int(pixelSize.height)) @\(String(format: "%g", scale))x"
    }
}

struct WindowOption: Identifiable, Hashable {
    let id: CGWindowID
    let title: String
    let appName: String
    let frame: CGRect
}

enum ShareableContent {

    /// Enumerates displays and on-screen windows.
    ///
    /// Note: this call is itself gated by the Screen Recording permission — it
    /// throws before the user grants access, which is a useful secondary check.
    static func fetch() async throws -> (displays: [DisplayOption], windows: [WindowOption], raw: SCShareableContent) {
        let content = try await SCShareableContent.excludingDesktopWindows(true, onScreenWindowsOnly: true)

        let displays: [DisplayOption] = content.displays.map { display in
            let bounds = CGDisplayBounds(display.displayID)
            let pixels = pixelSize(for: display.displayID,
                                   fallbackPoints: CGSize(width: display.width, height: display.height))
            return DisplayOption(
                id: display.displayID,
                localizedName: displayName(for: display.displayID) ?? "Display \(display.displayID)",
                pointSize: bounds.size == .zero ? CGSize(width: display.width, height: display.height) : bounds.size,
                pixelSize: pixels
            )
        }

        let ourPID = ProcessInfo.processInfo.processIdentifier
        let windows: [WindowOption] = content.windows
            .filter { $0.owningApplication?.processID != ourPID }
            .filter { $0.frame.width > 40 && $0.frame.height > 40 }
            .map {
                WindowOption(id: $0.windowID,
                             title: $0.title ?? "",
                             appName: $0.owningApplication?.applicationName ?? "",
                             frame: $0.frame)
            }

        return (displays, windows, content)
    }

    /// True backing-pixel size of a display, from its current display mode.
    static func pixelSize(for displayID: CGDirectDisplayID, fallbackPoints: CGSize) -> CGSize {
        if let mode = CGDisplayCopyDisplayMode(displayID) {
            let w = mode.pixelWidth, h = mode.pixelHeight
            if w > 0 && h > 0 { return CGSize(width: w, height: h) }
        }
        // Fall back to points * backing scale.
        let scale = backingScale(for: displayID)
        return CGSize(width: fallbackPoints.width * scale, height: fallbackPoints.height * scale)
    }

    private static func displayName(for displayID: CGDirectDisplayID) -> String? {
        NSScreen.screens.first {
            ($0.deviceDescription[.init("NSScreenNumber")] as? NSNumber)?.uint32Value == displayID
        }?.localizedName
    }

    private static func backingScale(for displayID: CGDirectDisplayID) -> CGFloat {
        NSScreen.screens.first {
            ($0.deviceDescription[.init("NSScreenNumber")] as? NSNumber)?.uint32Value == displayID
        }?.backingScaleFactor ?? 2.0
    }
}
