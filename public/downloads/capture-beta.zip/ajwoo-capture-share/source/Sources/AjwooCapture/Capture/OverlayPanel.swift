import AppKit

/// A borderless panel that goes exactly where it's put.
///
/// `NSWindow.constrainFrameRect(_:to:)` keeps ordinary windows clear of the menu
/// bar and on-screen. That's right for documents and wrong for an overlay drawn
/// over a specific rectangle: it silently clamps the frame, so a capture region
/// near the top of the display refuses to grow upward and its top handles appear
/// stuck. Returning the proposed rect unchanged is the fix.
///
/// Every overlay this app puts on screen uses this, so none of them can be
/// quietly moved out from under the coordinates they were given.
final class OverlayPanel: NSPanel {
    override func constrainFrameRect(_ frameRect: NSRect, to screen: NSScreen?) -> NSRect {
        frameRect
    }

    /// Borderless panels are not key by default, which would stop them ever
    /// receiving a drag.
    override var canBecomeKey: Bool { false }
}
