import Foundation
import CoreGraphics
import AppKit
import ScreenCaptureKit

enum ScreenRecordingPermission: Equatable {
    case granted
    case notDetermined
    case denied

    var isGranted: Bool { self == .granted }
}

enum CapturePermissions {

    /// Checks without prompting.
    ///
    /// macOS has no API that distinguishes "never asked" from "asked and denied",
    /// so we track whether we've prompted ourselves. `CGPreflightScreenCaptureAccess`
    /// only ever tells us yes or no.
    static func screenRecordingStatus() -> ScreenRecordingPermission {
        if CGPreflightScreenCaptureAccess() { return .granted }
        return hasPromptedForScreenRecording ? .denied : .notDetermined
    }

    private static let promptedKey = "AjwooCapture.hasPromptedForScreenRecording"

    static var hasPromptedForScreenRecording: Bool {
        get { UserDefaults.standard.bool(forKey: promptedKey) }
        set { UserDefaults.standard.set(newValue, forKey: promptedKey) }
    }

    /// Triggers the system prompt if we've never asked. Returns the resulting status.
    ///
    /// The prompt is one-shot per app identity: if the user dismisses or denies it,
    /// macOS will not show it again — the only way back is System Settings, which
    /// is why `openScreenRecordingSettings()` exists.
    @discardableResult
    static func requestScreenRecording() -> ScreenRecordingPermission {
        if CGPreflightScreenCaptureAccess() { return .granted }
        hasPromptedForScreenRecording = true
        let granted = CGRequestScreenCaptureAccess()
        return granted ? .granted : .denied
    }

    static func openScreenRecordingSettings() {
        let url = URL(string: "x-apple.systempreferences:com.apple.preference.security?Privacy_ScreenCapture")!
        NSWorkspace.shared.open(url)
    }
}
