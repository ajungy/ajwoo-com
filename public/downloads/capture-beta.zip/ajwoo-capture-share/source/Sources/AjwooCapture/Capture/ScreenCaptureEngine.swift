import Foundation
import ScreenCaptureKit
import AVFoundation
import CoreMedia
import CoreGraphics
import AppKit

enum CaptureError: LocalizedError {
    case permissionDenied
    case displayNotFound
    case noFramesCaptured
    case streamFailed(String)

    var errorDescription: String? {
        switch self {
        case .permissionDenied:
            return "ajwoo capture can't see your screen yet."
        case .displayNotFound:
            return "That display is no longer available."
        case .noFramesCaptured:
            return "The stream stopped before delivering a single frame."
        case .streamFailed(let s):
            return "Screen recording stopped unexpectedly."
        }
    }
}

/// Phase 1: captures a whole display plus system audio into a `.ajwoocapture`
/// package, alongside a cursor/click log on the same clock.
///
/// # Why a hand-rolled AVAssetWriter instead of `SCRecordingOutput`
/// macOS 15 added `SCRecordingOutput`, which writes a movie for you in one line.
/// It's the wrong fit here, for three concrete reasons:
///
/// 1. It muxes system audio into the same file as the video. This architecture
///    needs system audio, mic and camera as *separate* files so the editor can
///    balance them at export.
/// 2. It exposes no codec, bitrate, profile or colour configuration. The capture
///    master is the thing zoom crops magnify, so its bitrate is not a knob we
///    can give up.
/// 3. It hands back no per-frame presentation timestamps, which is exactly what
///    the cursor log has to be aligned against.
///
/// It would also pin us to macOS 15+. See NOTES.md.
final class ScreenCaptureEngine: NSObject, SCStreamOutput, SCStreamDelegate {

    /// Pixel format asked of ScreenCaptureKit.
    ///
    /// `420v` — two-plane 4:2:0, video range — rather than BGRA. Frames go
    /// straight from the stream into `AVAssetWriterInput` with no processing in
    /// between, and both codecs written here are 8-bit 4:2:0, so the conversion
    /// happens either way. Doing it in the capture pipeline instead of inside
    /// the encoder is roughly 2 GB/s versus 750 MB/s at 4K60, which is most of
    /// why frames were dropped on busy screens.
    ///
    /// The cost is chroma subsampled one stage earlier — very slight colour
    /// fringing on small coloured text, which the 4:2:0 output format would have
    /// introduced at export regardless.
    ///
    /// If the luma range ever looks wrong (crushed blacks or a washed-out
    /// picture), `kCVPixelFormatType_32BGRA` is the safe fallback and this is
    /// the only line that has to change.
    static let capturePixelFormat = kCVPixelFormatType_420YpCbCr8BiPlanarVideoRange

    struct Outcome {
        let session: RecordingSession
        let duration: Double
        let videoFrames: Int
        let audioBuffers: Int
        /// Frames ScreenCaptureKit sent with no new pixels on them, because the
        /// screen hadn't changed. Reported separately from `warnings` — it isn't
        /// one. See the note where it's counted.
        let skippedFrames: Int
        let warnings: [String]
    }

    // MARK: - State

    private var stream: SCStream?
    private var videoWriter: TrackWriter?
    private var audioWriter: TrackWriter?
    private let cursorRecorder = CursorEventRecorder()

    private var session: RecordingSession?
    private var geometry: CaptureGeometry?
    private var settings = CaptureSettings()
    private var startedAtWallClock = Date()

    private let lock = NSLock()
    /// Presentation timestamp of the first written video frame. The origin of
    /// every timestamp in the package.
    private var t0: CMTime?
    private var lastVideoPTS: CMTime = .invalid
    private var pendingAudio: [CMSampleBuffer] = []
    private var incompleteFrames = 0
    private var stopping = false
    private var streamError: Error?

    private let videoQueue = DispatchQueue(label: "com.ajwoo.capture.capture.video", qos: .userInitiated)
    private let audioQueue = DispatchQueue(label: "com.ajwoo.capture.capture.audio", qos: .userInitiated)

    /// Non-async wrapper so the lock is never held across a suspension point.
    private func withLock<T>(_ body: () -> T) -> T {
        lock.lock(); defer { lock.unlock() }
        return body()
    }

    /// Live normalized pointer position, for the debug overlay.
    var latestCursorNormalized: CGPoint? { cursorRecorder.latestNormalized }
    private(set) var activeGeometry: CaptureGeometry?

    // MARK: - Start

    /// Called on the video queue the instant `t0` is fixed, so auxiliary
    /// recorders (camera, mic) can start their writers on the same origin.
    var onOriginEstablished: ((CMTime) -> Void)?

    func start(session: RecordingSession,
               displayID: CGDirectDisplayID,
               region: CaptureRegion?,
               settings: CaptureSettings) async throws {
        guard CGPreflightScreenCaptureAccess() else { throw CaptureError.permissionDenied }

        self.settings = settings
        self.startedAtWallClock = Date()

        let content = try await SCShareableContent.excludingDesktopWindows(true, onScreenWindowsOnly: true)
        guard let display = content.displays.first(where: { $0.displayID == displayID }) else {
            throw CaptureError.displayNotFound
        }

        // Keep our own windows out of the capture, unless asked to include them.
        // SCContentFilter exclusion is more reliable than hiding windows: nothing
        // to un-hide, no race with the first frame, and the app stays usable
        // while recording.
        let ourApp = settings.includeAppWindows
            ? nil
            : content.applications.first { $0.bundleIdentifier == Bundle.main.bundleIdentifier }
        let filter = SCContentFilter(display: display,
                                     excludingApplications: ourApp.map { [$0] } ?? [],
                                     exceptingWindows: [])

        // --- geometry ---
        // One rectangle drives both pointer mapping and frame sizing, so they
        // cannot disagree. For a full-display capture that's CGDisplayBounds;
        // for a region it's the selected rect, still in global CG points.
        let displayBounds = CGDisplayBounds(displayID)
        let boundsPoints = region.map { $0.rectPoints.intersection(displayBounds) } ?? displayBounds
        guard boundsPoints.width > 4, boundsPoints.height > 4 else { throw CaptureError.displayNotFound }
        let scale = CGFloat(filter.pointPixelScale)
        // Encoders dislike odd dimensions. Display sizes are effectively always
        // even, so this is belt-and-braces; a shaved pixel would introduce a
        // ~0.03% mapping error, which is below one pixel of cursor placement.
        let pixelWidth = max(2, Int((boundsPoints.width * scale).rounded()) & ~1)
        let pixelHeight = max(2, Int((boundsPoints.height * scale).rounded()) & ~1)

        let geometry = CaptureGeometry(
            sourceRectPoints: boundsPoints,
            framePixelWidth: pixelWidth,
            framePixelHeight: pixelHeight,
            pointPixelScale: scale,
            displayID: displayID
        )
        self.geometry = geometry
        self.activeGeometry = geometry

        // --- writers ---
        self.session = session

        let videoWriter = try TrackWriter.screenVideo(
            url: session.screenVideoURL,
            pixelWidth: pixelWidth,
            pixelHeight: pixelHeight,
            settings: settings
        )
        self.videoWriter = videoWriter

        if settings.capturesSystemAudio {
            self.audioWriter = try TrackWriter.audio(url: session.systemAudioURL, kind: "system audio")
        }

        // --- stream ---
        let config = SCStreamConfiguration()
        config.width = pixelWidth
        config.height = pixelHeight
        config.minimumFrameInterval = CMTime(value: 1, timescale: CMTimeScale(settings.frameRate))
        // The whole architecture rests on this being false.
        config.showsCursor = false
        // Two-plane 4:2:0, not BGRA.
        //
        // Frames go straight from the stream into `AVAssetWriterInput` with no
        // processing in between, and both codecs we write are 8-bit 4:2:0 — so
        // the conversion happens either way. Doing it in the capture pipeline
        // rather than inside the encoder is the difference between moving about
        // 2 GB/s and about 750 MB/s at 4K60, which is most of why frames were
        // being dropped on busy screens.
        //
        // The cost is that chroma is subsampled a stage earlier. On screen
        // content that shows as very slight colour fringing on small coloured
        // text — and it would have shown at export regardless, because the
        // output format is 4:2:0.
        config.pixelFormat = Self.capturePixelFormat
        config.colorSpaceName = CGColorSpace.sRGB
        // Max permitted is 8. Deeper queue = more slack before SCK starts
        // dropping frames when the encoder hiccups.
        config.queueDepth = 8
        config.scalesToFit = false
        config.captureResolution = .best
        if let region {
            // Crop in the capture pipeline rather than in software afterwards:
            // ScreenCaptureKit only moves the pixels we asked for, and the
            // encoder only ever sees the region.
            // sourceRect is display-local points, top-left origin.
            config.sourceRect = region.localRectPoints.intersection(
                CGRect(origin: .zero, size: displayBounds.size)
            )
        }
        config.capturesAudio = settings.capturesSystemAudio
        config.sampleRate = Int(CaptureSettings.audioSampleRate)
        config.channelCount = CaptureSettings.audioChannelCount
        // Don't record ourselves recording.
        config.excludesCurrentProcessAudio = true

        let stream = SCStream(filter: filter, configuration: config, delegate: self)
        try stream.addStreamOutput(self, type: .screen, sampleHandlerQueue: videoQueue)
        if settings.capturesSystemAudio {
            try stream.addStreamOutput(self, type: .audio, sampleHandlerQueue: audioQueue)
        }
        self.stream = stream

        // Start the cursor log before the stream so we already have a position
        // in hand when the first frame lands.
        cursorRecorder.start(geometry: geometry)

        do {
            try await stream.startCapture()
        } catch {
            cursorRecorder.stop()
            videoWriter.cancel()
            audioWriter?.cancel()
            try? session.delete()
            self.stream = nil
            throw CaptureError.streamFailed(error.localizedDescription)
        }
    }

    // MARK: - Stop

    /// - Parameters:
    ///   - additionalMedia: camera/mic entries from `CameraMicRecorder`, folded
    ///     into `events.json` so the package describes every file it contains.
    func stop(additionalMedia: [EventLog.MediaFile] = [],
              additionalWarnings: [String] = []) async throws -> Outcome {
        withLock { stopping = true }

        // Stop delivery first, then read the clock state — a frame can land
        // between setting the flag and the stream actually winding down.
        if let stream {
            try? await stream.stopCapture()
        }
        stream = nil
        cursorRecorder.stop()

        let (capturedT0, capturedLast, dropped) = withLock { (t0, lastVideoPTS, incompleteFrames) }

        guard let session, let geometry else { throw CaptureError.noFramesCaptured }

        guard let t0 = capturedT0, capturedLast.isValid else {
            videoWriter?.cancel()
            audioWriter?.cancel()
            try? session.delete()
            reset()
            throw streamError.map { CaptureError.streamFailed($0.localizedDescription) } ?? CaptureError.noFramesCaptured
        }

        await videoWriter?.finish()
        await audioWriter?.finish()

        let duration = max(0, CMTimeGetSeconds(CMTimeSubtract(capturedLast, t0)))
        let t0Seconds = CMTimeGetSeconds(t0)

        // --- events.json ---
        let (cursorSamples, clickEvents, pointerShapes) = cursorRecorder.finish(t0: t0Seconds, duration: duration)

        var media: [EventLog.MediaFile] = []
        if let v = videoWriter {
            media.append(.init(file: v.url.lastPathComponent, kind: "screenVideo",
                               startOffsetSeconds: v.startOffset, sampleCount: v.sampleCount))
        }
        if let a = audioWriter, a.sampleCount > 0 {
            media.append(.init(file: a.url.lastPathComponent, kind: "systemAudio",
                               startOffsetSeconds: a.startOffset, sampleCount: a.sampleCount))
        }
        media.append(contentsOf: additionalMedia)

        let log = EventLog(
            recording: .init(
                startedAt: startedAtWallClock,
                durationSeconds: duration,
                frameRate: settings.frameRate,
                geometry: geometry,
                media: media
            ),
            cursor: cursorSamples,
            clicks: clickEvents,
            pointerShapes: pointerShapes.isEmpty ? nil : pointerShapes
        )
        try log.write(to: session.eventsURL)
        try ProjectState().write(to: session.projectURL)

        // --- warnings ---
        var warnings: [String] = additionalWarnings
        if let f = videoWriter?.failureDescription { warnings.append("Couldn't save the screen video.") }
        if let f = audioWriter?.failureDescription { warnings.append("Couldn't save the computer sound.") }
        if settings.capturesSystemAudio, (audioWriter?.sampleCount ?? 0) == 0 {
            warnings.append("No computer sound was recorded. Nothing was playing.")
        }
        // Deliberately *not* a warning.
        //
        // These are frames where the screen simply hadn't changed, so there were
        // no new pixels to write. Skipping them is what keeps a still desktop
        // from costing 100 Mbps — it's the feature working, not a fault. Sitting
        // in the warnings list beside "couldn't save the video" it read as a
        // failure, and on a slide-based demo it was the loudest thing on screen.
        if cursorSamples.isEmpty {
            warnings.append("The pointer wasn't tracked, so it won't appear in the video.")
        }
        if let e = streamError {
            warnings.append("Stream reported: \(e.localizedDescription)")
        }

        let outcome = Outcome(
            session: session,
            duration: duration,
            videoFrames: videoWriter?.sampleCount ?? 0,
            audioBuffers: audioWriter?.sampleCount ?? 0,
            skippedFrames: dropped,
            warnings: warnings
        )
        reset()
        return outcome
    }

    private func reset() {
        lock.lock()
        t0 = nil
        lastVideoPTS = .invalid
        pendingAudio.removeAll()
        incompleteFrames = 0
        stopping = false
        streamError = nil
        lock.unlock()

        videoWriter = nil
        audioWriter = nil
        session = nil
        geometry = nil
        activeGeometry = nil
    }

    // MARK: - SCStreamOutput

    func stream(_ stream: SCStream, didOutputSampleBuffer sampleBuffer: CMSampleBuffer, of type: SCStreamOutputType) {
        guard sampleBuffer.isValid else { return }
        switch type {
        case .screen: handleVideo(sampleBuffer)
        case .audio:  handleAudio(sampleBuffer)
        default:      break
        }
    }

    private func handleVideo(_ sampleBuffer: CMSampleBuffer) {
        lock.lock()
        let isStopping = stopping
        lock.unlock()
        guard !isStopping else { return }

        // SCK marks each frame .complete / .idle / .blank / .suspended. Only
        // .complete carries new pixels; the rest are heartbeats for an unchanged
        // screen. Skipping them is not dropping frames — it's what keeps an idle
        // desktop from costing 100 Mbps. Playback holds the last frame.
        guard let attachments = CMSampleBufferGetSampleAttachmentsArray(sampleBuffer, createIfNecessary: false)
                as? [[SCStreamFrameInfo: Any]],
              let info = attachments.first,
              let rawStatus = info[.status] as? Int,
              let status = SCFrameStatus(rawValue: rawStatus)
        else { return }

        guard status == .complete, CMSampleBufferGetImageBuffer(sampleBuffer) != nil else {
            lock.lock(); incompleteFrames += 1; lock.unlock()
            return
        }

        let pts = CMSampleBufferGetPresentationTimeStamp(sampleBuffer)
        guard pts.isValid else { return }

        lock.lock()
        let needsStart = (t0 == nil)
        lock.unlock()

        if needsStart {
            // Start both writers *before* publishing t0. The audio queue treats
            // a non-nil t0 as "the writers are live", so publishing it last is
            // what keeps the two queues from racing.
            do {
                try videoWriter?.start(atSourceTime: pts)
                try audioWriter?.start(atSourceTime: pts)
            } catch {
                lock.lock(); streamError = error; lock.unlock()
                return
            }
            lock.lock(); t0 = pts; lock.unlock()
            // Camera and mic writers latch onto the same origin.
            onOriginEstablished?(pts)
        }

        lock.lock()
        let origin = t0 ?? pts
        lastVideoPTS = pts
        lock.unlock()

        videoWriter?.append(sampleBuffer, t0: origin)
    }

    /// Runs on `audioQueue`, which is serial — so every append to the audio
    /// input happens from one thread, in presentation order. The pre-`t0`
    /// backlog is drained here rather than from the video queue for that reason.
    private func handleAudio(_ sampleBuffer: CMSampleBuffer) {
        lock.lock()
        let isStopping = stopping
        guard let origin = t0 else {
            // Audio can beat the first video frame. Hold it until t0 exists
            // rather than throwing it away; the cap stops a stalled video path
            // from eating memory (240 buffers is a few seconds).
            if !isStopping, pendingAudio.count < 240 { pendingAudio.append(sampleBuffer) }
            lock.unlock()
            return
        }
        let backlog = pendingAudio
        pendingAudio.removeAll()
        lock.unlock()

        guard !isStopping else { return }
        for buffer in backlog { audioWriter?.append(buffer, t0: origin) }
        audioWriter?.append(sampleBuffer, t0: origin)
    }

    // MARK: - SCStreamDelegate

    func stream(_ stream: SCStream, didStopWithError error: Error) {
        lock.lock()
        streamError = error
        lock.unlock()
        NSLog("[ajwoo capture] SCStream stopped with error: \(error.localizedDescription)")
    }
}
