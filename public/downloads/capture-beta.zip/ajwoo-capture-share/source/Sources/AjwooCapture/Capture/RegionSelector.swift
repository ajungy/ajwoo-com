import AppKit
import SwiftUI
import ScreenCaptureKit
import CoreGraphics

/// A rectangle to capture, in CoreGraphics global display points.
struct CaptureRegion: Codable, Equatable {
    var displayID: CGDirectDisplayID
    /// Global CG coordinates: origin top-left of the primary display, Y down.
    var rectPoints: CGRect

    /// The same rect expressed relative to its display's top-left, which is what
    /// `SCStreamConfiguration.sourceRect` wants.
    var localRectPoints: CGRect {
        let bounds = CGDisplayBounds(displayID)
        return rectPoints.offsetBy(dx: -bounds.minX, dy: -bounds.minY)
    }

    static let defaultsKey = "AjwooCapture.lastRegion"

    static var remembered: CaptureRegion? {
        guard let data = UserDefaults.standard.data(forKey: defaultsKey) else { return nil }
        return try? JSONDecoder().decode(CaptureRegion.self, from: data)
    }

    func remember() {
        guard let data = try? JSONEncoder().encode(self) else { return }
        UserDefaults.standard.set(data, forKey: Self.defaultsKey)
    }
}

/// Full-screen overlay for dragging out a capture region, with window snapping.
@MainActor
final class RegionSelector {

    private var panels: [NSPanel] = []
    private var completion: ((CaptureRegion?) -> Void)?
    private var monitor: Any?

    /// Presents the overlay and calls back with the chosen region, or nil if
    /// cancelled. Window frames are fetched up front so hovering can snap.
    func present(completion: @escaping (CaptureRegion?) -> Void) {
        dismiss()
        self.completion = completion

        Task { @MainActor in
            let snapTargets = (try? await ShareableContent.fetch().windows) ?? []

            for screen in NSScreen.screens {
                guard let displayID = screen.displayID else { continue }
                let panel = OverlayPanel(contentRect: screen.frame,
                                    styleMask: [.borderless, .nonactivatingPanel],
                                    backing: .buffered,
                                    defer: false)
                panel.level = .screenSaver
                panel.isOpaque = false
                panel.backgroundColor = .clear
                panel.hasShadow = false
                panel.collectionBehavior = [.canJoinAllSpaces, .stationary, .fullScreenNone, .ignoresCycle]
                panel.ignoresMouseEvents = false
                panel.acceptsMouseMovedEvents = true

                let view = RegionSelectionView(frame: NSRect(origin: .zero, size: screen.frame.size))
                view.displayID = displayID
                view.screenFrameAppKit = screen.frame
                // Only the windows that live on this display can be snapped to here.
                view.snapTargets = snapTargets.filter {
                    CGDisplayBounds(displayID).intersects($0.frame)
                }
                view.onFinish = { [weak self] region in
                    self?.finish(with: region)
                }
                panel.contentView = view
                panel.orderFrontRegardless()
                panels.append(panel)

                // The panel must be key to receive Esc / Return.
                if screen.frame.contains(NSEvent.mouseLocation) {
                    panel.makeKeyAndOrderFront(nil)
                    panel.makeFirstResponder(view)
                }
            }

            // Belt and braces: a nonactivating panel doesn't always get key
            // status, so watch Esc globally too.
            monitor = NSEvent.addLocalMonitorForEvents(matching: .keyDown) { [weak self] event in
                if event.keyCode == 53 { // Esc
                    self?.finish(with: nil)
                    return nil
                }
                return event
            }
        }
    }

    private func finish(with region: CaptureRegion?) {
        let completion = self.completion
        self.completion = nil
        dismiss()
        region?.remember()
        completion?(region)
    }

    func dismiss() {
        if let monitor { NSEvent.removeMonitor(monitor) }
        monitor = nil
        panels.forEach { $0.orderOut(nil) }
        panels.removeAll()
    }
}

// MARK: - The overlay view

private final class RegionSelectionView: NSView {

    var displayID: CGDirectDisplayID = 0
    var screenFrameAppKit: NSRect = .zero
    var snapTargets: [WindowOption] = []
    var onFinish: ((CaptureRegion?) -> Void)?

    private var dragStart: NSPoint?
    private var dragCurrent: NSPoint?
    private var hoveredWindow: WindowOption?
    private var trackingArea: NSTrackingArea?

    override var acceptsFirstResponder: Bool { true }
    override var isFlipped: Bool { false }

    override func updateTrackingAreas() {
        super.updateTrackingAreas()
        if let trackingArea { removeTrackingArea(trackingArea) }
        let area = NSTrackingArea(rect: bounds,
                                  options: [.activeAlways, .mouseMoved, .inVisibleRect],
                                  owner: self, userInfo: nil)
        addTrackingArea(area)
        trackingArea = area
        NSCursor.crosshair.set()
    }

    // MARK: Coordinates

    /// View point (bottom-left origin, local) -> CoreGraphics global (top-left origin).
    private func globalCG(from viewPoint: NSPoint) -> CGPoint {
        let appKit = CGPoint(x: screenFrameAppKit.minX + viewPoint.x,
                             y: screenFrameAppKit.minY + viewPoint.y)
        return ScreenSpace.globalCG(fromAppKit: appKit)
    }

    /// CoreGraphics global rect -> local view rect, for drawing snap highlights.
    private func viewRect(fromGlobalCG rect: CGRect) -> NSRect {
        let topLeftAppKit = ScreenSpace.appKit(fromGlobalCG: CGPoint(x: rect.minX, y: rect.minY))
        return NSRect(x: topLeftAppKit.x - screenFrameAppKit.minX,
                      y: topLeftAppKit.y - screenFrameAppKit.minY - rect.height,
                      width: rect.width,
                      height: rect.height)
    }

    private var currentSelectionViewRect: NSRect? {
        if let start = dragStart, let current = dragCurrent {
            let rect = NSRect(x: min(start.x, current.x), y: min(start.y, current.y),
                              width: abs(current.x - start.x), height: abs(current.y - start.y))
            return rect.width > 4 && rect.height > 4 ? rect : nil
        }
        if let hovered = hoveredWindow {
            return viewRect(fromGlobalCG: hovered.frame)
        }
        return nil
    }

    // MARK: Mouse

    override func mouseMoved(with event: NSEvent) {
        guard dragStart == nil else { return }
        let point = convert(event.locationInWindow, from: nil)
        let global = globalCG(from: point)
        // Smallest window under the pointer wins — otherwise a full-screen
        // window behind everything always swallows the hit.
        hoveredWindow = snapTargets
            .filter { $0.frame.contains(global) }
            .min { $0.frame.width * $0.frame.height < $1.frame.width * $1.frame.height }
        needsDisplay = true
    }

    override func mouseDown(with event: NSEvent) {
        dragStart = convert(event.locationInWindow, from: nil)
        dragCurrent = dragStart
        needsDisplay = true
    }

    override func mouseDragged(with event: NSEvent) {
        dragCurrent = convert(event.locationInWindow, from: nil)
        hoveredWindow = nil
        needsDisplay = true
    }

    override func mouseUp(with event: NSEvent) {
        defer { dragStart = nil; dragCurrent = nil }

        if let rect = currentSelectionViewRect {
            confirm(viewRect: rect)
        } else if let hovered = hoveredWindow {
            // A click without a drag means "take this window's bounds".
            confirm(globalRect: hovered.frame)
        }
    }

    override func keyDown(with event: NSEvent) {
        switch event.keyCode {
        case 53: // Esc
            onFinish?(nil)
        case 36, 76: // Return / keypad Enter
            if let rect = currentSelectionViewRect { confirm(viewRect: rect) }
        default:
            super.keyDown(with: event)
        }
    }

    private func confirm(viewRect: NSRect) {
        let topLeft = globalCG(from: NSPoint(x: viewRect.minX, y: viewRect.maxY))
        confirm(globalRect: CGRect(origin: topLeft, size: viewRect.size))
    }

    private func confirm(globalRect: CGRect) {
        // Clip to the display, then round to even pixel dimensions — encoders
        // reject odd sizes, and the rounding has to happen in *pixels*, not
        // points, or a 2x display lands on an odd pixel count anyway.
        let bounds = CGDisplayBounds(displayID)
        let clipped = globalRect.intersection(bounds)
        guard clipped.width > 8, clipped.height > 8 else {
            onFinish?(nil)
            return
        }

        let scale = NSScreen.screens.first { $0.displayID == displayID }?.backingScaleFactor ?? 2
        let evenWidth = (CGFloat(Int(clipped.width * scale) & ~1)) / scale
        let evenHeight = (CGFloat(Int(clipped.height * scale) & ~1)) / scale
        let rounded = CGRect(x: clipped.minX.rounded(), y: clipped.minY.rounded(),
                             width: evenWidth, height: evenHeight)

        onFinish?(CaptureRegion(displayID: displayID, rectPoints: rounded))
    }

    // MARK: Draw

    override func draw(_ dirtyRect: NSRect) {
        NSColor.black.withAlphaComponent(0.35).setFill()
        bounds.fill()

        guard let selection = currentSelectionViewRect else {
            drawHint()
            return
        }

        // Punch the selection out of the dimming so you can see what you'll get.
        NSColor.clear.setFill()
        selection.fill(using: .copy)

        NSColor.controlAccentColor.setStroke()
        let border = NSBezierPath(rect: selection)
        border.lineWidth = 2
        border.stroke()

        let scale = NSScreen.screens.first { $0.displayID == displayID }?.backingScaleFactor ?? 2
        let label = "\(Int(selection.width * scale)) × \(Int(selection.height * scale)) px"
        let attributes: [NSAttributedString.Key: Any] = [
            .font: NSFont.monospacedSystemFont(ofSize: 12, weight: .semibold),
            .foregroundColor: NSColor.white,
        ]
        let string = NSAttributedString(string: label, attributes: attributes)
        let size = string.size()
        let badge = NSRect(x: selection.midX - size.width / 2 - 8,
                           y: selection.minY - size.height - 12,
                           width: size.width + 16, height: size.height + 8)
        NSColor.black.withAlphaComponent(0.8).setFill()
        NSBezierPath(roundedRect: badge, xRadius: 5, yRadius: 5).fill()
        string.draw(at: NSPoint(x: badge.minX + 8, y: badge.minY + 4))
    }

    private func drawHint() {
        let hint = "Drag to select a region · click a window to snap to it · Return to confirm · Esc to cancel"
        let attributes: [NSAttributedString.Key: Any] = [
            .font: NSFont.systemFont(ofSize: 13, weight: .medium),
            .foregroundColor: NSColor.white.withAlphaComponent(0.9),
        ]
        let string = NSAttributedString(string: hint, attributes: attributes)
        let size = string.size()
        let badge = NSRect(x: bounds.midX - size.width / 2 - 12,
                           y: bounds.midY - size.height / 2 - 6,
                           width: size.width + 24, height: size.height + 12)
        NSColor.black.withAlphaComponent(0.7).setFill()
        NSBezierPath(roundedRect: badge, xRadius: 8, yRadius: 8).fill()
        string.draw(at: NSPoint(x: badge.minX + 12, y: badge.minY + 6))
    }
}

extension NSScreen {
    var displayID: CGDirectDisplayID? {
        (deviceDescription[.init("NSScreenNumber")] as? NSNumber)?.uint32Value
    }
}
