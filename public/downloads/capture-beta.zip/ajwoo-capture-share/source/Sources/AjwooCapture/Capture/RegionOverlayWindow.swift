import AppKit
import CoreGraphics

/// Keeps the chosen capture region visible on screen — and adjustable — after
/// the selector closes.
///
/// # Why this is five windows and not one
/// The obvious build is one borderless panel over the region that returns nil
/// from `hitTest` everywhere except the handles. That does not work, and it
/// failed twice here: a window that isn't `ignoresMouseEvents` sits between the
/// pointer and everything beneath it regardless of what its content view's
/// `hitTest` says. The result both times was a screen that looked fine and
/// accepted no clicks anywhere — you couldn't use the thing you were about to
/// record.
///
/// So the outline and the handles are separate windows:
///
/// - **The outline panel** covers the region and is `ignoresMouseEvents = true`.
///   It can never take a click, so nothing it covers is blocked.
/// - **Four handle panels**, 26 pt square, sit on the corners and are the only
///   surfaces in the whole overlay that accept the mouse.
///
/// Everything outside those four small squares behaves exactly as it did before
/// a region was chosen.
///
/// The panels belong to this app, so `SCContentFilter` keeps them out of the
/// capture unless "record this app's own windows" is on.
@MainActor
final class RegionOverlayWindow {

    /// Margin around the region for the outline, and room above it for the badge.
    private static let margin: CGFloat = 12
    private static let badgeSpace: CGFloat = 28
    /// Side of a corner handle's window. Small on purpose — it's the only part
    /// of the screen the overlay takes away from you.
    static let handleSide: CGFloat = 26

    enum Corner: CaseIterable {
        case topLeft, topRight, bottomLeft, bottomRight
    }

    private var outlinePanel: OverlayPanel?
    private var outlineView: RegionOutlineView?
    private var handlePanels: [Corner: OverlayPanel] = [:]
    private var onChange: ((CaptureRegion) -> Void)?

    private var region: CaptureRegion?
    private var screenFrame: NSRect = .zero
    /// The rect being dragged, in AppKit screen coordinates.
    private var liveRect: NSRect = .zero

    func show(region: CaptureRegion, onChange: @escaping (CaptureRegion) -> Void) {
        self.onChange = onChange
        self.region = region

        guard let screen = NSScreen.screens.first(where: { $0.displayID == region.displayID }) else {
            hide()
            return
        }
        screenFrame = screen.frame
        liveRect = Self.appKitRect(for: region)

        makeOutlineIfNeeded()
        makeHandlesIfNeeded()
        layout()
    }

    func hide() {
        outlinePanel?.orderOut(nil)
        outlinePanel = nil
        outlineView = nil
        for panel in handlePanels.values { panel.orderOut(nil) }
        handlePanels = [:]
        onChange = nil
        region = nil
    }

    // MARK: - Geometry

    /// The region in AppKit screen coordinates (bottom-left origin).
    private static func appKitRect(for region: CaptureRegion) -> NSRect {
        let topLeft = ScreenSpace.appKit(fromGlobalCG: CGPoint(x: region.rectPoints.minX,
                                                               y: region.rectPoints.minY))
        return NSRect(x: topLeft.x,
                      y: topLeft.y - region.rectPoints.height,
                      width: region.rectPoints.width,
                      height: region.rectPoints.height)
    }

    private func outlineFrame() -> NSRect {
        var frame = liveRect.insetBy(dx: -Self.margin, dy: -Self.margin)
        frame.size.height += Self.badgeSpace
        return frame
    }

    /// Where a handle window goes.
    ///
    /// Centred on its corner, then pushed back inside the area you can actually
    /// click. A region whose top edge runs under the menu bar would otherwise put
    /// its top handles under the menu bar, which owns those clicks — the handles
    /// were visible and completely dead.
    ///
    /// Pushed *inward*, not clamped to the screen edge, so a displaced handle
    /// sits over the region it resizes rather than half off the display. It stops
    /// being exactly on the corner, and that's the right trade: a handle slightly
    /// inside the corner still works, and one under the menu bar doesn't.
    private func handleOrigin(_ corner: Corner) -> NSPoint {
        let half = Self.handleSide / 2
        let point: NSPoint
        switch corner {
        case .topLeft:     point = NSPoint(x: liveRect.minX, y: liveRect.maxY)
        case .topRight:    point = NSPoint(x: liveRect.maxX, y: liveRect.maxY)
        case .bottomLeft:  point = NSPoint(x: liveRect.minX, y: liveRect.minY)
        case .bottomRight: point = NSPoint(x: liveRect.maxX, y: liveRect.minY)
        }

        var origin = NSPoint(x: point.x - half, y: point.y - half)
        guard let screen = NSScreen.screens.first(where: { $0.displayID == region?.displayID })
        else { return origin }

        // `visibleFrame` excludes the menu bar and the Dock — precisely the
        // regions where a window is present but unclickable.
        let usable = screen.visibleFrame.insetBy(dx: 2, dy: 2)
        origin.x = min(max(origin.x, usable.minX), usable.maxX - Self.handleSide)
        origin.y = min(max(origin.y, usable.minY), usable.maxY - Self.handleSide)
        return origin
    }

    /// True when a handle had to be moved off its corner to stay clickable.
    private func isDisplaced(_ corner: Corner) -> Bool {
        let half = Self.handleSide / 2
        let placed = handleOrigin(corner)
        let ideal: NSPoint
        switch corner {
        case .topLeft:     ideal = NSPoint(x: liveRect.minX - half, y: liveRect.maxY - half)
        case .topRight:    ideal = NSPoint(x: liveRect.maxX - half, y: liveRect.maxY - half)
        case .bottomLeft:  ideal = NSPoint(x: liveRect.minX - half, y: liveRect.minY - half)
        case .bottomRight: ideal = NSPoint(x: liveRect.maxX - half, y: liveRect.minY - half)
        }
        return abs(placed.x - ideal.x) > 0.5 || abs(placed.y - ideal.y) > 0.5
    }

    // MARK: - Windows

    private func makeOutlineIfNeeded() {
        guard outlinePanel == nil else { return }

        let panel = OverlayPanel(contentRect: outlineFrame(),
                            styleMask: [.borderless, .nonactivatingPanel],
                            backing: .buffered,
                            defer: false)
        panel.level = .floating
        panel.isOpaque = false
        panel.backgroundColor = .clear
        panel.hasShadow = false
        // The whole point: this window can never take a click.
        panel.ignoresMouseEvents = true
        panel.collectionBehavior = [.canJoinAllSpaces, .stationary, .fullScreenNone, .ignoresCycle]

        let view = RegionOutlineView(frame: NSRect(origin: .zero, size: panel.frame.size))
        panel.contentView = view
        panel.orderFrontRegardless()

        outlinePanel = panel
        outlineView = view
    }

    private func makeHandlesIfNeeded() {
        for corner in Corner.allCases where handlePanels[corner] == nil {
            let panel = OverlayPanel(contentRect: NSRect(origin: .zero,
                                                    size: NSSize(width: Self.handleSide,
                                                                 height: Self.handleSide)),
                                styleMask: [.borderless, .nonactivatingPanel],
                                backing: .buffered,
                                defer: false)
            panel.level = .floating
            panel.isOpaque = false
            panel.backgroundColor = .clear
            panel.hasShadow = false
            panel.ignoresMouseEvents = false
            panel.collectionBehavior = [.canJoinAllSpaces, .stationary, .fullScreenNone, .ignoresCycle]

            let view = RegionHandleView(frame: NSRect(origin: .zero,
                                                     size: NSSize(width: Self.handleSide,
                                                                  height: Self.handleSide)))
            view.corner = corner
            view.onDrag = { [weak self] corner, screenPoint in
                self?.resize(corner: corner, to: screenPoint)
            }
            view.onCommit = { [weak self] in self?.commit() }
            panel.contentView = view
            panel.orderFrontRegardless()
            handlePanels[corner] = panel
        }
    }

    private func layout() {
        outlinePanel?.setFrame(outlineFrame(), display: false)
        outlineView?.frame = NSRect(origin: .zero, size: outlineFrame().size)
        outlineView?.regionInPanel = NSRect(x: Self.margin,
                                            y: Self.margin,
                                            width: liveRect.width,
                                            height: liveRect.height)
        outlineView?.scale = NSScreen.screens.first { $0.displayID == region?.displayID }?
            .backingScaleFactor ?? 2
        outlineView?.needsDisplay = true

        for corner in Corner.allCases {
            handlePanels[corner]?.setFrameOrigin(handleOrigin(corner))
            let view = handlePanels[corner]?.contentView as? RegionHandleView
            view?.displaced = isDisplaced(corner)
            view?.needsDisplay = true
        }
    }

    // MARK: - Dragging

    private func resize(corner: Corner, to screenPoint: NSPoint) {
        var rect = liveRect
        let minimum: CGFloat = 48

        switch corner {
        case .topLeft, .bottomLeft:
            let maxX = rect.maxX
            rect.origin.x = min(screenPoint.x, maxX - minimum)
            rect.size.width = maxX - rect.origin.x
        case .topRight, .bottomRight:
            rect.size.width = max(minimum, screenPoint.x - rect.minX)
        }

        switch corner {
        case .bottomLeft, .bottomRight:
            let maxY = rect.maxY
            rect.origin.y = min(screenPoint.y, maxY - minimum)
            rect.size.height = maxY - rect.origin.y
        case .topLeft, .topRight:
            rect.size.height = max(minimum, screenPoint.y - rect.minY)
        }

        liveRect = rect.intersection(screenFrame).isEmpty ? rect : rect
        layout()
    }

    /// Publishes the new region once the drag ends.
    ///
    /// During the drag only the overlay moves; the capture settings are written
    /// on mouse-up so a drag doesn't produce fifty updates, each one re-laying
    /// out the main window.
    private func commit() {
        guard var region else { return }

        let topLeftAppKit = CGPoint(x: liveRect.minX, y: liveRect.maxY)
        let topLeftCG = ScreenSpace.globalCG(fromAppKit: topLeftAppKit)

        // Even pixel dimensions, as the selector does — encoders reject odd sizes.
        let scale = NSScreen.screens.first { $0.displayID == region.displayID }?.backingScaleFactor ?? 2
        let width = (CGFloat(Int(liveRect.width * scale) & ~1)) / scale
        let height = (CGFloat(Int(liveRect.height * scale) & ~1)) / scale

        region.rectPoints = CGRect(x: topLeftCG.x.rounded(), y: topLeftCG.y.rounded(),
                                   width: max(16, width), height: max(16, height))
        region.remember()
        self.region = region
        onChange?(region)
    }
}

/// Draws the bounds and the size badge. Never takes the mouse.
private final class RegionOutlineView: NSView {
    var regionInPanel: NSRect = .zero
    var scale: CGFloat = 2

    override var isFlipped: Bool { false }

    override func draw(_ dirtyRect: NSRect) {
        let rect = regionInPanel
        guard rect.width > 1, rect.height > 1 else { return }

        // A dark hairline under a light one, so the bounds read over any content.
        NSColor.black.withAlphaComponent(0.6).setStroke()
        let shadow = NSBezierPath(rect: rect.insetBy(dx: -1, dy: -1))
        shadow.lineWidth = 3
        shadow.stroke()

        NSColor.white.setStroke()
        let border = NSBezierPath(rect: rect)
        border.lineWidth = 1
        border.stroke()

        let label = "\(Int(rect.width * scale)) × \(Int(rect.height * scale)) px"
        let attributes: [NSAttributedString.Key: Any] = [
            .font: NSFont.monospacedSystemFont(ofSize: 11, weight: .medium),
            .foregroundColor: NSColor.white,
        ]
        let string = NSAttributedString(string: label, attributes: attributes)
        let size = string.size()
        let badge = NSRect(x: rect.minX, y: rect.maxY + 7, width: size.width + 12, height: size.height + 6)
        NSColor.black.withAlphaComponent(0.8).setFill()
        NSBezierPath(roundedRect: badge, xRadius: 5, yRadius: 5).fill()
        string.draw(at: NSPoint(x: badge.minX + 6, y: badge.minY + 3))
    }
}

/// One corner grip. The only part of the overlay that accepts a click.
private final class RegionHandleView: NSView {
    var corner: RegionOverlayWindow.Corner = .topLeft
    var onDrag: ((RegionOverlayWindow.Corner, NSPoint) -> Void)?
    var onCommit: (() -> Void)?

    /// Set when this handle had to move off its corner to stay clickable. It's
    /// drawn hollow, so it's clear it isn't sitting on the corner it controls.
    var displaced = false

    private var hovering = false
    private var dragging = false
    private var trackingArea: NSTrackingArea?

    override var isFlipped: Bool { false }

    override func updateTrackingAreas() {
        super.updateTrackingAreas()
        if let trackingArea { removeTrackingArea(trackingArea) }
        let area = NSTrackingArea(rect: bounds,
                                  options: [.activeAlways, .mouseEnteredAndExited, .inVisibleRect],
                                  owner: self, userInfo: nil)
        addTrackingArea(area)
        trackingArea = area
    }

    override func mouseEntered(with event: NSEvent) {
        hovering = true
        NSCursor.crosshair.set()
        needsDisplay = true
        toolTip = displaced
            ? "Drag to resize. This corner is off the screen edge, so the handle sits just inside it."
            : "Drag to resize the recorded area"
    }

    override func mouseExited(with event: NSEvent) {
        hovering = false
        if !dragging { NSCursor.arrow.set() }
        needsDisplay = true
    }

    override func mouseDown(with event: NSEvent) {
        dragging = true
        needsDisplay = true
    }

    override func mouseDragged(with event: NSEvent) {
        guard dragging, let window else { return }
        // The handle window is only 26 pt across, so the pointer leaves it
        // immediately. Screen coordinates are the only frame that stays valid.
        let inWindow = event.locationInWindow
        let onScreen = window.convertPoint(toScreen: inWindow)
        onDrag?(corner, onScreen)
    }

    override func mouseUp(with event: NSEvent) {
        dragging = false
        needsDisplay = true
        onCommit?()
    }

    override func draw(_ dirtyRect: NSRect) {
        // The grip is drawn smaller than its window: the extra room is grab
        // slop, so the handle is easy to hit without looking heavy.
        let side: CGFloat = hovering || dragging ? 12 : 9
        let box = NSRect(x: bounds.midX - side / 2, y: bounds.midY - side / 2,
                         width: side, height: side)

        if displaced {
            NSColor.black.withAlphaComponent(0.5).setFill()
        } else {
            NSColor.white.setFill()
        }
        NSBezierPath(roundedRect: box, xRadius: 2.5, yRadius: 2.5).fill()

        (displaced ? NSColor.white : NSColor.black.withAlphaComponent(0.55)).setStroke()
        let outline = NSBezierPath(roundedRect: box, xRadius: 2.5, yRadius: 2.5)
        outline.lineWidth = displaced ? 2 : 1
        outline.stroke()
    }
}
