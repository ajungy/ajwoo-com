import AVFoundation
import AppKit
import SwiftUI

/// Live camera preview for the home window, before anything is being recorded.
///
/// You should be able to see that you're in frame, lit, and pointing the right
/// way *before* pressing Record — finding out afterwards means doing the take
/// again. This runs a minimal `AVCaptureSession` with the camera input and no
/// outputs at all: an `AVCaptureVideoPreviewLayer` draws straight from the
/// session, so nothing is decoded, encoded or written.
///
/// Like `MicMonitor`, it never triggers the permission prompt. A dialog
/// appearing because you opened the app would be rude; the preview stays blank
/// until a real recording asks properly.
@MainActor
final class CameraMonitor: ObservableObject {

    private(set) var captureSession = AVCaptureSession()
    @Published private(set) var isRunning = false
    private var currentDeviceID: String?

    /// Starts, or switches device. A no-op if already showing this camera.
    func start(deviceID: String) {
        if captureSession.isRunning, currentDeviceID == deviceID { return }
        stop()

        guard AVCaptureDevice.authorizationStatus(for: .video) == .authorized,
              let device = AVCaptureDevice(uniqueID: deviceID),
              let input = try? AVCaptureDeviceInput(device: device)
        else { return }

        let session = AVCaptureSession()
        session.beginConfiguration()
        session.sessionPreset = .high
        guard session.canAddInput(input) else {
            session.commitConfiguration()
            return
        }
        session.addInput(input)
        session.commitConfiguration()

        captureSession = session
        currentDeviceID = deviceID
        isRunning = true

        // `startRunning` blocks for a beat while the device warms up.
        Task.detached(priority: .userInitiated) { session.startRunning() }
    }

    func stop() {
        let session = captureSession
        if session.isRunning {
            Task.detached(priority: .utility) { session.stopRunning() }
        }
        currentDeviceID = nil
        isRunning = false
    }
}

/// Draws an `AVCaptureSession` with the preview mirrored.
///
/// Mirroring is the point rather than a detail: an unmirrored preview shows you
/// moving left when you move right, which makes it useless for the one job it
/// has, which is checking your framing. The recorded camera track is mirrored to
/// match — see `CameraMirror`.
struct CameraPreviewView: NSViewRepresentable {
    let session: AVCaptureSession
    var cornerRadius: CGFloat = 8

    func makeNSView(context: Context) -> NSView {
        let view = PreviewView()
        view.wantsLayer = true
        view.attach(session: session, cornerRadius: cornerRadius)
        return view
    }

    func updateNSView(_ nsView: NSView, context: Context) {
        (nsView as? PreviewView)?.attach(session: session, cornerRadius: cornerRadius)
    }

    private final class PreviewView: NSView {
        private var preview: AVCaptureVideoPreviewLayer?

        func attach(session: AVCaptureSession, cornerRadius: CGFloat) {
            if preview?.session === session {
                preview?.cornerRadius = cornerRadius
                return
            }
            preview?.removeFromSuperlayer()

            let layer = AVCaptureVideoPreviewLayer(session: session)
            layer.videoGravity = .resizeAspectFill
            layer.cornerRadius = cornerRadius
            layer.masksToBounds = true
            layer.frame = bounds
            CameraMirror.apply(to: layer.connection)
            self.layer?.addSublayer(layer)
            preview = layer
        }

        override func layout() {
            super.layout()
            preview?.frame = bounds
        }

        // Purely a viewport; it must never take the mouse.
        override func hitTest(_ point: NSPoint) -> NSView? { nil }
    }
}

/// One place that decides which way round the camera faces.
///
/// Applied to the preview layer's connection *and* to the recorder's video data
/// output, so what you check before recording is what ends up in the file. If
/// only the preview were mirrored, every take would come out reversed from what
/// you rehearsed.
enum CameraMirror {
    /// Mirrored, as a front-facing camera should be: move right, your image
    /// moves right. Unmirrored front-camera video reads as wrong to everyone
    /// except the person who has never seen themselves in a mirror.
    static let isMirrored = true

    static func apply(to connection: AVCaptureConnection?) {
        guard let connection, connection.isVideoMirroringSupported else { return }
        connection.automaticallyAdjustsVideoMirroring = false
        connection.isVideoMirrored = isMirrored
    }
}
