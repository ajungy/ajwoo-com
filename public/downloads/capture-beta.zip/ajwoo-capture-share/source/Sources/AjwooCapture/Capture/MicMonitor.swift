import Foundation
import AVFoundation
import CoreMedia

/// Listens to the microphone while **not** recording, purely to drive the level
/// meter.
///
/// Without this the meter only comes alive once you hit record, which is exactly
/// backwards: the moment you want to know the mic works is *before* the take,
/// not after you've narrated two minutes into a muted input.
///
/// Nothing is written to disk. The session is torn down before a real recording
/// starts so `CameraMicRecorder` has the device to itself.
final class MicMonitor: NSObject, AVCaptureAudioDataOutputSampleBufferDelegate {

    private let captureSession = AVCaptureSession()
    private let queue = DispatchQueue(label: "com.ajwoo.capture.mic-monitor", qos: .utility)
    private let lock = NSLock()
    private var _level: Float = 0
    private var currentDeviceID: String?

    var level: Float {
        lock.lock(); defer { lock.unlock() }
        return _level
    }

    var isRunning: Bool { captureSession.isRunning }

    /// Starts (or switches) monitoring. A no-op if already on this device.
    func start(deviceID: String) async {
        if captureSession.isRunning, currentDeviceID == deviceID { return }
        stop()

        // Never trigger the permission prompt from here — the meter is passive,
        // and a dialog appearing because you opened the app would be rude. If
        // access hasn't been granted yet, the meter just stays quiet until the
        // first real recording asks properly.
        guard AVCaptureDevice.authorizationStatus(for: .audio) == .authorized,
              let device = AVCaptureDevice(uniqueID: deviceID),
              let input = try? AVCaptureDeviceInput(device: device)
        else { return }

        captureSession.beginConfiguration()
        guard captureSession.canAddInput(input) else {
            captureSession.commitConfiguration()
            return
        }
        captureSession.addInput(input)

        let output = AVCaptureAudioDataOutput()
        output.setSampleBufferDelegate(self, queue: queue)
        if captureSession.canAddOutput(output) { captureSession.addOutput(output) }
        captureSession.commitConfiguration()

        currentDeviceID = deviceID
        // startRunning blocks; keep it off the main thread so the UI doesn't
        // hitch when you pick a device.
        await withCheckedContinuation { (continuation: CheckedContinuation<Void, Never>) in
            queue.async { [captureSession] in
                captureSession.startRunning()
                continuation.resume()
            }
        }
    }

    func stop() {
        if captureSession.isRunning { captureSession.stopRunning() }
        captureSession.inputs.forEach(captureSession.removeInput)
        captureSession.outputs.forEach(captureSession.removeOutput)
        currentDeviceID = nil
        lock.lock(); _level = 0; lock.unlock()
    }

    func captureOutput(_ output: AVCaptureOutput,
                       didOutput sampleBuffer: CMSampleBuffer,
                       from connection: AVCaptureConnection) {
        guard let peak = AudioPeak.peak(of: sampleBuffer) else { return }
        lock.lock()
        _level = AudioPeak.smooth(previous: _level, peak: peak)
        lock.unlock()
    }
}

/// Peak extraction shared by the monitor and the recorder, so the meter reads
/// identically before and during a take.
enum AudioPeak {

    /// Rough peak amplitude of a PCM buffer, 0...1.
    ///
    /// `AVCaptureAudioDataOutput` hands back the device's native format, so this
    /// reads whichever of the two common layouts it is rather than dragging in a
    /// format converter for what is only ever a meter.
    static func peak(of sampleBuffer: CMSampleBuffer) -> Float? {
        guard let blockBuffer = CMSampleBufferGetDataBuffer(sampleBuffer) else { return nil }
        var length = 0
        var pointer: UnsafeMutablePointer<Int8>?
        guard CMBlockBufferGetDataPointer(blockBuffer, atOffset: 0, lengthAtOffsetOut: nil,
                                          totalLengthOut: &length, dataPointerOut: &pointer) == noErr,
              let raw = pointer, length > 0,
              let format = CMSampleBufferGetFormatDescription(sampleBuffer),
              let asbd = CMAudioFormatDescriptionGetStreamBasicDescription(format)?.pointee
        else { return nil }

        var peak: Float = 0
        if asbd.mFormatFlags & kAudioFormatFlagIsFloat != 0 {
            let count = length / MemoryLayout<Float>.size
            raw.withMemoryRebound(to: Float.self, capacity: count) { samples in
                for i in stride(from: 0, to: count, by: 4) { peak = max(peak, abs(samples[i])) }
            }
        } else {
            let count = length / MemoryLayout<Int16>.size
            raw.withMemoryRebound(to: Int16.self, capacity: count) { samples in
                for i in stride(from: 0, to: count, by: 4) {
                    peak = max(peak, abs(Float(samples[i]) / 32768))
                }
            }
        }
        return peak
    }

    /// Fast attack, slow release. A meter that snaps back to zero between
    /// syllables reads as "not working".
    static func smooth(previous: Float, peak: Float) -> Float {
        peak > previous ? peak : previous * 0.82
    }
}
