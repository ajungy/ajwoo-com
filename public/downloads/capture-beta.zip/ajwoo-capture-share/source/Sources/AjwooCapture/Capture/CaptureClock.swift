import Foundation
import CoreMedia
import QuartzCore

/// The single clock everything in a recording is measured against.
///
/// # Why this matters
/// Screen video, system audio, the webcam, the microphone and the cursor log all
/// arrive through different APIs. If any one of them is timestamped against a
/// different clock, it drifts — slowly, and invisibly until you watch a 10-minute
/// recording and the click sound lands half a second after the click.
///
/// # The clock
/// Everything uses the **mach absolute time base**, i.e. seconds since boot,
/// not counting time asleep. Four APIs, one clock:
///
/// | Source | API | Base |
/// |---|---|---|
/// | ScreenCaptureKit video/audio | `CMSampleBuffer.presentationTimeStamp` | `CMClockGetHostTimeClock()` |
/// | AVCaptureSession (camera/mic) | `CMSampleBuffer.presentationTimeStamp` | host time clock (macOS default) |
/// | Cursor polling | `CACurrentMediaTime()` | mach absolute time |
/// | Mouse clicks | `NSEvent.timestamp` | seconds since startup = mach absolute time |
///
/// All four are the same number line. `CaptureClock.now()` returns a reading on
/// it, and every timestamp written to disk is `reading - t0`, where `t0` is the
/// presentation timestamp of the **first screen video frame actually written**.
///
/// That choice of origin means `screen.mov` starts at exactly 0 by definition,
/// and everything else is expressed relative to the picture — which is the thing
/// you're looking at when you judge whether the sync is right.
enum CaptureClock {
    static let name = "machAbsoluteTime"

    /// Current reading, in seconds.
    static func now() -> Double {
        CACurrentMediaTime()
    }

    /// Same reading as a `CMTime` on the host time clock, for AVFoundation.
    static func nowCMTime() -> CMTime {
        CMClockGetTime(CMClockGetHostTimeClock())
    }

    static func seconds(_ time: CMTime) -> Double {
        CMTimeGetSeconds(time)
    }
}
