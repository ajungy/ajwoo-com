import Foundation
import AVFoundation
import ImageIO
import UniformTypeIdentifiers
import CoreGraphics

/// Animated GIF via ImageIO's own encoder — no third-party GIF library, which
/// keeps the dependency list at zero and the licence story clean.
///
/// Frames come from `AVAssetImageGenerator` pointed at the same video
/// composition as the movie export, so a GIF gets the same zooms and the same
/// rendered cursor.
enum GIFExporter {

    /// GIF is a bad container for anything long: 256 colours, no inter-frame
    /// motion compensation. Past half a minute the file is enormous and an MP4
    /// would be better in every way, so the UI refuses beyond this.
    static let maximumDuration: Double = 30
    static let frameRate: Double = 15
    static let maximumWidth: CGFloat = 800

    enum GIFError: LocalizedError {
        case tooLong(Double)
        case cannotCreateDestination
        case noFrames
        case cancelled

        var errorDescription: String? {
            switch self {
            case .tooLong(let seconds):
                return String(format: "GIF export is limited to %.0f seconds; this range is %.1fs. Trim it first.",
                              maximumDuration, seconds)
            case .cannotCreateDestination: return "Couldn't make the GIF."
            case .noFrames:                return "There was nothing to export."
            case .cancelled:               return "Export cancelled."
            }
        }
    }

    static func export(session: RecordingSession,
                       context: RenderContext,
                       to url: URL,
                       token: ExportCancellationToken,
                       progress: @escaping @Sendable (Double) -> Void) async throws {

        let project = context.project
        // Cuts shrink the output, so the GIF's length — and the 30 s limit — are
        // measured against the composition, not the recording.
        let map = TimeMap(cuts: project.cuts, duration: context.duration)
        let start = map.compositionTime(forRecording: max(0, project.trimStart))
        let end = map.compositionTime(forRecording: min(context.duration, project.trimEnd ?? context.duration))
        let span = end - start
        guard span > 0 else { throw GIFError.noFrames }
        guard span <= maximumDuration else { throw GIFError.tooLong(span) }

        // Render size: cap the width, keep the canvas aspect — which follows
        // the background section's chosen ratio, not just the crop.
        let sourceSize = context.canvasSize
        let scale = min(1, maximumWidth / max(1, sourceSize.width))
        let renderSize = CGSize(width: CGFloat(Int(sourceSize.width * scale) & ~1),
                                height: CGFloat(Int(sourceSize.height * scale) & ~1))

        let composition = try await CompositionBuilder.build(
            session: session,
            context: context,
            renderSize: renderSize,
            frameRate: Int(frameRate)
        )

        let generator = AVAssetImageGenerator(asset: composition.composition)
        generator.videoComposition = composition.videoComposition
        generator.appliesPreferredTrackTransform = false
        generator.requestedTimeToleranceBefore = .zero
        generator.requestedTimeToleranceAfter = .zero
        generator.maximumSize = renderSize

        let frameCount = max(1, Int(span * frameRate))
        try? FileManager.default.removeItem(at: url)

        guard let destination = CGImageDestinationCreateWithURL(
            url as CFURL, UTType.gif.identifier as CFString, frameCount, nil
        ) else { throw GIFError.cannotCreateDestination }

        CGImageDestinationSetProperties(destination, [
            kCGImagePropertyGIFDictionary: [kCGImagePropertyGIFLoopCount: 0],
        ] as CFDictionary)

        let frameProperties = [
            kCGImagePropertyGIFDictionary: [kCGImagePropertyGIFDelayTime: 1.0 / frameRate],
        ] as CFDictionary

        var written = 0
        for index in 0..<frameCount {
            if token.isCancelled {
                try? FileManager.default.removeItem(at: url)
                throw GIFError.cancelled
            }
            let time = CMTime(seconds: start + Double(index) / frameRate, preferredTimescale: 600)
            guard let image = try? await generator.image(at: time).image else { continue }
            CGImageDestinationAddImage(destination, image, frameProperties)
            written += 1
            progress(Double(index + 1) / Double(frameCount))
        }

        guard written > 0, CGImageDestinationFinalize(destination) else {
            try? FileManager.default.removeItem(at: url)
            throw GIFError.noFrames
        }
        progress(1)
    }
}
