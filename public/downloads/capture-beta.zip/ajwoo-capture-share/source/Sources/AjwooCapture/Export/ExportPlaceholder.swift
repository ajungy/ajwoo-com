// Phase 7 lives here: AVAssetWriter export through the shared compositing
// pipeline, the audio mix, the camera overlay, and GIF output via
// CGImageDestination.
