import Foundation
import AVFoundation
import CoreMedia

/// Renders a `.ajwoocapture` package to a finished movie.
///
/// Video goes through `AVAssetReaderVideoCompositionOutput` driving the **same**
/// `AVVideoComposition` and therefore the same `FrameRenderer` the preview uses.
/// There is no export-only drawing code, so "the export doesn't match the
/// preview" isn't a class of bug that exists here.
///
/// Audio is mixed by `AVAssetReaderAudioMixOutput` from the separate system and
/// mic tracks — which is the payoff for keeping them apart at capture time.
enum VideoExporter {

    enum ExportError: LocalizedError {
        case cancelled
        case readerFailed(String)
        case writerFailed(String)
        case nothingToExport

        var errorDescription: String? {
            switch self {
            case .cancelled:            return "Export cancelled."
            case .readerFailed(let s):  return "Couldn't read this recording."
            case .writerFailed(let s):  return "Couldn't save the video."
            case .nothingToExport:      return "The trimmed range is empty."
            }
        }
    }

    struct Result {
        let url: URL
        let outputSize: CGSize
        let frameRate: Int
        let upscaleClamped: Bool
    }

    static func export(session: RecordingSession,
                       context: RenderContext,
                       settings: ExportSettings,
                       to url: URL,
                       token: ExportCancellationToken,
                       progress: @escaping @Sendable (Double) -> Void) async throws -> Result {

        let project = context.project
        // `canvasSize`, not `effectiveSourceSize`: the background section can
        // fix the exported frame to a different aspect ratio than the crop
        // itself, and the resolution preset below has to scale *that* shape.
        let (outputSize, upscaleClamped) = settings.outputSize(sourceSize: context.canvasSize)
        let frameRate = settings.frameRate(sourceFrameRate: context.frameRate)

        let composition = try await CompositionBuilder.build(
            session: session,
            context: context,
            renderSize: outputSize,
            frameRate: frameRate
        )

        // Trim bounds the read rather than shifting anything. The handles are in
        // recording time, so they go through the time map — with cuts present,
        // trimEnd at 0:30 of a recording is not 0:30 of the composition.
        let map = composition.timeMap
        let recordingEnd = project.trimEnd ?? map.recordingDuration
        let start = CMTime(seconds: map.compositionTime(forRecording: max(0, project.trimStart)),
                           preferredTimescale: 600)
        let end = CMTime(seconds: map.compositionTime(forRecording: min(map.recordingDuration, recordingEnd)),
                         preferredTimescale: 600)
        guard end > start else { throw ExportError.nothingToExport }
        let timeRange = CMTimeRange(start: start, end: end)
        let totalSeconds = timeRange.duration.seconds

        // --- reader ---
        let reader = try AVAssetReader(asset: composition.composition)
        reader.timeRange = timeRange

        let videoTracks = composition.composition.tracks(withMediaType: .video)
        let videoOutput = AVAssetReaderVideoCompositionOutput(videoTracks: videoTracks, videoSettings: [
            kCVPixelBufferPixelFormatTypeKey as String: kCVPixelFormatType_32BGRA,
        ])
        videoOutput.videoComposition = composition.videoComposition
        videoOutput.alwaysCopiesSampleData = false
        guard reader.canAdd(videoOutput) else { throw ExportError.readerFailed("video output rejected") }
        reader.add(videoOutput)

        let audioTracks = composition.composition.tracks(withMediaType: .audio)
        var audioOutput: AVAssetReaderAudioMixOutput?
        if !audioTracks.isEmpty {
            let output = AVAssetReaderAudioMixOutput(audioTracks: audioTracks, audioSettings: [
                AVFormatIDKey: kAudioFormatLinearPCM,
                AVSampleRateKey: 48_000,
                AVNumberOfChannelsKey: 2,
                AVLinearPCMBitDepthKey: 32,
                AVLinearPCMIsFloatKey: true,
                AVLinearPCMIsNonInterleaved: false,
                AVLinearPCMIsBigEndianKey: false,
            ])
            // Reuses the mix `CompositionBuilder.build(...)` already made,
            // rather than rebuilding it here — that one was constructed with
            // the mic's noise-gate envelope already loaded (see its own
            // comment), which a second call from here wouldn't have without
            // loading it all over again.
            output.audioMix = composition.audioMix
            if reader.canAdd(output) {
                reader.add(output)
                audioOutput = output
            }
        }

        // --- writer ---
        try? FileManager.default.removeItem(at: url)
        let writer = try AVAssetWriter(outputURL: url, fileType: .mov)

        let videoInput = AVAssetWriterInput(
            mediaType: .video,
            outputSettings: settings.videoOutputSettings(outputSize: outputSize, frameRate: frameRate)
        )
        videoInput.expectsMediaDataInRealTime = false
        guard writer.canAdd(videoInput) else { throw ExportError.writerFailed("video input rejected") }
        writer.add(videoInput)

        var audioInput: AVAssetWriterInput?
        if audioOutput != nil {
            let input = AVAssetWriterInput(mediaType: .audio, outputSettings: settings.audioOutputSettings)
            input.expectsMediaDataInRealTime = false
            if writer.canAdd(input) {
                writer.add(input)
                audioInput = input
            }
        }

        guard writer.startWriting() else {
            throw ExportError.writerFailed(writer.error?.localizedDescription ?? "unknown")
        }
        // Session starts at the trim point, so the output file begins at 0.
        writer.startSession(atSourceTime: timeRange.start)
        guard reader.startReading() else {
            throw ExportError.readerFailed(reader.error?.localizedDescription ?? "unknown")
        }

        let videoQueue = DispatchQueue(label: "com.ajwoo.capture.export.video", qos: .userInitiated)
        let audioQueue = DispatchQueue(label: "com.ajwoo.capture.export.audio", qos: .userInitiated)

        async let videoDone: Void = pump(
            input: videoInput, output: videoOutput, queue: videoQueue, token: token
        ) { pts in
            guard totalSeconds > 0 else { return }
            let elapsed = pts.seconds - timeRange.start.seconds
            progress(min(1, max(0, elapsed / totalSeconds)))
        }

        async let audioDone: Void = {
            guard let audioInput, let audioOutput else { return }
            await pump(input: audioInput, output: audioOutput, queue: audioQueue, token: token, onPTS: nil)
        }()

        _ = await (videoDone, audioDone)

        if token.isCancelled {
            reader.cancelReading()
            writer.cancelWriting()
            try? FileManager.default.removeItem(at: url)
            throw ExportError.cancelled
        }

        if reader.status == .failed {
            writer.cancelWriting()
            try? FileManager.default.removeItem(at: url)
            throw ExportError.readerFailed(reader.error?.localizedDescription ?? "unknown")
        }

        await writer.finishWriting()

        if writer.status == .failed {
            try? FileManager.default.removeItem(at: url)
            throw ExportError.writerFailed(writer.error?.localizedDescription ?? "unknown")
        }

        progress(1)
        return Result(url: url, outputSize: outputSize, frameRate: frameRate, upscaleClamped: upscaleClamped)
    }

    /// Drains one reader output into one writer input.
    ///
    /// `requestMediaDataWhenReady` re-invokes its block whenever the encoder has
    /// room, so the continuation has to be resumed exactly once no matter how
    /// many times the block runs — hence the latch.
    private static func pump(input: AVAssetWriterInput,
                             output: AVAssetReaderOutput,
                             queue: DispatchQueue,
                             token: ExportCancellationToken,
                             onPTS: (@Sendable (CMTime) -> Void)?) async {
        let latch = ResumeLatch()
        await withCheckedContinuation { (continuation: CheckedContinuation<Void, Never>) in
            input.requestMediaDataWhenReady(on: queue) {
                while input.isReadyForMoreMediaData {
                    if token.isCancelled {
                        input.markAsFinished()
                        latch.resume(continuation)
                        return
                    }
                    guard let sample = output.copyNextSampleBuffer() else {
                        input.markAsFinished()
                        latch.resume(continuation)
                        return
                    }
                    onPTS?(CMSampleBufferGetPresentationTimeStamp(sample))
                    if !input.append(sample) {
                        input.markAsFinished()
                        latch.resume(continuation)
                        return
                    }
                }
            }
        }
    }

    private final class ResumeLatch: @unchecked Sendable {
        private let lock = NSLock()
        private var resumed = false

        func resume(_ continuation: CheckedContinuation<Void, Never>) {
            lock.lock()
            let shouldResume = !resumed
            resumed = true
            lock.unlock()
            if shouldResume { continuation.resume() }
        }
    }
}
