import Foundation
import AVFoundation
import VideoToolbox
import CoreGraphics

struct ExportSettings: Equatable {

    enum Preset: String, CaseIterable, Identifiable {
        case p1080, p1440, p4k, original
        var id: String { rawValue }
        var label: String {
            switch self {
            case .p1080:    return "1080p"
            case .p1440:    return "1440p"
            case .p4k:      return "4K"
            case .original: return "Original"
            }
        }
        /// Target height. `nil` means "whatever the source is".
        var height: CGFloat? {
            switch self {
            case .p1080:    return 1080
            case .p1440:    return 1440
            case .p4k:      return 2160
            case .original: return nil
            }
        }
    }

    enum Codec: String, CaseIterable, Identifiable {
        case hevc, h264
        var id: String { rawValue }
        var label: String { self == .hevc ? "HEVC" : "H.264" }
        var avCodec: AVVideoCodecType { self == .hevc ? .hevc : .h264 }
    }

    enum FrameRateMode: String, CaseIterable, Identifiable {
        case matchSource, thirty
        var id: String { rawValue }
        var label: String { self == .matchSource ? "Match source" : "30 fps" }
    }

    /// How hard to squeeze. Screen content is unusually compressible — long
    /// static stretches, then bursts of motion — so the gap between these is
    /// bigger than it would be for camera footage.
    enum Quality: String, CaseIterable, Identifiable {
        case high, balanced, small
        var id: String { rawValue }
        var label: String {
            switch self {
            case .high:     return "High"
            case .balanced: return "Balanced"
            case .small:    return "Small"
            }
        }
        /// Bits per pixel per frame.
        var bitsPerPixel: Double {
            switch self {
            case .high:     return 0.35
            case .balanced: return 0.16
            case .small:    return 0.08
            }
        }
        var floor: Int {
            switch self {
            case .high:     return 12_000_000
            case .balanced: return 6_000_000
            case .small:    return 3_000_000
            }
        }
        var ceiling: Int {
            switch self {
            case .high:     return 130_000_000
            case .balanced: return 60_000_000
            case .small:    return 30_000_000
            }
        }
        var audioBitrate: Int {
            switch self {
            case .high:     return 256_000
            case .balanced: return 160_000
            case .small:    return 96_000
            }
        }
    }

    var preset: Preset = .p1080
    var codec: Codec = .hevc
    var frameRateMode: FrameRateMode = .matchSource
    var quality: Quality = .balanced

    func frameRate(sourceFrameRate: Int) -> Int {
        switch frameRateMode {
        case .matchSource: return max(1, sourceFrameRate)
        case .thirty:      return 30
        }
    }

    /// Output size for a given source.
    ///
    /// Two rules, both from the quality bar:
    ///
    /// - **Width follows the source aspect ratio.** "1080p" means 1080 tall at
    ///   whatever shape the display was. Forcing 16:9 would mean either a silent
    ///   crop or black bars, and neither is something the app should decide.
    /// - **Never upscale.** Asking for 4K from a 1080p capture clamps to the
    ///   source size; `upscaleClamped` reports it so the UI can say so.
    func outputSize(sourceSize: CGSize) -> (size: CGSize, upscaleClamped: Bool) {
        guard sourceSize.width > 0, sourceSize.height > 0 else {
            return (CGSize(width: 1920, height: 1080), false)
        }
        guard let targetHeight = preset.height else {
            return (Self.even(sourceSize), false)
        }

        let clamped = min(targetHeight, sourceSize.height)
        let wasClamped = targetHeight > sourceSize.height + 1
        let aspect = sourceSize.width / sourceSize.height
        return (Self.even(CGSize(width: clamped * aspect, height: clamped)), wasClamped)
    }

    private static func even(_ size: CGSize) -> CGSize {
        CGSize(width: CGFloat(max(2, Int(size.width.rounded()) & ~1)),
               height: CGFloat(max(2, Int(size.height.rounded()) & ~1)))
    }

    /// Balanced gives ~20 Mbps at 1080p60; High ~44; Small ~10.
    ///
    /// Even Small sits above a typical streaming ladder, because screen content
    /// has hard edges and fine text that low bitrates smear into mush.
    func bitrate(outputSize: CGSize, frameRate: Int) -> Int {
        let raw = Double(outputSize.width * outputSize.height) * Double(frameRate) * quality.bitsPerPixel
        return min(quality.ceiling, max(quality.floor, Int(raw)))
    }

    /// Estimated finished size in bytes.
    ///
    /// Video is rate-controlled to roughly the target average, so bitrate × time
    /// is a fair estimate; HEVC tends to land a little under on screen content,
    /// which is why this is presented as an approximation and not a promise.
    func estimatedBytes(outputSize: CGSize, frameRate: Int, seconds: Double, hasAudio: Bool) -> Int64 {
        let video = Double(bitrate(outputSize: outputSize, frameRate: frameRate))
        let audio = hasAudio ? Double(quality.audioBitrate) : 0
        return Int64((video + audio) * max(0, seconds) / 8)
    }

    func videoOutputSettings(outputSize: CGSize, frameRate: Int) -> [String: Any] {
        var compression: [String: Any] = [
            AVVideoAverageBitRateKey: bitrate(outputSize: outputSize, frameRate: frameRate),
            AVVideoExpectedSourceFrameRateKey: frameRate,
            AVVideoMaxKeyFrameIntervalKey: frameRate * 2,
            AVVideoAllowFrameReorderingKey: false,
        ]
        switch codec {
        case .hevc: compression[AVVideoProfileLevelKey] = kVTProfileLevel_HEVC_Main_AutoLevel
        case .h264: compression[AVVideoProfileLevelKey] = AVVideoProfileLevelH264HighAutoLevel
        }

        return [
            AVVideoCodecKey: codec.avCodec,
            AVVideoWidthKey: Int(outputSize.width),
            AVVideoHeightKey: Int(outputSize.height),
            AVVideoCompressionPropertiesKey: compression,
            AVVideoColorPropertiesKey: [
                AVVideoColorPrimariesKey: AVVideoColorPrimaries_ITU_R_709_2,
                AVVideoTransferFunctionKey: AVVideoTransferFunction_ITU_R_709_2,
                AVVideoYCbCrMatrixKey: AVVideoYCbCrMatrix_ITU_R_709_2,
            ],
        ]
    }

    var audioOutputSettings: [String: Any] {
        [
            AVFormatIDKey: kAudioFormatMPEG4AAC,
            AVSampleRateKey: 48_000,
            AVNumberOfChannelsKey: 2,
            AVEncoderBitRateKey: quality.audioBitrate,
        ]
    }
}

/// Cooperative cancellation shared with the background export queues.
final class ExportCancellationToken: @unchecked Sendable {
    private let lock = NSLock()
    private var cancelled = false

    var isCancelled: Bool {
        lock.lock(); defer { lock.unlock() }
        return cancelled
    }

    func cancel() {
        lock.lock(); cancelled = true; lock.unlock()
    }
}
