# GTM Status — ajwoo capture

> Tracker for the `gtm-launch-guard` skill. Commit this file.

**Last audited:** 2026-09-04 · **By:** Claude (gtm-launch-guard) · **Current gate:** 2→3 in progress
**Tier:** T2 — indie commercial (taking money, worldwide consumer users, but unusually little personal data — see Profile)

---

## Profile

| | |
|---|---|
| **Legal seller** | **GG Creative Studios, LLC** — confirmed via the installed Developer ID Application certificate (Team ID ZN8PX654HF). State of formation and EIN still not recorded here [DECISION: fill in]. |
| **Delivery channels** | Downloadable macOS app (direct download, outside the Mac App Store) |
| **Monetization** | One-time purchase, via Gumroad [DECISION: confirm] |
| **Users** | Consumer, worldwide (friends + public buyers) |
| **Markets** | US-focused for now, short-term; not actively restricting checkout, just not marketing outside the US yet — reassess before actively expanding |
| **Personal data held** | **None, by the app itself.** Verified in code: zero `URLSession`/network calls anywhere, zero analytics/telemetry SDKs, on-device-only speech transcription (`requiresOnDeviceRecognition = true`). The only personal data in the whole picture is what a payment processor collects at checkout (email, card) — the processor is the controller for that, not this app. |
| **Who wrote the code** | Solo (Alex) + AI assistant (Claude). No contractors, no OSS contributions merged in. |
| **AI features** | Calls Apple's on-device `SFSpeechRecognizer`/`SpeechAnalyzer` for transcription and subtitles. First-party, on-device, no network call, no separate vendor terms to flow down. |
| **Payment rail** | Gumroad (Merchant of Record) recommended and assumed in the current document drafts [DECISION: confirm this is what's actually set up] |
| **Code signing** | **Resolved.** `Developer ID Application: GG Creative Studios, LLC (ZN8PX654HF)` is installed and verified (`security find-identity`). `scripts/make_app.sh` signs with the hardened runtime + a real timestamp whenever this identity is used. |
| **Notarization** | **Not yet set up on this machine.** No `notarytool` keychain profile found. Without it, Gatekeeper will still block a Developer-ID-signed build outright (this has been mandatory since macOS 10.15, not just a stronger warning) — see Blocking findings. |
| **Launch date** | None set |

---

## Gate status

| Gate | Name | Status | Notes |
|---|---|---|---|
| 0 | Name & Own | 🟡 in progress | "ajwoo" is an existing house brand across other projects (ajwoo-canvas, ajwoo-draw, ajwoo-narrate, ajwoo-dictate, www.ajwoo.com) — marginal new risk for "ajwoo capture" specifically is low, but no formal trademark search has been run. Copyright registration not yet filed. |
| 1 | Build Clean | ✅ (continuous) | Zero external dependencies — entire app is Apple frameworks only. Nothing to license-audit. |
| 2 | Paper | 🟡 in progress | EULA, Privacy Policy, and a new Refund Policy drafted — see `EULA.md` / `PRIVACY.md` / `REFUND-POLICY.md`. EULA now includes indemnification and a draft arbitration/class-action-waiver clause. None reviewed by counsel. |
| 3 | Harden | 🟡 in progress | Developer ID certificate installed and wired into the build script. Notarization credentials not yet set up — this is the one remaining piece of Gate 3. |
| 4 | Launch & Run | ⬜ not started | |

---

## Open findings

### Blocking — do not launch
- [ ] **Not notarized.** A Developer-ID-signed app that isn't notarized is *still* blocked by Gatekeeper by default (a different, less alarming dialog than "unidentified developer," but still a hard block until the recipient goes into System Settings and clicks "Open Anyway"). Run `xcrun notarytool store-credentials` once (needs an app-specific Apple ID password — see the project's own notes on this), then build with `AJWOO_NOTARY_PROFILE` set. Until then, every recipient still needs the same manual override the ad-hoc/self-signed builds needed. — *owner: Alex*
- [ ] **No EULA, Privacy Policy, or Refund Policy published anywhere a buyer can see them at checkout** — drafts exist in this repo (`EULA.md`, `PRIVACY.md`, `REFUND-POLICY.md`) but need to be hosted at a public URL and linked from Gumroad's checkout page — *owner: Alex*
- [ ] **Payment rail not confirmed set up** — the documents above assume Gumroad; if that's not actually live yet, nothing can be sold regardless of how ready the paperwork is — *owner: Alex*

### Serious — fix before scale
- [ ] **No formal trademark search on "ajwoo capture"** — low marginal risk given the existing "ajwoo" house brand, but not zero — run a USPTO/TESS search (or a $200–400 professional clearance search) before spending real money on marketing or a domain — *revisit before any paid ads or press*
- [ ] **Copyright registration not filed** — register with the US Copyright Office within 3 months of first public distribution to preserve statutory damages and attorney's fees eligibility — *due: within 3 months of first sale/download*
- [ ] **EULA's arbitration clause is a placeholder, not final language** — §9 marks exactly this; it's real risk-reduction once drafted correctly and real risk if relied on as-is against an actual dispute. Same for the indemnification clause in §7, though that one is closer to boilerplate that generally holds up.
- [ ] **State of LLC formation still blank** — needed to fill the governing-law clause in the EULA and the "who we are" line in the Privacy Policy; without it those two documents have a real gap in them, not just an unconfirmed detail.

### Watch — revisit next gate
- [ ] EU Cyber Resilience Act vulnerability-reporting obligations start 11 Sept 2026 — applies to downloadable software. Revisit scope/microenterprise exceptions closer to that date.
- [ ] If subscriptions are ever added instead of one-time purchase, the auto-renewal disclosure checklist in `09-money-tax-export.md` applies in full — currently N/A for a one-time purchase.
- [ ] If a future version adds any network call (crash reporting, update checks, license validation pinging a server), the "zero data collection" privacy story changes and the policy must be rewritten before that ships, not after.
- [ ] **EU/UK/Australia consumer rights (14-day withdrawal, non-excludable warranties)** — downgraded from Serious since distribution is US-focused short-term and Gumroad screens/handles most of this by default regardless. Re-promote to Serious the moment marketing actively targets international buyers. `REFUND-POLICY.md` already matches the EU 14-day window unconditionally, which reduces this further.
- [ ] **US state sales tax on digital goods** — Gumroad, as Merchant of Record, is the one registering and remitting this in every US state, not you. If you ever move to direct Stripe, this becomes your own economic-nexus problem — one more reason MoR stays the right call even fee-indifferent.

### Get a lawyer for
- Confirming the LLC's state of formation and whether GG Creative Studios, LLC is the right entity to sell this specific product under (vs. forming a new one) — has the facts a business attorney needs: existing entity's formation state, existing business lines, whether this product's liability profile should be isolated from the others.
- **The arbitration/class-action-waiver clause in `EULA.md` §9** — this is the single highest-priority item on this list for actually reducing legal exposure once real money is changing hands. Drafted wrong, it can be struck entirely and give you nothing.
- A paid review of the EULA's liability cap and indemnification clause once real revenue starts — template language is a reasonable T2 starting point, not a substitute.

---

## Accepted risks

| Date | Risk | Why accepted | Accepted by | Revisit |
|---|---|---|---|---|
| 2026-09-04 | Shipping without notarization set up yet | Getting the certificate itself installed first; notarization credentials are the very next step, not skipped indefinitely | Alex | Before any build leaves this Mac for a stranger (friends who already know it's unsigned/beta are lower-stakes) |

---

## Key facts and dates

| Item | Value |
|---|---|
| First publication date | *(not yet)* |
| **Copyright registration deadline** (publication + 3 months) | *(set once first-publication date is known)* |
| Copyright registration filed | ☐ |
| Trademark search completed | ☐ |
| Entity formed / EIN | GG Creative Studios, LLC — state of formation and EIN not yet recorded here |
| Developer ID certificate | ✅ installed — Team ID ZN8PX654HF |
| Notarization credentials configured | ☐ |
| Export self-classification filed | ☐ — likely N/A/routine (mass-market, no custom crypto; see finding below) |
| ToS version live | N/A — no hosted service, EULA covers the licensed-software relationship |
| Privacy policy version live | draft v0.2, not yet published |
| EULA version live | draft v0.2, not yet published |
| Refund policy version live | draft v0.1, not yet published |

---

## Third-party inventory

| Item | Type | License | Commercial OK | Redistribution OK | Notes |
|---|---|---|---|---|---|
| *(none)* | — | — | — | — | Zero external dependencies confirmed in `Package.swift` and by source scan |

**Stop-and-raise licenses present:** none

---

## Data map summary

| Data | Category | Purpose | Lawful basis | Retention | Deletion path |
|---|---|---|---|---|---|
| *(none collected by the app)* | — | — | — | — | — |
| Email + payment details, at checkout only | Payment | Process the purchase | Contract | Per processor's policy | Processor's own deletion path |

**Third parties receiving personal data:** Gumroad only, assuming that's the confirmed Merchant of Record [DECISION: confirm]. No other subprocessor.

---

## Documents

| Document | Status | Version | Reviewed by counsel? | URL |
|---|---|---|---|---|
| Terms of Service | N/A | — | — | not needed — no hosted service |
| EULA | 🟡 draft, strengthened for commercial sale | v0.2 | ☐ | not yet published |
| Privacy Policy | 🟡 draft | v0.2 | ☐ | not yet published |
| Refund / cancellation policy | 🟡 draft | v0.1 | ☐ | not yet published — see `REFUND-POLICY.md` |
| SECURITY.md | ⬜ | — | ☐ | low priority at this scale, add before any public vulnerability report arrives |

---

## Audit log

| Date | Gate | Auditor | Summary |
|---|---|---|---|
| 2026-08-23 | 0–2 | Claude (gtm-launch-guard) | Initial intake + audit. Verified zero dependencies and zero network calls by source scan. Identified signing/notarization as the sole launch blocker. Drafted EULA and Privacy Policy. |
| 2026-09-04 | 2–3 | Claude (gtm-launch-guard) | Found a Developer ID Application certificate already installed (GG Creative Studios, LLC / ZN8PX654HF) — Gate 3's signing half is done. Updated `scripts/make_app.sh` to use hardened runtime + notarization automatically for that identity. Strengthened `EULA.md` with indemnification and a draft arbitration/class-action-waiver clause (both flagged for counsel review), filled in the confirmed entity name across `EULA.md`/`PRIVACY.md`, and added `REFUND-POLICY.md`. Notarization credentials remain the one open item before a build can be shared without a manual Gatekeeper override. |
