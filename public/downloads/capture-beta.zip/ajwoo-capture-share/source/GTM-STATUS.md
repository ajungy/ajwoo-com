# GTM Status — ajwoo capture

> Tracker for the `gtm-launch-guard` skill. Commit this file.

**Last audited:** 2026-08-23 · **By:** Claude (gtm-launch-guard) · **Current gate:** 0→2 in progress
**Tier:** T2 — indie commercial (taking money, worldwide consumer users, but unusually little personal data — see Profile)

---

## Profile

| | |
|---|---|
| **Legal seller** | LLC/corp confirmed to exist — **name, state, EIN not yet recorded here** [DECISION: fill in] |
| **Delivery channels** | Downloadable macOS app (direct download, outside the Mac App Store) |
| **Monetization** | Not yet chosen — recommend one-time purchase [DECISION] |
| **Users** | Consumer, worldwide (friends + public buyers) |
| **Markets** | US-focused for now, short-term; not actively restricting checkout, just not marketing outside the US yet — reassess before actively expanding |
| **Personal data held** | **None, by the app itself.** Verified in code: zero `URLSession`/network calls anywhere, zero analytics/telemetry SDKs, on-device-only speech transcription (`requiresOnDeviceRecognition = true`). The only personal data in the whole picture is what a payment processor collects at checkout (email, card) — the processor is the controller for that, not this app. |
| **Who wrote the code** | Solo (Alex) + AI assistant (Claude). No contractors, no OSS contributions merged in. |
| **AI features** | Calls Apple's on-device `SFSpeechRecognizer`/`SpeechAnalyzer` for transcription and subtitles. First-party, on-device, no network call, no separate vendor terms to flow down. |
| **Payment rail** | None yet — **recommend a Merchant of Record** (Gumroad, Lemon Squeezy, or Paddle) — see recommendation below |
| **Launch date** | None set |

---

## Gate status

| Gate | Name | Status | Notes |
|---|---|---|---|
| 0 | Name & Own | 🟡 in progress | "ajwoo" is an existing house brand across other projects (ajwoo-canvas, ajwoo-draw, ajwoo-narrate, ajwoo-dictate, www.ajwoo.com) — marginal new risk for "ajwoo capture" specifically is low, but no formal trademark search has been run. Copyright registration not yet filed. |
| 1 | Build Clean | ✅ (continuous) | Zero external dependencies — entire app is Apple frameworks only. Nothing to license-audit. Verified 2026-08-23. |
| 2 | Paper | 🟡 in progress | EULA and Privacy Policy drafted this session — see `EULA.md` / `PRIVACY.md`. Neither reviewed by counsel. |
| 3 | Harden | ⬜ not started | No code signing beyond local dev cert. No notarization. |
| 4 | Launch & Run | ⬜ not started | |

---

## Open findings

### Blocking — do not launch
- [ ] **App is signed with a local self-signed dev certificate (`Voicekey Local Dev`), not notarized** — Gatekeeper will show "malicious software, can't be opened" for every user except the one machine that trusts that cert — enroll in the Apple Developer Program ($99/yr), get a Developer ID Application certificate, sign with it, and notarize every release build — *owner: Alex / due: before first distribution*
- [ ] **No payment method wired up** — can't collect money yet — set up a Merchant of Record account (recommend Gumroad or Lemon Squeezy for lowest setup effort) — *owner: Alex*
- [ ] **No EULA or Privacy Policy published anywhere a buyer can see them at checkout** — drafts exist in this repo (`EULA.md`, `PRIVACY.md`) but need to be hosted at a public URL and linked from the MoR's checkout page — *owner: Alex*

### Serious — fix before scale
- [ ] **No formal trademark search on "ajwoo capture"** — low marginal risk given the existing "ajwoo" house brand, but not zero — run a USPTO/TESS search (or a $200–400 professional clearance search) before spending real money on marketing or a domain — *revisit before any paid ads or press*
- [ ] **Copyright registration not filed** — register with the US Copyright Office within 3 months of first public distribution to preserve statutory damages and attorney's fees eligibility — *due: within 3 months of first sale/download*
- [ ] **No refund policy published** — even for one-time purchases, publish one; Gumroad provides a default one at checkout — confirm it's enabled and matches what you want to honor

### Watch — revisit next gate
- [ ] EU Cyber Resilience Act vulnerability-reporting obligations start 11 Sept 2026 — applies to downloadable software. Revisit scope/microenterprise exceptions closer to that date.
- [ ] If subscriptions are ever added instead of one-time purchase, the auto-renewal disclosure checklist in `09-money-tax-export.md` applies in full — currently N/A for a one-time purchase.
- [ ] If a future version adds any network call (crash reporting, update checks, license validation pinging a server), the "zero data collection" privacy story changes and the policy must be rewritten before that ships, not after.
- [ ] **EU/UK/Australia consumer rights (14-day withdrawal, non-excludable warranties)** — downgraded from Serious since distribution is US-focused short-term and Gumroad screens/handles most of this by default regardless. Re-promote to Serious the moment marketing actively targets international buyers.
- [ ] **US state sales tax on digital goods** — Gumroad, as Merchant of Record, is the one registering and remitting this in every US state, not you. If you ever move to direct Stripe, this becomes your own economic-nexus problem — one more reason MoR stays the right call even fee-indifferent.

### Get a lawyer for
- Confirming the exact legal name/state of the existing LLC and whether it's the right entity to sell this specific product under (vs. forming a new one) — has the facts a business attorney needs: existing entity's formation state, existing business lines, whether this product's liability profile should be isolated from the others.
- A single paid review of the EULA's liability cap and arbitration clause once real revenue starts — template language is a reasonable T2 starting point, not a substitute.

---

## Accepted risks

| Date | Risk | Why accepted | Accepted by | Revisit |
|---|---|---|---|---|
| | | | | |

---

## Key facts and dates

| Item | Value |
|---|---|
| First publication date | *(not yet)* |
| **Copyright registration deadline** (publication + 3 months) | *(set once first-publication date is known)* |
| Copyright registration filed | ☐ |
| Trademark search completed | ☐ |
| Entity formed / EIN | LLC/corp exists — details not recorded here yet |
| Export self-classification filed | ☐ — likely N/A/routine (mass-market, no custom crypto; see finding below) |
| ToS version live | N/A — no hosted service, EULA covers the licensed-software relationship |
| Privacy policy version live | draft v0.1, not yet published |

---

## Third-party inventory

| Item | Type | License | Commercial OK | Redistribution OK | Notes |
|---|---|---|---|---|---|
| *(none)* | — | — | — | — | Zero external dependencies confirmed in `Package.swift` and by source scan, 2026-08-23 |

**Stop-and-raise licenses present:** none

---

## Data map summary

| Data | Category | Purpose | Lawful basis | Retention | Deletion path |
|---|---|---|---|---|---|
| *(none collected by the app)* | — | — | — | — | — |
| Email + payment details, at checkout only | Payment | Process the purchase | Contract | Per processor's policy | Processor's own deletion path |

**Third parties receiving personal data:** the chosen Merchant of Record only (Gumroad / Lemon Squeezy / Paddle — pick one). No other subprocessor.

---

## Documents

| Document | Status | Version | Reviewed by counsel? | URL |
|---|---|---|---|---|
| Terms of Service | N/A | — | — | not needed — no hosted service |
| EULA | 🟡 draft | v0.1 | ☐ | not yet published |
| Privacy Policy | 🟡 draft | v0.1 | ☐ | not yet published |
| Refund / cancellation policy | ⬜ | — | ☐ | usually provided by the MoR's own checkout terms — confirm coverage |
| SECURITY.md | ⬜ | — | ☐ | low priority at this scale, add before any public vulnerability report arrives |

---

## Audit log

| Date | Gate | Auditor | Summary |
|---|---|---|---|
| 2026-08-23 | 0–2 | Claude (gtm-launch-guard) | Initial intake + audit. Verified zero dependencies and zero network calls by source scan. Identified signing/notarization as the sole launch blocker. Drafted EULA and Privacy Policy. |
