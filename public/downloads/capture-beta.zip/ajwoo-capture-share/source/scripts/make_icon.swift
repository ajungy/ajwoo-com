#!/usr/bin/env swift
//
// Generates Resources/AppIcon.icns.
//
//   ./scripts/make_icon.swift        (or: make icon)
//
// Drawn in code rather than shipped as a binary asset so the mark can be tweaked
// by editing numbers, and so there's nothing in the repo we can't regenerate.
//
// The mark, taken from the Figma source ("ajwoo capture Logo", node 242:5435):
// a dark squircle tile with a subtle top-to-bottom gradient, a white rounded
// square outline, and a white dot in the middle. Every proportion below is the
// Figma value divided by the 840 pt tile, so the drawing is the design rather
// than an approximation of it.

import AppKit
import Foundation

let fileManager = FileManager.default
let root = URL(fileURLWithPath: fileManager.currentDirectoryPath)
let iconset = root.appendingPathComponent("build/AppIcon.iconset")
let output = root.appendingPathComponent("Resources/AppIcon.icns")

// MARK: - Drawing

func drawIcon(size: CGFloat) -> CGImage? {
    let pixels = Int(size)
    guard let ctx = CGContext(
        data: nil, width: pixels, height: pixels,
        bitsPerComponent: 8, bytesPerRow: 0,
        space: CGColorSpace(name: CGColorSpace.sRGB) ?? CGColorSpaceCreateDeviceRGB(),
        bitmapInfo: CGImageAlphaInfo.premultipliedLast.rawValue
    ) else { return nil }

    ctx.setAllowsAntialiasing(true)
    ctx.interpolationQuality = .high
    // Work top-down so the numbers below read like a layout.
    ctx.translateBy(x: 0, y: size)
    ctx.scaleBy(x: 1, y: -1)

    // --- tile ---
    // Near full bleed. The Figma artboard has generous margins around the tile,
    // and reproducing them left a visible empty border — at Finder's 16 px the
    // mark was a small square inside a larger transparent box, which is what
    // makes an icon look shrunken next to its neighbours. macOS icons do carry a
    // margin, but it belongs to the shadow, not to a second inset.
    let inset = size * 0.012
    let tile = CGRect(x: inset, y: inset, width: size - inset * 2, height: size - inset * 2)
    let tileSide = tile.width
    // 237/840 in the source — a little rounder than Apple's 22.37% squircle.
    let tileRadius = tileSide * (237.0 / 840.0)
    let tilePath = CGPath(roundedRect: tile, cornerWidth: tileRadius, cornerHeight: tileRadius,
                          transform: nil)

    // Vertical gradient, #363638 down to #1C1C1E. It's barely visible at 16 px
    // and that's fine — it's there to keep the 512 px version from looking flat.
    ctx.saveGState()
    ctx.addPath(tilePath)
    ctx.clip()
    let space = CGColorSpace(name: CGColorSpace.sRGB)!
    if let gradient = CGGradient(colorsSpace: space, colors: [
        CGColor(srgbRed: 0.2118, green: 0.2118, blue: 0.2196, alpha: 1),
        CGColor(srgbRed: 0.1098, green: 0.1098, blue: 0.1176, alpha: 1),
    ] as CFArray, locations: [0, 1]) {
        ctx.drawLinearGradient(gradient,
                               start: CGPoint(x: 0, y: tile.minY),
                               end: CGPoint(x: 0, y: tile.maxY),
                               options: [])
    }
    ctx.restoreGState()

    // --- rounded square outline ---
    // 500x500 at (171, 183) inside the 840 tile, 100 radius, 46 stroke, drawn
    // inside the box. The mark sits ~12 pt below the tile's centre in the
    // source; that offset is kept — it's an optical centring, not a mistake.
    func scaled(_ value: CGFloat) -> CGFloat { tileSide * value / 840.0 }
    let markCenterY = tile.minY + scaled(432.5)
    let markCenterX = tile.minX + scaled(420.5)

    let squareSide = scaled(500)
    let strokeWidth = max(1, scaled(46))
    let square = CGRect(x: markCenterX - squareSide / 2,
                        y: markCenterY - squareSide / 2,
                        width: squareSide, height: squareSide)
    // Figma strokes this one INSIDE the box, so the path is inset by half the
    // width to put a centred stroke in the same place.
    ctx.addPath(CGPath(roundedRect: square.insetBy(dx: strokeWidth / 2, dy: strokeWidth / 2),
                       cornerWidth: scaled(100) - strokeWidth / 2,
                       cornerHeight: scaled(100) - strokeWidth / 2,
                       transform: nil))
    ctx.setStrokeColor(CGColor(gray: 1, alpha: 1))
    ctx.setLineWidth(strokeWidth)
    ctx.setLineJoin(.round)
    ctx.strokePath()

    // --- record dot ---
    let dotRadius = scaled(100)
    ctx.setFillColor(CGColor(gray: 1, alpha: 1))
    ctx.fillEllipse(in: CGRect(x: markCenterX - dotRadius, y: markCenterY - dotRadius,
                               width: dotRadius * 2, height: dotRadius * 2))

    return ctx.makeImage()
}

// MARK: - Iconset

// Every size macOS asks for. Missing entries make the icon fall back to a
// blurry scale of another size in some places (notably the Dock).
let variants: [(name: String, pixels: CGFloat)] = [
    ("icon_16x16.png", 16),      ("icon_16x16@2x.png", 32),
    ("icon_32x32.png", 32),      ("icon_32x32@2x.png", 64),
    ("icon_128x128.png", 128),   ("icon_128x128@2x.png", 256),
    ("icon_256x256.png", 256),   ("icon_256x256@2x.png", 512),
    ("icon_512x512.png", 512),   ("icon_512x512@2x.png", 1024),
]

try? fileManager.removeItem(at: iconset)
try fileManager.createDirectory(at: iconset, withIntermediateDirectories: true)

for variant in variants {
    guard let image = drawIcon(size: variant.pixels) else {
        FileHandle.standardError.write("failed to draw \(variant.name)\n".data(using: .utf8)!)
        exit(1)
    }
    let rep = NSBitmapImageRep(cgImage: image)
    rep.size = NSSize(width: variant.pixels, height: variant.pixels)
    guard let data = rep.representation(using: .png, properties: [:]) else { exit(1) }
    try data.write(to: iconset.appendingPathComponent(variant.name))
}

try fileManager.createDirectory(at: output.deletingLastPathComponent(), withIntermediateDirectories: true)

let iconutil = Process()
iconutil.executableURL = URL(fileURLWithPath: "/usr/bin/iconutil")
iconutil.arguments = ["-c", "icns", iconset.path, "-o", output.path]
try iconutil.run()
iconutil.waitUntilExit()

guard iconutil.terminationStatus == 0 else {
    FileHandle.standardError.write("iconutil failed\n".data(using: .utf8)!)
    exit(1)
}

try? fileManager.removeItem(at: iconset)
print("wrote \(output.path)")
