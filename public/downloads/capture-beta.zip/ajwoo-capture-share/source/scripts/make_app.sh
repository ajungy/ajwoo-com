#!/bin/bash
# Builds "ajwoo capture" and assembles a signed .app bundle.
#
#   ./scripts/make_app.sh              debug build,   signed with $AJWOO_SIGN_IDENTITY
#   CONFIG=release ./scripts/make_app.sh
#   AJWOO_SIGN_IDENTITY="-" ./scripts/make_app.sh    ad-hoc sign
#
#   # Real release build, for distributing outside this Mac:
#   AJWOO_SIGN_IDENTITY="Developer ID Application: Your Name (TEAMID)" \
#   AJWOO_NOTARY_PROFILE="ajwoo-notary" \
#   CONFIG=release ./scripts/make_app.sh
#
# Why the signing identity matters: macOS ties the Screen Recording grant to the
# app's code signature. Ad-hoc signing produces a new cdhash on every build, so
# macOS treats each build as a different app and re-prompts. Signing with a
# stable self-signed certificate keeps the grant across rebuilds.
#
# A "Developer ID Application" identity additionally triggers notarization
# (when AJWOO_NOTARY_PROFILE is set) — see the one-time setup notes near the
# codesign step below, or NOTES.md.

set -euo pipefail

cd "$(dirname "$0")/.."

# Swift target / binary name (must be a valid identifier) vs. the user-visible
# app name. Everything a person sees says "ajwoo capture".
TARGET_NAME="AjwooCapture"
APP_NAME="ajwoo capture"

# Release by default. A debug Swift build is unoptimised — Core Image
# compositing and the timeline redraw are several times slower — and "the app
# feels laggy" traces back here more often than to any single piece of code.
# Use CONFIG=debug when you actually need to debug.
CONFIG="${CONFIG:-release}"
SIGN_IDENTITY="${AJWOO_SIGN_IDENTITY:-Voicekey Local Dev}"
# The bundle lands at the repo root, not inside build/, so its icon is visible
# the moment you open the folder. build/ keeps only throwaway intermediates.
BUILD_DIR="build"
APP_DIR="${APP_NAME}.app"

echo "==> swift build -c ${CONFIG}"
if [ "${CONFIG}" = "release" ]; then
	# -gnone drops debug info: a smaller binary, and nothing is debugged
	# through a release build anyway.
	swift build -c release -Xswiftc -gnone
else
	swift build -c debug
fi

BIN_PATH="$(swift build -c "${CONFIG}" --show-bin-path)/${TARGET_NAME}"
if [ ! -f "${BIN_PATH}" ]; then
	echo "error: binary not found at ${BIN_PATH}" >&2
	exit 1
fi

if [ ! -f "Resources/AppIcon.icns" ]; then
	echo "==> generating app icon"
	swift scripts/make_icon.swift
fi

echo "==> assembling ${APP_DIR}"
rm -rf "${APP_DIR}"
mkdir -p "${APP_DIR}/Contents/MacOS" "${APP_DIR}/Contents/Resources"

cp "${BIN_PATH}" "${APP_DIR}/Contents/MacOS/${TARGET_NAME}"
if [ "${CONFIG}" = "release" ]; then
	# Local symbols only — the Swift runtime needs the exported ones.
	strip -x "${APP_DIR}/Contents/MacOS/${TARGET_NAME}" 2>/dev/null || true
fi
cp "Resources/Info.plist" "${APP_DIR}/Contents/Info.plist"
cp "Resources/AppIcon.icns" "${APP_DIR}/Contents/Resources/AppIcon.icns"
# Bundled background photos (the "Canyon"/"Skyline"/"Peak" presets). Optional —
# BackgroundImageStore falls back to a flat tint for any preset whose file
# isn't here, so a build with none still works.
if [ -d "Resources/Backgrounds" ]; then
	cp -R "Resources/Backgrounds" "${APP_DIR}/Contents/Resources/Backgrounds"
fi
printf 'APPL????' > "${APP_DIR}/Contents/PkgInfo"

# Bump CFBundleVersion to the current epoch so Launch Services notices changes.
/usr/libexec/PlistBuddy -c "Set :CFBundleVersion $(date +%s)" "${APP_DIR}/Contents/Info.plist" >/dev/null

echo "==> codesign (identity: ${SIGN_IDENTITY})"
# A "Developer ID Application: ..." identity is the one Apple will actually
# notarize — and notarization requires the hardened runtime plus a real
# (not "none") timestamp. Every other identity (the local dev cert, ad-hoc)
# keeps the old flags: notarization isn't in play, and a real timestamp needs
# a network round-trip to Apple's timestamp server for no benefit there.
if [[ "${SIGN_IDENTITY}" == "Developer ID Application"* ]]; then
	CODESIGN_ARGS=(--force --sign "${SIGN_IDENTITY}" --options runtime --timestamp)
else
	CODESIGN_ARGS=(--force --sign "${SIGN_IDENTITY}" --timestamp=none)
fi

if ! codesign "${CODESIGN_ARGS[@]}" "${APP_DIR}" 2>/dev/null; then
	echo "    '${SIGN_IDENTITY}' unavailable — falling back to ad-hoc."
	echo "    Screen Recording permission will likely need re-granting after each build."
	codesign --force --sign - "${APP_DIR}"
fi

codesign --verify --verbose=1 "${APP_DIR}" 2>&1 | sed 's/^/    /'

# --- notarization (Developer ID builds only) ---
#
# Signing with a real Developer ID stops Gatekeeper's "unidentified
# developer" block, but a fresh build is still unknown to Apple until it's
# been notarized — without this step people would see a scarier "Apple could
# not verify this app is free of malware" message instead. Opt in by setting
# AJWOO_NOTARY_PROFILE to a `notarytool store-credentials` profile name; see
# NOTES.md or the project README for the one-time setup.
if [[ "${SIGN_IDENTITY}" == "Developer ID Application"* ]]; then
	if [ -z "${AJWOO_NOTARY_PROFILE:-}" ]; then
		echo "==> skipping notarization: set AJWOO_NOTARY_PROFILE to notarize and staple this build"
	else
		echo "==> zipping for notarization"
		rm -f "${APP_DIR}.zip"
		ditto -c -k --keepParent "${APP_DIR}" "${APP_DIR}.zip"

		echo "==> submitting to Apple for notarization (usually a few minutes)"
		xcrun notarytool submit "${APP_DIR}.zip" --keychain-profile "${AJWOO_NOTARY_PROFILE}" --wait

		echo "==> stapling the notarization ticket"
		xcrun stapler staple "${APP_DIR}"
		rm -f "${APP_DIR}.zip"

		echo "==> verifying Gatekeeper acceptance"
		spctl --assess --type execute --verbose=1 "${APP_DIR}" 2>&1 | sed 's/^/    /'
	fi
fi

echo "==> done: ${APP_DIR}"
echo "    open \"${APP_DIR}\""
