#!/bin/bash
# Builds "ajwoo capture" and assembles a signed .app bundle.
#
#   ./scripts/make_app.sh              debug build,   signed with $AJWOO_SIGN_IDENTITY
#   CONFIG=release ./scripts/make_app.sh
#   AJWOO_SIGN_IDENTITY="-" ./scripts/make_app.sh    ad-hoc sign
#
# Why the signing identity matters: macOS ties the Screen Recording grant to the
# app's code signature. Ad-hoc signing produces a new cdhash on every build, so
# macOS treats each build as a different app and re-prompts. Signing with a
# stable self-signed certificate keeps the grant across rebuilds.

set -euo pipefail

cd "$(dirname "$0")/.."

# Swift target / binary name (must be a valid identifier) vs. the user-visible
# app name. Everything a person sees says "ajwoo capture".
TARGET_NAME="AjwooCapture"
APP_NAME="ajwoo capture"

# Release by default. A debug Swift build is unoptimised — Core Image
# compositing and the timeline redraw are several times slower — and "the app
# feels laggy" traces back here more often than to any single piece of code.
# Use CONFIG=debug when you actually need to debug.
CONFIG="${CONFIG:-release}"
SIGN_IDENTITY="${AJWOO_SIGN_IDENTITY:-Voicekey Local Dev}"
# The bundle lands at the repo root, not inside build/, so its icon is visible
# the moment you open the folder. build/ keeps only throwaway intermediates.
BUILD_DIR="build"
APP_DIR="${APP_NAME}.app"

echo "==> swift build -c ${CONFIG}"
if [ "${CONFIG}" = "release" ]; then
	# -gnone drops debug info: a smaller binary, and nothing is debugged
	# through a release build anyway.
	swift build -c release -Xswiftc -gnone
else
	swift build -c debug
fi

BIN_PATH="$(swift build -c "${CONFIG}" --show-bin-path)/${TARGET_NAME}"
if [ ! -f "${BIN_PATH}" ]; then
	echo "error: binary not found at ${BIN_PATH}" >&2
	exit 1
fi

if [ ! -f "Resources/AppIcon.icns" ]; then
	echo "==> generating app icon"
	swift scripts/make_icon.swift
fi

echo "==> assembling ${APP_DIR}"
rm -rf "${APP_DIR}"
mkdir -p "${APP_DIR}/Contents/MacOS" "${APP_DIR}/Contents/Resources"

cp "${BIN_PATH}" "${APP_DIR}/Contents/MacOS/${TARGET_NAME}"
if [ "${CONFIG}" = "release" ]; then
	# Local symbols only — the Swift runtime needs the exported ones.
	strip -x "${APP_DIR}/Contents/MacOS/${TARGET_NAME}" 2>/dev/null || true
fi
cp "Resources/Info.plist" "${APP_DIR}/Contents/Info.plist"
cp "Resources/AppIcon.icns" "${APP_DIR}/Contents/Resources/AppIcon.icns"
# Bundled background photos (the "Canyon"/"Skyline"/"Peak" presets). Optional —
# BackgroundImageStore falls back to a flat tint for any preset whose file
# isn't here, so a build with none still works.
if [ -d "Resources/Backgrounds" ]; then
	cp -R "Resources/Backgrounds" "${APP_DIR}/Contents/Resources/Backgrounds"
fi
printf 'APPL????' > "${APP_DIR}/Contents/PkgInfo"

# Bump CFBundleVersion to the current epoch so Launch Services notices changes.
/usr/libexec/PlistBuddy -c "Set :CFBundleVersion $(date +%s)" "${APP_DIR}/Contents/Info.plist" >/dev/null

echo "==> codesign (identity: ${SIGN_IDENTITY})"
if ! codesign --force --sign "${SIGN_IDENTITY}" --timestamp=none "${APP_DIR}" 2>/dev/null; then
	echo "    '${SIGN_IDENTITY}' unavailable — falling back to ad-hoc."
	echo "    Screen Recording permission will likely need re-granting after each build."
	codesign --force --sign - "${APP_DIR}"
fi

codesign --verify --verbose=1 "${APP_DIR}" 2>&1 | sed 's/^/    /'

echo "==> done: ${APP_DIR}"
echo "    open \"${APP_DIR}\""
