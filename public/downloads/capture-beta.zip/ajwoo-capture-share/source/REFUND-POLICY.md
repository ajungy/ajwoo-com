# Refund Policy — ajwoo capture

**⚠️ DRAFT — not reviewed by an attorney. See `GTM-STATUS.md`.**

**Version 0.1 — draft, not yet published**
**Last updated:** [DECISION: set the date you actually publish this]

## The short version

If ajwoo capture doesn't work for you, email **alex@ajwoo.com** within
14 days of purchase and you'll get a full refund, no questions asked.

## Details

- **Refund window:** 14 days from the date of purchase.
- **How to request one:** email alex@ajwoo.com with your order number or the
  email address you purchased with. Refunds are processed through
  **Gumroad**, the payment processor that handled your purchase — the money
  goes back the same way it came.
- **Processing time:** refunds are typically issued within 5 business days
  of the request; your bank or card issuer may take longer to show it.
- **After 14 days:** requests are considered case by case. A clear bug or
  defect in the Software is grounds for a refund regardless of when it's
  reported.

## Why 14 days specifically

This matches the **EU/UK statutory withdrawal right** for digital content
sold to consumers there — by matching it for every purchase rather than only
where it's legally required, the policy is the same for everyone, which is
simpler to run and to explain. (Under EU/UK law, that 14-day right can be
waived if the buyer expressly consents to immediate access to a digital
download and acknowledges losing the withdrawal right by doing so — this
policy does not rely on that waiver, and offers the refund unconditionally
instead.)

## What isn't covered

- A change of mind after 14 days, without a specific issue.
- Misuse of the Software in violation of the [EULA](EULA.md).

`[DECISION: confirm this whole policy matches whatever Gumroad's own
checkout-level refund handling actually does — Gumroad may have its own
buyer-facing refund mechanism that should be consistent with what's written
here, not contradict it.]`

## Contact

alex@ajwoo.com
