# Privacy Policy — ajwoo capture

**⚠️ DRAFT — not reviewed by an attorney. Fill in every `[DECISION: ...]` before
publishing. See `GTM-STATUS.md`.**

**Version 0.2 — draft, not yet published**
**Last updated:** [DECISION: set the date you actually publish this]

## The short version

ajwoo capture does not collect, transmit, or have access to any of your data.
It has no analytics, no crash reporting, no account system, and makes no
network connections of any kind. Everything it records or lets you edit stays
on your Mac, in files you control. We only learn your email address if you buy
the app, because our payment processor tells us so we can send you a receipt
and, if you ask, a refund.

That's the whole policy in plain terms. The rest of this document is the
detailed version regulators expect us to provide.

## 1. Who we are

**GG Creative Studios, LLC**, [DECISION: state of formation], is the
publisher of ajwoo capture (the "Software"). Contact: alex@ajwoo.com
[DECISION: confirm this is the support address you want published].

## 2. What data the Software itself collects

**None.** Specifically:

- The Software makes no network requests. This was verified directly in the
  source code: there is no use of `URLSession`, no HTTP client, no analytics
  SDK, and no telemetry of any kind anywhere in the codebase.
- Screen, camera, and microphone recordings are written only to local files on
  your Mac, in a folder you choose. They never leave your device unless you
  personally move, share, or upload them yourself.
- Speech-to-text transcription (used for subtitles and filler-word removal)
  runs entirely on your device using Apple's on-device speech recognition
  (`SFSpeechRecognizer` with `requiresOnDeviceRecognition` enabled, and
  `SpeechAnalyzer` on macOS 26+). Your audio is never sent to Apple's servers
  or anyone else's for this feature.
- The Software does not require or support creating an account.
- The Software does not use cookies (it is not a website) or any comparable
  tracking technology.

## 3. What data is collected when you buy the Software

We sell the Software through **Gumroad**, acting as Merchant of Record
[DECISION: confirm this is still the platform you're using — swap the name
throughout this section if not]. When you purchase, **Gumroad**, not us,
collects your payment details (card number, billing address) and processes the
transaction. We receive from them:

- Your email address (to deliver the download link and any receipt)
- The fact and amount of the purchase

We do not receive or store your full card number at any point.

**Purpose:** to deliver the product you paid for, provide customer support,
and process refunds if requested.
**Legal basis (GDPR):** performance of a contract (Art. 6(1)(b)).
**Retention:** purchase records are kept for [DECISION: how long — commonly
as long as needed for accounting/tax purposes, often 7 years in the US].
**Third party:** Gumroad acts as an independent controller for the payment
data it collects — see
[Gumroad's privacy policy](https://gumroad.com/privacy) for how it handles
that data, including its own transfer mechanisms.

## 4. Your rights

Because we hold so little data about you — an email address and a purchase
record, nothing else — most requests are simple to fulfill:

- **Access or delete your purchase record:** email alex@ajwoo.com. We will
  respond within 30 days.
- **Access, delete, or export any recording you made with the Software:**
  you already have full control — every file is on your own Mac. There is
  nothing for us to provide, because we never had it.
- **EU/UK/California residents** have additional statutory rights (correction,
  portability, restriction, objection, and the right to lodge a complaint with
  a supervisory authority). Given how little data we hold, these mostly apply
  to your purchase record with our payment processor — contact them directly,
  or contact us and we will forward the request.

## 5. International transfers

Gumroad may process your data outside your home country. Check
[Gumroad's own privacy policy](https://gumroad.com/privacy) for its current
transfer mechanism (Standard Contractual Clauses, an adequacy decision, or
the EU-US Data Privacy Framework) — that mechanism is Gumroad's to maintain,
not ours, since Gumroad is the one actually processing the payment data.

## 6. Children

The Software is not directed at children under 16, and we do not knowingly
collect personal data from anyone under that age. Because we collect
essentially no data at all, this is a low-risk area, but if you believe a
minor has purchased directly and this concerns you, contact us.

## 7. Security

Because the Software transmits nothing, there is no server-side attack surface
for your recordings. The security of your purchase and payment details is
handled by Gumroad, which is PCI-DSS compliant.

## 8. Changes to this policy

If a future version of the Software adds any feature that changes this policy
— for example, an optional update-checker, crash reporting, or a cloud
feature — we will update this policy before that version ships, and the
change will be described in the release notes.

## 9. Contact

alex@ajwoo.com
