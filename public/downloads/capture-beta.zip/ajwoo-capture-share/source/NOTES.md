# ajwoo capture — architecture notes

Running log of decisions, the `events.json` schema, and places where Apple's APIs
behaved differently than expected. Updated as each phase lands.

Status: **Phases 0–7 complete**, plus three rounds of work beyond the original
brief. Record (full display or region, with camera and mic, optionally including
the app's own windows), edit (crop, trim, cut, zoom, auto-zoom, cursor styling,
camera shape/placement/grading, undo), export (movie or GIF). Phases 8
(distribution) and 9 (polish) are not started.

### Naming

The product is **ajwoo capture** on every user-visible surface: window titles,
the menu bar, Info.plist, the `.app` bundle, `~/Movies/ajwoo capture/`. The Swift
target and binary are `AjwooCapture` because a target name has to be an
identifier, and the bundle ID is `com.ajwoo.capture`.

`AppInfo.name` is the single source of truth in code; `scripts/make_app.sh` holds
the bundle name. Recording packages use the `.ajwoocapture` extension.

> **Changing the bundle ID reset TCC.** The app used to be `com.ajwoo.screenkit`;
> macOS keys Screen Recording permission to the bundle ID, so the grant does not
> carry over and has to be given once more.

---

## 1. The core architectural decision

Recording produces **lossless-ish capture plus metadata**. Nothing is baked in.

| Written during capture | Applied at export |
| --- | --- |
| `screen.mov` at native pixels, **no cursor** | zoom (crop of the source) |
| `system.m4a`, `mic.m4a`, `camera.mov` | cursor rendering + click animation |
| `events.json` — cursor path and clicks | camera overlay, audio mix, background |
| `project.json` — edit state, rewritten freely | trim |

Two consequences worth stating plainly, because everything downstream depends on them:

- **Zoom is a crop, never an upscale.** A 2x zoom on a 3456×2234 master exporting
  to 1080p is still sampling ~1728×1117 real pixels into a 1920×1080 frame. It
  stays sharp because we never threw the pixels away.
- **The cursor is not in the video.** `SCStreamConfiguration.showsCursor = false`
  is load-bearing. Because the cursor is drawn later from `events.json`, it can be
  resized, restyled, smoothed and animated after the fact — and it can be drawn
  *after* the zoom crop, so it stays a constant on-screen size at any zoom level.
  If the cursor were burned in, none of Phase 6 would be possible.

---

## 2. Build setup (and why it isn't an Xcode project)

Xcode is not installed on this machine — only Command Line Tools, so there is no
`xcodebuild` and no way to author or verify an `.xcodeproj`. Every framework we
need is in the CLT SDK (26.2): ScreenCaptureKit, AVFoundation, SwiftUI, CoreImage,
VideoToolbox, Metal.

So: **SwiftPM executable target + `scripts/make_app.sh`** which assembles a real
`.app` bundle (Info.plist, `PkgInfo`, codesign). Sources sit in plain folders
(`Capture/`, `Editor/`, `Export/`, `Models/`, `UI/`), so wrapping them in an
`.xcodeproj` later is a file-add operation with zero code changes.

```
make build      # compile only, fastest loop — cannot record (no bundle → no TCC identity)
make app        # debug .app bundle, signed
make run        # build bundle + launch
make release    # optimised .app bundle
make icon       # regenerate Resources/AppIcon.icns
make selftest   # headless render-pipeline check, needs no permissions
```

The bundle is written to the repo root as `ajwoo capture.app` so its icon is
visible on opening the folder; `build/` holds only intermediates.

**The app must run from the bundle to record.** A bare SwiftPM binary has no
bundle identifier, so TCC has nothing to attach the Screen Recording grant to.

### Signing and the TCC re-prompt trap

macOS keys the Screen Recording grant to the app's **code signature**, not its
path. Ad-hoc signing (`codesign -s -`) produces a fresh cdhash on every build, so
each rebuild looks like a brand-new app and you get re-prompted — miserable while
iterating on capture code.

`make_app.sh` therefore signs with a **stable self-signed certificate**, defaulting
to the existing `Voicekey Local Dev` identity, and falls back to ad-hoc with a
warning if it's missing. Override with `AJWOO_SIGN_IDENTITY=...`.

Phase 8 will still document the ad-hoc path for distribution — that's a different
tradeoff (recipients get Gatekeeper friction once; developers get re-prompted
constantly).

Not sandboxed. Sandboxing would need entitlements for camera, mic and `~/Movies`
write access, and buys nothing until we ship through the App Store — which we
won't, since screen recording apps have a rough time in review.

---

## 3. The clock — how nothing drifts

Screen video, system audio, camera, mic and the cursor log all arrive through
different APIs. Get one of them onto a different clock and it drifts invisibly
until you watch a ten-minute recording and the click sound lands late.

**Everything uses the mach absolute time base** — seconds since boot, not counting
sleep. Four APIs, one number line:

| Source | API | Base |
| --- | --- | --- |
| ScreenCaptureKit video + audio | `CMSampleBuffer.presentationTimeStamp` | `CMClockGetHostTimeClock()` |
| AVCaptureSession (camera, mic) | `CMSampleBuffer.presentationTimeStamp` | host time clock (macOS default) |
| Cursor polling | `CACurrentMediaTime()` | mach absolute time |
| Mouse clicks | `NSEvent.timestamp` | "seconds since system startup" = mach absolute time |

`CaptureClock` (in `Capture/CaptureClock.swift`) is the single accessor.

**`t0` is the presentation timestamp of the first screen frame actually written.**
Every timestamp on disk is `reading − t0`. That origin is chosen deliberately:
`screen.mov` then starts at exactly 0 by definition, and everything else is
expressed relative to the picture — which is the thing you look at when judging
whether the sync is right.

Each media file gets its own `AVAssetWriter`, but **all of them are started with
`startSession(atSourceTime: t0)`**. AVAssetWriter maps the session start time to
the beginning of the output file, so every file in the package shares one
timeline. Samples arriving before `t0` are dropped, not written.

`events.json` records each file's actual first-sample offset in
`recording.media[].startOffsetSeconds` as a diagnostic. Expect `0.0` for video
and a few milliseconds for audio. **If you ever see a large value there, sync is
broken and that field is where it will show up first.**

---

## 4. `events.json` schema

Version 1. Written by `Models/EventLog.swift`.

```jsonc
{
  "version": 1,
  "recording": {
    "startedAt": "2026-08-10T22:46:11Z",   // wall clock, display only — never use for sync
    "clock": "machAbsoluteTime",
    "durationSeconds": 42.5183,
    "frameRate": 60,
    "geometry": {
      // The rect the encoded frame covers, in CoreGraphics global display
      // coordinates: origin top-left of the primary display, Y down, POINTS.
      "sourceRectPoints": [[0, 0], [1728, 1117]],   // [[x,y],[w,h]]
      "framePixelWidth": 3456,
      "framePixelHeight": 2234,
      "pointPixelScale": 2,
      "displayID": 1
    },
    "media": [
      { "file": "screen.mov", "kind": "screenVideo",
        "startOffsetSeconds": 0,      "sampleCount": 2551 },
      { "file": "system.m4a", "kind": "systemAudio",
        "startOffsetSeconds": 0.0107, "sampleCount": 1993 }
    ]
  },

  "cursor": [
    { "t": 0,      "x": 0.51233, "y": 0.44102 },
    { "t": 0.0083, "x": 0.51301, "y": 0.44098 }
  ],

  "clicks": [
    { "t": 1.2341, "x": 0.5102, "y": 0.4411, "button": "left", "phase": "down" },
    { "t": 1.3187, "x": 0.5102, "y": 0.4411, "button": "left", "phase": "up"   }
  ]
}
```

Field rules:

- **`t`** — seconds since recording start (see §3). Always `>= 0`.
- **`x` / `y`** — normalized against the **capture frame**, `(0,0)` = top-left,
  `(1,1)` = bottom-right. Normalized rather than pixels so the same log renders
  correctly against a 1080p or a 4K export without rescaling.
- **Values may fall outside `0…1`.** That means the pointer was on another display
  or outside a selected region. Deliberately not clamped — the renderer uses it to
  *hide* the cursor rather than pinning it to an edge. Clamping here would produce
  a cursor that slides along the frame border, which looks like a bug.
- **`cursor` is deduplicated.** A sample is written only when the position changed
  by more than ~0.08 px, with a forced keepalive every 0.5 s
  (`EventLog.keepaliveInterval`) so gaps stay bounded. **Consumers must hold the
  last known position across a gap.** An idle minute costs ~120 samples instead of
  ~7,200.
- `x`/`y` are rounded to 5 decimals, `t` to 4. Five decimals is ~0.04 px on a 4K
  frame — invisible, and roughly halves the file.
- `button` is `left` | `right` | `other`; `phase` is `down` | `up`.
- A position sample is force-inserted at every click timestamp, so a click always
  has an exact position rather than one up to 8 ms stale.

`project.json` (edit state — trim, zoom segments, cursor style, audio mix) is
written with defaults in Phase 1 so the package is complete and openable. Phases
4–7 fill it in.

---

## 5. Coordinate spaces — read this before touching cursor code

Three spaces are in play, and mixing them is the single most likely bug in this
codebase. All of this lives in `Models/CaptureGeometry.swift`.

1. **CoreGraphics global display space** — origin top-left of the primary display,
   Y **down**, units **points**. `CGDisplayBounds`, `CGEvent.location`.
   **This is ajwoo capture's canonical space for pointer input.**
2. **AppKit global screen space** — origin bottom-left of the primary display,
   Y **up**, units points. `NSScreen.frame`, `NSEvent.mouseLocation`.
   Used *only* for positioning our own overlay windows.
3. **Capture frame space** — origin top-left of the encoded frame, units **pixels**.

Choices that remove whole classes of bugs:

- **Poll with `CGEvent(source: nil)?.location`, not `NSEvent.mouseLocation`.**
  It returns space 1 directly, so there is no Y-flip in the hot path to get wrong
  (or to accidentally apply twice), and it is safe to call off the main thread.
- **Clicks use `event.cgEvent?.location`** for the same reason, falling back to
  flipping `NSEvent.mouseLocation` only if that's nil.
- **`sourceRectPoints` comes from `CGDisplayBounds(displayID)`**, and the frame
  pixel size is derived from *that same rect* times `pointPixelScale`. Pointer
  mapping and frame sizing therefore cannot disagree — they're computed from one
  number.
- The AppKit ⇄ CG flip is about the **primary** display's height
  (`CGDisplayBounds(CGMainDisplayID()).height`), not the current display's. On a
  multi-monitor setup, flipping about the wrong display's height produces an error
  that looks correct on the built-in screen and wrong everywhere else.

### Debug overlay

`Cursor debug overlay` in the main window draws a red crosshair at the position
being *logged*, not at the position the OS reports. It takes the normalized value
headed for `events.json`, runs it back through
`CaptureGeometry.globalCG(fromNormalized:)` and the CG→AppKit flip, and draws
there — so it exercises the mapping end to end. If the crosshair sits under the
real pointer, the math is right. A vertical mirror, a display-origin offset, or a
2x scale error is immediately obvious.

The overlay is one of our own windows, so `SCContentFilter` excludes it: you see
it live, it never lands in the file.

---

## 6. Capture configuration

Screen master, `SCStreamConfiguration`:

| Setting | Value | Why |
| --- | --- | --- |
| `width`/`height` | display points × `pointPixelScale`, rounded to even | native retina, never upscaled; encoders dislike odd dimensions |
| `minimumFrameInterval` | `1/fps` (60 default, 30 selectable) | |
| `showsCursor` | **`false`** | the entire cursor architecture depends on this |
| `pixelFormat` | `kCVPixelFormatType_32BGRA` | straightforward Core Image interop for Phase 4 |
| `colorSpaceName` | `sRGB` | predictable now; Display P3 / 10-bit is a Phase 7 question |
| `queueDepth` | `8` (the maximum) | slack before SCK drops frames when the encoder hiccups |
| `captureResolution` | `.best` | |
| `scalesToFit` | `false` | no resampling in the capture path |
| `capturesAudio` | `true` | |
| `excludesCurrentProcessAudio` | `true` | don't record ourselves |

Master bitrate: `pixels × fps × 0.2 bits`, clamped to 40–240 Mbps. Roughly 99 Mbps
at 4K60, 93 Mbps on a 16" MBP's 3456×2234, 40 Mbps (the floor) at 1080p60.
Deliberately fat: the master is never watched, it exists to be **cropped**, and a
zoom crop magnifies whatever artifacts are in it. The floor keeps small displays
from being starved by the bits-per-pixel formula.

Codec: HEVC by default, H.264 selectable, both hardware-encoded through
VideoToolbox via `AVAssetWriter`. `AVVideoAllowFrameReorderingKey = false` — no
B-frames, because screen content doesn't need them and decode order matching
presentation order makes scrubbing cheaper in Phase 4.

System audio: AAC 256 kbps, 48 kHz stereo, its own `system.m4a`. Kept separate
from the mic (Phase 3) so they can be balanced at export rather than at capture,
which is irreversible.

---

## 7. `SCRecordingOutput` (macOS 15+) — evaluated, not used

The brief asked whether macOS 15's `SCRecordingOutput` is a better path than a
hand-rolled `AVAssetWriter`. It isn't, for this app. Three concrete reasons:

1. **It muxes system audio into the same file as the video.** This architecture
   needs system audio, mic and camera as separate files so the editor can balance
   them at export. That alone disqualifies it.
2. **No codec, bitrate, profile or colour configuration.** The capture master is
   the thing zoom crops magnify; its bitrate is not a knob we can give up.
3. **No per-frame presentation timestamps.** `t0` — the origin the cursor log is
   aligned against — is exactly the thing it doesn't hand back.

It would also pin the app to macOS 15+, against a stated macOS 14 target. The
hand-rolled writer is maybe 120 lines (`Capture/MediaWriter.swift`) and gives full
control. Revisit only if Apple exposes codec settings and multi-file output.

---

## 8. Surprises and gotchas hit so far

**SCK frame status.** Every frame carries an `SCStreamFrameInfo.status`
attachment; only `.complete` has new pixels. `.idle` / `.blank` / `.suspended` are
heartbeats for an unchanged screen and are skipped. This is *not* dropped frames —
it's what stops an idle desktop from costing 100 Mbps. The resulting movie has
variable frame timing and players hold the last frame. The recording UI reports
the skipped count so it can't be mistaken for a problem.

**Audio can arrive before the first video frame.** `t0` isn't known until the
first complete frame lands, so early audio buffers are held in a bounded queue
(240 buffers, a few seconds) and drained once `t0` exists. The drain happens on
the *audio* queue, not the video queue, so every append to the audio input comes
from one serial thread in presentation order — appending out of order to an AAC
input fails silently.

**`NSEvent.addGlobalMonitorForEvents` never sees your own app's events.** A local
monitor is installed alongside it. Without that, clicks on ajwoo capture's own window
would be missing from the log.

Mouse-only global monitoring does **not** require the Accessibility permission
(only key events do), which is why there's no `CGEventTap` here and no second TCC
prompt.

**Screen Recording has no documented `Info.plist` usage-description key.** macOS
supplies its own prompt text. `NSScreenCaptureUsageDescription` is included anyway
since some releases surface it; camera and microphone keys are the documented
`NSCameraUsageDescription` / `NSMicrophoneUsageDescription`.

**The permission prompt is one-shot.** `CGRequestScreenCaptureAccess()` shows the
dialog only if the user has never answered. After a denial the only route back is
System Settings, and macOS gives no API to distinguish "never asked" from
"denied" — `CGPreflightScreenCaptureAccess()` returns a bare bool. ajwoo capture
tracks whether it has prompted in `UserDefaults` to tell the two states apart and
show the right UI.

**Two files named `README.swift` in different folders break SwiftPM.** Object
files are named from the basename, so they collide: *"multiple producers"*.
Basenames must be unique across the whole target.

**`NSLock` in an `async` function warns** ("unavailable from asynchronous
contexts") and is an error under Swift 6. Correctly fixed by moving the critical
section into a non-`async` helper, which also guarantees the lock is never held
across a suspension point.

---

## 9. Licensing

Zero third-party dependencies so far. Everything is Apple SDK — ScreenCaptureKit,
AVFoundation, VideoToolbox, Core Image, Metal, SwiftUI, AppKit — usable in
commercial closed-source software under the standard Apple SDK agreement.

**No FFmpeg, no libx264, no GPL/LGPL anything.** H.264 and HEVC encoding go
through VideoToolbox, i.e. Apple's hardware encoders, where the patent licensing
is Apple's problem and not ours.

Full audit lands in Phase 8. Rule going forward: any new dependency must be
MIT/Apache-2.0/BSD, and gets flagged here before it's added.

---

## 10. The compositing pipeline (Phases 4–6)

One function does all the visual work:

```
FrameRenderer.render(screen:camera:time:snapshot:outputSize:) -> CIImage
```

**The preview and the exporter both call this and nothing else.** There is no
export-only drawing path, so "the export doesn't match the preview" is not a
class of bug that exists here.

### How one renderer serves both

`AjwooCaptureCompositor` wraps `FrameRenderer` in `AVVideoCompositing`. That one
adapter is consumed two ways:

| | Preview | Export |
| --- | --- | --- |
| Driver | `AVPlayerItem.videoComposition` | `AVAssetReaderVideoCompositionOutput` |
| Gets for free | audio playback, scrubbing, seeking | frame pacing, trim range |
| Render size | capped at 1600 px on the long edge | full output resolution |

The only difference between them is `renderSize`. Preview compositing of a 4K
frame for a 900 px window is wasted work, and dropped preview frames look worse
than a slightly softer preview — the editor says "Preview downscaled" when this
is in effect. Export always runs at full resolution.

`AVFoundation` instantiates the compositor class itself with no arguments, so
render state reaches it through a custom `RenderInstruction` attached to the
video composition, not a global. Preview and export can therefore run at once
with different state.

### Order of operations — the order *is* the feature

1. Evaluate zoom at `t` → a crop rect **in source pixels**.
2. Crop the master, scale the crop to the output (Lanczos).
3. Optional background: inset, round the corners, drop a shadow.
4. **Draw the cursor — after the crop, in output space.**
5. Camera bubble on top.

Step 4 is the one that matters. Cursor size is `outputHeight × 0.045 ×
multiplier`, derived from the output alone, so it is constant through a zoom and
identical between a 1080p and a 4K export. Drawing the cursor *before* the crop
would scale it with the zoom — the classic version of this bug, and the reason
the pipeline can't just be "composite everything then crop".

### Zoom

A segment is `{start, end, level, focusX, focusY, rampDuration}`. Weight ramps in
and out with `Easing.inOutCubic`, clamped to half the segment length so a 0.6 s
ramp on a 0.5 s segment ramps faster instead of overshooting.

Overlapping segments **blend rather than pop**: focus is a weighted average, and
level fades toward 1.0 as total influence drops below 1 — which is also what
makes an isolated segment ramp at all.

The crop is clamped inside the source, so a focus point near an edge *slides* the
crop instead of exposing black bars. Above `sourceWidth / outputWidth` the crop
samples below 1:1 and the inspector says so rather than silently going soft.

### Cursor smoothing: centred, not causal

The raw 120 Hz path is jittery. A one-pole or trailing filter would smooth it but
lag behind the real pointer, and a laggy cursor looks broken next to the clicks
it is supposed to be making. `CursorPath` resamples onto a uniform 120 Hz grid
and applies a **centred** moving average — zero phase lag, because the whole
recording is on disk and we are allowed to look into the future. The slider maps
0 → no filtering and 1 → a ~208 ms window; the 0.25 default is ~58 ms.

Linear interpolation between logged samples is correct despite the log being
deduplicated: two equal consecutive samples mean "didn't move", and interpolating
between equal values holds still.

### Click animation

Pulse: scale to 0.8 and back over 150 ms, eased both directions. Ripple: a ring
expanding to 3.1× over 450 ms with `Easing.outCubic`, fading as it goes. Both
toggleable; the ripple draws under the cursor.

### Auto-zoom suggestions

Clicks are clustered with a 2.5 s gap threshold; each cluster becomes a proposal
running from 0.8 s before the first click to 1.5 s after the last, focused on the
cluster centroid. Overlapping proposals merge. **Nothing is applied until you
accept it individually** — an editor that silently rewrites your timeline is
worse than one with no suggestions.

---

## 11. Trim, and why the timeline is never shifted

The full asset is always inserted into the composition **at time zero**. Trimming
is applied by the player's loop bounds during preview and by
`AVAssetReader.timeRange` at export — never by shifting the composition.

That means composition time always equals recording time, so every timestamp in
`events.json` is usable directly with no offset. Shifting the timeline instead
would put the cursor in the right place at the start of a trimmed clip and
progressively wrong later, which is a miserable bug to chase.

---

## 12. Export (Phase 7)

Presets are **1080p / 1440p / 4K / Original**, HEVC or H.264, source frame rate
or 30 fps. Two rules, both from the quality bar:

- **Width follows the source aspect ratio.** "1080p" means 1080 tall at whatever
  shape the display was. Forcing 16:9 would mean either a silent crop or black
  bars, and neither is the app's decision to make.
- **Never upscale.** Asking for 4K from a 1080p capture clamps to the source and
  the sheet says so.

Bitrate is `pixels × fps × 0.35`, clamped to 12–130 Mbps: ~44 Mbps for 1080p60.
Higher than a streaming ladder, because screen content has hard edges and fine
text that low bitrates smear.

Audio is mixed at export by `AVAssetReaderAudioMixOutput` from the separate
system and mic tracks — the payoff for keeping them apart at capture time.

GIF goes through `CGImageDestination` with `UTType.gif`: 15 fps, max 800 px wide,
capped at 30 s. No third-party GIF encoder, so the licence story stays clean.
Past half a minute GIF is simply the wrong format and the button disables itself.

---

## 13. Verification without Xcode: `--selftest`

XCTest and swift-testing both require a full Xcode install, which this machine
doesn't have — `swift test` fails with *no such module 'XCTest'*. So the pipeline
check lives in the app binary instead:

```
"build/ajwoo capture.app/Contents/MacOS/AjwooCapture" --selftest
```

It synthesises a recording package (a four-colour quadrant video plus a handmade
`events.json`), exports it through the real `VideoExporter`, and samples pixels
out of the result. It needs no permissions and takes a few seconds. It checks the
three things that would otherwise only surface by eye:

- **Orientation** — each quadrant lands where it should. Core Image is
  bottom-left origin and `events.json` is top-left; a single missed flip puts
  every cursor and zoom focus in the wrong half of the frame and looks plausible
  until you compare against the source.
- **Zoom crops exactly the right rectangle** — 2× focused on (0.25, 0.25) must
  produce a uniformly red frame.
- **Cursor size is zoom-invariant** — near-white pixel count at 1× vs 3× must
  match within 15%.

Run it after touching anything in `Editor/`.

---

## 14. Region capture (Phase 2)

`SCStreamConfiguration.sourceRect` crops inside the capture pipeline, so
ScreenCaptureKit only moves the pixels we asked for and the encoder never sees
the rest — cheaper and sharper than capturing everything and cropping in
software.

`sourceRect` is **display-local points, top-left origin**, while `CaptureRegion`
stores global CG points; `localRectPoints` does the conversion. As in Phase 1,
one rectangle drives both the pointer mapping and the frame size, so they cannot
disagree.

The overlay rounds to even **pixel** dimensions, not even points: on a 2× display
rounding points can still land on an odd pixel count, which encoders reject.

Hovering highlights the smallest window under the pointer — otherwise a
full-screen window behind everything always wins the hit test. The last region is
remembered in `UserDefaults`.

---

## 15. Camera and microphone (Phase 3)

`AVCaptureSession` timestamps against the host time clock on macOS, the same base
as ScreenCaptureKit, so sync needs only a shared origin. The screen engine
publishes `t0` via `onOriginEstablished` the instant its first frame lands, and
the camera/mic writers hold their buffers until then — the same
buffer-until-origin pattern the system audio path uses. Camera and mic start
*before* the screen stream so nothing at the head of the take is lost.

Mic and system audio are never mixed at capture time. Mixing is destructive; if
the mic is hot relative to a video you were playing, a single mixed track can't
be repaired. One extra file makes the balance an export-time slider.

Failures are isolated: a missing camera, a denied permission or a disconnected
device leaves that flag false, adds a warning, and the screen recording carries
on.

### The live preview conflict

The brief asked for the camera preview to be both **draggable** and
**click-through**. Those are mutually exclusive — `ignoresMouseEvents = true` is
exactly what makes a window unable to receive a drag.

It's click-through, because a window that eats clicks while you're demonstrating
something is much worse than one you can't reposition. Instead it parks in
whichever corner the export overlay is set to, which also makes it an honest
preview of where the bubble will end up. The recorded `camera.mov` is always
full-frame, so position is an export-time decision anyway.

---

## 16. Further surprises

**`AVVideoCompositing.startVideoCompositionRequest` was renamed** to
`startRequest(_:)`. The old name still appears in a lot of sample code and the
compiler flags it as an error, not a deprecation.

**`AVPlayerItem` only re-renders when handed a video composition it hasn't seen.**
Mutating the existing one in place does nothing, and a paused player will happily
keep showing a stale frame. Every edit therefore builds a fresh
`AVMutableVideoComposition` (cheap — they're just descriptors) and follows it with
a zero-tolerance seek to the current time.

**Slider drags need coalescing.** Without a ~40 ms debounce, dragging the zoom
slider rebuilds the video composition sixty times a second and the preview
stutters badly.

**Sprites are premultiplied**, so fading one means scaling all four channels by
the same factor. Scaling only the alpha channel leaves bright fringes.

**Two files with the same basename break SwiftPM** regardless of directory —
object files are named from the basename and collide with *"multiple producers"*.

**`NSLock` in an `async` function** warns and is an error under Swift 6. Fixed by
moving each critical section into a non-`async` helper, which also guarantees the
lock is never held across a suspension point.

**Forcing mono when decoding for the waveform** isn't just an optimisation: with
interleaved stereo, one decoded sample is not one frame, and the bucket index
drifts so the waveform draws into the first half of the strip.

---

## 17. Editor features added after the brief

### Two arrow tones

macOS draws a **black** pointer with a white outline; Windows draws a **white**
pointer with a black outline. Which reads better depends entirely on the content
behind it, so both are available and `arrowTone` defaults to `.dark` — matching
what you actually saw on screen while recording.

Both are drawn from the same vector path with the fill and stroke swapped. The
drop shadow stays dark either way; it's what separates the pointer from a
same-coloured background.

### Auto-zoom on click

A checkbox that drops a zoom onto the timeline around every click burst. The
generated segments are **real segments** — visible on the zoom track, selectable,
editable, deletable — not a hidden rendering mode.

They carry `isAuto: true`, which is what makes the toggle reversible:
regenerating replaces exactly the auto segments and never disturbs a zoom placed
by hand. Clicks closer together than `clusterGap` (1.2 s) become one zoom, so a
double-click doesn't produce two segments fighting over the same stretch.

This is separate from the older **"suggest zooms"** popover, which proposes a
smaller number of longer zooms for you to accept one at a time. Auto-zoom is the
blanket "do it everywhere" switch; suggestions are the curated version. Both
exist because they answer different questions.

### Zoom that follows the cursor

Per-segment `followsCursor`. When set, focus comes from the pointer at that
instant instead of a fixed point.

It reads from a **separate, much more heavily smoothed path**
(`CursorPath.follow`, ~0.7 s window versus ~58 ms for cursor rendering). Driving
the framing from the rendering path is unwatchable — every small hand movement
swings the whole frame. An order of magnitude more smoothing turns it into a slow
camera pan.

Focus is normalized against the **full source frame** in every case, crop or no
crop, so a followed focus needs no conversion and stays in `events.json` space.

### Crop

`ProjectState.Crop`, normalized top-left like everything else, applied *before*
zoom — the crop becomes the effective frame and zoom crops within it. Both are
crops of the native master, so cropping costs no sharpness; it only reduces how
far you can zoom before hitting 1:1.

Export dimensions derive from the cropped size, so a cropped recording exports at
the shape you cropped it to rather than being letterboxed back to the display's
aspect.

While the crop tool is open the renderer is fed a doctored project with the crop
and all zooms disabled — you can't choose a crop region from a frame that's
already cropped and zoomed into. The tool takes over the transport bar rather
than opening a sheet, because you need to see the frame while choosing.

### Click feedback

Already existed; now has a **Strength** slider (0.5–2.0) scaling the pulse depth
and ripple size together, and clearer labels ("Shrink and bounce", "Expanding
ripple"). Pulse depth is clamped to 0.45 so the cursor can't collapse.

### Camera bubble shapes

Circle, rounded rectangle, rectangle, star — plus an aspect picker for the
rectangles (16:9 / 4:3 / 1:1 / 9:16) and a corner-radius slider for the rounded
one.

All four go through **one Core Graphics alpha mask** rather than per-shape Core
Image filters. A star has no filter equivalent, and one code path means the rim
and drop shadow work identically for every shape — they are literally the same
mask, grown by a border width and blurred. Masks are cached by shape + size +
radius, all stable across a render pass.

The self-test verifies the masks by area ratio rather than by sampling points:
a circle covers π/4 of its bounding box and a 5-point star with a 0.42 inner
radius about 0.31. That catches a mask silently falling back to a rectangle,
which is exactly how a broken star path would look.

### Camera and mic in the record bar

They were buried in the settings popover. "Record my face while I narrate" is a
headline feature, so both now have first-class menu buttons in the main row that
show state at a glance and let you pick a device in one click.

---

## 18. App icon

`scripts/make_icon.swift` draws the icon in Core Graphics and runs `iconutil`;
`make icon` regenerates `Resources/AppIcon.icns`. Drawn in code rather than
committed as a binary asset so the mark can be adjusted by editing numbers, and
so there's nothing in the repo that can't be regenerated.

The mark: a dark rounded tile, a white rounded-rectangle display outline, a red
record dot. At 16 px the outline becomes a suggestion and the red dot carries the
meaning — which is the wanted behaviour rather than mush. A 10%-white hairline
rim keeps the tile from disappearing against a dark Finder background.

All ten sizes are generated. Skipping any makes macOS fall back to a blurry scale
of another size, most visibly in the Dock.

`make_app.sh` copies the `.icns` into the bundle and generates it first if it's
missing; `CFBundleIconFile` is `AppIcon`.

---

## 19. Second editor pass

### Light and dark

SwiftUI followed the system already; what didn't was the timeline, which
hardcoded black at various opacities and looked like a bruise in light mode.
Those are now semantic colours in `Palette`, resolved against the current
appearance.

`AppTheme` (System / Light / Dark) pins the app via `NSApp.appearance`, applied
in `applicationDidFinishLaunching` before any window exists so there's no flash
of the wrong theme. Useful when recording a demo you don't want the OS flipping
halfway through.

The preview letterbox stays black in both themes — that's what a video player
does, and a light surround changes how the footage reads.

### Defaults

Auto-zoom on click is **on**, at **2.0x**, holding **2 s** after the last click
of a burst. A click is nearly always the thing worth looking at, and it's one
toggle to switch off.

Because it ships on, a project that has never generated its segments builds them
at load. `AutoZoom.generated` is what stops that resurrecting auto zooms the user
deleted one at a time.

### Four cursor options in one row

Arrow tone used to be a second picker below the style picker. From the user's
side "dark arrow" and "light arrow" are two styles, not one style plus a
modifier — so the row is now **Dark / Light / Dot / Off**. The model still keeps
`kind` and `arrowTone` apart because the renderer needs them apart;
`InspectorView.CursorChoice` flattens them for the picker.

### Click feedback: subtler, and adjustable speed

Default depth dropped from 0.2 to **0.11** — a big shrink reads as a glitch
rather than a press. `clickSpeed` (0.4–3.0) divides both the pulse and ripple
durations, so **Strength** controls how much and **Speed** how fast.

### Camera: direct manipulation and a look

Corner + size + margin is three widgets describing something you can point at,
and it couldn't express "slightly left of centre, tucked under the sidebar". The
bubble is now dragged on the preview: `centerX`/`centerY` normalized to the
output, a corner handle to resize. Only the bubble is hit-testable, so dragging
anywhere else still pans the zoom focus.

`CameraFilter` grades the webcam with `CIColorControls` + `CITemperatureAndTint`
+ a light blur, applied **after** scaling to the bubble — same look, a fraction
of the pixels. Presets: Off / Natural / Warm / Bright / Soft / Punchy, all
tweakable afterwards. Natural is the default because a laptop camera is flat,
grey and slightly cold, and lifting brightness a touch while warming the white
point is most of what makes a face look intentional.

The live *recording* preview keeps a corner setting (`CaptureSettings.PreviewCorner`)
— that's a different concern: where a floating click-through window parks while
you record, not where the bubble lands in the finished video.

### Cuts, and the end of an invariant

Cutting broke the rule that composition time equals recording time. Remove four
seconds at 0:10 and everything after happens four seconds earlier in the output,
while the cursor log still says 0:14.

The alternative — rewriting `events.json` on every cut — throws away the original
timing and makes cuts destructive. Instead the log is never touched and
`TimeMap` does piecewise-linear translation in one place:

- **Recording time**: `events.json`, zoom segments, cuts, the whole editor
  timeline. Never changes.
- **Composition time**: position in the spliced `AVComposition` — what the player
  and exporter see.

`CompositionBuilder` inserts each kept range back-to-back for every track;
`RenderInstruction` carries the map so the compositor converts before rendering;
the player and export reader convert at their boundaries. With no cuts it's the
identity, and the old behaviour is unchanged.

The timeline deliberately keeps showing the recording **as captured**, with cut
stretches struck through in red, rather than collapsing them — otherwise clips
slide around underneath you every time you remove something.

Cuts are the only edit that changes the composition's shape, so they're the only
one that rebuilds it (debounced 250 ms, playhead preserved). Everything else just
rebuilds the video composition.

### Undo / redo

Snapshot-based: `ProjectState` is small, and edits touch enough separate fields
that command objects would be more code and more ways to be wrong.

The interesting part is coalescing. A slider drag fires `didSet` sixty times a
second; without grouping you'd need sixty ⌘Z presses to get back. The base state
is captured on the first change of a burst and committed once edits stop for
500 ms — and ⌘Z flushes any in-flight burst first, so undoing right after a drag
does what you expect instead of nothing.

### Hover and pressed states

`HoverButtonStyle` gives every borderless control a background on hover and a
firmer one when pressed. On the timeline, `onContinuousHover` runs the same hit
test as the drag gesture but without the side effects, so zoom tiles, cut bands
and trim handles highlight before you commit — the tile lifts and shadows on
hover, settles on press.

### Audio you can actually see

Both meters were on a **linear amplitude** scale. Normal speech peaks around
0.1–0.3, so a linear bar barely twitches and reads as broken.

`AudioLevel.meter` maps to decibels over a −54 dB floor, which puts speech in the
upper half. The record meter went from a 54×5 pt sliver to 14 segments that turn
amber then red near clipping; the timeline waveform is taller, decibel-scaled,
normalized against its own loudest bucket so a quiet take still fills the strip,
and has a centre line so silence still reads as "there is audio here".

### Collapsible inspector sections

`CollapsibleSection` — chevron, hover highlight, expansion remembered per section
in `UserDefaults`. Auto-zoom carries a badge with its segment count so you can
see it's doing something while collapsed.

---

## 20. Third pass: defaults, chrome, and recording ourselves

### Recording ajwoo capture itself

`SCContentFilter` has always excluded our own windows, which is right by default —
a recorder shouldn't appear in its own output. `CaptureSettings.includeAppWindows`
switches that off, and then everything shows: main window, editor, popovers, the
camera preview. It's the only way to make a video *about* the app.

### The mic listens between takes

The meter used to come alive only once you hit record, which is backwards — the
moment you want to know the mic works is *before* the take, not after narrating
two minutes into a muted input.

`MicMonitor` runs a tiny `AVCaptureSession` whenever a mic is selected and we're
not recording, writing nothing to disk. It's torn down before a real recording so
`CameraMicRecorder` has the device to itself, and restarted afterwards. Both feed
the meter through the same `AudioPeak` helper, so the reading is identical before
and during.

It deliberately **never triggers the permission prompt** — a passive meter
shouldn't produce a dialog just because you opened the app. If access hasn't been
granted, it stays quiet until the first real recording asks properly.

### Cursor drop shadow

Now a toggle, on by default. Both real cursors have one, and it's the only thing
that separates a pointer from a background of its own colour: a dark macOS
pointer on a dark window, a light Windows pointer on a white page. The outline
alone disappears against its own colour.

Six sprites now instead of two (arrow × tone × shadow, plus two dots), all
`static let` — created once, lazily, safe to read from the preview and export
compositors simultaneously. A mutable cache would need a lock to save building
four small bitmaps.

### Defaults

Click strength **1.5** (up from 1.0) and the appearance defaults to **dark** —
an editor is mostly a video on a dark surround, and bright chrome around it skews
how the footage reads.

### The recording opens in the editor

`pendingEditorURL` is published when a take finishes; the main window opens it.
After a recording the next thing you want is to watch it back, not hunt for it in
a list.

**Caveat**: the handler lives on the main window, so if you've closed it and are
running menu-bar-only, the take is saved and listed but no editor opens.

### Chrome

- **Icon**: two colours now — a flat dark grey tile, a white display outline, a
  white dot. No gradient, no accent. A gradient is invisible at 16 px and noise
  at 512.
- **The `.app` builds to the repo root**, not `build/`, so its icon is the first
  thing you see when you open the folder. `build/` keeps only intermediates.
- **The header icon is gone** — the window is already the app.
- **Copy is trimmed throughout.** Explanatory sentences that sat permanently under
  controls have become tooltips: they're available when wanted and invisible when
  not. The main window's second row went from six facts to two.
- **Camera, mic and settings are full-size controls** in the record row rather
  than icon slivers. `.controlSize(.large)` plus `.menuStyle(.button)` makes the
  menus match the buttons exactly.
- **Tooltips on everything interactive**, in both the record window and the editor.

---

## 21. Fourth pass: the waveform bug, and direct camera placement

### The camera bubble genuinely wasn't clickable

`CameraOverlayEditor`'s root `ZStack` held only offset, fixed-size shapes, so it
shrank to fit them. Its coordinate space then no longer matched the preview's,
and `contentShape` was describing a rectangle in the wrong place — the hit area
sat somewhere other than the bubble you could see.

`CropOverlay` didn't have the bug because its first child is a `Path`, which
expands to fill; the camera overlay's first child was a small rounded rectangle.

Fixed by filling the preview (`Color.clear` + `maxWidth/maxHeight`, hit-testing
off) so the two spaces coincide, and hanging gestures off real sized subviews
instead of one big content shape. Resize is now a proper **bounding box**: four
corners, each pinning its opposite, with the aspect ratio driving width from the
dragged height. The size slider is gone — it was describing something you can
point at.

### The waveform was unreadable, for two reasons

**It was reading the wrong file.** `loadWaveform` preferred `system.m4a` whenever
it existed — which is always, since system audio is captured by default. A take
where nothing was playing drew a flat line even though the mic track was full of
narration. Both tracks are now loaded and drawn: mic in the accent colour, system
audio in teal behind it.

**And it was drawn wrong.** 900 hairlines across ~800 px alias into a flat band
that looks identical whether there's sound or not. Now it resamples to about one
column per 1.5 px and fills a mirrored envelope, so speech and silence have
obviously different footprints.

There's also a **silence gate** at 0.002 raw amplitude. Without it the decibel
curve lifts a digitally silent track into a solid bar — a −54 dB floor maps
"almost nothing" to a visible height, and normalising against the track's own
peak makes it worse. Below the gate a bucket draws as a hairline; above it, the
normalised dB curve. Normalisation gain is capped at 4x for the same reason.

### Camera filters that are actually distinguishable

The presets sat a few percent from each other, which on a 200 px bubble is
indistinguishable and makes the whole control feel broken. They're now far apart:
Punchy is +42% contrast and +60% saturation, Bright is +0.24 brightness with
*lowered* contrast, Warm pushes 1100 K.

Added **Clarity** (`CISharpenLuminance`). Laptop sensors are soft, and sharpening
is what makes a face look crisp rather than merely brighter — every preset except
Soft now leads with it, and Soft is the only one that blurs. Clarity is applied
before softness, since sharpening a blurred image only undoes the blur.

### Smaller things

- Auto-zoom now defaults to **1.5x**, **1 s lead time**, **follow cursor on**. A
  tracking zoom keeps what you're doing in frame where a fixed focus drifts off it.
- Click ripple **off** by default — the shrink-and-bounce alone reads as a click.
- "Lead in" → "Lead time", "Hold" → "Hold time".
- Recording subtitles reordered: size, length, cursor samples, clicks, then which
  tracks are present.
- Icon-only buttons were visibly stubbier than the text ones, because a bordered
  button wraps a shorter label in a shorter capsule. Every icon label is now
  pinned to text-line metrics so the row is one height.

---

## 22. Fifth pass: the real click bug, export options, hover scrub

### Why the camera bubble *actually* wasn't clickable

Last pass fixed a coordinate-space problem in the overlay, which was real but
wasn't the whole story. The remaining cause was `PlayerHostView`: an ordinary
`NSView` returns itself from `hitTest` for any point inside its bounds, so the
AVPlayerLayer host became the hit view for every click in the preview — sitting,
as far as AppKit was concerned, in front of the SwiftUI overlays layered above it.

`PlayerHostView.hitTest` now returns `nil`. It's a display surface and nothing
else. The zoom-focus pan gesture moved off the player onto its own transparent
SwiftUI layer beneath the overlays, so input ordering is now decided entirely by
the ZStack: pan at the bottom, camera bubble and crop box above it.

**The lesson worth keeping**: an `NSViewRepresentable` in a `ZStack` silently
outranks the SwiftUI views drawn on top of it. If a representable isn't meant to
be interactive, make it non-hit-testable explicitly.

### Star geometry

Two things were wrong. The mask context is y-up (unlike the cursor sprites, which
flip the CTM), so the path's `-π/2` start put the point at the bottom — now
`+π/2`. And the inner radius was the textbook 0.38, which at bubble size reads as
a sheriff's badge and crops the face away; it's 0.62 now, giving a fatter star
that keeps more of the picture.

The self-test check for this was wrong on its first attempt: comparing whole
halves fails on *correct* output, because a point-up star's wide arms sit above
the midline and give the top more total area either way. The decisive test is the
centre column — filled at the top (the point), empty at the bottom (the notch
between the legs).

### Filters, dialled back

Bright was +0.24 brightness, which blew out skin; it's 0.13. Punchy was +42%
contrast, which posterises a face; it's +18%. Soft was a 0.75 blur that just
looked out of focus — it's 0.22 with some clarity retained, because "soft" should
be a gentler grade, not a defocus.

### Export

- **Format picker** — Video or GIF — replacing the tucked-away "GIF…" button.
- **Quality tiers**: High / Balanced / Small, at 0.35 / 0.16 / 0.08 bits per pixel
  with matching floors, ceilings and audio bitrates. Balanced is the default and
  gives ~20 Mbps at 1080p60. Even Small sits above a streaming ladder, because
  screen content has hard edges and fine text that low bitrates smear.
- **Size estimate** before you commit: `(video + audio bitrate) × duration / 8`,
  shown in the summary row. Presented as approximate — HEVC usually lands under
  it on screen content.
- **Copy** button, left of Export. Renders to a temp file and puts a **file
  reference** on the pasteboard, which is what Slack, Mail, Messages and Finder
  all expect; writing raw bytes works in a couple of apps and silently fails in
  most.

### Hover scrub

Moving the pointer across the timeline now scrubs the preview, no click needed.
Suppressed during playback — hijacking the playhead mid-play is just a fight —
and it uses a deliberately sloppy seek (one frame of tolerance) because a
zero-tolerance seek decodes an exact frame and is far too slow to fire on every
pointer move. There's a toggle in the transport, remembered across launches,
since sweeping the playhead isn't for everyone.

### Smaller things

- Icon buttons get a zero-width `Text` beside the image, forcing the label to
  text-line height so the row matches whatever the system control metrics are —
  rather than a hardcoded number that would drift.
- Show in Finder moved left of Edit.
- The trash icon asks first. Deleting a take removes the only copy of the capture,
  and it doesn't go to the Trash.

---

## 23. Sixth pass: rebuilding preview input on the pattern that works

The camera bubble took three attempts. Two of them fixed real problems and it
still didn't work, which is itself the lesson: the structure had too many places
for pointer routing to go wrong, and no way to tell which one had.

**Attempt 1** — the overlay's root `ZStack` shrank to its offset children, so its
coordinate space didn't match the preview's and `contentShape` described a
rectangle in the wrong place. Real bug.

**Attempt 2** — `PlayerHostView`, being an ordinary `NSView`, returned itself from
`hitTest` for every point in its bounds, putting the AVPlayerLayer host in front
of the SwiftUI overlays as far as AppKit was concerned. Also a real bug.

**Attempt 3** — stop stacking gesture-bearing SwiftUI views over an
`NSViewRepresentable` at all.

`PreviewInteractionLayer` now owns every pointer interaction on the preview:
bubble move, corner resize, and zoom-focus panning everywhere else. **One view
that fills the area, one `DragGesture`, hit-testing in plain code** — the
timeline's pattern, which has worked from the first day it was written. The
per-subview gestures, the separate transparent pan layer, and the gesture hung
off the player are all gone.

`hitTest` is a **static pure function**, so the geometry is covered by the
self-test: middle of the bubble moves, corners resize, corners beat the body near
an edge, handles reach slightly outside the bounds, and anything else falls
through to zoom panning. That doesn't prove SwiftUI routes the events — nothing
headless can — but it means a coordinate mistake, which looks identical to a
routing failure from the outside, is ruled out.

### Chrome only on hover

The dashed outline was drawn permanently, on top of every frame you were trying
to judge. Now nothing is drawn until the pointer is over the bubble; then an
accent bounding box appears with four corner handles, the handle under the
pointer enlarges and fills, and the cursor changes — open hand over the body,
crosshair over a corner. Everything fades out again when you leave.

---

## 24. Applying the Minimal design system

`Sources/AjwooCapture/UI/DesignSystem.swift` is a direct port of
`minimal/tokens/tokens.json` — same semantic names, same values, expressed as
dynamic `NSColor`s so one token resolves in both appearances. That's the AppKit
equivalent of `data-theme` on `<html>`. **No hex value appears in a view**; if a
colour is needed that isn't in `DS`, the design is wrong rather than the token
set being short.

### Colour now means something

The editor had four hues carrying no meaning between them: blue zoom tiles, teal
system audio, yellow trim handles, a red playhead. Under the system, structure is
monochrome and separated by **lightness**, and colour is reserved:

- **Red** — cuts (the one thing on the timeline that destroys footage), the live
  recording dot, errors, delete.
- **Amber** — approaching clipping on the input meter, GIF-too-long.
- **Green** — export succeeded.
- **Everything else** — a neutral ramp.

The app tint is set to `DS.Text.primary`, so system pickers, sliders, toggles and
selection go monochrome too rather than reintroducing the stock blue.

Chrome drawn *over video* is the documented exception: always white with a dark
shadow, in both appearances. Video is its own surface, not page background, so
app text colours would disappear against half of any given frame.

### One emphasis per view

The record screen has exactly one primary button — Record. The editor has exactly
one — Export, at the end of the reading path. Everything else dropped to tertiary
(no border until hover) or secondary (1px border). Previously eight buttons in
the transport competed at equal weight.

### Nothing moves

The rule that changed the most code:

- The transport's Delete/Restore button used to appear and disappear with the
  selection, shifting every button after it. It's now always present, disabled
  when nothing is selected, at a fixed 72pt width.
- `(−X.Xs cut)` is gone from the timecode, and the timecode itself is a
  132pt monospaced-digit slot.
- Status, warning and error messages on the record screen share one fixed-height
  slot, so a message appearing can't shove the recordings list down.
- The recording timecode in the header is always laid out and fades in, rather
  than being inserted.
- Slider value readouts are fixed-width with monospaced digits.
- Camera bubble corner handles keep a constant box and darken their ring instead
  of growing — the thing you're aiming at doesn't move as you approach it.
- Zoom tiles no longer scale up on hover (fill only); the one permitted transform,
  `scale(0.98)` on press, is all that's left.

### The rest

Type comes from the scale (17/15/14/13/11) with tracking tightening as size
grows. One line weight, 1px, everywhere. Radius 10 controls / 14 cards / 20
modals. Spacing is 8-grid: 8 within a group, 16 between groups, 32 between
sections — which let most `Divider()`s be deleted, since the gap *is* the
grouping. Motion is 120/180/260ms on the system's easings, and only opacity,
transform and colour animate.

Empty and error states name what's missing and offer the action that fixes it.
Every icon-only control has both a tooltip and an accessibility label.

### Deliberate deviations

- **The record button stays neutral while recording** rather than turning red.
  Red means "a real problem" in this system, and a recording in progress isn't
  one. The live state is carried by a red dot and a running timecode in the
  header instead.
- **The page padding is 24, not the desktop 32.** The shell sits in the `medium`
  canvas class (600–839pt), where 24 is the specified value.

---

## 25. Pointer shapes, a smooth playhead, and a one-row shell

### The pointing hand

macOS swaps the pointer for a hand over anything clickable, and a recording that
loses that loses a real signal about what was being pointed at.

`CursorEventRecorder` now samples `NSCursor.currentSystem` at 15 Hz on the main
thread — a shape change is a discrete event, not a trajectory, so it doesn't need
the 120 Hz position cadence — and writes **sparse change entries** to
`events.json` under `pointerShapes`. `PointerShapeTrack` binary-searches them.

Classification is by hot spot and image size. `NSCursor` implements no equality
and `currentSystem` hands back a fresh object each call, so identity comparison
is out; hot spot cleanly separates arrow, pointing hand and I-beam, which is all
three sprites we care about.

The hand sprite is built from six overlapping rounded rectangles. The clean
outline comes from **stroking every subpath thickly first, then filling on top** —
the fills cover the internal strokes, which gives a union outline without real
boolean path operations.

The I-beam deliberately falls back to the arrow: a text cursor at 3× reads as a
smudge and isn't what a viewer needs to follow.

Recordings made before this existed have no track and render as an arrow
throughout, which is exactly the old behaviour.

### A playhead that actually slides

It was driven by the 60 Hz `addPeriodicTimeObserver`, so it stepped. The playhead
is now wrapped in `SwiftUI.TimelineView(.animation)` while playing and reads
`player.currentTime()` directly each display frame. Only that one element
repaints; the rest of the timeline is untouched.

### The waveform is a fader now

Each track is drawn at its mix level, so pulling a volume slider down visibly
shrinks that shape and muting removes it. The row shows what will be exported
rather than what was captured — which is what every editing tool does, and what
makes the sliders legible at a glance.

### Everything draggable looks draggable

Cut and zoom segments grow edge grips on hover, drawn like the trim handles that
already worked, and the pointer becomes a resize cursor over any draggable edge.
Grips keep a constant box and change fill only, so the target never moves out
from under you.

### Shell

The window title is gone — one line of chrome repeating what the title bar
already said. Record, the display picker, Region and the camera/mic toggles moved
up into that row, left-aligned, with the live indicator and settings on the
right.

Guidance that used to sit permanently under the camera controls is now an ⓘ
beside the section title. `CollapsibleSection` takes an `info:` string; the same
treatment is on Auto-zoom and Cursor. Copy across the inspector was rewritten to
be formal and concise.

### Deliberate deviation

**The delete button is now evenly spaced with the rest of the row**, where the
house rule asks for 24pt of separation around anything irreversible. Deleting
already requires a confirmation, which is the stronger of the two guards, and the
uneven gap was reading as a layout bug.

---

## 26. Transcription, subtitles, and a tooltip that works

### Tooltips were silently doing nothing

`.help()` is unreliable once a view sits inside a custom `ButtonStyle`, an
overlay, or a `Menu` label — which is most of this app, and why controls carrying
`.help()` showed nothing on hover.

`.tooltip()` parks an invisible, non-hit-testing `NSView` over the control and
uses AppKit's own `NSView.toolTip`, which always works. The view returns `nil`
from `hitTest`, so clicks pass through while the tooltip tracking rect stays
live. Every interactive control now has one, with its keyboard shortcut where it
has one, and the string doubles as the accessibility hint.

### Speech, on this Mac only

The original brief ruled out transcription. It was asked for later, so it's here —
under the same constraint as everything else: `SFSpeechRecognizer` with
`requiresOnDeviceRecognition = true`. If on-device recognition isn't available
for the language, transcription **fails with an explanation** rather than quietly
falling back to Apple's servers. That fallback would break the one promise the
product makes.

Transcripts cache to `transcript.json` in the package, so re-opening a recording
doesn't re-run recognition.

**Filler and silence removal produce ordinary cuts.** They're `CutRange`s tagged
`isAuto`, which means they appear on the timeline, can be dragged or deleted
individually, and reuse the entire existing cut pipeline — no second mechanism,
and `TimeMap` already knows how to splice them.

The filler list is deliberately short: "um", "uh", "er", "hmm" and close
variants. **"Like" and "so" are excluded** — they're filler about half the time
and load-bearing the other half, and silently deleting a real word is far worse
than leaving a stray "um". Silence cuts leave a 0.2 s beat at each end, because
cutting a gap to zero makes speech sound spliced.

### Subtitles

Rendered with Core Text into a cached bitmap and composited last, after the
camera bubble, so nothing can cover them. Text layout, wrapping and font metrics
are solved problems in AppKit and nowhere near solved in Core Image, so the
caption is rasterised once per unique cue-plus-style and reused for every frame
it's on screen.

Cues break at the word limit, at sentence-ending punctuation, and at any gap
over a second — so captions follow the shape of the speech rather than chopping
every N words regardless.

The block is draggable on the preview like the camera bubble, and its left and
right edges set the wrap width, which is how you trade line length against line
count. `PreviewInteractionLayer` gained the targets; the camera bubble wins where
the two overlap.

Six typefaces, all shipped with macOS and free to embed in exported video.
Backdrop is None, Shadow or Box — Box being the only one legible over arbitrary
footage.

### Cursor

"Pointing hand over links" is now **"Show hand cursor"**, which is what it always
did: it draws the hand wherever the *system* showed one, whether that was a link,
a button, or anything else that sets `NSCursor.pointingHand`.

### Action bar

Reordered to Record → Camera → Mic → Region → Display. Icon buttons are square
(`MinimalButton(square:)` drops the horizontal padding rather than wrapping a
single glyph in a wide capsule), the display picker is pinned to the 40pt control
height so the row aligns, and the gap between the summary line and the divider
came down.

---

## 27. Not done yet

**Phase 8 — distribution.** No release script beyond `make release`, no
`LICENSE`, no dependency audit document (there are still zero third-party
dependencies), no notarization notes.

**Phase 9 — polish.** No global hotkey (⌘⇧R only works while the app is
focused), no countdown, no disk-space check, no crash safety — if the app is
killed mid-recording the package has no `moov` atom and won't open.

Known gaps elsewhere:

- The display picker doesn't offer individual windows as capture sources; window
  *snapping* during region selection covers most of that need.
- Zoom focus is panned by dragging the preview rather than by dragging a marker.
- The crop tool is free-form only — no fixed aspect-ratio presets.
- Cuts are made one at a time at the playhead and then dragged; there's no
  range-select-then-cut.
- Undo covers `project.json` only. It doesn't cover recording, exporting or
  deleting a take.
- Camera filters are colour grading only — no background blur or replacement.
- Transcription needs on-device speech support for the current language; there is
  deliberately no network fallback.
- Subtitles are burned into the export. There is no sidecar `.srt`.
- GIF export still renders frame-by-frame through `AVAssetImageGenerator`, which
  is much slower than the movie path.
- The export size estimate is derived from the target bitrate, not measured.
- Auto-opening the editor after a take needs the main window open; in menu-bar-only
  mode the recording is saved but nothing opens.
- The idle mic monitor won't prompt for permission, so the meter stays flat until
  microphone access has been granted by a real recording.
- No undo. `project.json` is rewritten 400 ms after each edit.
- GIF export renders frame-by-frame through `AVAssetImageGenerator`, which is
  slower than the movie path.

## 27. Reactivity, transcription and the person cutout

**Immediate audio and camera grading.** Every project mutation used to go
through one 40 ms debounce before the preview was rebuilt. For discrete edits
that's right — it coalesces a burst of changes into one composition rebuild. For
a slider being dragged it isn't: the preview kept playing at the old mix while
the fader was still moving. `pushProjectToRenderer(immediate:)` now reassigns
`AVPlayerItem.audioMix` and refreshes without waiting whenever `audio` or
`camera.filter` changed. Only those two — they're the controls you judge by
result rather than by number.

**Transcription starts on open.** It was an explicit button, which meant
subtitles appeared to do nothing: "Add subtitles" was disabled, and the reason
was written inside a collapsed section further down. Now the editor kicks off
recognition when it loads (if there's a microphone track and no cached
transcript), and switching subtitles on starts it too and reports progress in
place.

**The progress bar creeps.** `SFSpeechRecognizer` reports nothing until it has
decoded its first chunk, so the bar sat at 0% for several seconds and read as
hung. `startTranscriptionCreep()` advances it on `0.85 * (1 - e^(-t/14))` — it
decelerates, never claims to be finished, and real progress overtakes it via
`max(shown, value)` so the bar can't go backwards.

**Subtitles were never broken.** `checkSubtitlesRender` in the self-test drives
the whole chain — transcript, cue grouping, cue lookup, bitmap, composite — and
asserts white pixels appear when enabled and move with `centerY`. It passed
first time. The bug was entirely upstream: no transcript ever arrived.

**`.cutout` camera shape.** `VNGeneratePersonSegmentationRequest` at
`.balanced`, run on the already-scaled bubble rather than the full camera frame —
segmenting 1080p to draw 240 px costs about ten times as much for no visible
difference. Ships with macOS, so it adds no dependency and no licence question.
The mask is scaled back to the bubble and blurred by ~1 px, because a hard edge
on a human outline reads as a cheap cutout. The last good mask is cached: if a
frame fails, reusing it beats flashing the background back in. If segmentation
finds nobody at all the bubble falls through to the plain rectangle path rather
than disappearing. The shape's shadow is grown from the cutout's own alpha, so
it traces the person instead of a box.

**Filmstrip.** Was fourteen sequential `image(at:)` calls publishing nothing
until the last returned. Now one batched `images(for:)` pass, published
incrementally, at the displayed size (240×120) instead of 320². The timeline
draws `thumbnailSlots` placeholder tiles from the first paint so the row has its
final shape immediately.

**Speech row.** The waveform shows level, which isn't the same as speech — a fan
registers just as loudly. `speechBands` groups transcript words into runs,
bridging gaps under 0.3 s, and the timeline draws them as their own thin row.

**Inspector order and density.** Frame first (Auto-zoom, Cursor, Background,
Camera), then sound (Audio, Speech, Subtitles). Speech and Subtitles start
collapsed — neither is part of a typical edit and both are tall. Related toggles
share a row via `pair`, which roughly halves the scroll distance. The Soften
slider is gone; it only ever undid Clarity.

**Colour panel.** `ColorPicker` opens the shared `NSColorPanel`, which stays up
until explicitly closed — a large panel hovering over the preview long after the
colour was chosen. `ColorPanelDismisser` closes it on resign-key, deferred one
run-loop hop so it doesn't swallow the click that took focus. Three background
presets sit beside the colour rails, since reaching a good gradient through two
pickers is fiddly.

## 28. Speed, cursors, and one-editor-per-recording

**Transcription is now `SpeechAnalyzer`** (macOS 26), not `SFSpeechRecognizer`.
The old API was built for live dictation and streams a file past the model at
roughly the rate it was recorded, so a five-minute take took about five minutes.
Measured on this machine with `--transcribe`:

| audio | old (approx.) | new |
|---|---|---|
| 17.9 s | ~18 s | **2.3 s** |
| 115.4 s | ~115 s | **5.4 s** |

About 21× real time, with ~1.8 s of fixed setup. `SFSpeechRecognizer` remains as
the fallback for macOS 14–15. Word timings and punctuation both survive, which
matters because filler detection keys off `"Um,"` including its comma.

Two things found on the way:

- **`NSSpeechRecognitionUsageDescription` was missing from `Info.plist`.** Asking
  for speech authorisation without it doesn't fail, it aborts the process —
  `SIGABRT`, no message. Transcription could never have worked in the shipped
  app. Added.
- **`SpeechAnalyzer` doesn't need that authorisation at all** for a local file,
  so the fast path now runs before the permission check rather than after it.

The one caveat worth stating plainly: the language model is a system asset, and
if it isn't installed macOS fetches it once through `AssetInventory`. That's the
same asset `SFSpeechRecognizer`'s on-device mode already required, so it isn't
new exposure, but it is the only point in this app where a network request can
occur — and it's the OS making it, about the language, not the recording.

**Editor open.** `EventLog.read` and `ProjectState.read` are JSON decodes — tens
of thousands of cursor samples on a long take — and were running on the main
actor before the window had drawn. Both now happen on a detached task. Auto
transcription is deferred 1.5 s so it isn't competing with thumbnail decoding
and the first frames of preview.

**One editor per recording.** `WindowGroup(for:)` will open a second window over
the same recording, both writing `project.json`, with nothing to indicate the
other exists. Each editor now stamps its `NSWindow` with the recording's path;
opening one raises the existing window (with a small shake, so it's obvious
which window answered) instead of making a duplicate.

**Cursors.** The pointing hand was a union of five rounded rectangles, which is
why it read as a mitten. It's now a single traced contour — long slim index
finger, thumb bulging from the left edge, three knuckle humps stepping down,
flat wrist — which is how real cursor artwork is built: one silhouette, one or
two internal creases, nothing else.

Seven more shapes joined it: I-beam, horizontal and vertical resize, open hand,
fist, crosshair, and the two magnifiers. `CursorEventRecorder.classify` matches
them off hot spot plus image size, and `PointerShapeChange.Shape` decodes
unknown values as `.arrow` so a log from a newer build still opens here.

There's no assertion for "does this look like a hand", so `--sprites <out.png>`
writes a contact sheet of every glyph on mid grey and it gets looked at.

**Menu bar.** Idle shows the outline mark; recording breathes the centre dot on
a 1.6 s cycle; stopping sweeps an arc. Driven by `TimelineView(.animation)` —
a `MenuBarExtra` label is re-rendered rather than animated in place, so implicit
animation has nothing to run against. The main window reports the same
processing state in the slot the timecode occupies.

**Tooltips.** All rewritten for someone who has never edited video ("Cut out
long pauses", not "Cuts gaps between words longer than the threshold"). Every
remaining `.help()` became `.tooltip()`, and `NSInitialToolTipDelay` is now
registered as the first statement in `applicationDidFinishLaunching` — AppKit
reads it once, the first time it needs it, so registering it late was a race.

## 29. Logo and cursors from the Figma source

Both came out of Figma via the REST API rather than being approximated by eye.

**Icon** — `scripts/make_icon.swift` now draws the exact geometry of node
`242:5435`: an 840 pt tile with a 237 pt corner radius, a vertical gradient from
#363638 to #1C1C1E, a 500×500 rounded square (100 radius, 46 stroke, drawn
*inside* the box) and a 200 pt dot. Every number is the Figma value over 840, so
it's the design rather than a likeness of it.

The mark sits about 12 pt below the tile's centre in the source. That's kept —
it's optical centring against the rounded corners, not a mistake.

**Menu bar** uses the same mark at 16 pt, so the icon in the menu bar and the
icon in the Dock are recognisably one thing.

**Cursors.** The reference kit showed two details the first attempt missed, and
they turn out to be most of what makes a hand read as a hand:

1. The folded fingers are **separate humps** — a scalloped top edge, not one
   smooth curve.
2. The separations **continue as lines down into the palm**, at the same weight
   as the outer contour. On the real cursor the fingers are separate shapes that
   happen to touch. Without those lines the hand is an amoeba.

`fingerSeparators` is shared by the pointing hand, the open hand and the fist so
the three stay a family. The base of the pointing hand also picked up its two
lobes and shallow notch; a flat wrist was the other thing making it look rubbery.

The I-beam gained flared serifs — the bar swells out to the caps instead of
meeting them square, which is what stops it reading as a lowercase L.

`--sprites <out.png>` renders the whole set on mid grey for comparison against
the reference.

## 30. Preview resolution

Preview compositing capped at 1200 px, down from 1600. With camera, background
and subtitles all switched on, 1600 dropped frames on a 4K source. Chosen
knowingly: the preview is softer while editing, and the export is untouched —
it always renders at full resolution.

## 31. Cursor artwork is now the Figma export, parsed

`CursorArtwork.swift` holds the SVG `d` strings from node 251:5482 verbatim, and
`SVGPath.swift` parses them into `CGPath` at load. Nothing is re-traced.

Two rounds of hand-tracing the pointing hand produced, in the author's words, a
deformed hand — first a mitten, then something closer but still wrong. Tracing a
cursor by eye is a bad use of anyone's time when the vector already exists. The
parser handles the subset Figma emits (`M L H V C S Q T Z`, absolute and
relative) and *throws* on arcs rather than silently skipping them.

Each cursor is a white body with a 25-unit outline, so the same geometry gives
the macOS arrow (dark body, white edge) and the Windows one (reversed) without
two copies. The outline is stroked twice: once under the shadow to define the
silhouette, once on top at 62% width because the fill covers its inner half.

The I-beam, resize bars, crosshair and magnifiers stay code-drawn — they're pure
geometry, and an export would be more to keep in sync than it's worth.

## 32. The region overlay was covering the whole screen

The panel spanned the display and relied on `hitTest` returning nil to be
click-through. That is not sufficient: a borderless panel still sits between the
pointer and everything under it, and the result was a screen you couldn't use
after choosing a region.

The panel is now sized to the region plus a 14 pt margin (and room for the size
badge), so the rest of the display is never covered at all. Within that margin
only the four corners take the mouse — edge dragging is gone, because a live
border is a lot of screen to keep claiming for a control used once.

## 33. The menu bar icon rendered as nothing

`MenuBarExtra`'s label is flattened into a status item image. A `ZStack` of
`Circle`s wrapped in `TimelineView(.animation)` did not survive that trip — the
status item was simply invisible, which removed the only way into the app once
its window was behind something.

`MenuBarIcon` now draws an `NSImage` with `isTemplate = true`, and the controller
drives it from a 20 Hz timer that only exists while there's something to animate.
Template images also get the menu bar's light/dark and highlight handling for
free, which hand-picked colours would get wrong.

## 34. Silence removal now reads the audio

The old implementation took the gaps between transcribed words, which fails in
precisely the situation people complain about. In a room with a fan, a keyboard
or a street outside, the recogniser emits words across the low-level noise and
stretches their timings over it; the gaps it leaves come out shorter than the
real pauses and most fall under the threshold. The checkbox appeared to do
nothing.

`SilenceDetector` works on a 50 buckets/second envelope of the mic track, with a
threshold *relative to the recording's own speech level* — the 90th percentile
stands in for "how loud is this person", since the mean would be dragged down by
the very pauses being looked for and the maximum would be set by one door slam.
Anything under 10% of that is silence, which is what "treat micro sounds as
silence" means in practice. An absolute floor of 0.012 handles the degenerate
case of a track that is quiet throughout.

Four checks in the self-test pin it, including the noisy-room case that the old
version got wrong.

Ticking or unticking either speech option now rebuilds the composition
immediately rather than waiting out the 250 ms cut debounce — they're discrete
actions, so there's nothing to coalesce, and the delay meant the timeline
disagreed with the checkbox you had just clicked.

## 35. Smoothness

The periodic time observer ran at 60 Hz and wrote to a `@Published` property, so
every frame of playback re-evaluated the timeline, the inspector and the toolbar.
It's now 10 Hz: the playhead is drawn inside a `TimelineView(.animation)` that
reads the player's clock directly, so it already moves at display rate, and the
observer only feeds the timecode readout and the trim-end check.

The filmstrip moved into an `Equatable` view flattened with `drawingGroup`, so
fourteen images aren't diffed and composited on every frame. Inspector rows have
a fixed height, so a readout changing width can't relayout everything below it.

## 36. Icon and subtitles

The icon tile is now inset 1.2% instead of 5.5%. Reproducing the Figma artboard's
generous margins left a visible empty border — at Finder's 16 px the mark was a
small square inside a larger transparent box, which is what makes an icon look
shrunken next to its neighbours.

Subtitles gained **shadow strength** and **box opacity**. The shadow is no longer
tied to the `.shadow` backdrop: a shadow under a turned-down box is what keeps
captions readable, and at strength 0 it costs nothing. Bitmap padding now clears
the blur radius as well as the box, or a strong shadow gets clipped at the edge
of its own bitmap.

## 37. Menu bar weight, arrow artwork, export readout

**Menu bar stroke** was being drawn at 2.2× the icon's own proportion "for
legibility", which made the mark a thick blob beside a thin-lined app icon —
recognisably not the same logo. It's now the true 46/500 ratio with a 1 pt floor.

**Arrow** re-exported from node 251:5480, which had changed: pure black fill and
`strokeAlign: OUTSIDE`. Alignment now matters, so `Artwork` carries
`strokeOutside`. An outside stroke is drawn at double width with the fill on top
— the fill covers the inner half, leaving exactly the authored width outside.
Centred strokes keep the old two-pass treatment.

**Hand cursor default** was already `true`, and `checkDefaults` has pinned it for
several rounds. A recording whose `project.json` was saved with it off keeps that
value; that's a per-recording setting, not the default.

**Export readout.** Under the timecode: position over total in the primary
colour, and beneath it the exported length with the saving, in red. The second
line's space is always reserved even when empty — an earlier version appeared and
disappeared, which shifted every button in the row.

## 38. Camera preview and mirroring

`CameraMonitor` runs a minimal `AVCaptureSession` — camera input, no outputs at
all — so the home window can show a live preview before recording. An
`AVCaptureVideoPreviewLayer` draws straight from the session, so nothing is
decoded, encoded or written. Like `MicMonitor` it never triggers the permission
prompt; a dialog appearing because you opened the app would be rude.

`CameraMirror` is the single place that decides which way round the camera faces,
and it's applied to three connections: the home preview, the floating preview
during recording, and **the recorder's video data output**. That last one is the
point — if only the previews were mirrored, every take would come out reversed
from what you rehearsed.

## 39. Editing a caption

Double-click a caption on the preview and it becomes a `TextField` in place —
a real one, so select-a-word, delete, paste and ⌘Z all work as they already do
everywhere else. Clicking out saves; Escape abandons.

Corrections live in `subtitles.edits`, keyed by **cue start time to two decimal
places** rather than by index. Indices shift the moment a cut lands, which would
silently reassign a correction to a different caption; time is stable against
that. Changing "words per caption" does move cue boundaries, so an edit whose
start no longer matches any cue is dropped — the alternative is corrected text
appearing over the wrong speech.

Setting a caption back to the recogniser's own wording removes the override
rather than storing a no-op, so `edits` only ever holds real corrections and a
later re-transcription isn't shadowed by stale identical entries.

## 40. Style sets, and the hand cursor for real this time

**Hand cursor.** The default was already `true` and had been for several rounds —
what wasn't true is that *existing* projects picked it up. `project.json` files
saved with it off kept it off, which is what was actually being seen. There's now
a `schemaVersion` on `ProjectState` and a `migrate()` that switches it on once
for anything older.

The version field is `Int?`, not `Int`, and that's load-bearing: synthesized
`Codable` requires every non-optional key to be present, so adding a plain `Int`
would have thrown on every existing file and silently reset all of them to
defaults. Optional decodes a missing key as `nil`.

The migration only runs once — switching it off afterwards sticks, and there's a
check for exactly that.

**Style sets.** Reset, three slots, and a Save-set menu, above every section
because it acts on all of them. `StyleSet` captures cursor, background, camera,
subtitle styling, audio, speech options and the auto-zoom *parameters*.

What it deliberately doesn't capture: zoom segments, cuts, trim, crop and
hand-corrected captions. Those are bound to one recording's timeline, and
applying them to a different take would put cuts at meaningless timestamps. A set
is a style, not an edit — and `Reset` follows the same line, so it can't cost you
an hour of trimming. Four checks pin that boundary, because getting it wrong is
the expensive kind of bug.

Sets live in `UserDefaults` rather than beside a recording: carrying a look from
one recording to the next is the entire point. `autoZoom.generated` is cleared on
apply, or the incoming settings would be ignored because segments already exist.

**Caption editor** gained visible Save and Cancel buttons. Return and Escape
still work, but they're invisible until someone tells you about them, and
clicking away to save is a leap of faith the first time. Saving on click-away is
now handled by a transparent catcher view rather than by focus loss — pressing
Cancel moves focus away before its action runs, so a focus-loss save would have
committed the very change Cancel exists to discard.

**Camera preview** moved to the head of the summary row and is 50% larger
(168×95). It's the one thing in that row you have to *look* at rather than read,
so it shouldn't sit at the end of the reading path.

## 41. The region overlay, third attempt — five windows

The first two versions were one panel over the region that returned nil from
`hitTest` everywhere except the handles. That does not work, and it's worth
writing down why: **a window that isn't `ignoresMouseEvents` sits between the
pointer and everything beneath it, whatever its content view's `hitTest`
returns.** Both times the result was a screen that looked correct and accepted no
clicks anywhere — you couldn't use the thing you were about to record.

The outline and the handles are now separate windows:

- **One outline panel** over the region, `ignoresMouseEvents = true`. It can never
  take a click, so nothing it covers is blocked.
- **Four handle panels**, 26 pt square, on the corners. The only surfaces in the
  whole overlay that accept the mouse.

Everything outside those four small squares behaves exactly as it did before a
region was chosen. Corner drags read the pointer in *screen* coordinates —
the handle window is 26 pt across, so the pointer leaves it immediately and
window-local coordinates go stale. The new rect is published on mouse-up, not
during the drag, so one drag doesn't produce fifty settings writes.

## 42. Home layout

Record, then microphone, then camera — the order people actually switch things
on. The display picker is replaced by **Reselect region** once a region is
chosen; it was previously just disabled, leaving a dead control where the useful
action belongs. The mic meter moved to its own line: sharing a row with the
capture description meant it slid sideways whenever that text changed length,
which is exactly when you're looking at it. All margins are 16 pt.

**`MinimalButton` gained a `tint`.** The style sets `foregroundStyle` on the
label, so a `.foregroundStyle` applied to the `Button` from outside never reached
it — the destructive actions had been rendering in the ordinary text colour for
as long as they've existed. `DS.Status.danger` is `#B42318` on light and
`#F87171` on dark, both comfortably above 4.5:1.

## 43. The wand shows what's on the timeline

It used to list *suggestions*: zooms proposed but not applied, which you added
one at a time. That duplicated auto-zoom, which already puts them on the
timeline — so the wand showed things that weren't in your video while the things
that were had no home anywhere.

It now reflects the timeline. `autoZoomStatuses` compares what auto-zoom *would*
generate against what's actually there and reports each one as unchanged, edited
or removed, with a way back in every case, plus Reset all and Remove all. A dot
on the wand marks that something has been changed — a count badge would move the
button.

Matching is by time overlap, not by id: an auto segment keeps its id through an
edit but gets a fresh one on regeneration, so ids can't be relied on across both.
Overlap is what a person means by "that's the same zoom, moved".

## 44. Reset is a panel button

It was resetting the timeline too, which meant clicking it to undo a colour
choice silently put back every automatic zoom you'd deleted. `resetStyleToDefaults`
and `applyStyleSet` now both carry `zoomSegments` and `autoZoom.generated` across
unchanged. Restoring the generated zooms is the wand's job, in the toolbar next
to the timeline they'd appear on. Two checks pin the boundary.

## 45. Smaller edit-mode changes

- 16 pt between the set row and the sections, and between sections.
- Background above Cursor — it's the frame everything else sits inside.
- Everything except Auto-zoom and Background starts collapsed. The stored
  open/closed state is namespaced `.v2`, or a value saved under the old defaults
  would quietly win over the new ones.
- Default gradient top is **#1C1E26**. Near-black read as an absence of
  background rather than a choice.
- The red line under the timecode is now position **and** length in the exported
  video (`0:04.2 / 0:31.8`), not a saving. The white line counts through the
  recording; this one counts through what will actually be produced, and that
  second number is the one you quote to someone.

## 46. Region: dimmed during, gone after

The Reselect button is gone — the Region toggle already reselects, so it was two
controls for one action.

While recording, `RegionDimWindow` puts 30% black over everything outside the
region, with a hairline on the boundary. Without it there's no way to tell what's
in shot once the selection overlay disappears — you're performing to a rectangle
you can't see. It's the same language the selector already uses while choosing.
One even-odd fill rather than four rectangles around the hole: no seams, and
nothing to get wrong when the region touches an edge of the display.

`ignoresMouseEvents = true`, so unlike the two failed overlay attempts it can
never come between the pointer and what's being demonstrated.

**The region clears when the take ends.** A region is a decision about one take,
and leaving its rectangle floating over the screen while you edit the recording
it produced is just in the way.

## 47. Messages in plain words

Every warning and error rewritten for someone who has never recorded a screen.
"Camera permission denied — recording without the webcam." became "No camera
access. Recorded without it." The pattern throughout: what happened, then what
you still got — not what failed inside.

## 48. The hand cursor, settled

Default is **off**. The evidence: a project created *after* the v2 migration
shipped had `schemaVersion = 2` and `matchSystemShape = false`, meaning it was
switched off deliberately, and the request to make it "checked off by default"
came again after that. So "checked off" meant unchecked.

The v2 migration that forced it on is removed rather than kept and immediately
contradicted; schema v3 stamps the version and touches nothing. Existing
projects keep whatever they recorded, either way, and there's a check for both
directions. The artwork for all ten pointer shapes is there for anyone who
switches it on.

## 49. Reset and the set buttons disable when they'd do nothing

`styleIsDefault` and `styleMatches(_:)` compare whole `StyleSet` values rather
than field-by-field, so a setting added later can't quietly drop out of the
comparison the way an explicit field list would. The set currently in use also
draws as `.secondary`, so which one is active is visible without hovering.

## 50. Performance, measured

`--benchmark <recording>` times what opening the editor actually does, because
guessing at this has been wrong twice. On a 12.2 s / 12.2 MB recording:

```
blocking — the window can't draw until these finish
  EventLog.read              0.0014 s
  CompositionBuilder.build   0.0081 s
background — these fill the window in after it opens
  thumbnails (14)            0.1704 s
  waveform (both tracks)     0.0002 s
  silence envelope           0.0001 s
```

The blocking path is under 10 ms. Editor open is **not** bound by any of these,
so further work on them would be wasted — what's left is SwiftUI building the
window and the first composited frame arriving, which is why most sections now
start collapsed.

**Capture** switched to `420v` — see `ScreenCaptureEngine.capturePixelFormat`.
That is the real lever for dropped frames: about 750 MB/s instead of 2 GB/s at
4K60, with the 4:2:0 conversion moved out of the encoder and into the capture
pipeline, where it was going to happen anyway.

**Timeline** — the waveform joined the filmstrip as an `Equatable` view. It's a
`Canvas` walking 1800 samples inside a view that re-evaluates on any model
change; now it redraws only when the samples or the two mix levels change.

**Size** — 2.4 MB total: 2.1 MB binary, 431 KB icon. `-Osize` was measured at
1.79 MB, saving 313 KB, and rejected: the saving is 13% of the bundle and the
risk lands on `FrameRenderer`, `CursorPath` and `WaveformLoader`, which are the
per-frame paths. Re-encoding the icon PNGs was tried and changed nothing —
`NSBitmapImageRep` ignores `compressionFactor` for PNG and was already producing
the smaller output.

## 51. Overlays were being moved by AppKit

`NSWindow.constrainFrameRect(_:to:)` keeps ordinary windows clear of the menu bar
and on-screen. That's right for documents and wrong for an overlay drawn over a
specific rectangle: it silently clamps the frame, which is why a capture region
near the top of the display refused to grow upward and its top handles looked
stuck. `OverlayPanel` returns the proposed rect unchanged, and every overlay the
app puts on screen — region outline, corner handles, dim surround, the selector
itself, the camera bubble — is now one.

## 52. The menu bar menu

Two bugs, one symptom. **A bare `Text` is still a menu item** to AppKit but not
to SwiftUI, so the highlight landed one row off: hovering "Stop Recording" lit
the timer above it. Everything in the menu is a `Button` now; the readout is a
disabled one, which is a real item that can't be picked.

**A menu that redraws under the pointer loses its highlight.** `elapsed` ticks
ten times a second and every tick re-rendered the open menu. There's now a
separate `elapsedSeconds` that changes once a second, and the readout binds to
that.

The timer also moved below Quit — it's the one row you can't act on.

## 53. Reopening an editor took the app down

`EditorWindows.open` ran a `CABasicAnimation` on the existing window to draw
attention to it. Raising a window is not worth any risk of losing the editor you
were working in, so the flourish is gone and the function does one thing.

## 54. Capture sets, and fewer settings

`CaptureSet` mirrors the editor's `StyleSet` for the recording side: frame rate,
codec, system audio, preview corner. Device identities are excluded — a set that
pinned "this webcam" would silently do nothing on a Mac without it, which is
worse than not restoring it.

Removed from settings entirely: the cursor debug overlay (and
`DebugCursorOverlayController` with it) and "record this app's own windows".
Both were for working on the app, not for using it.

## 55. Home layout

The status line moved into the text column, under the mic meter and beside the
camera preview — a status under a 95 pt picture is a long way from the controls
it reports on.

The window sizes to its content. `maxHeight: .infinity` on the shell stretched it
to whatever height the window happened to be, leaving dead space under an empty
list; the recordings list is now exactly as tall as its rows up to five, and
scrolls beyond that.

## 56. Edit mode

- One button per auto-zoom row. Two buttons that both meant "undo" on a removed
  row was the same action twice.
- "removed" is white, not amber. It's a statement of fact, and that panel already
  carried enough colour.
- The timecode is a single centred line when there are no cuts; the second line
  only appears when there's a second number worth reading.
- The camera bubble defaults to the bottom-right corner with a 16 pt margin at
  1080p, expressed as a fraction so it holds at any export size.

One self-test bound had to be corrected as a consequence: "star mask covers
~0.31 of its box" only ever passed because the bubble was clipped by the right
edge of the frame at the position that check ran at — the star was being measured
with a slice missing. Centred and whole it fills ~0.45, and the check now says so.

## 57. Window sizing and colour

The shell claims no more height than its content, and `.windowResizability(.contentMinSize)`
makes the window open at exactly that height while still being draggable larger.
The page colour is painted across the whole window separately
(`DS.Surface.page.ignoresSafeArea()` behind a `maxHeight: .infinity, alignment: .top`
frame) — without that, dragging the window taller exposed the system's default
window background under the content, a visibly different shade.

## 58. Region handles near the screen edges

`OverlayPanel` stopped AppKit *moving* the handles, but a handle sitting under
the menu bar is still dead: the menu bar owns those clicks. `handleOrigin` now
pushes a handle back inside `screen.visibleFrame`, which excludes the menu bar
and the Dock — exactly the regions where a window exists but can't be clicked.

Pushed *inward*, not clamped to the screen edge, so a displaced handle sits over
the region it resizes. It stops being exactly on the corner, and that's the right
trade: a handle slightly inside the corner works, one under the menu bar doesn't.
A displaced handle draws hollow instead of solid and says why in its tooltip.

## 59. Frame rates, quality, and a floor that was doing the wrong thing

Frame rates are now 15/24/30/60/120, and there's a **Quality** picker: Smaller
file (0.35×), Balanced (1×), Best quality (2×) scaling the master's bitrate.

Adding the low frame rates exposed a real bug. `masterBitrateFloor` was an
absolute 40 Mbps, so 1080p at 15 fps and 1080p at 60 fps produced *the same
target* — choosing a lower frame rate to get a smaller file did nothing, at
exactly the resolution where someone would try it. The floor is now per frame per
second (40 Mbps ÷ 60), so 60 fps is unchanged and 15 fps gets a quarter of the
budget. Resulting targets, Mbps:

| | Smaller | Balanced | Best |
|---|---|---|---|
| 1080p 15 | 4 | 10 | 20 |
| 1080p 60 | 14 | 40 | 80 |
| 4K 15 | 9 | 25 | 50 |
| 4K 60 | 35 | 100 | 199 |

Set 3 is gone — two slots fit on one row beside Reset and Save set, and the third
wasn't being filled.

## 60. Frame rates the display can actually deliver

Asking ScreenCaptureKit for more frames than the panel produces doesn't get them
— it repeats what's there — so 120 fps on a 60 Hz display was an option that
silently did nothing. Rates above `NSScreen.maximumFramesPerSecond` are greyed
out, and `clampFrameRateToDisplay()` drops the setting when the display changes
under it. Without that clamp the picker would show a disabled option as selected,
which is a state you can't click your way out of.

`maximumFramesPerSecond` reports 0 on displays that don't answer; 60 is the safe
reading of "we don't know".

## 61. One rhythm in the home window

16 pt between every section and 16 pt to every edge, with the shell owning all of
it — sections carry no padding of their own, so the gaps can't be the sum of two
different opinions. The recordings list lost its internal margins for the same
reason.

The empty state is one line. It used to add "Press Record to make one." — an
instruction to use the largest, leftmost button on screen, which made the empty
state twice as tall as the thing it described.

## 62. Cropping with a padded background

The background insets the picture and rounds its corners, so cropping against it
meant dragging a rectangle over a shrunken, clipped version of the frame — every
edge picked was wrong by the padding. It's switched off in the preview for the
duration of a crop and restored on exit; the setting itself is never touched, and
the inspector's toggle disables while cropping so the two can't disagree.

## 63. Timeline: a ruler, a readable playhead, and words on the speech row

**Ruler** above the filmstrip. A filmstrip tells you what's there but not when;
finding "about forty seconds in" meant guessing at a proportion of the width.
Ticks every second, a taller one every fifth, labels where they fit. The step
grows on long recordings — one mark per second across twenty minutes is a grey
smear — climbing through 2, 5, 10, 30, 60 until the ticks have room. Labels read
`12` under a minute and `1:05` over it, because a bare `65` reads as nothing.

**Playhead knob** gained the dark ring the line already had. It was vanishing
against pale thumbnails while the line beneath it stayed perfectly readable.

**Speech row** now carries the opening words of each run, at 9 pt inside the
band, and is 16 pt tall to fit them. That turns "there is speech at 0:42" into
"the bit about pricing is at 0:42", which is what you're actually scanning for.
Labels are drawn only when the band is wider than 34 pt — a clipped half-word is
worse than no word.

## 64. The window's minimum width is measured, not guessed

The action bar is a fixed set of controls with no flexible member except its
spacer, so below a certain width the row clips from the right — and the first
thing to disappear is the settings button, which is the only way into the
settings. The minimum was 640 pt; the row needs 774.

`MainWindowView.minimumContentWidth` computes it rather than hard-coding it. The
three variable-width labels ("Full display", "Region", the elapsed readout) are
measured against the font they're actually drawn in; everything else comes from
the same `DS` tokens the views use. A hard-coded number drifts the moment a label
or a control size changes, and the symptom — a button quietly falling off the
right edge — is easy to miss.

`checkMinimumWindowWidth` recomputes the sum independently, so a mistake in the
property doesn't silently agree with the same mistake in the check, and prints
the number because it moves whenever a control does.

## 65. Reset was never disabling — a bookkeeping flag in the wrong place

`styleIsDefault` compares `StyleSet(from: project)` against
`StyleSet(from: ProjectState())`, and it could never be true. `StyleSet` carried
`autoZoom` whole, including `generated` — the flag that records whether *this
recording's* zooms have been built yet. Opening any project builds them and flips
it, so an untouched project never compared equal to the defaults and Reset stayed
enabled with nothing to reset.

`generated` is bookkeeping about one recording, not a setting, so
`StyleSet(from:)` now normalises it out alongside the caption corrections. The
check for it states the failure rather than the mechanism, since that's what
would break again.

The same class of bug is worth watching for elsewhere: any field that describes
*progress* rather than *intent* has no business in a value used for equality.

## 66. The speech row is gone

Removed, along with `speechBands`, `speechLabel(for:)` and `rebuildSpeechBands()`
— the row was their only consumer. The waveform already shows where sound is, and
a second band underneath saying roughly the same thing in words was more timeline
to scan rather than less.

## 67. Motion blur on zoom movement (removed — see 73)

A zoom that ramps in over half a second is, frame to frame, a hard cut between
two slightly different crops. Real footage smears during a push because the
shutter is open while the lens moves; without that, even a well-eased zoom reads
as stepped rather than filmed.

`FrameRenderer.motionBlurred` derives the blur from how far the crop travelled
since the previous frame, in two components because a zoom does two things at
once:

- **Scale** — the crop grows or shrinks, smearing radially outward from the
  focus point. `CIZoomBlur`.
- **Pan** — the crop slides, smearing in a straight line. `CIMotionBlur`.

Both are skipped below a threshold of 0.15% change per frame, so a static hold
pays nothing — which is most frames in most recordings — and the cost peaks
exactly where the motion is fastest. The previous crop is sampled at a fixed
1/60 s regardless of the real frame rate, so a 30 fps export isn't twice as
smeared as a 60 fps one for identical motion. The image is clamped before
blurring or the filters sample transparent black past the edges and darken the
border.

The setting lives on `AutoZoom` because that's where the control sits, but it
applies to hand-placed zooms too — half the zooms blurred would read as a
mistake, not as a choice. On by default.

**A note on testing it.** The first version of the check put the zoom focus at
the centre of the synthetic frame, where its four colour quadrants meet — and
reported that the blur was barely working. It was behaving correctly: zoom blur
is radial from the focus point and is *zero at the centre by definition*, so the
one measurable feature in the frame sat exactly where the filter does nothing.
Moving the focus off-centre showed the real effect. The held-frame check compares
proportionally rather than exactly, because two separate lossy encodes differ by
a handful of pixels whatever the filter chain does.

"Zoom all clicks" is now "Zoom all".

## 68. The recordings list takes the slack

The list had a fixed height of five rows, so dragging the window taller left an
empty band below it instead of showing more recordings — the list stayed five
rows tall however much room there was.

It's now `minHeight: one row, idealHeight: rows capped at five, maxHeight: .infinity`.
The ideal is what `.windowResizability(.contentMinSize)` opens the window at, so
the window still starts at content size; the maximum is what lets it absorb extra
height afterwards. The empty state takes the slack the same way, so an expanded
window with no recordings is page-coloured all the way down rather than ending in
a band of window chrome.

## 69. No bottom margin

16 pt on three sides and nothing at the bottom. The recordings list now runs to
the window's edge, so a list that continues past the frame looks like it does —
a 16 pt band of background under the last visible row read as the end of the
list, which it usually wasn't.

## 70. Adding a setting was silently wiping projects

Synthesized `Codable` requires every non-optional key to be present. So the
moment a setting is added, every `project.json` written before it fails to
decode — and `load()` falls back to `ProjectState()`, discarding that recording's
cuts, zooms, trim and crop without saying anything. Adding `autoZoom.motionBlur`
did precisely this to two projects saved the day before.

`ProjectState.read` no longer decodes the file directly. It merges the stored
values *over* an encoded set of defaults, so:

- a **missing** key keeps its default and everything else survives;
- a key whose **JSON type doesn't match** is ignored, which covers a setting
  changing type — `motionBlur` going from `Bool` to a slider's `Double` in this
  very turn would otherwise have cost the same edits again;
- an **unknown** key from a newer build is carried through rather than dropped,
  so downgrading doesn't lose it either.

Arrays are replaced wholesale, not merged element-wise: `cuts` and
`zoomSegments` are lists of things, and merging them positionally would be
nonsense. Booleans are separated from numbers explicitly because
`JSONSerialization` represents both as `NSNumber`, and without that a stored
`true` would satisfy a `Double` field and decode as 1.

Five checks drive the three ways a stored file can disagree with the model. The
two affected recordings load again.

**The general lesson**, worth applying to `events.json` too: a persisted format
belongs to files that already exist, and the strict reading of it is a decision
to lose data on every future change.

## 71. Motion blur is a slider (removed — see 73)

0–100% in the Auto-zoom section, default 50%. The strength doubles the tuned
constants, so the midpoint reproduces what the toggle used to do and the top is
twice that — a default sitting at the extreme with nowhere to go would make the
control pointless in one direction.

## 72. Two features were written but never wired up

`TimeRuler` and the motion-blur control both existed in full — struct, model
field, renderer, tests — and neither appeared in the UI. The edits that were
meant to place them targeted text that had already been changed by an earlier
pass, matched nothing, and did nothing, silently.

Both are now inserted against asserted anchors. The lesson is procedural rather
than technical: an edit that finds no match has to fail loudly, and "the tests
pass" says nothing about whether a control is on screen when the tests reach the
model directly.

Wiring the ruler up then exposed a second bug it had been hiding. `hoverTest` and
`beginDrag` each restated the row offsets as their own sums, so putting a 14 pt
ruler above the filmstrip moved every row on screen while every hit region stayed
where it was — an 18 pt gap between what you clicked and what responded. There
are now single definitions (`filmstripTop`, `waveformTop`, `zoomRowTop`) derived
from each other, `totalHeight` is derived from those, and the trim overlay is
offset to the filmstrip rather than to the top of the stack.

The motion-blur slider sits outside the `enabled` branch of the auto-zoom
section, because it governs hand-placed zooms too — hiding it when auto-zoom is
off would hide the only control for the zooms you made yourself. Two checks pin
the ends of the slider: hard left is byte-identical to no blur, hard right is
measurably stronger than the middle. Without those, a control reading 0–100%
could be doing the same thing throughout.

## 73. Motion blur removed

Gone entirely: the model field, both Core Image filters, the previous-crop
sampling, the inspector slider and its checks. It didn't work well enough to be
worth the per-frame cost, and a control that has to be left at zero is worse than
no control.

Sections 67 and 71 are kept as a record of what was tried. The one part worth
remembering is the testing note in 67: zoom blur is radial and therefore zero at
its own centre, which made an early measurement say the effect was broken when it
was behaving exactly as specified.

## 74. The audio row

Same height as the zoom row, 24 pt. Two thin rows read as a pair of tracks; one
fat and one thin read as a mistake.

The height is now a **perceptual** curve rather than the raw peak. Speech peaks
around 0.2–0.4 of full scale, so drawing amplitude linearly left ordinary talking
as a barely-moving ripple near the centre line while the top and bottom of the
row went unused — you could see there was audio, but not where it got louder.
Raising the value to the power of 0.45 is roughly how loudness is heard: 0.3
becomes 0.58, 0.6 becomes 0.79, and anything genuinely loud reaches the edge and
clips there.

The silence gate runs *before* the curve, not after. `pow()` is steepest near
zero, which is exactly where room tone lives, so applying it first would have
lifted the noise floor into view — the opposite of what the gate is for. Five
checks pin the shape: silence flat, noise floor gated, speech well up the row,
loud audio clipping at the top, and the whole thing monotonic.

## 75. The ruler shows numbers, not tall ticks

The tall white tick and its number were competing for the same 14 pt, and the
number lost — it was drawn above the tick, off the top of the row, and simply
wasn't visible. The number is the marker now, so the tick is redundant even
where it would fit; only the short grey second-ticks remain.

Labels are centred on the moment they mark, and pulled inside the row at either
end rather than dropped. That's what puts **0** at the left edge: the old code
skipped any label whose box crossed the boundary, which meant the one number you
can be certain of was the one number never shown.

## 76. Audio levels go to 2x

Both faders now run 0–2.00x instead of 0–1.50x, and the value reads `1.75x` so
it's obviously a multiplier rather than a percentage of something.

`setVolume` is a gain multiplier, not a normalised fader, so values above 1.0 are
passed straight through and 2.0 really is twice as loud. A take already close to
full scale will clip up there. That's the honest behaviour for a gain control —
silently capping at 1.0 would leave a quietly-recorded take unrescuable while
looking like the fader worked. Three checks cover it, including that mute still
overrides any level.

## 77. Skipped frames aren't a warning

The message read "69 frames arrived without complete content and were skipped
(normal when the screen is idle)" and sat in the warnings list beside things like
"couldn't save the video". Two problems: it was written in the vocabulary of the
capture API rather than the user's, and it was categorised as a fault when it is
the opposite — those are frames where the screen hadn't changed, and skipping
them is what keeps a still desktop from costing 100 Mbps. On a slide-based demo,
where almost nothing moves, it was simultaneously the loudest message on screen
and the least important.

`Outcome.skippedFrames` is now reported separately from `warnings`, and the UI is
a small ⓘ beside the frame rate that says nothing until hovered:

> 69 frames were skipped because the screen didn't change. That's normal and
> doesn't affect your video.

Not quite the requested wording — "missing" would have been simpler but untrue,
and a message that misdescribes a healthy recording as damaged is worse than a
slightly longer one. The shape asked for (quiet marker, right of the fps, detail
on hover) is exactly as specified.

## 78. Export aspect ratio, independent of the crop

`ProjectState.Background.CanvasAspect` — Recording (native), 16:9, 4:3, 1:1,
3:4, 9:16 — a picker under the background section's colour presets. It only
takes effect while the padded background is on: with it off there's nothing to
letterbox into, so the canvas always follows the recording, same as before this
existed.

**What it changes and what it doesn't.** The crop is untouched — this isn't
another way to crop, it's a canvas the cropped recording sits inside. Picking
9:16 on a 16:9 capture doesn't stretch or slice the recording; it fixes the
*exported frame* to 9:16 and lets the existing padded-background machinery
(which already letterboxes content inside a possibly-larger canvas, for the
ordinary padding case) fill the rest. Chosen dimensions preserve the *pixel
area* of the cropped content rather than its width or height, so switching from
16:9 to 9:16 doesn't quietly change the export's resolution budget along with
its shape — a 1280×720 (921,600 px) source becomes roughly 720×1280, not
1280×2276 or 405×720.

**One `CGSize` decides everything downstream.**
`ProjectState.Background.canvasSize(for:)` is the only place the math lives;
`RenderContext.canvasSize` (used by export and GIF export) and
`EditorModel.canvasSize` (used by the live preview) both call through it, so
preview and export can never disagree about the shape. `EditorModel.canvasSize`
adds one rule the render context doesn't need: forced back to
`effectiveSourceSize` while `isCropping` is true, for the same reason
`effectiveSourceSize` itself ignores the crop mid-drag — cropping already shows
the whole uncropped frame, and letterboxing that into an unrelated canvas shape
while you're drawing a rectangle on it would be actively confusing.

**Four places quietly assumed the canvas always matched the content's own
aspect,** and all four would have silently misplaced things the first time this
feature was used:
- `outputAspect` (camera bubble placement) and `videoRect(in:)` (what
  `AVPlayerLayer` actually displays, which `PreviewInteractionLayer` uses for
  drag math) — both switched from `effectiveSourceSize` to `canvasSize`. Left on
  the old basis, the camera bubble would drag to one place in the SwiftUI
  overlay and render in a different one, since `FrameRenderer` positions it
  against the *true* render canvas regardless of what the UI thinks that is.
- `previewIsDownscaled` — switched so the "downscaled" indicator reflects what's
  actually being rendered into, not the content's own resolution.
- The three `CompositionBuilder` call sites that set `renderSize` — all three
  switched from `effectiveSourceSize` to `canvasSize`. Changing the aspect ratio
  needed no other wiring: it's a plain `ProjectState` field, so it already flows
  through the existing `project` `didSet` → `pushProjectToRenderer` →
  `scheduleRefresh` → `refreshPreview` path that every other non-cut edit uses,
  and `refreshPreview` swapping in a new `AVMutableVideoComposition` with a
  different `renderSize` on the live `AVPlayerItem` is the same operation the
  crop toggle already exercises.

**Export and GIF export get the same fix**, one line each:
`VideoExporter.export` and `GIFExporter.export` both fed `effectiveSourceSize`
into their own resolution math; both now feed `canvasSize`. `ExportSettings.
outputSize(sourceSize:)` needed no change — it only cares about the aspect and
magnitude of whatever size it's handed, both of which `canvasSize` already
encodes.

**Reopening a project that saved a custom aspect** shows that shape from the
first frame rather than the recording's own aspect for one frame until an edit
rebuilds it — the initial composition build in `load()` now computes its
`renderSize` from `loaded.background.canvasSize(for:)` instead of the raw
capture size. This is based on the *uncropped* source, same as the pre-existing
(unrelated, untouched) limitation that crop itself isn't reflected until the
first edit either — a project combining a saved crop and a saved custom aspect
opens at a very slightly different pixel budget than after its first edit,
purely cosmetic and self-correcting.

Nineteen checks: `canvasSize(for:)` in isolation — a disabled background always
returns the source unchanged, `.recording` does too even with the background on,
each of the five ratios measures correctly, keeps the source's pixel area within
3%, and lands on even dimensions — plus one end-to-end export check that
actually decodes the resulting `.mov`'s track and confirms a 9:16 pick produces
a 9:16 file, not just a number a helper function reports.

## 79. Settings popover, home window, subtitle layout, and a hover language for non-buttons

**Settings popover** — every `Divider` removed, outer padding and row spacing
tightened from `l`(16) to `m`(12), width from 340pt down to 300pt (still wide
enough for Reset / the two slots / Save set to share one line — that's what
originally set the width, not the dividers).

**Home window** — the divider above the recordings list is gone, and so is the
"Recordings" section title. The list now sits directly under the capture
controls; nothing else in the window needed naming to be self-evident, and this
didn't either.

**Subtitles.** Three changes:
- **"None" dropped from the Backdrop picker.** It and Shadow have painted
  identically ever since the shadow slider stopped being tied to which backdrop
  was picked (see §36) — Shadow *is* the no-box option now, so offering both was
  offering the same thing twice. The `.none` case stays in the model (an old file
  that stored it must keep decoding), but `migrate()` now steers it onto
  `.shadow` so a project last saved with it doesn't reopen into a segmented
  control with nothing highlighted. Schema bumped to 4; two checks cover both
  directions (`.none` → `.shadow`, everything else left alone).
- **Font paired with Uppercase**, using the same `pair()` helper that already
  splits a row in half elsewhere in the inspector. The Font picker is capped at
  128pt (`"System Rounded"` is the longest label) — narrower on purpose, which is
  what buys the room for Uppercase beside it rather than below it.
- **Box opacity moved to the end of the section**, only shown for the one
  backdrop it applies to, instead of sitting wedged directly under the Backdrop
  picker ahead of Shadow and Width.

**A hover language for controls that aren't buttons.** `HoverHighlight` (in
`DesignSystem.swift`) is a `ViewModifier`, not a custom `ToggleStyle` — `Toggle`
and `Slider` already render correct native AppKit chrome (the checkbox glyph,
the thumb), and reimplementing that from scratch to add a border would have been
both more code and a real risk of it looking or behaving subtly wrong next to
the system controls around it. Instead it wraps whatever it's given in the exact
border-and-background pair `MinimalButton`'s `.secondary` variant already rests
on (`DS.Action.secondaryBorderHover`, `DS.Action.secondaryHover`), so a hovered
checkbox row now reads exactly the way a hovered button already does — one
visual language for "this responds to you," not two.

The border is drawn on an inflated frame and then shrunk back to the original
size with equal negative padding, a standard SwiftUI trick for adding visual
weight without disturbing layout — wrapping a control in this modifier can't
nudge its neighbours or break a paired row's 50/50 split, because the reported
size never changes. It also reads `@Environment(\.isEnabled)`: a disabled
control doesn't highlight, since inviting a hover on something you can't click
would be the wrong signal.

Applied at 23 sites: both slider helpers (`labelled` and `autoZoomSlider`) each
needed one change to cover every slider in the inspector; every `Toggle` (20)
and `ColorPicker` (3) got it individually, since neither has a single shared
choke point the way the sliders did. Verified mechanically rather than by eye —
a script asserted each of the 20 target blocks appeared exactly once before
rewriting it, so a stale or duplicated match would have failed loudly instead of
silently landing on the wrong toggle or being skipped (the kind of failure that
cost real work twice already this project — see §72).

## 80. The home window sizes itself to what it's actually showing

**Empty state removed entirely** — not just its second line (that was §80's
predecessor, back in the original cleanup), the whole thing. An empty window is
already the message; a "No recordings yet" caption sitting under an already-empty
action bar was repeating something the window itself was already saying.

**Default height dropped from 460 to 160.** `.windowResizability(.contentMinSize)`
clamps the real window up to whatever the content actually needs, so 160 only has
to be small enough to never be the binding constraint — with the empty state
gone, an empty window's true minimum is just the action bar and the summary row,
which is well under that anyway.

**The window grows itself by one row the first time there's something to show.**
SwiftUI's window-sizing APIs size a window once, at open, and never track a later
change in content — there's no declarative way to say "grow when this list stops
being empty." `WindowAccessor` (an `NSViewRepresentable` probe, the same pattern
`EditorWindowClaim` already uses to reach its own `NSWindow`) hands back the real
`NSWindow`, and `growWindowToShowRecordingsIfNeeded` grows it downward by
`RecordingsListView.rowHeight`, keeping the top edge — where the controls
already are — exactly where it was.

Guarded by a `hasGrownToShowRecordings` flag rather than "did the count just go
from zero," and checked from two places: once when the window first resolves,
once on every change to the recordings count. A plain zero-to-one check has a
real race in it — `WindowAccessor` resolving the window and `refreshRecordings()`
populating the list are two independent async paths, and depending on launch
timing either can finish first. Checking the same guarded condition from both
places means it doesn't matter which one wins the race; whichever arrives second
triggers the grow, and the flag stops it from ever firing twice. It fires exactly
once per window — a session that already has recordings doesn't grow again every
time one more is added, which would have been presumptuous about space the user
may have deliberately reclaimed by shrinking the window back down.

## 81. "Record Capture's own windows" is back

Removed in §54 alongside the debug cursor overlay, on the reasoning that both
were for working on the app rather than using it. That reasoning didn't hold for
this one — recording a video *about* ajwoo capture is a real, ordinary use of a
screen recorder, not a debug tool — so the toggle is back in the settings
popover, next to System audio.

Nothing changed underneath: `CaptureSettings.includeAppWindows` and its wiring
into `SCContentFilter` were never removed, only the UI control was. The filter
excludes by `Bundle.main.bundleIdentifier` — the whole running process, not one
specific window — so switching it on was always going to cover the home window
and every open editor window together, with no extra work needed to make the
edit-mode windows included too. That's the behaviour asked for; it just needed
its Toggle back.

## 82. The camera track now spans exactly the screen track's duration

The camera started visibly after the screen and ended visibly before it. Real,
measurable, and — it turns out — not fixable by trying to make the hardware
behave better; only by papering over what it actually does.

**Why the gap exists at all.** `AVCaptureSession.startRunning()` takes real
time to produce a first frame — a few hundred milliseconds is ordinary, more
for an external or Continuity camera — and stopping loses a similar sliver at
the tail. `CameraMicRecorder` already buffers frames until the shared origin
(`t0`, the screen's first frame) is known, so buffering was never the problem;
buffering can't invent a frame the camera hadn't produced yet. `camera.mov`'s
decodable content genuinely starts partway in and stops partway before the
screen's own end, because that's when the hardware actually had frames.

**The fix, and the two bugs found building it.** `CompositionBuilder.insertCamera`
now holds the camera's first real frame frozen back to composition time zero,
and its last real frame frozen forward to the screen's own end, using
`insertTimeRange` on a short probe followed by `scaleTimeRange(_:toDuration:)`
to stretch it — the standard AVFoundation freeze-frame technique. Every
composition instant that has a screen frame now has a camera frame, real or
held.

Getting there took two real bugs, both caught by a test that actually decoded
exported frames rather than trusting that the composition-building code hadn't
thrown:

1. **The two edges needed different safety margins, and didn't have them.**
   A probe asked to start exactly on a range's boundary — the literal `CMTime`
   value read back from the asset — measurably failed to match any sample:
   `Double`-seconds round-tripped back into a `CMTime` at a different timescale
   than the source track natively uses, and that conversion can land a tick
   before the real first sample, where `insertTimeRange` silently matches
   nothing rather than snapping to the nearest one. Backing the probe off by
   one full frame-width from *both* edges (not just clamping it to stay within
   range) fixed it.

2. **`AVAssetTrack.timeRange.start` lies.** For a file `AVAssetWriter` produces
   this way, it reports `0` unconditionally — regardless of how much later the
   first *appended* sample's timestamp actually was — while `.duration` (or
   `.timeRange.end`) correctly reports where the real content actually stops.
   Confirmed by hand: a synthetic track whose real samples begin at 0.4s still
   reported `timeRange.start == 0`. The old code (and my first attempt at the
   fix) trusted this value for where the camera's real content starts, which
   is exactly backwards — it meant the "camera has no content here yet" check
   never fired, and the unmodified insert path silently requested (and got,
   without error) a range that included content that didn't exist.

   The one place the true offset is actually recorded is at capture time, in
   `TrackWriter.startOffset` — "PTS of the first sample actually written,
   relative to t0" — already threaded through to `events.json`'s per-file
   `startOffsetSeconds`. `CompositionBuilder.build` now reads that instead of
   asking the asset, and builds `cameraRange` from it. The synthetic test
   fixture picked up a "camera" `MediaFile` entry it didn't have before, for
   the same reason — without it, the test would have been checking its own fix
   against the same unreliable value that caused the bug.

Three checks, end to end: a camera.mov deliberately covering only the *middle*
1.2 s of a 2 s recording (0.4 s missing at each end — an exaggerated stand-in
for real warm-up/wind-down latency) still shows the bubble in an exported frame
sampled 50 ms after the export starts, and again 50 ms before it ends, with a
sanity check that the fixture's real footage shows up normally in between.

Two smaller, related fixes in the same commit:
- `insert(_:from:into:sourceDuration:)` — the original, still used for the
  screen track and both audio tracks — gained a doc comment explaining why
  camera video specifically can't share it: a short audio track just means
  less sound, but a short *video* track means a visible gap.
- `EventLog.RecordingInfo.media`'s doc comment, which claimed video offsets
  "should be ~0," is corrected — that was true for the screen track (which
  defines `t0`) but was never true for the camera, and this bug is exactly
  what believing it produced.

## 83. Auto-zoom skips the trailing "stop recording" click

Asked for, then explicitly retracted the same session, then asked for again —
worth a careful implementation given the back-and-forth, and one that's cheap
to undo if the heuristic guesses wrong.

**The signal.** The very last click cluster in a recording, if it sits in the
menu bar's own strip at the top of the frame, is almost certainly someone
opening the menu bar to click Stop — not content. Position alone (top of frame)
isn't a safe signal on its own: a tutorial legitimately pointing at the menu bar
mid-recording looks identical. Being the *last* cluster is what makes it safe —
nothing else can happen in the recording after it, which is never true of a
middle click. Both conditions have to hold; only the last cluster is judged, and
only when it's also up in that strip.

The strip itself is a fixed 4% of frame height, not a measured menu bar height:
the real height varies by Mac (24pt ordinarily, ~38pt with the notch), and a
recording gets edited long after the display it was made on might be
disconnected or swapped out. 4% comfortably covers every real menu bar with
margin, while staying tight enough that ordinary near-the-top content — a
browser's tab strip, a toolbar — sits below it. For a region recording this
mostly doesn't come up at all: a menu-bar click almost always lands outside the
captured region, and already gets filtered out by the existing `focusX/focusY`
bounds check before this logic ever sees it.

**The blueprint has to keep it, even though the timeline doesn't.** The first
version dropped the trailing click inside the shared generation function
entirely — which meant it vanished from *both* the live timeline and the wand
tool's "what would auto-zoom generate" comparison, leaving no way to get it
back if the heuristic guessed wrong. Fixed by threading an
`excludingTrailingMenuBarClick` flag through instead: `regenerateAutoZooms()`
passes `true` (it shouldn't land on the timeline), `autoZoomBlueprint()` passes
`false` (the wand tool needs the full picture to compare against). Since the
wand already treats "in the blueprint but not on the live timeline" as
`.removed` — the same state a zoom the user deleted by hand ends up in — this
needed no new UI at all: the excluded click shows up there with the same
one-click restore as anything else.

**Pulled out into `AutoZoomGenerator`**, a pure function taking clicks,
settings, duration and the existing segments — no `EditorModel` involved. Two
reasons: `EditorModel`'s relevant state (`log`, `duration`) is genuinely
private, so nothing outside `EditorModel.swift` could exercise this logic
directly to test it; and it's the same shape `TranscriptAnalysis` already used
for exactly this reason. `EditorModel.buildAutoZooms` is now a five-line
wrapper.

Four checks, directly against the generator, no session or export needed: the
trailing menu-bar click is missing from the live result but present in the
blueprint; the identical click earlier in the same recording (not trailing) is
left alone; and an ordinary trailing click away from the menu bar survives.
